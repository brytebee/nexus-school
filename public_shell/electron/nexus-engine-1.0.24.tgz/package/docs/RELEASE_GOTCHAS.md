# Nexus School OS — Release Gotchas & Known Issues

> **Purpose:** Lessons learned from every release cycle. Read this BEFORE starting any new
> release. Each entry has the root cause, the exact error seen, and the verified fix.
>
> **Last updated:** 2026-07-10
> **Maintained by:** @brytebee

---

## ⚠️ MUST-CHECK BEFORE EVERY RELEASE

### 1. Engine Tarball — `file:` Symlinks Are FORBIDDEN by electron-builder

**When it breaks:** Every time you try to use a `file:` path to the engine that is a symlink
or resolves outside the `public_shell/electron/` project root.

**Error seen:**
```
Error: ENOENT: no such file or directory
Cannot pack a dependency that is outside the project root (file:../../private_engine)
```

**Root cause:** electron-builder resolves symlinks before packaging. Any `file:` path that
lands outside the project root directory is silently excluded or throws.

**Verified fix:**
```bash
# In private_engine/:
npm pack
# → produces nexus-engine-X.Y.Z.tgz

# Copy to electron shell:
cp nexus-engine-X.Y.Z.tgz ../public_shell/electron/

# Update package.json dependency:
# "@nexus/engine": "file:nexus-engine-X.Y.Z.tgz"

# Reinstall:
cd ../public_shell/electron && npm install

# Delete the OLD tarball:
rm nexus-engine-OLD.tgz
```

> ✅ ONLY use `file:nexus-engine-X.Y.Z.tgz` (tarball in same dir). Never `file:../../private_engine`.

---

### 2. main.js Import Crash on Startup (Production Only)

**When it breaks:** Any time you add a `require()` or `import` in main.js using a
relative path to `private_engine/` that works in dev but breaks in the packaged app.

**Error seen (production console / crash log):**
```
Error: Cannot find module '../../private_engine/src/result-dispatcher'
```

**Root cause:** In the packaged ASAR, the working directory is not the project root.
Relative paths like `../../private_engine/` simply don't exist. The engine code is
inside `node_modules/@nexus/engine/`.

**Verified fix:** Always import engine modules via the package scope, never by path:
```js
// ❌ BROKEN in production:
require('../../private_engine/src/result-dispatcher')

// ✅ CORRECT:
require('@nexus/engine/src/result-dispatcher')
```

**How to check before releasing:** Search main.js for any `../../private_engine` references:
```bash
grep -n "private_engine" public_shell/electron/main.js
```
Should return zero results.

---

### 3. `@napi-rs/canvas` / DOMMatrix Crash on Linux

**When it breaks:** Linux builds only. The `receipt-analysis` module uses `canvas` for
PDF parsing. Linux native bindings for `@napi-rs/canvas` are cross-compiled from macOS
and may not load properly under the ASAR on Linux.

**Error seen (Linux terminal on launch):**
```
Error: DOMMatrix is not defined
TypeError: Cannot read properties of undefined (reading 'createCanvas')
```

**Root cause:** Native `.node` bindings packaged inside ASAR cannot be loaded by
`dlopen()` on Linux. The binding file must be extracted outside the ASAR archive.

**Verified fix in `public_shell/electron/package.json`:**
```json
"build": {
  "asarUnpack": [
    "node_modules/@napi-rs/canvas/**/*",
    "node_modules/better-sqlite3/**/*"
  ]
}
```

**Also required:** Wrap the `receipt-analysis` require in a try-catch in `main.js` so
a canvas failure doesn't crash the whole app:
```js
try {
  receiptAnalysis = require('@nexus/engine/src/receipt-analysis');
} catch(e) {
  console.warn('[Engine] receipt-analysis unavailable:', e.message);
}
```

**Long-term fix (V2):** Set up a Linux CI runner (`ubuntu-latest` GitHub Actions) to
build Linux targets natively — see `docs/tasks/version2_dev.md §4.3`.

---

### 4. AppImage Requires FUSE — Fails on Most Linux Systems

**When it breaks:** Every time a Linux user tries to run the AppImage on a standard
Ubuntu/Debian system.

**Error seen:**
```
dlopen(): error loading libfuse.so.2
AppImages require FUSE to run.
```

**Root cause:** AppImage uses FUSE to mount itself as a filesystem. Most Ubuntu live
sessions and minimal installs do not have `libfuse.so.2` installed. FUSE 3 does not
provide `libfuse.so.2` — only FUSE 2 does.

**Workaround used:**
```bash
# Extract and run without FUSE:
./"Nexus School OS-1.0.1.AppImage" --appimage-extract
./squashfs-root/AppRun
```

**Recommended approach for clients:** Always deliver the `.deb` package, not the AppImage.
```bash
sudo dpkg -i nexusschoolos_1.0.1_amd64.deb
# Then launch: nexusschoolos
```

**Note in PRODUCTION.md:** Update the delivery guide to say `.deb` is the primary Linux
installer. AppImage is provided for advanced users only and requires FUSE.

---

### 5. Boot Screen Ordering — Wrong Screen on First Install

**When it broke:** v1.0.1 — first install on all platforms.

**Symptom:** On first launch after install (no license file), the app showed the admin
login screen (PIN pad with "No admins configured") instead of the license activation screen.

**Root cause:** `licenseStatus` defaulted to `{ locked: false }` at module scope.
The `loadFile('lock.html')` call ran before the license verification block (Phase 4),
so the window loaded with no hash and displayed the login UI.

**Verified fix (applied in v1.0.2):**
1. Added a synchronous file-existence pre-check immediately before `loadFile()`:
```js
const _earlyLicensePath = path.join(app.getPath('userData'), 'license.nexus');
if (!fs.existsSync(_earlyLicensePath)) {
  licenseStatus = { locked: true, reason: 'no_license', message: 'NO_LICENSE' };
}
```
2. Added `api.onLicenseStatus()` IPC listener in `lock.html` as a fallback for
   expired licenses (where the file exists but content has expired — the early check
   does not cover this; Phase 4 catches it and the IPC updates the UI).

**Check before releasing:** Test on a fresh OS user profile (no `userData` dir) to
confirm the activation screen is the very first thing shown.

---

### 6. License Activation Screen Was a Dead-End

**When it broke:** v1.0.1 — `lock.html#invalid` showed "No License Found" + a
"Contact Support" mailto button. No way to actually import a license within the app.

**Symptom:** School admin on first launch sees the locked screen but can't do anything
except send an email — they cannot import the `.nexus` license file.

**Verified fix (applied in v1.0.2):**
- `lock.html` `renderLockScreen('invalid')` and `renderLockScreen('expired')` now show:
  - **"📂 Import License File"** → calls `api.invoke('license:import')` → file picker →
    copies `.nexus` to userData → calls `api.invoke('app:relaunch')`
  - **"🌐 Activate Online"** → calls `api.invoke('license:activate-online')` → opens
    portal with hardware ID pre-filled
- Added `ipcMain.handle('app:relaunch')` in main.js for clean restart after import.

---

### 7. License Public Key — Inconsistency in Personal Data Docs

**Risk:** ⚠️ VERIFY BEFORE ISSUING ANY NEW LICENSES

**Issue:** The personal data file `licence-keys.md` (at `/Users/MAC/Documents/Projects/nexus-personal-data/`) documents two different public keys from two separate keypair generation sessions.

**The authoritative key embedded in `main.js` (fallback):**
```
3a963a04b3da96bd402eb5d8a4ffd200e8c695f9fa4633c789649fa188db0daa
```

This is the **last 32 bytes** of the 128-char signing key stored in the personal data:
```
b99b19bd9235977dae4393b40c46d0ac3173314736e2008fc1af4ec529cca58d  ← seed (32 bytes)
3a963a04b3da96bd402eb5d8a4ffd200e8c695f9fa4633c789649fa188db0daa  ← public key (32 bytes)
```
In `tweetnacl`, `kp.secretKey` (64 bytes) = `seed + publicKey`. The fallback in main.js
is derived correctly from the signing key.

**The `8b0233eff...` key in `licence-keys.md` is from an EARLIER generation attempt
that was discarded.** It does NOT match the signing key used in production.

**Rule:** The `.env` file MUST have `NEXUS_LICENSE_PUBLIC_KEY=3a963a04...` so the app
always uses the correct key. Never set it to `8b0233eff...`.

**Check before releasing:**
```bash
grep NEXUS_LICENSE_PUBLIC_KEY public_shell/electron/.env
# Must output: NEXUS_LICENSE_PUBLIC_KEY=3a963a04b3da96bd402eb5d8a4ffd200e8c695f9fa4633c789649fa188db0daa
```

---

### 8. Windows Build on Mac — Cross-Compilation Caveat

**Note from PRODUCTION.md:** "Never build the Windows installer on a Mac" because
`better-sqlite3` must be compiled on the target OS.

**Reality:** electron-builder's `@electron/rebuild` step downloads prebuilt binaries
for `better-sqlite3` when building for Windows on macOS. This WORKS for standard
64-bit x64 Windows targets as long as prebuilts are available for the Electron version.

**Risk:** If a prebuilt binary is not available for the exact Electron version, the build
will fail or produce a broken installer. The app may crash on launch on Windows with:
```
A dynamic link library (DLL) initialization routine failed.
```

**Mitigation:** Test the Windows EXE on an actual Windows machine before distributing
to clients. Do not assume a successful build = working app.

---

### 9. `chmod -x` Trap on Linux

**When it broke:** v1.0.1 — admin accidentally ran `chmod -x` (remove execute) instead
of `chmod +x` (add execute) on the AppImage.

**Symptom:** AppImage silently does nothing when double-clicked. No error shown.

**Correct command to make AppImage executable:**
```bash
chmod +x "Nexus School OS-1.0.1.AppImage"
./"Nexus School OS-1.0.1.AppImage" --no-sandbox
```

> Again: prefer the `.deb` — it handles permissions automatically.

---

### 10. `.deb` install — Desktop Entry Delay

**When it breaks:** After `sudo dpkg -i *.deb`, the app doesn't immediately appear in
the application menu/launcher.

**Cause:** `update-alternatives` and `desktop-file-utils` triggers run post-install but
the desktop database refresh may not apply immediately in the current session.

**Fix:**
```bash
# Force desktop database refresh:
sudo update-desktop-database
# Or: log out and back in
```

---

## Release Verification Protocol

Run these checks on every platform BEFORE sending to a client:

| Check | Command / Action |
|---|---|
| No private_engine relative imports in main.js | `grep -n "private_engine" public_shell/electron/main.js` → 0 results |
| Correct public key in .env | `grep NEXUS_LICENSE_PUBLIC_KEY public_shell/electron/.env` |
| All tests pass | `npm run test` → 258/258 (or current count) |
| Fresh install test (no license) | Delete userData dir, launch app — must show activation screen |
| License import works | Import a `.nexus` file from activation screen — must restart and unlock |
| Login works after license | Select admin, enter PIN — must load dashboard |
| Linux: use `.deb` not AppImage | Install `.deb` on Ubuntu VM, confirm launch via terminal |
| Windows EXE: test on real Windows | Launch on Windows 10/11, confirm no DLL errors |
| macOS: Gatekeeper | Right-click → Open on first launch (no code signing yet) |

---

## Version History of Issues

| Version | Issue | Status |
|---|---|---|
| v1.0.0 | file: symlink blocked by electron-builder | Fixed in v1.0.1 |
| v1.0.0 | main.js relative import crash (result-dispatcher) | Fixed in v1.0.1 |
| v1.0.0 | @napi-rs/canvas DOMMatrix crash on Linux | Fixed in v1.0.1 (asarUnpack) |
| v1.0.1 | AppImage requires FUSE | Mitigated: use .deb |
| v1.0.1 | Boot shows login instead of activation on first install | Fixed in v1.0.2 |
| v1.0.1 | Activation screen had no import button (dead-end) | Fixed in v1.0.2 |
| v1.0.1 | Public key inconsistency in personal docs | Documented — verify before issuing licenses |
| v1.0.1 | chmod -x trap (Linux) | Documented |
| v1.0.1 | .deb desktop entry delay after install | Documented |

---

### 11. Dual Calendar — TWO Files Must Stay in Sync

**Risk:** ⚠️ LICENSES SILENTLY EXPIRE EARLY if out of sync

The Nigerian academic calendar is duplicated in two places that **must always match**:

| File | Used by |
|---|---|
| `nexusos/src/lib/calendar.ts` | Sovereign portal term generator + onsite form |
| `public_shell/electron/main.js` (line ~5560) | Electron offline license verifier |

**When it breaks:** If you add a new session (e.g. `2028/2029`) to `calendar.ts` but forget `main.js`,
the portal will issue licenses with `2028/2029-T1` terms but the desktop app won't recognise them.
The license will appear expired immediately on every install.

**The rule:** Any time you touch one calendar, touch the other in the same commit.

**Check before releasing:**
```bash
# Both should list the same sessions:
grep "'20[0-9]" nexusos/src/lib/calendar.ts
grep "'20[0-9]" nexus-school/public_shell/electron/main.js
```

**Current state (as of 2026-07-10):** Both files contain `2024/2025`, `2025/2026`, `2026/2027`, `2027/2028`.

**Long-term fix (V2):** Move the calendar to a shared package imported by both projects.

---

### 12. Ed25519 Key Type Bug — Every License Appeared as "Tampered" *(Fixed v1.0.1)*

**Symptom:** Importing any valid `.nexus` license file showed **"License Integrity Error"** immediately.

**Root cause:** `crypto.createPublicKey({ format: 'raw', type: 'spki' })` was used in `verifyNexusToken()`.
- `type: 'spki'` requires a DER-encoded key structure and throws a `TypeError` when given a raw 32-byte buffer.
- Attempting to fix it by changing `type` to `'ed25519'` with `format: 'raw'` also failed. Node.js silently ignores the `type` parameter when `format` is `'raw'`. It generated an unusable key object, causing `crypto.verify()` to return `false`.

**Verified fix (Commit `395e4bb`):** Prepend the 12-byte Ed25519 SPKI ASN.1 DER header to the raw 32-byte public key buffer, then load as DER/spki format:
```javascript
const SPKI_ED25519_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
const spkiDer = Buffer.concat([SPKI_ED25519_PREFIX, pubKey]);
const keyObj = crypto.createPublicKey({ key: spkiDer, format: 'der', type: 'spki' });
```

**Pre-release check:**
```bash
grep -A 3 "SPKI_ED25519_PREFIX" public_shell/electron/main.js
# Must show the DER prefix buffer concat and format: 'der', type: 'spki'
```

---

### 13. First-Run DB Timing Bug — PIN Screen Shown with Zero Admins *(Fixed v1.0.1)*

**Symptom:** On a completely fresh install, importing a valid license loaded the standard PIN lock screen instead of the Admin Setup Wizard, resulting in a dead end.

**Root cause:** The startup routine check `SELECT COUNT(*) FROM admin_users` ran before the database/tables had been initialized by Phase 4.
- The query threw a table-not-found error.
- The catch block in `main.js` did not handle the error by routing to the setup page; it simply logged a warning and defaulted `bootFile` to `lock.html`.

**Verified fix (Commit `7264eb5`):** Update the catch block to default to `firstRun=1` (`dist/renderer.html`) if the database query fails. On first launch, a database query error always implies that the database is uninitialized (fresh install).

---

### 14. Native C++ Modules Target Mismatch — "invalid ELF header" *(Fixed v1.0.1)*

**Symptom:** The packaged Linux `.deb` installs correctly but crashes instantly on launch with:
```
[Database] Error detail: .../better_sqlite3.node: invalid ELF header
Failed to load/save identity.json or initialize DB Error: .../better_sqlite3.node: invalid ELF header
```

**Root cause:** `better-sqlite3` and `@napi-rs/canvas` are native C++ modules.
- When running `electron-builder --linux` on a macOS host, standard dependencies are recompiled by `@electron/rebuild`.
- Because the compiler runs on macOS, it builds Mach-O binaries for the host OS instead of ELF binaries for the target Linux OS.

**Verified fix:**
- **Short-term:** Download the pre-built Linux x64 ELF module matching the Electron version ABI (e.g. Electron ABI v116 for Node v20/v21) from the package's GitHub releases. Inject it manually into `./node_modules/better-sqlite3/build/Release/better_sqlite3.node` and package with `"npmRebuild": false` set in `package.json` to prevent electron-builder from overwriting it.
- **Long-term:** Run the build on a Linux runner (e.g. Github Actions using `ubuntu-latest`), or run the build on the Mac inside a Linux Docker container (using OrbStack/Docker Desktop).

