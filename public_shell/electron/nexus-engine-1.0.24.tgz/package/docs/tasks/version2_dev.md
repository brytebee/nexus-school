# Nexus School OS — Version 2 Development Plan

> **Status**: Planning
> **Target**: Migrate the Electron UI from dual-stack (vanilla HTML + React) to a
> single unified React application, and resolve all known architectural debt.

---

## Context

The current app ships two parallel UI stacks:

| File | Stack | Purpose |
|---|---|---|
| `lock.html` | Vanilla HTML/JS (762 lines) | Boot/lock/activation screen |
| `index.html` | Vanilla HTML/JS | Main dashboard |
| `dist/renderer.html` | React + Vite | New React dashboard (partial) |

Electron's `createWindow()` loads either `lock.html → index.html` or
`lock.html → dist/renderer.html` depending on `USE_REACT_UI`. This creates:
- Flash transitions between files (full page reload)
- Duplicated auth logic in two places
- No shared state between screens
- Growing maintenance cost as features are added to both stacks

---

## Goal

One entry point. One React app. All screens are components.

```
Electron starts
  └─ loadFile('dist/renderer.html')  ← always, no conditionals
       └─ React renders <BootGate />
            ├─ No license     → <ActivationScreen />
            ├─ Expired        → <RenewalScreen />
            ├─ Locked         → <LockedScreen reason={...} />
            ├─ Valid, no auth  → <LockScreen />   (PIN/password login)
            └─ Valid + session → <App />           (full dashboard)
```

Zero `loadFile` calls after the initial one. All screen transitions are React
state changes — instant, animated, no flash.

---

## Phase 1 — Boot Gate & Auth Screens (Replace lock.html)

### New files
```
src/
├── boot/
│   ├── BootGate.tsx          — top-level screen router
│   ├── ActivationScreen.tsx  — no license (replaces lock.html#invalid)
│   ├── RenewalScreen.tsx     — expired license (replaces lock.html#expired)
│   ├── LockedScreen.tsx      — tampered/revoked/hardware_mismatch
│   └── LockScreen.tsx        — PIN/password login (replaces lock.html default)
└── main.tsx                  — updated entry: render <BootGate /> not <App />
```

### BootGate.tsx logic
```tsx
// On mount:
// 1. api.getLicenseStatus() → determines which locked screen (if any)
// 2. api.auth.getSession()  → determines if already authenticated
// 3. Renders the appropriate screen
// All transitions are instant React state — no loadFile(), no flash
```

### LockScreen.tsx
- Port the PIN numpad + admin selector from `lock.html`
- Add password auth mode (already in lock.html, port as-is)
- Add `ForgotPIN` flow as a modal (already in lock.html, extract to component)
- On successful auth: transition to `<App />` via state, not via `loadFile`

### ActivationScreen.tsx / RenewalScreen.tsx
- "Import License File" → `api.license.importFile()` → `api.invoke('app:relaunch')`
- "Activate Online" → `api.license.activateOnline()`
- Hardware ID display (for support reference)
- Link to portal

### main.js changes
- Remove `mainWindow.loadFile('lock.html', loadOptions)` entirely
- Replace with `mainWindow.loadFile('dist/renderer.html')` always
- Remove the `DEV_AUTO_LOGIN` / `bootFile` decision tree (now handled in React)
- Keep the early `licenseStatus` pre-check — send it via `did-finish-load`
- The `app:relaunch` handler stays — still needed after license import

---

## Phase 2 — Migrate index.html Dashboard to React

The main dashboard (`index.html`) is a large vanilla JS single-page app.
Migrate incrementally, view-by-view:

### Migration order (low to high complexity)
Most views already exist in `src/views/` — the work is wiring + cleanup:

1. `Dashboard.tsx` ✓ exists
2. `Students.tsx` ✓ exists
3. `Teachers.tsx` ✓ exists
4. `Classes.tsx` ✓ exists
5. `Attendance.tsx` ✓ exists
6. `FinancialHub.tsx` ✓ exists
7. `NexusPulse.tsx` ✓ exists
8. `ResultStudio.tsx` ✓ exists
9. `Settings.tsx` ✓ exists
10. `PrintHub.tsx`, `SyncHub.tsx`, `CbtArena.tsx` ✓ exist

Primary work for each view:
- Wire into unified router/nav (no page reloads)
- Replace raw `window.electronAPI.*` calls with typed React hooks
- Remove the parallel vanilla implementation from `index.html`

### Shared layout
```
src/
├── layout/
│   ├── AppShell.tsx     — sidebar + topbar + content area
│   ├── Sidebar.tsx      — nav items, tier badges, pulse status dot
│   └── Topbar.tsx       — school name, session, admin avatar, lock button
```

### State management
React Context + useReducer (no external library needed):
```
src/
├── context/
│   ├── AuthContext.tsx     — session, logout, lock
│   ├── LicenseContext.tsx  — licenseStatus, tier gates
│   └── IdentityContext.tsx — school name, logo, term config
```

### Typed IPC hooks
Components never call `api.invoke()` directly:
```
src/
├── hooks/
│   ├── useLicense.ts
│   ├── useAuth.ts
│   ├── useStudents.ts
│   ├── useFinancial.ts
│   └── ...
```

---

## Phase 3 — Remove Dual Stack

Once Phase 1 and 2 are complete:

1. Delete `lock.html`
2. Delete `index.html`
3. Remove `USE_REACT_UI` env var and all conditional checks in `main.js`
4. Remove the `bootFile` / `loadFile` switching logic entirely
5. Remove the early `no_license` pre-check (BootGate handles it via IPC)
6. `"start": "electron ."` — no flags, no conditions

---

## Phase 4 — Additional V2 Features

### 4.1 First-time Setup Wizard
**Problem**: After license activation, if no admin exists, the app shows
"No admins configured" + PIN pad — a dead end.

**Solution**: After BootGate confirms license valid + no admins, render `<SetupWizard />`:
- Step 1: School identity (name, logo, address, contact)
- Step 2: Create first Superadmin (username + PIN/password)
- Step 3: Class structure (upload CSV or manual entry)
- Step 4: Done → `<LockScreen />`

### 4.2 Slug Registration Flow
**Problem**: Portal slug is self-assigned in Settings with no uniqueness check.

**Solution**: During setup wizard (Step 1), add slug field with live validation:
- Call `nexus-api /api/slug/check?slug=X` before saving
- Show availability status (✅ Available / ❌ Taken)
- Save confirmed slug to `app_settings` + identity packet

### 4.3 Linux Native Build
**Problem**: `@napi-rs/canvas` cross-compiled from macOS; Linux binary unreliable.
Results in `DOMMatrix` warning and try-catch workaround in `receipt-analysis.js`.

**Solution**: Add a GitHub Actions workflow (`build-linux.yml`) using
`ubuntu-latest` runner to build Linux targets natively:
```yaml
- runs-on: ubuntu-latest
- run: npm run dist:linux
```
This eliminates the try-catch guard and the `asarUnpack` workaround for canvas.

### 4.4 Code Signing
| Platform | Certificate | Effect |
|---|---|---|
| macOS | Apple "Developer ID Application" | Removes Gatekeeper warning |
| Windows | EV code signing certificate | Removes SmartScreen warning |
| Linux | GPG sign `.deb` | Enables apt repo distribution |

Store certs as GitHub Actions secrets. Use `CSC_LINK` / `CSC_KEY_PASSWORD` env
vars with electron-builder's built-in signing support.

### 4.5 Auto-Update UX
**Current**: Update downloaded silently; user must go to Help → Check for Updates.

**V2**: Non-intrusive toast notification when `update:ready` IPC fires:
```tsx
// Already have the IPC event — just needs the UI component
api.updater.onUpdateReady(() => showToast('Update ready — restart to install'));
```

### 4.6 Role-Based Access Control (RBAC)

**Problem**: The `role_level` column exists in `admin_users` and is set at account
creation, but nothing in the UI or IPC layer reads it to restrict access.
Every authenticated user — regardless of whether they are the Superadmin or a
form teacher — sees and can operate the full dashboard.

#### Role level definitions

| `role_level` | Role name | Intended scope |
|---|---|---|
| `9` | **Superadmin** | Full access. Can wipe data, manage all admins, and access every module. Only Superadmin accounts can be created during the Setup Wizard. |
| `7` | **Principal / Head** | Read-only across all modules. Can approve/reject grade remarks. Cannot edit fee structures or wipe data. |
| `5` | **Bursar / Finance Officer** | Full Financial Hub access. No access to Result Studio, CBT Arena, or Settings. |
| `3` | **Form Teacher / Class Admin** | Read/write access only to their assigned class — attendance, grades, and student profiles. No financial access. |
| `1` | **Viewer / Staff** | Read-only across Students and Attendance. No write access. |

#### Implementation layers

RBAC must be enforced at **two independent layers** — UI gating alone is not
sufficient because any admin with DevTools access can call IPC handlers directly.

**Layer 1 — UI (sidebar + view):**
The `AuthContext` exposes the current admin's `role_level`. `AppShell.tsx`
filters the sidebar nav items based on a `minRole` property declared on each
route:
```tsx
const navItems = ALL_NAV_ITEMS.filter(item => session.role_level >= item.minRole);
```
Views that the user cannot access are simply not rendered (no route exists for
them in the current session). Attempting to navigate there returns to Dashboard.

**Layer 2 — IPC (backend enforcement):**
Destructive and sensitive IPC handlers (`reset-app-data`, `fees:update-structure`,
`results:publish`, `admin:create`, etc.) must read the calling admin's
`role_level` from the active session and reject calls below the minimum:
```javascript
// Example guard pattern (main.js / ipc handlers)
if (session.role_level < REQUIRED_ROLE) {
  return { ok: false, error: 'Insufficient permissions.' };
}
```
The session's `role_level` is stamped at login and stored in a main-process
variable — it is never trusted from the renderer directly.

#### nav item minimum role table (proposed)

| Module | `minRole` |
|---|---|
| Dashboard | 1 |
| Students | 3 |
| Teachers | 5 |
| Classes | 5 |
| Attendance | 3 |
| Financial Hub | 5 |
| Nexus Pulse | 7 |
| Result Studio | 3 |
| CBT Arena | 5 |
| Print Hub | 3 |
| Sync Hub | 7 |
| Settings | 9 (Superadmin only) |

> **Note**: Settings (which contains wipe, license, identity, and admin
> management) is restricted to `role_level = 9` only. A Bursar or Form
> Teacher must never reach the reset or admin-creation controls.

#### New files
```
src/
├── context/
│   └── AuthContext.tsx     — add role_level to session shape; expose hasRole(min) helper
├── components/
│   └── RoleGate.tsx        — wrapper component: <RoleGate min={5}>...</RoleGate>
layout/
└── AppShell.tsx            — filter navItems by session.role_level
```

#### IPC handlers to add role guards
- `reset-app-data` — require level 9
- `admin:create` / `admin:delete` — require level 9
- `fees:update-structure` / `fees:update-settings` — require level 5
- `results:publish` — require level 7
- `identity:save` — require level 9
- `license:import` — require level 9

### 4.7 Local Ad Packaging & Rendering (Offline-First)

**Problem**: The application renders sponsored ads from third-party networks inside the `<AdModal />` component using YouTube video streams. Under slow network conditions, the iframe takes a long time to buffer, rendering a spinner and blocking the user interface until the 10-second safety timeout unlocks the skip button. In full offline mode, the iframe fails to load completely.

**Solution**: Package lightweight, static local ad assets (e.g., compressed images or offline videos) directly inside the Electron app wrapper and display them instantly as fallbacks if the network request fails or times out.
- **Offline detection**: Update `prefetchAds()` in `main.js` to immediately use the local asset fallback if `navigator.onLine` is false or the ping to the ad API times out (reduce timeout limit to 2.5s for faster local rendering).
- **Asset Packaging**: Store fallback images inside the packaged assets folder (e.g., `public_shell/electron/assets/ads/`).
- **Render fallback**: Update `<AdModal />` to detect if the YouTube embed failed to load, and fall back to rendering local static `<img>` or `<video>` elements with a local skip timer.

---

## Dependency / Tooling Cleanup

| Item | Action |
|---|---|
| `nexus-engine-1.0.X.tgz` committed to git | Add `nexus-engine-*.tgz` to `.gitignore`; pack fresh in CI |
| `private_engine` as embedded folder | Evaluate npm workspace or proper monorepo setup |
| `@electron/rebuild` in devDependencies | Remove — electron-builder includes it |
| 868 kB bundle chunk size warning | Add code splitting in `vite.config.ts` for large views |
| `index.html` (vanilla) | Delete after Phase 2 complete |
| `lock.html` (vanilla) | Delete after Phase 1 complete |

---

## Commit Convention for V2 Work

```
feat(boot): add BootGate component with license-aware screen routing
feat(lock): migrate LockScreen to React with PIN + password auth
feat(activation): add ActivationScreen and RenewalScreen components
refactor(main): remove loadFile switching, always load renderer.html
feat(setup): add first-time setup wizard (identity + first admin)
feat(slug): add slug availability check in setup wizard
chore: delete lock.html and index.html after full migration
ci: add ubuntu-latest workflow for native Linux builds
```

---

## Notes

- `dist/renderer.html` is already built with Vite 8 — no tooling changes for Phase 1/2
- All IPC bridges are already in `preload.js` — no new `contextBridge` additions needed
- `licenseStatus` is already sent via `did-finish-load` and the `ui-ready` handler
- The `app:relaunch` IPC handler added in v1.0.x stays — needed after license import
- The early `no_license` pre-check in `main.js` can be removed in Phase 3 (React handles it)

---

## Production Issues Resolved in v1.0.1

Three boot/license bugs were found and fixed during QA before production rollout.
The full technical post-mortem — including root causes, broken patterns to avoid,
and a diagnostic checklist — is in:

📄 **[`docs/sovereign/screen-flow.md`](../sovereign/screen-flow.md)**

**Summary of fixes:**

| Commit | Bug | Impact |
|---|---|---|
| `395e4bb` | `crypto.createPublicKey({ format: 'raw', type: 'spki' })` throws — wrong key type for raw Ed25519 buffer | Every valid license showed "License Integrity Error" |
| `395e4bb` | `type: 'ed25519'` is silently ignored when `format: 'raw'` — Node.js has no algorithm context | Same symptom, different failure mode |
| `395e4bb` | **Fix:** Prepend 12-byte SPKI DER header (`302a300506032b6570032100`) before importing as `format: 'der', type: 'spki'` | License verification now works correctly |
| `7264eb5` | First-run `catch` block kept `bootFile = 'lock.html'` when the DB query failed on fresh install | PIN login screen shown with no admins — dead end |
| `7264eb5` | **Fix:** Any DB failure in the admin-count check defaults to `firstRun=1` (setup wizard) | Admin Setup Wizard shown correctly on first launch |

> These fixes directly inform **Phase 1** and **Phase 4.1** of this plan — when
> `BootGate.tsx` is built, it must handle the same edge cases: provisional license
> with no hardware binding, and no-admin detection before showing any auth screen.
