# Onsite / Cash Payment Bypass Guide

> **For operator eyes only.** This playbook covers the operational procedures for manually onboarding a client school that pays via Cash, Bank Transfer, or Cheque locally. It bypasses the standard online Paystack checkout flow, issues their license key, and updates their Portal status to Active.

---

## The Operational Flow

When onboarding a school using local cash or bank transfer, you have two pathways depending on whether the school has already registered on the online portal.

### Flow A: School Registers Online First (Recommended)

This is the cleanest approach because it ensures the school sets their own admin credentials and claims their unique URL slug first.

1. **Instruct the Client**: Have the school administrator visit the portal and register their email and school name. They must verify their email with the 6-digit OTP code and select their permanent URL slug (e.g., `greenwood-academy`).
2. **Collect Payment**: Verify that the cash has been received or that the bank transfer has cleared.
3. **Generate the License**:
   * Log into the **Sovereign Console** and navigate to the **Onsite Setup & Sync Panel** at `nexusos.com.ng/sovereign/onsite`.
   * Fill out the form using their **exact registered email address**, school name, product (`sch`), target tier, and terms.
   * Input the cash amount collected.
   * Under **Payment Method**, select `Cash 💵` or `Bank Transfer 🏦`.
   * Click **Generate & Register License**.
   * Copy the generated license token or click **Download license.nexus** to download the activation file.
4. **Synchronize Records**: Click **Sync with Production** to push the local record to the central database. This associates the license directly with their registered email.
5. **Onsite Activation**: Deliver the `.nexus` license file to the school (via USB or email) to unlock their local desktop installation. Their online portal dashboard status will instantly update to **✅ Active**.
6. **First Admin Setup** *(happens automatically on the client's machine)*: After importing the license file the app restarts and detects that no admin account exists. It shows the **Admin Setup Screen** — the school's IT contact must complete two steps:
   - **Step 1 — Credentials**: Enter their **Admin Name**, set a numeric **PIN** (minimum 4 digits), confirm the PIN, and optionally add a phone number.
   - **Step 2 — Recovery**: Choose a **Security Question** and provide an answer (used to reset PIN if forgotten).
   - Click **Create Admin Account** — the app navigates to the login screen automatically.
7. **First Login**: The admin selects their name from the dropdown, enters their PIN, and accesses the dashboard. They can add more staff admins from **Settings → Admin Management**.


---

### Flow B: Pre-emptive Onboard (No Portal Account Yet)

If you are at the client school site and need to activate their desktop software immediately, but they have not yet set up an online portal account:

1. **Generate the License**:
   * Go to `/sovereign/onsite` on your operator machine.
   * Enter their intended school name and **their target admin email address**.
   * Fill out the tier, payment details, and click **Generate & Register License**.
   * Deliver the generated `license.nexus` file to unlock their desktop app immediately.
2. **Register Later**: When the client is ready to access their online portal dashboard, instruct them to sign up using the **same email address** you used in step 1.
3. **Automatic Link**: Once they claim their slug and finish logging in, the system will automatically discover the pre-existing license registered to their email. Their dashboard will show **✅ Active** with no checkout required.
4. **First Admin Setup** *(same as Flow A Step 6)*: On first launch after license import, the app detects no admin exists and shows the Admin Setup Screen. The school's IT contact creates their admin name, PIN, and security recovery question before accessing the dashboard.

---

## SQL Database Fallbacks

If the automated synchronizer fails to sync or you need to link an offline cash payment to a portal school account manually in the database:

### 1. Identify the School ID
Query the database to find the target school's internal ID:
```sql
SELECT id, name, email FROM "School" WHERE email = 'admin@greenwood.com';
```

### 2. Record the Cash Payment
Insert a manual payment record. **Crucial:** You must prefix the payment reference with `OFFLINE-` (e.g. `OFFLINE-CASH-101`) to prevent validation conflicts:
```sql
INSERT INTO "Payment" (id, school_id, reference, product, tier, student_count, term_count, amount_kobo, status, confirmed_at)
VALUES (
  'pay_manual_' || lower(hex(randomblob(4))), 
  'YOUR_SCHOOL_ID_HERE', 
  'OFFLINE-CASH-101', 
  'sch', 
  'gold', 
  500, 
  2, 
  14000000, -- Amount in Kobo (e.g. ₦140,000)
  'confirmed', 
  NOW()
);
```

### 3. Issue and Link the License
Insert the cryptographic license record linked to the manual payment:
```sql
INSERT INTO "License" (id, school_id, payment_id, product, tier, student_cap, licensed_terms, token, valid_until, status)
VALUES (
  'lic_manual_' || lower(hex(randomblob(4))), 
  'YOUR_SCHOOL_ID_HERE', 
  'YOUR_PAYMENT_ID_HERE', 
  'sch', 
  'gold', 
  500, 
  ARRAY['2026/2027-T1', '2026/2027-T2'],
  'YOUR_CRYPTOGRAPHIC_LICENSE_TOKEN_STRING',
  '2027-09-01 00:00:00',
  'active'
);
```

---

*Generated: 2026-07-07 | Sovereign Operations Team*
