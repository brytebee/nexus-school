const { google } = require('googleapis');
const crypto = require('crypto');
const axios = require('axios');

// Constants for Decryption
const ALGORITHM = 'aes-256-gcm';

/**
 * Main Webhook Handler (Vercel Serverless Function)
 */
module.exports = async (req, res) => {
    // 1. Webhook Verification (GET)
    if (req.method === 'GET') {
        const mode = req.query['hub.mode'];
        const token = req.query['hub.verify_token'];
        const challenge = req.query['hub.challenge'];

        if (mode && token === process.env.META_VERIFY_TOKEN) {
            console.log("[Pulse Cloud] Webhook Verified.");
            return res.status(200).send(challenge);
        }
        return res.status(403).send('Forbidden');
    }

    // 2. Message Handling (POST)
    if (req.method === 'POST') {
        const body = req.body;
        const value = body.entry?.[0]?.changes?.[0]?.value;

        // 2a. Handle Image Receipts
        if (value?.messages?.[0]?.type === 'image') {
            const msg = value.messages[0];
            const from = msg.from;
            const phoneId = value.metadata.phone_number_id;
            try {
                await handleReceiptUpload(from, msg.image.id, phoneId);
            } catch (err) {
                console.error("[Pulse Cloud] Receipt upload failed:", err.message);
                await sendWhatsAppMessage(from, phoneId, "⚠️ We couldn't save your receipt. Please try again or contact the admin.");
            }
            return res.status(200).send('EVENT_RECEIVED');
        }

        // 2b. Handle Text Queries
        if (value?.messages?.[0]?.type === 'text') {
            const msg = value.messages[0];
            const from = msg.from;
            const text = msg.text.body.toUpperCase().trim();
            const phoneId = value.metadata.phone_number_id;

            console.log(`[Pulse Cloud] Incoming text from ${from}: ${text}`);

            try {
                if (text.includes("RESULT") || text.includes("ATTENDANCE") || text.includes("FEE") || text.includes("PAY")) {
                    await handleQuery(from, text, phoneId);
                } else {
                    await sendWhatsAppMessage(from, phoneId, "👋 Welcome to the Nexus School Assistant.\n\nReply with:\n- *RESULT* to check grades\n- *ATTENDANCE* to check status\n- *FEE* to see balance\n- *PAY* to get payment instructions");
                }
            } catch (err) {
                console.error("[Pulse Cloud] Query failed:", err.message);
            }
            return res.status(200).send('EVENT_RECEIVED');
        }

        return res.status(200).send('EVENT_RECEIVED');
    }

    res.status(405).send('Method Not Allowed');
};

/**
 * Handles parent queries by fetching and decrypting Drive data
 */
async function handleQuery(parentPhone, queryType, phoneId) {
    // 1. Initialize Google Auth
    const auth = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET
    );
    auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });

    const drive = google.drive({ version: 'v3', auth });

    // 2. Find and download pulse_cache.enc
    const listRes = await drive.files.list({
        q: "name = 'pulse_cache.enc' and trashed = false",
        fields: 'files(id)',
    });

    if (listRes.data.files.length === 0) {
        throw new Error("pulse_cache.enc not found in Google Drive.");
    }

    const fileId = listRes.data.files[0].id;
    const fileRes = await drive.files.get({ fileId, alt: 'media' });
    const encryptedContent = fileRes.data;

    // 3. Decrypt data
    const decryptedData = decrypt(encryptedContent, process.env.PULSE_SECURITY_KEY);
    const pulseData = JSON.parse(decryptedData);

    // 4. Normalize parent phone for lookup (last 10 digits)
    const normalizedPhone = parentPhone.replace(/\D/g, '').slice(-10);
    const parentRecord = pulseData.parents[normalizedPhone];

    if (!parentRecord) {
        return await sendWhatsAppMessage(parentPhone, phoneId, "Sorry, your phone number is not registered for any student at our school. Please contact the admin.");
    }

    // 5. Generate Response
    let responseText = `👋 Hello! Here is the status for your child(ren) at ${pulseData.schoolName}:\n\n`;

    for (const student of parentRecord.students) {
        responseText += `👤 *${student.name}* (${student.class_name})\n`;
        
        if (queryType.includes("PAY") || queryType.includes("FEE")) {
            const f = student.fee_details;
            if (f && f.billed > 0) {
                const statusLabel = f.status.charAt(0).toUpperCase() + f.status.slice(1);
                responseText += `💰 Fee Status: *${statusLabel}*\n`;
                responseText += `   - Billed: ₦${f.billed.toLocaleString()}\n`;
                responseText += `   - Paid: ₦${f.paid.toLocaleString()}\n`;
                if (f.balance > 0) {
                    responseText += `   - *Outstanding: ₦${f.balance.toLocaleString()}*\n`;
                }

                if (queryType.includes("PAY") && f.balance > 0) {
                    responseText += `\n💳 *Payment Instructions:*\n`;
                    
                    const plans = pulseData.feeSettings?.installment_plans || [];
                    if (plans.length > 0) {
                        responseText += `_Installment Options:_\n`;
                        plans.forEach(p => {
                            const amount = Math.round(f.billed * (p.percent / 100));
                            responseText += ` • ${p.label}: ₦${amount.toLocaleString()}\n`;
                        });
                    }

                    const accounts = pulseData.feeSettings?.bank_accounts || [];
                    if (accounts.length > 0) {
                        responseText += `\n_Transfer to any account below:_\n`;
                        accounts.forEach(acc => {
                            responseText += `🏦 ${acc.bank}\n   ${acc.number} (${acc.name})\n`;
                        });
                    }

                    const ref = `NX-${student.id.slice(-4)}-${Date.now().toString().slice(-4)}`.toUpperCase();
                    responseText += `\n📌 Reference: *${ref}*\n`;
                    responseText += `\n_Once paid, please reply with a photo of your receipt._\n`;
                }
            } else {
                responseText += `💰 Fee Status: No outstanding balance.\n`;
            }
        }

        if (queryType.includes("ATTENDANCE")) {
            const present = student.attendance?.filter(a => a.status === 'Present').length || 0;
            const total = student.attendance?.length || 0;
            responseText += `📅 Attendance: ${present}/${total} days\n`;
        }

        if (queryType.includes("RESULT")) {
            responseText += `📊 Latest Results:\n`;
            (student.results || []).slice(-3).forEach(r => {
                responseText += ` - ${r.subject}: ${r.score}%\n`;
            });
        }
        responseText += `\n`;
    }

    await sendWhatsAppMessage(parentPhone, phoneId, responseText);
}

/**
 * Handles receipt image uploads from WhatsApp to Google Drive
 */
async function handleReceiptUpload(parentPhone, mediaId, phoneId) {
    // 1. Initialize Google Auth
    const auth = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET);
    auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
    const drive = google.drive({ version: 'v3', auth });

    // 2. Fetch Media URL from Meta
    const mediaRes = await axios.get(`https://graph.facebook.com/v18.0/${mediaId}`, {
        headers: { 'Authorization': `Bearer ${process.env.META_ACCESS_TOKEN}` }
    });
    const downloadUrl = mediaRes.data.url;

    // 3. Download Image Buffer
    const imageRes = await axios.get(downloadUrl, {
        headers: { 'Authorization': `Bearer ${process.env.META_ACCESS_TOKEN}` },
        responseType: 'arraybuffer'
    });

    // 4. Upload to Drive
    await drive.files.create({
        resource: {
            name: `Receipt_${parentPhone}_${new Date().toISOString().split('T')[0]}.jpg`,
            mimeType: 'image/jpeg'
        },
        media: {
            mimeType: 'image/jpeg',
            body: Buffer.from(imageRes.data)
        }
    });

    await sendWhatsAppMessage(parentPhone, phoneId, "✅ Thank you! Your payment receipt has been uploaded for verification. Our administrator will update your record shortly.");
}

/**
 * AES-256-GCM Decryption Logic
 */
function decrypt(encryptedText, key) {
    try {
        const [ivHex, authTagHex, encryptedHex] = encryptedText.split(':');
        const iv = Buffer.from(ivHex, 'hex');
        const authTag = Buffer.from(authTagHex, 'hex');
        const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(key, 'hex'), iv);
        decipher.setAuthTag(authTag);
        let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    } catch (err) {
        throw new Error("Decryption failed. Check your PULSE_SECURITY_KEY.");
    }
}

/**
 * Sends a WhatsApp message via Meta Graph API
 */
async function sendWhatsAppMessage(to, phoneId, text) {
    const url = `https://graph.facebook.com/v18.0/${phoneId}/messages`;
    await axios.post(url, {
        messaging_product: "whatsapp",
        to: to,
        type: "text",
        text: { body: text }
    }, {
        headers: { 'Authorization': `Bearer ${process.env.META_ACCESS_TOKEN}` }
    });
}
