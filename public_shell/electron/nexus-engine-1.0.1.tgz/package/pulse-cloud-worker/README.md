# Nexus Pulse Cloud Worker

This is the stateless serverless worker that powers the **Always-On Cloud Bridge** for Nexus Pulse.

## Deployment Instructions

1. **Deploy to Vercel**:
   - Push this directory to a GitHub repo.
   - Link the repo to [Vercel](https://vercel.com).
   - Set the following **Environment Variables**:
     - `PULSE_SECURITY_KEY`: (From your Nexus Desktop Hub)
     - `GOOGLE_CLIENT_ID`: (From Google Cloud Console)
     - `GOOGLE_CLIENT_SECRET`: (From Google Cloud Console)
     - `GOOGLE_REFRESH_TOKEN`: (Generated after account linking)
     - `META_ACCESS_TOKEN`: (Meta System User Token)
     - `META_VERIFY_TOKEN`: (Your secret verification word)

2. **Configure Webhook**:
   - URL: `https://your-app.vercel.app/api/webhook`
   - Verify Token: (Same as `META_VERIFY_TOKEN`)
   - Subscribe to: `messages`

## Architecture
- **Stateless**: No data is stored in the cloud. It reads from Google Drive on every request.
- **Secure**: All data is AES-256 encrypted at rest (in Drive). Decryption happens only in memory during the request.
