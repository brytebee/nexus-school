# 🚀 Nexus School OS — Version 2 Development Master Tracker

> Companion to `nexus_master_plan.md`. This file tracks every feature, engineering
> initiative, and infrastructure task for the V2 cycle in a single, scannable
> reference. Cross-references: `react-migration.md` (frontend architecture),
> `nexus_master_plan.md` (product strategy & business context).

---

## 📋 V1 Feature Audit: What Is Live Today

### ✅ Active Nav Items (fully working in production build)

| # | View Label | `data-view` | Tier Gate | JS Module(s) |
|---|---|---|---|---|
| 1 | Dashboard | `dashboard` | None | `dashboard.js` |
| 2 | Teachers | `teachers` | None | `teachers.js` |
| 3 | Students | `students` | None | `students.js` |
| 4 | Sync Hub | `sync` | None | `sync.js` |
| 5 | Print Hub | `printhub` | None | `printhub.js` |
| 6 | Result Studio | `result-studio` | None | `result-studio.js` |
| 7 | Attendance | `attendance` | 🥇 Gold | `attendance-ui.js` / `attendance.js` |
| 8 | Nexus Pulse | `pulse` | 🥇 Gold | `pulse-ui.js` |
| 9 | Financial Hub | `fees` | 🥇 Gold | `fees-ui.js` |
| 10 | Sovereign Portal | `portal` | 🥇 Gold | `portal-ui.js` |
| 11 | Portal Content | `portal-content` | 🥇 Gold | `portal-content-ui.js` |
| 12 | Nexus Scholar | `scholar` | 💎 Diamond | `scholar-ui.js` |
| 13 | CBT Arena | `cbt` | 💎 Diamond | `cbt-ui.js` / `cbt-ipc-handlers.js` |
| — | Settings | `settings` | None | `settings.js` |
| — | About | `about` | None | inline |

**Core engine modules (private_engine/src/):**
- `database.js` — SQLite init, schema migrations, all DB queries
- `report-compiler.js` — grade context, ranking engine, PDF HTML generation
- `scholar.js` — NexusScholar class (AI/analytics layer)
- `server.js` — Express LAN server, device pairing, sync endpoints

---

## 🔮 Coming Soon — Currently in Sidenav (SOON badge)

These have sidenav entries and stub views but **no working implementation yet**:

| Label | `data-view` | Pitch Doc Reference | Tier | Priority |
|---|---|---|---|---|
| ⚡ Live Quiz System | `live-quiz` | Slide 07 — Nexus Live Quiz Arena | 💎 Diamond | Phase 7 |
| 📈 Analytics Dashboard | `analytics` | Slide 05/08 — At-Risk flagging, WAEC prep | 💎 Diamond | Phase 7 |
| 📚 Notes Marketplace | `notes-marketplace` | Slide 06 — Revenue Stream 3 | 💎 Diamond | Phase 8 |
| 🎯 Skill Mastery | `skill-mastery` | Slide 08 — IEP-standard academic tracking | 💎 Diamond | Phase 7 |

---

## ⚠️ Missing — Promised to Customers, Not Yet in the App

Sold in the pitch document and tier descriptions but have **no nav entry** (not even coming soon):

| Feature | Where Promised | Tier | Phase | Notes |
|---|---|---|---|---|
| **Verified Student Public Profiles** | Pitch Slide 06, Gold plan | 🥇 Gold | 6 | Cloud-hosted shareable academic records |
| **Digital Assignment Hub** | Pitch Slide 08, Gold plan | 🥇 Gold | 6 | Teacher assigns, student/parent views |
| **Parent Portal (read view)** | Pitch Slide 08, Gold plan | 🥇 Gold | 5 | Parents view results on school LAN — `portal.html` serves this but no dedicated admin section for managing it |
| **Multi-Campus Sync** | Pitch Slide 08, Diamond plan | 💎 Diamond | 8 | Unified dashboard across branches |
| **Mobile Admin "Command Center"** | Master plan Phase 7 | 💎 Diamond | 7 | Principal's dedicated mobile app |
| **Biometric Staff Attendance** | Master plan Custom Features | Custom upsell | 7 | USB fingerprint scanner clock-in/out |
| **Dynamic Fee Reminders / Fee Pulse** | Master plan Custom Features | Custom upsell | 7 | On-demand WhatsApp fee blast |
| **Exam Hall Clearance QR** | Master plan Custom Features | Custom upsell | 7 | Green/Red gate for fee-cleared exam entry |

---

## 🆕 New Initiatives (V2 Additions — Not in V1 Plan)

### 1. 🏗️ React Migration (HIGHEST PRIORITY — ENGINEERING)

Full frontend architecture modernisation from 2,500-line `index.html` to
componentised React + Vite. This is the foundation every subsequent V2 feature
will be built on.

**See full plan:** `private_engine/docs/tasks/react-migration.md`

**Summary of approach:**
- Strangler-fig migration (no big-bang rewrite, no feature freeze)
- Phase 0: Vite + React scaffolding alongside existing `index.html`
- Phase 1: Shared design system (DataTable, Modal, StatusBadge, NavSidebar)
- Phase 2: Migrate views one at a time (12 views over 6 weeks)
- Phase 3: Portal HTML → React
- Phase 4: CBT as first-class React app

**React migration is a prerequisite for:** Roles system, Technician Console,
Live Quiz, Analytics Dashboard, all V2 features.

---

### 2. 🧪 Test Suite (Prerequisite to React Migration)

Guard all working V1 logic before any migration begins. Tests must pass in
both vanilla JS (current) and React (post-migration) — achieved by testing
pure logic modules that both layers consume.

**Framework:** Vitest (already installed via Vite)

**Test modules to be extracted and guarded:**

| Test File | Logic Being Tested | Source Location |
|---|---|---|
| `grading.test.js` | `getGradeInfo()`, A1–F9 scale lookup | `report-compiler.js` |
| `ranking.test.js` | `computeRankMap()`, dense ranking, tie handling | `report-compiler.js` |
| `subject-ranking.test.js` | `computeSubjectRankMap()`, per-subject class rank | `report-compiler.js` |
| `scoring.test.js` | Score aggregation, average, percent calculation | `report-compiler.js` (inline) |
| `fee-calculator.test.js` | Balance calc, `cleared/partial/unpaid` status | `fees-ui.js` (extract) |
| `tier-gates.test.js` | `canAccessView(tier, view)` gating | `nav.js` / `boot.js` (extract) |
| `attendance.test.js` | `computeAttendanceScore()`, days/total formula | `report-compiler.js` |
| `cbt-scoring.test.js` | Score tallying, time tracking, answer validation | `cbt-ipc-handlers.js` (extract) |

**Structure:**
```
public_shell/electron/
├── src/lib/              ← Extracted pure logic (new)
│   ├── grading.js
│   ├── ranking.js
│   ├── scoring.js
│   ├── fee-calculator.js
│   ├── tier-gates.js
│   └── attendance.js
└── tests/                ← Test suite (new)
    ├── grading.test.js
    ├── ranking.test.js
    └── ...
```

> **The migration contract:** A view passes its React migration check only
> when all tests for its logic still pass after the port.

---

### 3. 👥 User Roles & Role-Based Access Control (RBAC)

Multi-admin support within the desktop app. Currently all admins have
identical full access.

**Planned roles:**

| Role | Access |
|---|---|
| **Super Admin / Principal** | Full access to all views and settings |
| **Bursar** | Financial Hub + fee reports only |
| **Form Teacher** | Own class grades + attendance only |
| **Result Clerk** | Result Studio + Print Hub, no financial data |
| **IT Admin** | Sync Hub + device management only |

**Implementation considerations:**
- Role definitions stored in SQLite (`staff_roles` table)
- Role enforced at nav.js tier-gate level (same pattern as Silver/Gold/Diamond)
- Audit trail: every action tagged with staff_id + role
- Login: PIN or biometric per role (reuse existing biometric system)
- Must be built in React (ties directly to React migration Phase 1 NavSidebar component)

---

### 4. 🔧 Technician Console (Scoped License Management)

Field technicians who perform onsite installs need a way to generate and
deliver `license.nexus` files **without** receiving the Ed25519 signing secret
or access to the full `/sovereign` dashboard.

**Problem:** Giving a technician the signing key = unlimited, unaccountable
license generation. Giving them `/sovereign` access = exposure of all school
data and billing.

**Solution — Technician API Portal:**

A scoped web interface (can live under `/sovereign/technicians` or as a
separate subdomain) where:

1. Technician logs in with their own account (no sovereign session)
2. They fill in school details (name, tier, student count, terms)
3. The server generates and signs the license (secret never leaves server)
4. Every generation is logged: technician ID + timestamp + school + license hash
5. The owner can audit all technician-generated licenses from `/sovereign`

**Technician account capabilities:**
- ✅ Generate licenses for assigned schools
- ✅ View their own generation history
- ✅ Download the `license.nexus` file
- ❌ Cannot set pricing or discounts
- ❌ Cannot see other technicians' schools
- ❌ Cannot access billing, payments, or sovereign-level data

**Two delivery modes for edge cases:**
- **Online delivery:** Server emails/provides the `license.nexus` directly
- **Pre-generated:** Owner generates the file and hands it to the technician
  on USB for fully offline deployments

---

### 5. 📖 Onsite Installation Documentation

Guides for field technicians and school administrators. Both render in the
live docs portal.

| Doc | Audience | Location |
|---|---|---|
| **Onsite & Activation Guide (Admin)** | School admins | `docs/onsite-installation/sch.md` → `/portal/docs/onsite-installation` |
| **Onsite & Licensing Guide (Developer/Tech)** | Field technicians | `docs/onsite-installation/tech.md` → `/sovereign/docs/onsite-installation/tech` |

**Status:** ✅ Written and rendering in portal. See `nexusos` repo.

---

## 📅 Recommended V2 Build Order

```
[NOW]      1. Extract logic → src/lib/  +  Write test suite
           2. All tests green on vanilla JS

[PHASE R0] 3. React: Vite scaffold + .env toggle (USE_REACT_UI)
           4. React: Design system components

[PHASE R1] 5. React: Migrate views one-by-one (tests stay green throughout)

[PARALLEL] 6. Technician Console API (backend — no React dependency)
           7. RBAC schema + role definitions in DB

[PHASE R2] 8. React: RBAC-aware NavSidebar + role login screen

[PHASE R3] 9. Coming Soon features built in React from day one:
              - Live Quiz Arena
              - Analytics Dashboard
              - Notes Marketplace
              - Skill Mastery Tracking

[PHASE R4] 10. Missing Gold features:
               - Assignment Hub
               - Verified Student Public Profiles
               - Parent Portal admin view

[FUTURE]   11. Multi-Campus Sync
           12. Mobile Admin Command Center
           13. Biometric Staff Attendance
           14. Exam Hall Clearance QR
```

---

## 🔗 Related Documents

| Document | Location | Purpose |
|---|---|---|
| Master Plan | `private_engine/nexus_master_plan.md` | Product strategy, business model, tier definitions |
| React Migration | `private_engine/docs/tasks/react-migration.md` | Full frontend architecture plan |
| This File | `private_engine/docs/tasks/version2_dev.md` | V2 feature tracker |
| Pitch Document | `private_engine/Nexus_School_OS_Pitch_Document.md` | Customer-facing feature promises |
| Onsite Admin Guide | `nexusos/docs/onsite-installation/sch.md` | School admin setup |
| Onsite Tech Guide | `nexusos/docs/onsite-installation/tech.md` | Developer onsite guide |
