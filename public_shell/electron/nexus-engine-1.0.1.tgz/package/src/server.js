const express = require('express');
const app = express();
const address = require('address');
const fs = require('fs');
const csv = require('csv-parser');

const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

const database = require('./database');

app.use(express.json());

// ─── Prompt 2: The CSV Matrix Parser ─────────────────────────────────────────
// Parses a phase-8 CSV with Teacher_ID, Teacher_Name, Teacher_Phone, and
// pipe-delimited Subjects. Inserts securely into SQLite via prepared statements.
function handleCSVUpload(filePath, callback) {
    const rows = [];

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            let db;
            try {
                db = database.getDb();
            } catch (e) {
                console.error('[CSV] Database not initialized. Aborting import.', e);
                if (callback) callback(0, 'DB not initialized');
                return;
            }

            // Prepare parameterized statements — no raw interpolation, SQL injection-proof
            const upsertTeacher = db.prepare(`
                INSERT INTO teachers (id, name, phone)
                VALUES (@id, @name, @phone)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name, phone=excluded.phone
            `);

            const upsertAllocation = db.prepare(`
                INSERT OR IGNORE INTO teacher_allocations (teacher_id, class_name, subject)
                VALUES (@teacher_id, @class_name, @subject)
            `);

            const upsertStudentSubject = db.prepare(`
                INSERT OR IGNORE INTO student_subjects (student_id, subject)
                VALUES (@student_id, @subject)
            `);

            const upsertStudent = db.prepare(`
                INSERT INTO students (id, name, class_name)
                VALUES (@id, @name, @class_name)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name, class_name=excluded.class_name
            `);

            // Wrap all inserts in a single transaction for speed + atomicity
            const runImport = db.transaction((rows) => {
                let studentCount = 0;
                let teacherIds = new Set();
                let allocationCount = 0;

                for (const row of rows) {
                    const studentId    = (row['Student_ID']    || row['ID'] || '').trim();
                    const firstName    = (row['First_Name']    || '').trim();
                    const lastName     = (row['Last_Name']     || '').trim();
                    const className    = (row['Class']         || '').trim();
                    const teacherId    = (row['Teacher_ID']    || '').trim();
                    const teacherName  = (row['Teacher_Name']  || '').trim();
                    const teacherPhone = (row['Teacher_Phone'] || '').trim();
                    const subjectsRaw  = (row['Subjects']      || '').trim();

                    // 1. If row defines a Teacher, process teacher logic
                    if (teacherId) {
                        if (!teacherIds.has(teacherId)) {
                            upsertTeacher.run({ id: teacherId, name: teacherName || teacherId, phone: teacherPhone });
                            teacherIds.add(teacherId);
                        }
                        // Upsert allocation if class and subjects exist
                        if (className) {
                            const subjects = subjectsRaw
                                ? subjectsRaw.split('|').map(s => s.trim()).filter(Boolean)
                                : ['General'];
                            for (const subject of subjects) {
                                upsertAllocation.run({ teacher_id: teacherId, class_name: className, subject });
                                allocationCount++;
                            }
                        }
                    }

                    // 2. If row defines a Student, process student logic
                    if (studentId && (firstName || lastName) && className) {
                        upsertStudent.run({
                            id: studentId,
                            name: `${firstName} ${lastName}`.trim(),
                            class_name: className
                        });

                        // Bug #2 fix: also write the student's subject enrollment so
                        // the handshake and Print Hub can filter correctly per subject.
                        if (subjectsRaw) {
                            const stuSubjects = subjectsRaw
                                .split('|')
                                .map(s => s.trim())
                                .filter(Boolean);
                            for (const subj of stuSubjects) {
                                upsertStudentSubject.run({ student_id: studentId, subject: subj });
                            }
                        }

                        studentCount++;
                    }
                }

                return { studentCount, teacherCount: teacherIds.size, allocationCount };
            });

            try {
                const result = runImport(rows);
                console.log(`[CSV] ✅ Import complete — ${result.studentCount} students, ${result.teacherCount} teachers, ${result.allocationCount} allocations.`);
                if (callback) callback(result.studentCount, null, result);
            } catch (err) {
                console.error('[CSV] ❌ Transaction failed:', err.message);
                if (callback) callback(0, err.message);
            }
        });
}
// ─────────────────────────────────────────────────────────────────────────────
// ─── CBT ENGINE LOCAL SERVING & API ──────────────────────────────────────────

const path = require('path');
// Serve the local student client
app.use('/cbt', express.static(path.join(__dirname, '../public/cbt')));

app.post('/api/cbt/auth', (req, res) => {
    const { token, dob_day, dob_month, dob_year } = req.body;
    if (!token) return res.status(400).json({ error: "Token required" });
    
    let db;
    try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT * FROM cbt_tokens WHERE token = ?").get(token.toUpperCase());
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    if (tk.status === 'submitted') return res.status(403).json({ error: "Exam already submitted" });
    
    // Validate Batch Window
    if (tk.batch_id) {
        const batch = db.prepare("SELECT status FROM cbt_batches WHERE id = ?").get(tk.batch_id);
        if (!batch || batch.status !== 'active') {
            return res.status(403).json({ error: "Your exam batch is not currently active." });
        }
    }
    
    // External 2FA Validation
    let candidateName = "";
    if (tk.external_candidate_id) {
        if (!dob_day || !dob_month || !dob_year) return res.status(401).json({ error: "Date of Birth required for external candidates." });
        const ext = db.prepare("SELECT * FROM cbt_external_candidates WHERE id = ?").get(tk.external_candidate_id);
        if (!ext || ext.dob_day !== dob_day || ext.dob_month !== dob_month || ext.dob_year !== dob_year) {
            return res.status(401).json({ error: "Authentication failed. Token and DOB do not match." });
        }
        candidateName = ext.name;
    } else {
        const stu = db.prepare("SELECT name FROM students WHERE id = ?").get(tk.student_id);
        candidateName = stu ? stu.name : "Internal Student";
    }

    const exam = db.prepare("SELECT * FROM cbt_exams WHERE id = ?").get(tk.exam_id);
    if (!exam || exam.status !== 'active') return res.status(403).json({ error: "Exam is closed or inactive." });

    // Mark active if not already
    if (tk.status === 'unused') {
        db.prepare("UPDATE cbt_tokens SET status = 'active', started_at = ? WHERE id = ?").run(new Date().toISOString(), tk.id);
    }

    res.json({ success: true, token_id: tk.id, candidate_name: candidateName, exam });
});

app.post('/api/cbt/paper', (req, res) => {
    const { token_id } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT exam_id FROM cbt_tokens WHERE id = ?").get(token_id);
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    
    const exam = db.prepare("SELECT bank_id, question_count, shuffle_questions, shuffle_options FROM cbt_exams WHERE id = ?").get(tk.exam_id);
    
    // Get questions, optionally shuffle, slice by count
    let qs = db.prepare("SELECT id, question_text, option_a, option_b, option_c, option_d FROM cbt_questions WHERE bank_id = ?").all(exam.bank_id);
    
    // Note: Do not send correct_option to the client!
    res.json({ success: true, questions: qs, config: exam });
});

app.post('/api/cbt/heartbeat', (req, res) => {
    const { token_id, tab_switches } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    if (tab_switches > 0) {
        db.prepare("UPDATE cbt_tokens SET tab_switches = tab_switches + ? WHERE id = ?").run(tab_switches, token_id);
    }
    res.json({ ok: true });
});

app.post('/api/cbt/submit', (req, res) => {
    const { token_id, answers } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT exam_id FROM cbt_tokens WHERE id = ?").get(token_id);
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    
    // Auto Grade
    let score = 0;
    const insertAnswer = db.prepare("INSERT INTO cbt_answers (token_id, question_id, selected_option, is_correct) VALUES (?, ?, ?, ?)");
    const getCorrect = db.prepare("SELECT correct_option FROM cbt_questions WHERE id = ?");
    
    const tx = db.transaction(() => {
        for (const ans of answers) {
            const q = getCorrect.get(ans.question_id);
            if (!q) continue;
            const isCorrect = q.correct_option === ans.selected_option ? 1 : 0;
            score += isCorrect; // simple 1 pt per correct for now
            insertAnswer.run(token_id, ans.question_id, ans.selected_option, isCorrect);
        }
        db.prepare("UPDATE cbt_tokens SET status = 'submitted', score = ?, submitted_at = ? WHERE id = ?")
          .run(score, new Date().toISOString(), token_id);
    });
    
    try {
        tx();
        res.json({ success: true, score });
    } catch (e) {
        res.status(500).json({ error: "Failed to grade exam: " + e.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────

// The "Day 1" Handshake Endpoint
app.post('/handshake', (req, res) => {
    const { device_id, teacher_id, teacher_name, public_key, thermal_status } = req.body;

    console.log(`[Handshake] Received identity from ${teacher_name} [${teacher_id || 'NO_ID'}] (${device_id})`);

    let db;
    try {
        db = database.getDb();
    } catch (e) {
        return res.status(500).json({ error: "Database not initialized" });
    }

    // Strict lookup: We must have a teacher_id from the QR Code
    if (!teacher_id) {
        return res.status(400).json({ error: "Missing teacher_id in handshake payload." });
    }

    const teacher = db.prepare('SELECT id, name FROM teachers WHERE id = ? LIMIT 1').get(teacher_id);

    if (!teacher) {
        console.warn(`[Handshake] Teacher ID not found: ${teacher_id}`);
        return res.status(404).json({ error: "Teacher ID not found in the vault." });
    }

    // Notify Main Process
    eventEmitter.emit('handshake-success', req.body);

    // Resolve form/homeroom class for this teacher (null if they are not a form teacher)
    const formTeacherRow = db.prepare(
        'SELECT class_name FROM form_teachers WHERE teacher_id = ? LIMIT 1'
    ).get(teacher.id);
    const formClass = formTeacherRow?.class_name || null;

    // Bug #1 fix: fetch students filtered by BOTH class AND subject enrollment.
    // A student only appears in a subject tab if they are explicitly enrolled in
    // that subject (student_subjects row exists).
    // PLUS: We union ALL students in the teacher's form_class under the 'General' subject 
    // so they are available on-device for Attendance taking.
    const students = db.prepare(`
        SELECT s.id, s.name, s.class_name, a.subject
        FROM students s
        JOIN teacher_allocations a ON s.class_name = a.class_name
        WHERE a.teacher_id = ?
          AND (
            EXISTS (
              SELECT 1 FROM student_subjects ss
              WHERE ss.student_id = s.id AND ss.subject = a.subject
            )
            OR NOT EXISTS (
              SELECT 1 FROM student_subjects ss2
              WHERE ss2.student_id = s.id
            )
          )
        UNION
        SELECT s.id, s.name, s.class_name, 'General' as subject
        FROM students s
        WHERE s.class_name = ?
    `).all(teacher.id, formClass || 'NONE_CLASS');

    // Read score_components from school_term_config so the tablet knows what fields to collect
    let scoreComponents = null;
    try {
        const termCfg = db.prepare('SELECT grading_scale FROM school_term_config WHERE id = 1').get();
        if (termCfg?.grading_scale) {
            const parsed = JSON.parse(termCfg.grading_scale);
            if (parsed && !Array.isArray(parsed) && parsed.components) {
                scoreComponents = parsed.components;
            }
        }
    } catch(e) { /* use default if config unreadable */ }
    if (!scoreComponents) {
        scoreComponents = [
            { key: "CA1",  label: "C.A. 1", max: 10 },
            { key: "CA2",  label: "C.A. 2", max: 10 },
            { key: "Exam", label: "Exam",   max: 80 },
        ];
    }

    // Extract ALL distinct school subjects to send to the phone (Master Subject List)
    const allSubjects = db.prepare(`
        SELECT subject FROM teacher_allocations 
        UNION 
        SELECT subject FROM student_subjects
    `).all().map(row => row.subject);

    // Form class was resolved above to support the new union query.

    // Merge saved school_config with guaranteed defaults so Android always
    // receives a valid modules array and primary_color regardless of what
    // fields the identity.json was saved with.
    const baseConfig = app.locals.school_config || {};
    const schoolConfig = {
        name:          baseConfig.name          || baseConfig.school_name || "Nexus School",
        primary_color: baseConfig.themePrimary  || baseConfig.primary_color || "#1A237E",
        logoBase64:    baseConfig.logoBase64    || null,
        modules:       Array.isArray(baseConfig.modules)
                         ? baseConfig.modules
                         : ["grading", "attendance"],  // always present for Android UI
    };

    const payloadObj = {
        status: "MARRIED",
        message: `Welcome to the ecosystem, ${teacher.name}.`,
        school_config: schoolConfig,
        score_components: scoreComponents,
        students: students,
        all_subjects: allSubjects,
        form_class: formClass,           // null if not a form teacher; class name if they are
        server_timestamp: new Date().toISOString()
    };

    const jsonString = JSON.stringify(payloadObj);

    // PM Rule: Gzip if > 500 students to prevent Heat Spikes on the mobile side
    // For testing/QA, let's keep the threshold tight or test dynamically, 
    // but the prompt specifies chunk/gzip if > 500.
    if (students.length > 500) {
        console.log(`[Eco-Mode] Payload > 500 targeted students (${students.length}). Gzipping for ${device_id}...`);
        const zlib = require('zlib');
        zlib.gzip(jsonString, (err, buffer) => {
            if (!err) {
                res.setHeader('Content-Encoding', 'gzip');
                res.setHeader('Content-Type', 'application/json');
                res.status(200).send(buffer);
            } else {
                res.status(500).send("Compression error");
            }
        });
    } else {
        console.log(`[Handshake] Sending ${students.length} targeted student records to ${device_id}`);
        res.status(200).json(payloadObj);
    }
});

// The "Day 2" Sync Endpoint
app.post('/sync', (req, res) => {
    const { device_id, teacher_id, teacher_name, signature, events } = req.body || {};
    const eventsArray = events || [];

    console.log(`[Sync] Received ${eventsArray.length} signed events from device: ${device_id || 'UNKNOWN'}`);
    if (signature) {
        console.log(`[Sync] ECDSA Signature Attached: ${signature.substring(0, 30)}...`);
    }

    let db;
    try {
        db = database.getDb();
    } catch (e) {
        console.error("[Sync] DB not ready.");
        return res.status(500).json({ error: "Database not initialized" });
    }

    // Bug #5 fix: resolve teacher by teacher_id (sent in QR payload) first.
    // Fall back to name lookup only if teacher_id is missing, so legacy clients
    // that don't embed the ID in their sync payload still work.
    let teacherId = "UNKNOWN_TEACHER";
    if (teacher_id) {
        const teacher = db.prepare('SELECT id FROM teachers WHERE id = ? LIMIT 1').get(teacher_id);
        if (teacher) teacherId = teacher.id;
    } else if (teacher_name) {
        // Fallback for older tablet app versions
        const teacher = db.prepare('SELECT id FROM teachers WHERE name = ? COLLATE NOCASE LIMIT 1').get(teacher_name);
        if (teacher) teacherId = teacher.id;
    }

    // Read current active session/term so every grade record is queryable by session+term.
    // This fixes the root cause of scores showing "—" in generated reports.
    const termRow      = db.prepare('SELECT academic_session, term FROM school_term_config WHERE id = 1').get() || {};
    const activeSession = termRow.academic_session || '2024/2025';
    const activeTerm    = termRow.term             || 'First Term';

    // Process Ledger insertions in a single atomic transaction.
    // Using INSERT OR IGNORE for the audit log so that idempotent re-syncs
    // (same deterministic event_id GRADE_<student>_<subject>) don't throw a
    // PRIMARY KEY conflict and silently abort the grade upsert that follows.
    const insertLog    = db.prepare('INSERT OR IGNORE INTO sync_logs (event_id, device_id, teacher_id, payload) VALUES (?, ?, ?, ?)');
    const upsertRecord = db.prepare(`
        INSERT OR REPLACE INTO student_records 
        (student_id, subject, academic_session, term, assessment, score, breakdown, teacher_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertStudent = db.prepare('INSERT OR IGNORE INTO students (id, name, class_name) VALUES (?, ?, ?)');
    const insertStudentSubject = db.prepare('INSERT OR IGNORE INTO student_subjects (student_id, subject) VALUES (?, ?)');

    let successfullyInserted = 0;
    const failedEvents = [];
    
    // Check if device is explicitly revoked
    if (app.locals.revoked_devices && app.locals.revoked_devices.has(device_id)) {
        return res.status(403).json({ error: "REVOKED" });
    }

    // License Check State
    let currentStudentCount = db.prepare('SELECT COUNT(id) AS c FROM students').get().c;
    const maxStudents = app.locals.license_limit?.payload ? JSON.parse(app.locals.license_limit.payload).student_count || 999999 : 999999;

    const processSyncTransaction = db.transaction(() => {
        for (const evt of eventsArray) {
            // 1. Audit Trail (INSERT OR IGNORE — safe on re-sync)
            try {
                insertLog.run(evt.event_id, device_id || 'UNKNOWN', teacherId, JSON.stringify(evt));
            } catch (auditErr) {
                console.warn(`[Sync] Audit log skipped for ${evt.event_id}:`, auditErr.message);
            }

            // 2. Add Student Interceptor (The Hawk)
            if (evt.event_type === "ADD_STUDENT") {
                try {
                    if (currentStudentCount >= maxStudents) {
                        failedEvents.push(evt.event_id);
                        continue; // Skip this insertion
                    }
                    const p = JSON.parse(evt.payload);
                    insertStudent.run(p.student_id, p.name, p.class_name);
                    insertStudentSubject.run(p.student_id, p.subject || 'General');
                    currentStudentCount++;
                } catch (e) {
                    console.error("Failed to add student:", e);
                }
            }

            // 3. Ledger Upsert — runs independently so audit errors never block grade writes
            if (evt.event_type === "UPDATE_GRADE") {
                try {
                    const p = JSON.parse(evt.payload);
                    const breakdownStr = p.breakdown ? JSON.stringify(p.breakdown) : "{}";
                    const incomingSubject = p.subject || 'General';

                    // --- SUBJECT CONSISTENCY ENGINE ---
                    // 1. Get the student's canonical class to check allocations
                    const studentRow = db.prepare('SELECT class_name FROM students WHERE id = ?').get(p.student_id);
                    if (studentRow && teacherId && incomingSubject !== 'General') {
                        // 2. Check if the teacher is allocated to teach this subject in this class
                        const allocationCheck = db.prepare('SELECT 1 FROM teacher_allocations WHERE teacher_id = ? AND class_name = ? AND subject = ?').get(teacherId, studentRow.class_name, incomingSubject);
                        
                        if (!allocationCheck) {
                            // 3. Mismatch detected! Log warning, but DO NOT drop the data (per requirements)
                            try {
                                db.prepare('INSERT INTO sync_warnings (device_id, teacher_id, student_id, mismatched_subject) VALUES (?, ?, ?, ?)').run(device_id, teacherId, p.student_id, incomingSubject);
                            } catch (warnErr) {
                                console.error("[Sync] Failed to log sync_warning:", warnErr.message);
                            }
                        }
                    }
                    // ----------------------------------

                    upsertRecord.run(
                        p.student_id,
                        incomingSubject,
                        activeSession,
                        activeTerm,
                        p.assessment || 'CA1',
                        p.score,
                        breakdownStr,
                        teacherId
                    );
                    successfullyInserted++;
                } catch (gradeErr) {
                    console.error(`[Sync] Grade upsert failed for ${evt.event_id}:`, gradeErr.message);
                }
            }

            // 4. Attendance Interceptor
            if (evt.event_type === "ATTENDANCE_UPDATE") {
                try {
                    const p = JSON.parse(evt.payload);
                    const source = p.source || 'teacher';
                    const upsertAttendance = db.prepare(`
                        INSERT INTO daily_attendance
                        (student_id, class_name, date, status, academic_session, term, recorded_by_teacher_id, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(student_id, date) DO UPDATE SET 
                        status=excluded.status, 
                        recorded_by_teacher_id=excluded.recorded_by_teacher_id,
                        source=excluded.source
                        WHERE daily_attendance.source != 'admin' OR excluded.source = 'admin'
                    `);
                    upsertAttendance.run(
                        p.student_id,
                        p.class_name,
                        p.date,
                        p.status,
                        activeSession,
                        activeTerm,
                        teacherId,
                        source
                    );
                    successfullyInserted++;

                    // Guardian Shield: Emit alert event if absent
                    if (p.status === 'Absent') {
                        eventEmitter.emit('attendance-alert', {
                            student_id: p.student_id,
                            date: p.date
                        });
                    }
                } catch (attErr) {
                    console.error(`[Sync] Attendance upsert failed for ${evt.event_id}:`, attErr.message);
                }
            }
        }
    });


    try {
        processSyncTransaction();
        console.log(`[Sync] Successfully upserted ${successfullyInserted} grade records into Ledger.`);
    } catch (err) {
        console.error("[Sync] Transaction failed:", err);
    }

    // Forward enriched events to main.js via EventEmitter
    eventEmitter.emit('sync-events', { teacher_name: teacher_name || "A Teacher", events: eventsArray, count: successfullyInserted });

    // Inform Main App if limit was breached!
    if (failedEvents.length > 0) {
        eventEmitter.emit('capacity-alert', { totalFailed: failedEvents.length });
    }

    // Resolve license expiry so phone can show a countdown warning
    let expiresAt = 0;
    try {
        if (app.locals.license_limit?.payload) {
            expiresAt = JSON.parse(app.locals.license_limit.payload).expires_at || 0;
        }
    } catch (_) {}

    // --- SUBJECT CONSISTENCY ENGINE ---
    // Push the canonical list of subjects back to the Android app so it can fix stale lists
    let canonicalSubjects = [];
    try {
        if (teacherId) {
            canonicalSubjects = db.prepare('SELECT class_name, subject FROM teacher_allocations WHERE teacher_id = ?').all(teacherId);
        }
    } catch (e) {
        console.error("[Sync] Failed to fetch canonical subjects:", e.message);
    }

    res.status(200).json({ 
        status: failedEvents.length > 0 ? 'PARTIAL_LIMIT' : 'ACK',
        failed_events: failedEvents,
        expires_at: expiresAt,
        canonical_subjects: canonicalSubjects
    });
});

function startServer(port = 3000) {
    app.listen(port, () => {
        const ip = address.ip();
        console.log(`[Nexus Server] Listening at http://${ip}:${port}`);
    });
    return eventEmitter;
}

function setSchoolConfig(config) {
    app.locals.school_config = config;
}

function setSchoolLicense(license) {
    app.locals.license_limit = license;
}

function revokeDevice(deviceId) {
    if (!app.locals.revoked_devices) app.locals.revoked_devices = new Set();
    app.locals.revoked_devices.add(deviceId);
}

function clearData() {
    try {
        const db = database.getDb();
        // Purge in dependency order so FK constraints are satisfied.
        db.exec(`
            DELETE FROM student_domains;
            DELETE FROM teacher_remarks;
            DELETE FROM student_records;
            DELETE FROM student_subjects;
            DELETE FROM sync_logs;
            DELETE FROM teacher_allocations;
            DELETE FROM students;
            DELETE FROM teachers;
        `);
        console.log('[CSV] All database tables fully cleared.');
    } catch (e) {
        console.warn('[CSV] Could not clear DB (not yet initialized):', e.message);
    }
}

module.exports = { startServer, setSchoolConfig, setSchoolLicense, revokeDevice, handleCSVUpload, clearData };
