const fs = require('fs');
const path = require('path');

let db;
let Database;

function init(dbPath, DatabaseConstructor) {
    if (db) return db;
    Database = DatabaseConstructor || require('better-sqlite3');

    // Ensure directory exists
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    // Initialize better-sqlite3
    try {
        db = new Database(dbPath, { verbose: console.log });
    } catch (err) {
        console.error(`[Database] FATAL: Failed to open SQLite at ${dbPath}`);
        console.error(`[Database] Error detail: ${err.message}`);
        if (err.message.includes('NODE_MODULE_VERSION')) {
             console.error("[Database] This is likely a Node/Electron version mismatch. Run 'npm install better-sqlite3' on this machine.");
        }
        throw err;
    }

    // Enable Write-Ahead Logging for better concurrency handling during sync
    db.pragma('journal_mode = WAL');

    // Enable foreign key enforcement (SQLite disables it by default).
    // This activates all ON DELETE CASCADE / RESTRICT rules in the schema.
    db.pragma('foreign_keys = ON');

    console.log(`[Database] SQLite connected at ${dbPath}`);

    // Architect and execute schema migration
    db.exec(`
        -- Table 1: Teachers
        CREATE TABLE IF NOT EXISTS teachers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT
        );

        -- Table 2: Teacher Allocations (Many-to-Many junction)
        CREATE TABLE IF NOT EXISTS teacher_allocations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id TEXT NOT NULL,
            class_name TEXT NOT NULL,
            subject TEXT NOT NULL,
            UNIQUE(teacher_id, class_name, subject),
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE
        );

        -- Table 3: Students
        CREATE TABLE IF NOT EXISTS students (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            class_name TEXT NOT NULL
        );

        -- Table 3b: Student Subjects (Explicit Enrollment)
        CREATE TABLE IF NOT EXISTS student_subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            UNIQUE(student_id, subject),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 4: Sync Logs (for offline queue resolution and auditing)
        CREATE TABLE IF NOT EXISTS sync_logs (
            event_id TEXT PRIMARY KEY,
            device_id TEXT NOT NULL,
            teacher_id TEXT NOT NULL,
            payload TEXT NOT NULL,
            synced_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Table 4b: Sync Warnings (Subject Consistency Engine)
        CREATE TABLE IF NOT EXISTS sync_warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT,
            teacher_id TEXT,
            student_id TEXT,
            mismatched_subject TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Table 5: Student Records (The Ledger)
        CREATE TABLE IF NOT EXISTS student_records (
            student_id TEXT,
            subject TEXT,
            assessment TEXT,
            score INTEGER,
            breakdown TEXT,
            teacher_id TEXT,
            academic_session TEXT DEFAULT '2024/2025',
            term TEXT DEFAULT 'First Term',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, subject, assessment, academic_session, term)
        );

        -- Table 6: School Term Configuration (V2)
        CREATE TABLE IF NOT EXISTS school_term_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            academic_session TEXT NOT NULL DEFAULT '2024/2025',
            term TEXT NOT NULL DEFAULT 'First Term',
            resumption_date TEXT DEFAULT '',
            grading_scale TEXT DEFAULT '[]',
            show_position INTEGER DEFAULT 1,
            show_domains INTEGER DEFAULT 1
        );

        -- Table 7: Student Domain Scores – Affective & Psychomotor (V2)
        CREATE TABLE IF NOT EXISTS student_domains (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            domain_type TEXT NOT NULL,
            trait TEXT NOT NULL,
            grade TEXT NOT NULL,
            UNIQUE(student_id, academic_session, term, domain_type, trait)
        );

        -- Table 8: Teacher Remarks per Student per Term (V2)
        CREATE TABLE IF NOT EXISTS teacher_remarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            teacher_id TEXT,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            remark TEXT DEFAULT '',
            principal_remark TEXT DEFAULT '',
            UNIQUE(student_id, academic_session, term)
        );
    `);

    // ── V2 Safe Migrations: add columns/tables if they don't already exist ──────
    const alterSafe = (sql) => { try { db.exec(sql); } catch(e) { /* already exists */ } };

    // student_records historical columns
    alterSafe(`ALTER TABLE student_records ADD COLUMN academic_session TEXT DEFAULT '2024/2025'`);
    alterSafe(`ALTER TABLE student_records ADD COLUMN term TEXT DEFAULT 'First Term'`);

    // V2.1: Extended student profile
    alterSafe(`ALTER TABLE students ADD COLUMN reg_no TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN gender TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN dob TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN photo TEXT DEFAULT NULL`);         // Diamond plan
    alterSafe(`ALTER TABLE students ADD COLUMN parent_email TEXT DEFAULT ''`);    // Gold+
    alterSafe(`ALTER TABLE students ADD COLUMN parent_phone TEXT DEFAULT ''`);    // Gold+
    alterSafe(`ALTER TABLE students ADD COLUMN fee_status TEXT DEFAULT 'cleared'`); // Gold+
    alterSafe(`ALTER TABLE students ADD COLUMN parent_name TEXT DEFAULT NULL`);      // Gold+ receipt matching

    // V2.2: Class Progression & CBT Engine Additions
    alterSafe(`ALTER TABLE students ADD COLUMN session_history TEXT DEFAULT '[]'`); // JSON array of past classes
    alterSafe(`ALTER TABLE cbt_exams ADD COLUMN is_promotional INTEGER DEFAULT 0`);

    // V3.0: The Vault — Admin Users Schema Migration
    // Existing installations may have admin_users with old columns (name, pin_hash, role).
    // We add the new columns safely; existing rows will have NULL values which the seeder handles.
    alterSafe(`ALTER TABLE admin_users ADD COLUMN username TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN secret_hash TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN auth_type TEXT DEFAULT 'pin'`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN role_level INTEGER DEFAULT 1`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN avatar TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP`);

    // Back-fill: if old rows exist with 'name' but no 'username', copy name → username
    try {
        db.exec(`UPDATE admin_users SET username = name WHERE username IS NULL AND name IS NOT NULL`);
        // Back-fill secret_hash from pin_hash if present
        db.exec(`UPDATE admin_users SET secret_hash = pin_hash WHERE secret_hash IS NULL AND pin_hash IS NOT NULL`);
        // Promote old 'super_admin' role to level 9
        db.exec(`UPDATE admin_users SET role_level = 9 WHERE role_level IS NULL OR role_level = 1`);

        // V3.1: Normalize hash format — old installs used bcrypt ($2b$...) which is ~60 chars.
        // The current Vault uses base64(pin) — "0000" → "MDAwMA==".
        // Any bcrypt hash will never match, so we reset those admins to the default PIN.
        // Admins are notified to change their PIN on first login.
        const defaultPinHash = Buffer.from('0000').toString('base64');
        const legacyAdmins = db.prepare(
            `SELECT id, username FROM admin_users WHERE secret_hash LIKE '$2b$%' OR length(secret_hash) > 30`
        ).all();
        if (legacyAdmins.length > 0) {
            const stmt = db.prepare(`UPDATE admin_users SET secret_hash = ? WHERE id = ?`);
            legacyAdmins.forEach(a => {
                stmt.run(defaultPinHash, a.id);
                console.log(`[DB Migration] Reset PIN for legacy admin '${a.username}' → default 0000`);
            });
        }
    } catch(e) { /* columns may not exist on fresh installs — that's fine */ }


    // Settings Table for flexible configuration (Hierarchy, Thresholds)
    db.exec(`
        CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('class_hierarchy', '["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"]');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('pass_mark_threshold', '50');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('current_academic_session', '2025/2026');
        -- V2.3: Dual-Layer Attendance & Truancy Detection defaults
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_daily_attendance', 'true');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_subject_attendance', 'false');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('truancy_escalation_flow', '[{"step":1,"trigger_after":1,"notify":"form_teacher","channel":"in-app"},{"step":2,"trigger_after":3,"notify":"principal","channel":"in-app"},{"step":3,"trigger_after":5,"notify":"parent","channel":"whatsapp"}]');
    `);

    // V2.3: Subject-Level Attendance & Truancy Flagging (Diamond)
    db.exec(`
        -- Raw per-class roll call (mirrors daily_attendance at subject level)
        CREATE TABLE IF NOT EXISTS subject_attendance (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id   TEXT    NOT NULL,
            subject_name TEXT    NOT NULL,
            class_name   TEXT    NOT NULL,
            date         TEXT    NOT NULL,
            status       TEXT    NOT NULL CHECK(status IN ('present','absent','late')),
            marked_by    TEXT,
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, subject_name, date),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Fast aggregate for report compilation (mirrors student_attendance)
        CREATE TABLE IF NOT EXISTS subject_attendance_agg (
            student_id       TEXT NOT NULL,
            subject_name     TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term             TEXT NOT NULL,
            total_classes    INTEGER DEFAULT 0,
            classes_attended INTEGER DEFAULT 0,
            PRIMARY KEY (student_id, subject_name, academic_session, term),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Truancy flag counter — drives the Guardian Shield escalation ladder
        CREATE TABLE IF NOT EXISTS truancy_flags (
            student_id      TEXT    NOT NULL,
            flag_count      INTEGER DEFAULT 0,
            last_flagged    TEXT,
            escalation_step INTEGER DEFAULT 0,
            PRIMARY KEY (student_id),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );
    `);

    // V2.1: Attendance tracking table
    db.exec(`
        CREATE TABLE IF NOT EXISTS student_attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            total_days INTEGER DEFAULT 0,
            days_attended INTEGER DEFAULT 0,
            UNIQUE(student_id, academic_session, term),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 9: Form Teachers (V2.1)
        CREATE TABLE IF NOT EXISTS form_teachers (
            class_name TEXT PRIMARY KEY,
            teacher_id TEXT NOT NULL,
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE
        );

        -- Table 10: Daily Attendance (Gold Phase A)
        CREATE TABLE IF NOT EXISTS daily_attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            class_name TEXT NOT NULL,
            date TEXT NOT NULL,
            status TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            recorded_by_teacher_id TEXT,
            UNIQUE(student_id, date),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 11: App Settings (Gold Phase B — school identity for Pulse Bot etc.)
        CREATE TABLE IF NOT EXISTS app_settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );

        -- ── Phase 5: Fee Management (Gold Lightweight + Diamond Full Ledger) ──────

        -- Table 12: student_fees — Aggregated fee state per student per term (Gold+)
        --   'balance' is NOT stored; always computed as (total_billed - total_paid) at query time.
        CREATE TABLE IF NOT EXISTS student_fees (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            academic_session TEXT    NOT NULL,
            term             TEXT    NOT NULL,
            total_billed     REAL    NOT NULL DEFAULT 0,
            total_paid       REAL    NOT NULL DEFAULT 0,
            next_due_date    TEXT    DEFAULT '',
            status           TEXT    NOT NULL DEFAULT 'unpaid'
                             CHECK(status IN ('cleared','partial','unpaid')),
            updated_at       TEXT    NOT NULL DEFAULT (datetime('now')),
            UNIQUE(student_id, academic_session, term),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 13: fee_transactions — Full payment ledger (Diamond only)
        CREATE TABLE IF NOT EXISTS fee_transactions (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            academic_session TEXT    NOT NULL,
            term             TEXT    NOT NULL,
            amount           REAL    NOT NULL,
            payment_method   TEXT    NOT NULL DEFAULT 'cash'
                             CHECK(payment_method IN ('cash','transfer','pos','bank_teller')),
            reference_number TEXT    DEFAULT '',
            recorded_by      TEXT    NOT NULL DEFAULT 'Admin',
            note             TEXT    DEFAULT '',
            created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 14: fee_structures — Itemised fee breakdown definitions (Diamond only)
        --   Rows describe what makes up total_billed for a given class.
        CREATE TABLE IF NOT EXISTS fee_structures (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT    NOT NULL,
            item_name  TEXT    NOT NULL,
            amount     REAL    NOT NULL DEFAULT 0,
            term       TEXT    NOT NULL DEFAULT 'All Terms',
            UNIQUE(class_name, item_name, term)
        );

        -- ── Phase 7: Full Production CBT Engine (Diamond) ──────

        -- Table 15: cbt_question_banks — Groups of questions
        CREATE TABLE IF NOT EXISTS cbt_question_banks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            subject TEXT NOT NULL,
            class_category TEXT NOT NULL DEFAULT 'General',
            is_premium BOOLEAN DEFAULT 0,
            pack_id TEXT DEFAULT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        -- Table 16: cbt_questions — Individual questions
        CREATE TABLE IF NOT EXISTS cbt_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bank_id INTEGER NOT NULL,
            question_text TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_option TEXT NOT NULL CHECK(correct_option IN ('A','B','C','D')),
            marks INTEGER NOT NULL DEFAULT 1,
            difficulty TEXT NOT NULL DEFAULT 'medium' CHECK(difficulty IN ('easy','medium','hard')),
            question_hash TEXT DEFAULT NULL,
            FOREIGN KEY (bank_id) REFERENCES cbt_question_banks(id) ON DELETE CASCADE
        );

        -- Table 17: cbt_exams — Scheduled exams
        CREATE TABLE IF NOT EXISTS cbt_exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            bank_id INTEGER NOT NULL,
            class_name TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            question_count INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','active','completed')),
            pass_mark_percentage INTEGER NOT NULL DEFAULT 50,
            shuffle_questions INTEGER NOT NULL DEFAULT 1,
            shuffle_options INTEGER NOT NULL DEFAULT 1,
            exam_type TEXT NOT NULL DEFAULT 'internal' CHECK(exam_type IN ('internal','external')),
            assessment_mapping TEXT DEFAULT NULL,
            security_profile TEXT DEFAULT '{}',
            result_release_policy TEXT NOT NULL DEFAULT 'immediate' CHECK(result_release_policy IN ('immediate','delayed_30m','delayed_1h','delayed_12h','delayed_24h','delayed_48h','manual')),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (bank_id) REFERENCES cbt_question_banks(id) ON DELETE RESTRICT
        );

        -- Table 17b: cbt_batches — Time slots for exams
        CREATE TABLE IF NOT EXISTS cbt_batches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','closed')),
            FOREIGN KEY (exam_id) REFERENCES cbt_exams(id) ON DELETE CASCADE
        );

        -- Table 17c: cbt_external_candidates — Non-student examinees
        CREATE TABLE IF NOT EXISTS cbt_external_candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            guardian_phone TEXT NOT NULL,
            dob_year TEXT NOT NULL,
            dob_month TEXT NOT NULL,
            dob_day TEXT NOT NULL,
            exam_year TEXT NOT NULL,
            exam_month TEXT NOT NULL,
            exam_day TEXT NOT NULL,
            target_class TEXT NOT NULL,
            subjects TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        -- Table 17d: used_expansion_keys — Token Pack Monetization tracking
        CREATE TABLE IF NOT EXISTS used_expansion_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_hash TEXT NOT NULL UNIQUE,
            tokens_added INTEGER NOT NULL,
            used_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        -- Table 18: cbt_tokens — Access tokens for students taking exams
        CREATE TABLE IF NOT EXISTS cbt_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER NOT NULL,
            student_id TEXT DEFAULT NULL,
            external_candidate_id INTEGER DEFAULT NULL,
            batch_id INTEGER DEFAULT NULL,
            token TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL DEFAULT 'unused' CHECK(status IN ('unused','active','submitted')),
            score INTEGER DEFAULT NULL,
            started_at TEXT DEFAULT NULL,
            submitted_at TEXT DEFAULT NULL,
            tab_switches INTEGER NOT NULL DEFAULT 0,
            whatsapp_dispatches INTEGER NOT NULL DEFAULT 0,
            portal_checks INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (exam_id) REFERENCES cbt_exams(id) ON DELETE CASCADE,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (external_candidate_id) REFERENCES cbt_external_candidates(id) ON DELETE CASCADE,
            FOREIGN KEY (batch_id) REFERENCES cbt_batches(id) ON DELETE CASCADE,
            UNIQUE(exam_id, student_id),
            UNIQUE(exam_id, external_candidate_id)
        );

        -- Table 19: cbt_answers — Student answers for auto-grading
        CREATE TABLE IF NOT EXISTS cbt_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            selected_option TEXT NOT NULL CHECK(selected_option IN ('A','B','C','D','NONE')),
            is_correct INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (token_id) REFERENCES cbt_tokens(id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES cbt_questions(id) ON DELETE CASCADE,
            UNIQUE(token_id, question_id)
        );

    `);

    // Seed default school name if not already set
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('school_name', 'Nexus School')`).run();

    // ── Admin Users & System Auth (The Vault) ─────────────────────────────────
    db.exec(`
        CREATE TABLE IF NOT EXISTS admin_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            secret_hash TEXT NOT NULL,
            auth_type TEXT DEFAULT 'pin',
            role_level INTEGER DEFAULT 1,
            avatar TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER,
            action TEXT NOT NULL,
            target TEXT,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(admin_id) REFERENCES admin_users(id)
        );
    `);

    // ── System Auth Seeder ─────────────────────────────────────────
    const adminCount = db.prepare("SELECT COUNT(*) as count FROM admin_users").get().count;
    if (adminCount === 0) {
        // Default PIN: "0000" stored in base64 as placeholder hash
        const defaultHash = Buffer.from("0000").toString('base64');
        db.prepare(`
            INSERT INTO admin_users (username, secret_hash, auth_type, role_level) 
            VALUES ('admin', ?, 'pin', 9)
        `).run(defaultHash);
        
        db.prepare(`
            INSERT INTO audit_logs (admin_id, action, target, details)
            VALUES (1, 'SYSTEM_INIT', 'admin_users', 'Default superadmin created')
        `).run();
    }

    db.exec(`
        -- Table: pending_pulse_messages — WhatsApp Message Queue (Gold Phase B)
        -- Prevents UI freeze during bulk sends (900+ parents).
        -- A 3-second setInterval worker drains this queue one message at a time.
        CREATE TABLE IF NOT EXISTS pending_pulse_messages (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            phone       TEXT    NOT NULL,
            message     TEXT    NOT NULL,
            type        TEXT    NOT NULL DEFAULT 'fee_reminder'
                        CHECK(type IN ('fee_reminder','guardian_alert','otp','digest','general')),
            status      TEXT    NOT NULL DEFAULT 'pending'
                        CHECK(status IN ('pending','sending','sent','failed')),
            attempts    INTEGER NOT NULL DEFAULT 0,
            student_id  TEXT    DEFAULT NULL,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            sent_at     TEXT    DEFAULT NULL,
            error_msg   TEXT    DEFAULT NULL
        );

        -- Table: fee_adjustments — Scholarships, Waivers, Grants (Gold+)
        CREATE TABLE IF NOT EXISTS fee_adjustments (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            academic_session TEXT    NOT NULL,
            term             TEXT    NOT NULL,
            adjustment_type  TEXT    NOT NULL DEFAULT 'discount'
                             CHECK(adjustment_type IN ('scholarship','waiver','owner_grant','bursary','discount')),
            description      TEXT    NOT NULL DEFAULT '',
            amount           REAL    NOT NULL DEFAULT 0,
            approved_by      TEXT    NOT NULL DEFAULT 'Admin',
            created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );
    `);

    // Seed default fee settings (shared by Gold & Diamond — reminder dates + Fee Shield config)
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('fee_settings', ?)`).run(JSON.stringify({
        reminder_date_1: '',          // ISO date string (YYYY-MM-DD)
        reminder_date_2: '',          // ISO date string (YYYY-MM-DD)
        fee_shield_enabled: false,    // Diamond only
        fee_shield_mode: 'warn'       // 'warn' | 'watermark' | 'block'
    }));

    // V2.1: Teacher signature
    alterSafe(`ALTER TABLE teachers ADD COLUMN signature TEXT DEFAULT NULL`);

    // V2.1: Remark signatures
    alterSafe(`ALTER TABLE teacher_remarks ADD COLUMN teacher_signature TEXT DEFAULT NULL`);
    alterSafe(`ALTER TABLE teacher_remarks ADD COLUMN principal_signature TEXT DEFAULT NULL`);

    // V2.1: Term config — template + optional display toggles
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN template TEXT DEFAULT 'clean_slate'`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_subject_position INTEGER DEFAULT 0`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_attendance INTEGER DEFAULT 1`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_fee_status INTEGER DEFAULT 0`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_highest_lowest INTEGER DEFAULT 0`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_class_average INTEGER DEFAULT 1`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN attendance_score_weight INTEGER DEFAULT 0`);

    // Gold Phase B: Attendance conflict authority
    alterSafe(`ALTER TABLE daily_attendance ADD COLUMN source TEXT DEFAULT 'teacher'`);

    // Gold Phase C: Term calendar boundaries — enables attendance date validation
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN term_start_date TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN term_end_date   TEXT DEFAULT ''`);

    // Seed default term config if empty
    db.prepare(`INSERT OR IGNORE INTO school_term_config (id, academic_session, term) VALUES (1, '2024/2025', 'First Term')`).run();

    // Diamond CBT: add description + subject columns to cbt_question_banks
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN description TEXT NOT NULL DEFAULT ''`);
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN subject TEXT NOT NULL DEFAULT ''`);
    
    // NexPack Updates
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN is_premium BOOLEAN DEFAULT 0`);
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN pack_id TEXT DEFAULT NULL`);
    alterSafe(`ALTER TABLE cbt_questions ADD COLUMN question_hash TEXT DEFAULT NULL`);
    // Back-fill: if subject is empty, copy class_category so existing banks are not blank
    try { db.exec(`UPDATE cbt_question_banks SET subject = class_category WHERE subject = '' AND class_category != ''`); } catch(_){}

    console.log(`[Database] V2.1 + Phase 5 Fee Management schema verified and migrated.`);


    // ── BLOCK A: ALWAYS seed roster (INSERT OR IGNORE — safe to run every startup) ──
    // This ensures all 15 demo students exist even if grades were already seeded partially.
    try {
        db.exec(`
            INSERT OR IGNORE INTO teachers (id, name, phone, email) VALUES ('T-AKI', 'Dr. Akinjide (Math/Sci)', '08012345678', 'akinjide@nexus.com');
            INSERT OR IGNORE INTO teachers (id, name, phone, email) VALUES ('T-OKO', 'Mrs. Okoro (HOD Arts)', '08087654321', 'okoro@nexus.com');
            INSERT OR IGNORE INTO teachers (id, name, phone, email) VALUES ('T-YUS', 'Mr. Yusuf (Physics/Chem)', '08011122233', 'yusuf@nexus.com');
            INSERT OR IGNORE INTO teachers (id, name, phone, email) VALUES ('T-BEL', 'Ms. Bello (English)', '08044455566', 'bello@nexus.com');
            INSERT OR IGNORE INTO teachers (id, name, phone, email) VALUES ('T-DAV', 'Engr. David (Commercial)', '08099900011', 'david@nexus.com');

            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-001', 'Chidi Abiola (Science)', 'SS1A', 'REG/2026/01');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-002', 'Aminu Danjuma (Science)', 'SS1A', 'REG/2026/02');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-003', 'Oluwatobi Okonkwo (Science)', 'SS1A', 'REG/2026/03');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-004', 'Nneka Adeyemi (Science)', 'SS1A', 'REG/2026/04');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-005', 'Zainab Eze (Science)', 'SS1A', 'REG/2026/05');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-006', 'Emeka Bello (Art)', 'SS1A', 'REG/2026/06');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-007', 'Funke Umar (Art)', 'SS1A', 'REG/2026/07');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-008', 'Uche Nwosu (Art)', 'SS1A', 'REG/2026/08');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-009', 'Sade Bakare (Art)', 'SS1A', 'REG/2026/09');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-010', 'Musa Igwe (Art)', 'SS1A', 'REG/2026/10');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-011', 'Blessing Alabi (Commercial)', 'SS1A', 'REG/2026/11');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-012', 'Mustafa Keita (Commercial)', 'SS1A', 'REG/2026/12');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-013', 'Ifeanyi Ojo (Commercial)', 'SS1A', 'REG/2026/13');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-014', 'Fatima Sule (Commercial)', 'SS1A', 'REG/2026/14');
            INSERT OR IGNORE INTO students (id, name, class_name, reg_no) VALUES ('STU-015', 'Kolawole Jide (Commercial)', 'SS1A', 'REG/2026/15');

            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Mathematics' FROM students;
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'English Language' FROM students;
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Civic Education' FROM students;
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Physics' FROM students WHERE name LIKE '%(Science)%';
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Further Maths' FROM students WHERE name LIKE '%(Science)%';
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Literature' FROM students WHERE name LIKE '%(Art)%';
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Government' FROM students WHERE name LIKE '%(Art)%';
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Financial Accounting' FROM students WHERE name LIKE '%(Commercial)%';
            INSERT OR IGNORE INTO student_subjects (student_id, subject) SELECT id, 'Commerce' FROM students WHERE name LIKE '%(Commercial)%';
        `);
        console.log(`[Database] Demo roster verified (15 students, 5 teachers).`);
    } catch(err) {
        console.warn("[Database] Roster seed warning:", err.message);
    }

    // ── BLOCK B: Only seed GRADES if none exist ───────────────────────────────
    try {
        const count = db.prepare("SELECT COUNT(*) as c FROM student_records").get().c;
        if (count === 0) {
            console.log("[Database] 0 grade records found. AUTO-REPAIRING grades...");
            db.exec(`
                -- Grades (Cross-term + Cross-session coverage for demo students)
                CREATE TEMPORARY TABLE rawgr (sid TEXT, sub TEXT, sc INTEGER, bd TEXT, tid TEXT);

                -- Grades (Cross-term + Cross-session coverage for demo students)
                CREATE TEMPORARY TABLE rawgr (sid TEXT, sub TEXT, sc INTEGER, bd TEXT, tid TEXT);
                INSERT INTO rawgr VALUES 
                ('STU-001','Mathematics',85,'{"CA1":12,"CA2":13,"Exam":60}','T-AKI'),
                ('STU-001','Further Maths',92,'{"CA1":15,"CA2":12,"Exam":65}','T-AKI'),
                ('STU-001','Physics',88,'{"CA1":14,"CA2":14,"Exam":60}','T-YUS'),
                ('STU-002','Physics',81,'{"CA1":12,"CA2":14,"Exam":55}','T-YUS'),
                ('STU-006','Literature',88,'{"CA1":14,"CA2":14,"Exam":60}','T-OKO'),
                ('STU-011','Financial Accounting',95,'{"CA1":15,"CA2":15,"Exam":65}','T-DAV');

                INSERT OR IGNORE INTO student_records (student_id, subject, assessment, academic_session, term, score, breakdown, teacher_id)
                SELECT sid, sub, 'Total', sess, trm, sc, bd, tid FROM rawgr
                CROSS JOIN (SELECT '2024/2025' AS sess UNION SELECT '2023/2024')
                CROSS JOIN (SELECT 'First Term' AS trm UNION SELECT '1st Term' UNION SELECT 'Term 1');
                DROP TABLE rawgr;
            `);
            console.log("[Database] Auto-repair complete.");
        }
    } catch(err) {
        console.warn("[Database] Auto-repair check failed:", err.message);
    }

    return db;

}


function getDb() {
    if (!db) {
        try {
            const electron = require('electron');
            const app = electron.app || (electron.remote && electron.remote.app);
            if (app) {
                // Priority 1: Look for the seeded demo DB in the private_engine root (Demo Mode)
                const repoDbPath = require('path').resolve(__dirname, "../nexus.sqlite");
                let dbPath = require('path').resolve(app.getPath("userData"), "nexus.sqlite");

                console.log(`[Database] Checking repo path: ${repoDbPath}`);
                if (fs.existsSync(repoDbPath)) {
                    console.log("[Database] Using seeded demo database from project root.");
                    dbPath = repoDbPath;
                } else {
                    console.log("[Database] Seeded file NOT found at repo path. Falling back to AppData.");
                }

                console.log(`[Database] Connecting to: ${dbPath}`);
                const connection = init(dbPath);
                
                // Final Diagnostic: Print row counts of the actual connected DB
                try {
                    const tCount = connection.prepare("SELECT COUNT(*) as c FROM teachers").get().c;
                    const sCount = connection.prepare("SELECT COUNT(*) as c FROM students").get().c;
                    console.log(`[Database] Connection Successful. Teachers: ${tCount}, Students: ${sCount}`);
                } catch (e) {
                    console.error("[Database] Diagnostic query failed:", e.message);
                }
                
                return connection;
            }
        } catch (e) {
            console.error("[Database] Auto-init failed:", e.message);
        }
        throw new Error("Database not initialized. Call init(dbPath) first.");
    }
    return db;
}

module.exports = { init, getDb };
