# Technical Architecture: Financial Hub and Fee Shield

This document outlines the engineering architecture of the Nexus School OS Financial Hub, ledger structure, and the Fee Shield execution gate.

---

## 1. Database Schema

The financial system uses a robust triple-entry ledger design inside SQLite to track billings, payments, and adjustments.

```sql
-- Tracks invoices issued to students based on Applied Fee Schedules
CREATE TABLE student_invoices (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    fee_schedule_id VARCHAR(64) NOT NULL,
    term VARCHAR(16) NOT NULL,
    academic_session VARCHAR(16) NOT NULL,
    amount_billed REAL NOT NULL,          -- Base billed amount (e.g. 50000.0)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(64) NOT NULL,      -- Username of the admin who billed
    FOREIGN KEY(student_id) REFERENCES students(id)
);

-- Tracks adjustments applied to standard bills (Scholarships, waivers, levies)
CREATE TABLE fee_adjustments (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    invoice_id VARCHAR(64),
    type VARCHAR(16) NOT NULL,            -- "WAIVER", "ADDITIONAL_CHARGE"
    amount REAL NOT NULL,                 -- Discount (negative) or charge (positive)
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(64) NOT NULL,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(invoice_id) REFERENCES student_invoices(id)
);

-- Tracks payments received from parents
CREATE TABLE payments (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    amount_paid REAL NOT NULL,            -- Amount received (e.g. 20000.0)
    payment_method VARCHAR(32) NOT NULL,  -- "BANK_TRANSFER", "CASH", "CARD"
    transaction_ref VARCHAR(128),         -- External banking transaction ID
    term VARCHAR(16) NOT NULL,
    academic_session VARCHAR(16) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by VARCHAR(64) NOT NULL,     -- Admin who entered the payment (Audit Log)
    FOREIGN KEY(student_id) REFERENCES students(id)
);
```

---

## 2. The Fee Shield Compilation Gate

During results compilation, `report-compiler.js` runs a financial query to evaluate the student's debt ratio before rendering the report.

### Arithmetic Logic for Debt Ratios
1. **Total Billed**: Sum of standard invoices + positive adjustments.
2. **Total Deductions**: Sum of negative adjustments (waivers/scholarships).
3. **Total Paid**: Sum of all payments.
4. **Real Balance**: `(Total Billed - Total Deductions) - Total Paid`.

### The Code-Level Compilation Gate

Inside `report-compiler.js`, the gate processes this balance:

```javascript
async function evaluateFeeShield(studentId, term, session, config) {
  // If licensing is not Diamond, Fee Shield is bypassed
  if (global.licenseTier !== 'Diamond') {
    return { status: 'CLEARED', balance: 0 };
  }

  const financialSummary = await db.get(`
    SELECT 
      (COALESCE((SELECT SUM(amount_billed) FROM student_invoices WHERE student_id = ? AND term = ? AND academic_session = ?), 0) +
       COALESCE((SELECT SUM(amount) FROM fee_adjustments WHERE student_id = ? AND type = 'ADDITIONAL_CHARGE'), 0)) AS total_billed,
      ABS(COALESCE((SELECT SUM(amount) FROM fee_adjustments WHERE student_id = ? AND type = 'WAIVER'), 0)) AS total_waiver,
      COALESCE((SELECT SUM(amount_paid) FROM payments WHERE student_id = ? AND term = ? AND academic_session = ?), 0) AS total_paid
  `, [studentId, term, session, studentId, studentId, studentId, term, session]);

  const netBilled = financialSummary.total_billed - financialSummary.total_waiver;
  const outstandingBalance = netBilled - financialSummary.total_paid;

  if (outstandingBalance <= config.fee_shield_tolerance_limit) {
    return { status: 'CLEARED', balance: outstandingBalance };
  }

  // Trigger Action Gating depending on term settings
  if (config.fee_shield_mode === 'HARD_LOCK') {
    return { status: 'LOCKED', balance: outstandingBalance };
  } else {
    return { status: 'WATERMARKED', balance: outstandingBalance };
  }
}
```

### Flow Outcome:
* If the status is **`LOCKED`**, the compiler throws a custom exception, which routes the builder to compile the fallback debt warning sheet.
* If the status is **`WATERMARKED`**, the compiler injects a boolean `watermark: true` to the Handlebars compilation context. The CSS layer then overlays a skewed base64 background SVG text:
  ```css
  .watermarked-report::before {
      content: "OUTSTANDING FEES - UNRELEASED REPORT";
      position: absolute;
      transform: rotate(-45deg);
      opacity: 0.12;
      font-size: 4rem;
      /* ... positioning layouts ... */
  }
  ```

---

## 3. Tier Capabilities Comparison

| Architectural Attribute | Gold Capability | Diamond Capability |
| :--- | :--- | :--- |
| **Active DB Ledger** | Writes to `student_invoices` and `payments` tables. | Fully locks database, tracking actions via `recorded_by` indices. |
| **Simultaneous Sync** | Locked to single-device write access. | Multi-admin SQLite WAL mode enabled, permitting concurrent desktop/tablet writes. |
| **Fee Shield Enforcer** | Bypassed. Reports print without financial validation checks. | Active. Bypasses only if explicit exemption flag exists in `student_exemption` table. |
| **Exam QR Gate** | Bypassed. | Generates cryptographic QR string: `encrypt(studentId + ":" + balance)`. |

---

## 4. Live DB Schema (Active Version)

While V1 used `student_invoices` and `payments` tables, the production release leverages a simplified and unified ledger model:

* **`student_fees`**: Tracks aggregated student status per term.
  * Columns: `student_id`, `academic_session`, `term`, `total_billed`, `total_paid`, `status` (`'unpaid' | 'partial' | 'cleared'`), `next_due_date`, `updated_at`.
* **`fee_transactions`**: The payment ledger (Diamond audit-enabled single source of truth).
  * Columns: `id`, `student_id`, `academic_session`, `term`, `amount`, `payment_method` (`'cash' | 'transfer' | 'card'`), `reference_number`, `note`, `recorded_by`, `created_at`.
* **`fee_structures`**: Class category fee templates.
  * Columns: `id`, `class_name`, `item_name`, `amount`, `academic_session`, `term`, `created_at`.
* **`fee_adjustments`**: Custom discounts or waiver entries.
  * Columns: `id`, `student_id`, `academic_session`, `term`, `amount`, `reason`, `recorded_by`, `created_at`.
* **`fee_payment_sessions`**: Temporary WhatsApp bot checkout session tracker.
  * Columns: `id`, `parent_phone`, `student_ids`, `total_amount`, `payment_type`, `partial_percent`, `paystack_ref`, `paystack_access_code`, `status`, `created_at`.

---

## 5. Performance Engineering: 100k-Record Scale

To support schools with large historical transaction registries (exceeding 100,000 records), the following optimizations are applied:

### Compound SQL Indexes
Two static indexes are created in `database.js` during server initialization:
```sql
-- Speeds up pagination and alphabetical class roster sorting
CREATE INDEX IF NOT EXISTS idx_students_class_name 
    ON students (class_name, name);

-- Accelerates status filtering (All/Unpaid/Partial/Cleared) queries
CREATE INDEX IF NOT EXISTS idx_student_fees_session_term_status 
    ON student_fees (academic_session, term, status);
```

### Direct Server-Side Filtering
The `fees:get-roster` IPC handler performs filter execution directly in SQLite. Rather than using subquery wrappers, a clean `COALESCE` check maps non-billed students to `'unpaid'` to preserve accurate counting and pagination:
```sql
SELECT COUNT(*) as total
FROM students s
LEFT JOIN student_fees f
  ON  f.student_id       = s.id
  AND f.academic_session = ?
  AND f.term             = ?
WHERE (s.name LIKE ? OR s.id LIKE ?)
  AND (? = 'all' OR COALESCE(f.status, 'unpaid') = ?)
```

---

## 6. Admin Control: Destruction and Danger Zone

Destructive wipes are restricted via the `fees:clear-data` IPC channel.

### IPC Handler Contract
* **Request Payload**: `{ scope: 'term' | 'session' | 'all', academic_session, term }`
* **Response Payload**: `{ ok: true, counts: { fees, transactions, adjustments, structures } }` or `{ ok: false, error: string }`

### Security Controls
1. **Active Session Requirement**: The handler asserts `currentAdminSession` exists. If not, it rejects with a `401 Unauthorized` equivalent error payload.
2. **Double-Confirmation Flow**: Wipes require two interactive checks:
   * Verification of admin credentials/PIN (verified against `auth:verify-pin` IPC handler).
   * Word matches validation requiring the admin to type `"DELETE"` in a sweetalert modal.
3. **Audit Log Registration**: Successful wipes write to the `audit_logs` table:
   * Action: `'CLEAR_FINANCIAL_DATA'`
   * Target: `'student_fees'`
   * Details: Records the scope, target term/session, and the count of deleted entries across tables.

---

## 7. App Session List Unification

To prevent hardcoded mismatched values, all session dropdown selectors must import and use the standard generator utility:
* **Import**: `import { generateSessionsList } from '../lib/sessions';`
* **Range**: Generates terms from current year - 2 up to current year + 3 (e.g. `2023/2024` through `2028/2029`).
* **Usage**: Extends to `PrintHub.tsx`, `FinancialHub.tsx`, `Dashboard.tsx`, and `Classes.tsx`.

---

## 8. Pull-Based Online Transaction Verification

For schools without static public IPs or tunnel bridges to handle Paystack Webhooks, payment states reconcile via background pull polling.

### Workflow Sequence
1. **Link Dispatch**: When a checkout is requested on WhatsApp, the bot initializes a transaction, registers a `pending` status session in `fee_payment_sessions`, and sends the checkout URL to the parent's phone.
2. **Redirect Configuration**: The checkout link forces a `callback_url` pointing to the public confirmation route `https://nexusos.com.ng/payment-complete`.
3. **Local SCAN (15s)**: Every 15 seconds, the main Electron process queries for pending sessions that are active within a 24-hour window.
4. **Paystack Direct Check**: The poller calls Paystack's official transaction verification endpoint.
5. **Ledger Update**: 
   * If verified **Success**, database ledger transactions are split across linked siblings, and `student_fees` and `fee_payment_sessions` records update to `'settled'`.
   * If verified **Failed**, or if the session exceeds 2 hours without payment, status is set to `'failed'`.
6. **Confirmation Dispatch**: The verification worker directly calls the local `pulse-bot` to trigger the confirmation invoice or failure receipt to the parent on WhatsApp, ensuring immediate confirmation.

