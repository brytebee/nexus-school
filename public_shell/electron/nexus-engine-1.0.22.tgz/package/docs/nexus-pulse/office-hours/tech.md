# Technical Architecture: Office Hours Bot (Local)

This document outlines the implementation of the local WhatsApp bot using `whatsapp-web.js` within the Electron environment.

## 1. Architecture Overview
The Office Hours bot is a local service running in the Electron main process. 
- **Library**: `whatsapp-web.js` (Puppeteer-based).
- **Authentication**: `LocalAuth` strategy persists session data in `~/.nexus_pulse_auth`.
- **UI Bridge**: Communicates state (Starting, QR, Ready) to the renderer via IPC (`pulse-status`).

## 2. Conversation State Machine
To provide a professional experience, the bot uses a stateful `Map` to track parent sessions:
- **Key**: Last 10 digits of the parent's phone number.
- **Value**: Session object containing current state (MENU, SCOPE, TERM_SELECT) and linked student data.
- **TTL**: Sessions automatically expire after 5 minutes of inactivity to free memory and reset the flow.

## 3. Phone Resolution & LID Handling
WhatsApp's multi-device architecture often masks phone numbers with internal Linked IDs (LIDs). The bot implements a multi-strategy resolution:
1. `contact.number` extraction.
2. `contact.id._serialized` parsing (stripping device suffixes).
3. `client.getNumberId(lid)` lookup for hard-to-resolve IDs.

## 4. Security & Privacy
- **Local Data**: All queries are performed against the local `nexus.sqlite` database. 
- **Privacy**: Only numbers registered in the `parent_phone` column of the `students` table can access data. If a number is not found, the bot gracefully declines the request.
- **Gating**: The `pulse:start` IPC channel is only activated if the license tier is `Gold` or higher.

---

## 5. Conversational Parent Email Collection (`AWAITING_EMAIL_INPUT`)

To satisfy the transaction initialization requirement from Paystack without blocking parents, the bot operates a middle-tier confirmation state.

```mermaid
graph TD
    A[AWAITING_PAYMENT_OPTION] -->|Reply 1: Pay Online| B{Email on Record?}
    B -->|Yes| C[Prompt to Confirm or Type New]
    B -->|No| D[Prompt to Type or Reply 2 to Skip]
    C --> E[AWAITING_EMAIL_INPUT]
    D --> E
    E -->|Reply 1| F[Use Existing Email]
    E -->|Reply 2| G[Fetch fallback_email from settings]
    E -->|Type Email| H[Validate Regex & Write back to DB]
    F --> I[generatePaystackLink]
    G --> I
    H --> I
```

### Flow Specifications
* **State Trigger**: When the user selects a payment option (in full, milestone, or custom), the state transitions to `STATE.AWAITING_EMAIL_INPUT`, caching the amount and paymentType details inside `session.paymentContext.pendingTx`.
* **State Inputs**:
  * **Option `1`**: Reuses the student's existing parent email.
  * **Option `2` (Skip)**: Fallback email resolution. Loads `fallback_email` from the `fee_settings` JSON in `app_settings`. If undefined, defaults to `parent-${phone}@nexusos.com.ng`.
  * **Email String**: Asserts email format matching `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`. On success, it writes back to the student registry:
    ```sql
    UPDATE students SET parent_email = ? WHERE id = ?
    ```
  * **Invalid Input**: Sends a validation reminder and stays in the same state.

---

## 6. Paystack Transaction Initialization Interface

The bot communicates with `paystack-service.js` which manages POST payloads to `api.paystack.co/transaction/initialize`.

* **Function Contract**: `async function initializeTransaction(params)`
* **Payload Requirements**:
  * **Email**: The verified parent email or resolved fallback email address.
  * **Amount**: Converted to **kobo** (Naira * 100), as Paystack processes values in minor currency units.
  * **Subaccount Code**: The school's subaccount ID associated with the active bank settings, allowing direct transaction splits.
  * **Callback URL**: Points to `https://nexusos.com.ng/payment-complete` to redirect parents' browsers cleanly upon completion.

---

## 7. Automatic Payment Reconciliation (Pull-Based Poller)

To guarantee reliable transaction delivery without public webhooks, the desktop app operates a local background worker.

### Polling Specifications
* **Interval**: Scans every 15 seconds.
* **Filter Gate**: Queries pending sessions created within the last 24 hours:
  ```sql
  SELECT *, CAST((strftime('%s', 'now') - strftime('%s', created_at)) / 60.0 AS REAL) AS elapsed_minutes
  FROM fee_payment_sessions 
  WHERE status = 'pending' AND created_at >= datetime('now', '-24 hours')
  ```
* **API Verification**: Polls `/transaction/verify/:reference` directly with Paystack using the school's secret keys.
* **Success Lifecycle**: Calls `processSuccessfulPayment()` to execute fee transactions split across sibling students, update payment registers to `settled`, and push a rich receipt invoice to the parent's WhatsApp.
* **Failure Lifecycle**: Calls `processFailedPayment()` if the verification returns failed/reversed status or if the link expires:
  * **Abandonment Gate**: Expire checkout links older than 2 hours.
  * **Unopened Gate**: Expire references that are not found on Paystack after 30 minutes.
  * Pushes a WhatsApp notification alerting the parent of the failure and requesting manual transfer verification.

