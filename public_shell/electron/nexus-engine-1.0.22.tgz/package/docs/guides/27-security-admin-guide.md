# Nexus School OS: Administrator Security & Access Guide

This guide describes the security features protecting your school's data, how to set up two-factor authentication (2FA), how to configure emergency password recoveries, and how the automatic screen locks operate.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

As a sovereign school management system, all your student grades, fee records, and parent contact details are stored **locally on your device**. Nexus School OS uses the **Nexus Sovereign Shield** to restrict access to this local vault. Because there is no central cloud server holding a backdoor, maintaining strong administrator credentials and recovery methods is essential to preventing data lockouts.

---

## 1. What is Protected?

Authentication gates protect key administrative actions throughout the application:
- **System Settings**: Changing the school identity metadata, logos, themes, and stamp configurations.
- **Academic Records**: Modifying class lists, student registrations, or grade ledgers.
- **Financial Roster**: Changing fee structures, applying scholarship waivers, and viewing fee summaries.
- **Mobile Pairing**: Authorizing new tablets to handshake and sync data.
- **Database Maintenance**: Backing up the database, restoring a backup, or wiping the app.

---

## 2. Managing Your Admin Profile

Administrators can customize their display name, upload an avatar, and configure recovery options:
1. Navigate to **Settings** -> click **🔓 Unlock Profile** inside the **Admin Profile & Security** card.
2. Enter your current admin PIN.
3. Update your **Username**, **Recovery Phone**, and **Recovery Email**.
4. Click on the avatar circle to upload a custom profile picture.
5. Enter your PIN or 2FA Code in the verification field and click **Save Profile Shard**.

---

## 3. Setting Up 2-Factor Authentication (2FA)

Two-Factor Authentication adds an extra layer of protection by requiring a 6-digit code from your mobile phone whenever you log in or save profile edits. This runs fully offline.

### 3.1 Initial Setup
1. In the **Admin Profile & Security** card (once unlocked), scroll down to the **Two-Factor Authentication** section.
2. Click **Setup 2FA Authenticator**. A QR code will display alongside a text-based setup key.
3. Open your mobile authenticator app (e.g., Google Authenticator, Microsoft Authenticator, Authy, or Duo).
4. Tap **Add Account** -> scan the QR code on the desktop screen.
5. Once your mobile app shows the 6-digit code for "Nexus School OS", enter it in the **Verification Code** input box.
6. Click **Verify & Enable**.

> [!IMPORTANT]
> Once enabled, your login screen and profile save actions will prompt you to enter the 6-digit token from your authenticator app in addition to your PIN.

---

## 4. Emergency Access & Password Recoveries

If you forget your PIN, the login screen provides a **Forgot PIN/Password?** link. You can reset your credentials using one of these recovery channels:

### 4.1 WhatsApp OTP Verification (Default)
1. Clicking forgot credentials will send a 6-digit one-time password (OTP) via WhatsApp to your configured recovery phone number.
2. Enter the OTP code and confirm your username.
3. Once verified, you will be prompted to set a new 4-digit PIN or text password.

### 4.2 Security Questions (Backup)
If the device is offline or WhatsApp delivery fails, you can fall back to the security question and answer configured during school setup.

---

## 5. Security Screen Locks

The application automatically locks down under the following conditions:

### 5.1 No-Activity Lock (Auto-Lock)
If there is no keyboard or mouse activity on the laptop for **15 minutes**, the screen automatically locks. You will be redirected to the secure login screen to re-authenticate. This prevents unauthorized staff or students from accessing the ledger when the administrator is away from the keyboard.

### 5.2 Boot Lock Restrictions
If the application detects license irregularities on startup, it will block access and show a dynamic lock screen:
- **No License Found**: The software is not activated.
- **License Integrity Error**: The license file has been modified or corrupted.
- **License Expired**: Subscription has run its course.
- **Device Revoked**: This machine's access has been disabled remotely by the school network admin.

---

## Tier Availability

All profile features and security warnings are **standard across all tiers**. Advanced multi-admin audit logging (tracking which admin performed which database transaction) is exclusive to the **Diamond Tier**.
