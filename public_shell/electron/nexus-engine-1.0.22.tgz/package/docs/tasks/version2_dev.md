# 🚀 Nexus School OS — Version 2 Development Master Tracker

> Companion to `nexus_master_plan.md`. This file tracks every feature, engineering
> initiative, and infrastructure task for the V2 cycle in a single, scannable
> reference. Cross-references: `react-migration.md` (frontend architecture),
> `nexus_master_plan.md` (product strategy & business context).

---

## 📋 V1 Feature Audit: What Is Live Today

### ✅ Active Nav Items (fully working in production build)

| # | View Label | `data-view` | Tier Gate | JS Module(s) |
|---|---|---|---|---|
| 1 | Dashboard | `dashboard` | None | `dashboard.js` |
| 2 | Teachers | `teachers` | None | `teachers.js` |
| 3 | Students | `students` | None | `students.js` |
| 4 | Sync Hub | `sync` | None | `sync.js` |
| 5 | Print Hub | `printhub` | None | `printhub.js` |
| 6 | Result Studio | `result-studio` | None | `result-studio.js` |
| 7 | Attendance | `attendance` | 🥇 Gold | `attendance-ui.js` / `attendance.js` |
| 8 | Nexus Pulse | `pulse` | 🥇 Gold | `pulse-ui.js` |
| 9 | Financial Hub | `fees` | 🥇 Gold | `fees-ui.js` |
| 10 | Sovereign Portal | `portal` | 🥇 Gold | `portal-ui.js` |
| 11 | Portal Content | `portal-content` | 🥇 Gold | `portal-content-ui.js` |
| 12 | Nexus Scholar | `scholar` | 💎 Diamond | `scholar-ui.js` |
| 13 | CBT Arena | `cbt` | 💎 Diamond | `cbt-ui.js` / `cbt-ipc-handlers.js` |
| — | Settings | `settings` | None | `settings.js` |
| — | About | `about` | None | inline |

**Core engine modules (private_engine/src/):**
- `database.js` — SQLite init, schema migrations, all DB queries
- `report-compiler.js` — grade context, ranking engine, PDF HTML generation
- `scholar.js` — NexusScholar class (AI/analytics layer)
- `server.js` — Express LAN server, device pairing, sync endpoints

---

## 🔮 Coming Soon — Currently in Sidenav (SOON badge)

These have sidenav entries and stub views but **no working implementation yet**:

| Label | `data-view` | Pitch Doc Reference | Tier | Priority |
|---|---|---|---|---|
| ⚡ Live Quiz System | `live-quiz` | Slide 07 — Nexus Live Quiz Arena | 💎 Diamond | Phase 7 |
| 📈 Analytics Dashboard | `analytics` | Slide 05/08 — At-Risk flagging, WAEC prep | 💎 Diamond | Phase 7 |
| 📚 Notes Marketplace | `notes-marketplace` | Slide 06 — Revenue Stream 3 | 💎 Diamond | Phase 8 |
| 🎯 Skill Mastery | `skill-mastery` | Slide 08 — IEP-standard academic tracking | 💎 Diamond | Phase 7 |

---

## ⚠️ Missing — Promised to Customers, Not Yet in the App

Sold in the pitch document and tier descriptions but have **no nav entry** (not even coming soon):

| Feature | Where Promised | Tier | Phase | Notes |
|---|---|---|---|---|
| **Verified Student Public Profiles** | Pitch Slide 06, Gold plan | 🥇 Gold | 6 | Cloud-hosted shareable academic records. See [archive-transcripts-registry.md](archive-transcripts-registry.md) and [nexus-transfer-badge.md](nexus-transfer-badge.md) |
| **Digital Assignment Hub** | Pitch Slide 08, Gold plan | 🥇 Gold | 6 | Teacher assigns, student/parent views |
| **Parent Portal (read view)** | Pitch Slide 08, Gold plan | 🥇 Gold | 5 | Parents view results on school LAN — `portal.html` serves this but no dedicated admin section for managing it |
| **Multi-Campus Sync** | Pitch Slide 08, Diamond plan | 💎 Diamond | 8 | Unified dashboard across branches |
| **Mobile Admin "Command Center"** | Master plan Phase 7 | 💎 Diamond | 7 | Principal's dedicated mobile app |
| **Mobile Role-Based Screens** | Sprint 2 Feedback | All Tiers | 6 | Dynamically switches mobile screens based on authenticated staff role (Command Center for Super Admin/Principal, Grader/Roster for Teachers, Financials/Invoicing for Bursar). |
| **Standalone Pack (Admin Extension)** | Field experience / demo feedback | 🆕 Standalone | 0 | One-time-purchase product. 2-device admin-extension mobile sync, reporting-only. See `docs/plan-details/standalone.md` |
| **Biometric Staff Attendance** | Master plan Custom Features | Custom upsell | 7 | USB fingerprint scanner clock-in/out |
| **Dynamic Fee Reminders / Fee Pulse** | Master plan Custom Features | Custom upsell | 7 | On-demand WhatsApp fee blast |
| **Exam Hall Clearance QR** | Master plan Custom Features | Custom upsell | 7 | Green/Red gate for fee-cleared exam entry |

---

## 🆕 New Initiatives (V2 Additions — Not in V1 Plan)

### 1. 🏗️ React Migration (HIGHEST PRIORITY — ENGINEERING)

Full frontend architecture modernisation from 2,500-line `index.html` to
componentised React + Vite. This is the foundation every subsequent V2 feature
will be built on.

**See full plan:** `private_engine/docs/tasks/react-migration.md`

**Summary of approach:**
- Strangler-fig migration (no big-bang rewrite, no feature freeze)
- Phase 0: Vite + React scaffolding alongside existing `index.html`
- Phase 1: Shared design system (DataTable, Modal, StatusBadge, NavSidebar) aligned strictly with the [Design System Specification](file:///Users/MAC/Documents/Projects/nexus-school/docs/system/design.md)
- Phase 2: Migrate views one at a time (12 views over 6 weeks)
- Phase 3: Portal HTML → React
- Phase 4: CBT as first-class React app

**React migration is a prerequisite for:** Roles system, Technician Console,
Live Quiz, Analytics Dashboard, all V2 features.

---

### 2. 🧪 Test Suite (Prerequisite to React Migration)

Guard all working V1 logic before any migration begins. Tests must pass in
both vanilla JS (current) and React (post-migration) — achieved by testing
pure logic modules that both layers consume.

**Framework:** Vitest (already installed via Vite)

**Test modules to be extracted and guarded:**

| Test File | Logic Being Tested | Source Location |
|---|---|---|
| `grading.test.js` | `getGradeInfo()`, A1–F9 scale lookup | `report-compiler.js` |
| `ranking.test.js` | `computeRankMap()`, dense ranking, tie handling | `report-compiler.js` |
| `subject-ranking.test.js` | `computeSubjectRankMap()`, per-subject class rank | `report-compiler.js` |
| `scoring.test.js` | Score aggregation, average, percent calculation | `report-compiler.js` (inline) |
| `fee-calculator.test.js` | Balance calc, `cleared/partial/unpaid` status | `fees-ui.js` (extract) |
| `tier-gates.test.js` | `canAccessView(tier, view)` gating | `nav.js` / `boot.js` (extract) |
| `attendance.test.js` | `computeAttendanceScore()`, days/total formula | `report-compiler.js` |
| `cbt-scoring.test.js` | Score tallying, time tracking, answer validation | `cbt-ipc-handlers.js` (extract) |

**Structure:**
```
public_shell/electron/
├── src/lib/              ← Extracted pure logic (new)
│   ├── grading.js
│   ├── ranking.js
│   ├── scoring.js
│   ├── fee-calculator.js
│   ├── tier-gates.js
│   └── attendance.js
└── tests/                ← Test suite (new)
    ├── grading.test.js
    ├── ranking.test.js
    └── ...
```

> **The migration contract:** A view passes its React migration check only
> when all tests for its logic still pass after the port.

---

### 3. 🔀 Unified Single-Port Routing & Handshake Deprecation (Zero-Router Topology) (✅ Aliases & Deprecation Warnings Live)

Consolidate all local network listeners (Parent Portal, CBT Client, and Grader Sync) into a single Express server running on Port 3000 to prevent port collisions, simplify firewall rules, and support zero-router hotspots. As part of this upgrade, the multi-step pairing handshake protocol is deprecated, and device pairing is handled implicitly and securely on first-sync via a single `/api/sync` endpoint.

**See full plan:** [networking-upgrade.md](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/docs/tasks/networking-upgrade.md)

---

### 4. 👥 User Roles & Role-Based Access Control (RBAC) (✅ Phase 1 Schema & Handshake Foundation Live)

Multi-admin support within the desktop app. Currently all admins have
identical full access.

**Planned roles:**

| Role | Access |
|---|---|
| **Super Admin / Principal** | Full access to all views and settings |
| **Bursar** | Financial Hub + fee reports only |
| **Form Teacher** | Own class grades + attendance only |
| **Result Clerk** | Result Studio + Print Hub, no financial data |
| **IT Admin** | Sync Hub + device management only |

**Implementation considerations:**
- Role definitions stored in SQLite (`staff_roles` table)
- Role enforced at nav.js tier-gate level (same pattern as Silver/Gold/Diamond)
- Audit trail: every action tagged with staff_id + role
- Login: PIN or biometric per role (reuse existing biometric system)
- Must be built in React (ties directly to React migration Phase 1 NavSidebar component)

---

### 5. 🔧 Technician Console (Scoped License Management)

Field technicians who perform onsite installs need a way to generate and
deliver `license.nexus` files **without** receiving the Ed25519 signing secret
or access to the full `/sovereign` dashboard.

**Problem:** Giving a technician the signing key = unlimited, unaccountable
license generation. Giving them `/sovereign` access = exposure of all school
data and billing.

**Solution — Technician API Portal:**

A scoped web interface (can live under `/sovereign/technicians` or as a
separate subdomain) where:

1. Technician logs in with their own account (no sovereign session)
2. They fill in school details (name, tier, student count, terms)
3. The server generates and signs the license (secret never leaves server)
4. Every generation is logged: technician ID + timestamp + school + license hash
5. The owner can audit all technician-generated licenses from `/sovereign`

**Technician account capabilities:**
- ✅ Generate licenses for assigned schools
- ✅ View their own generation history
- ✅ Download the `license.nexus` file
- ❌ Cannot set pricing or discounts
- ❌ Cannot see other technicians' schools
- ❌ Cannot access billing, payments, or sovereign-level data

**Two delivery modes for edge cases:**
- **Online delivery:** Server emails/provides the `license.nexus` directly
- **Pre-generated:** Owner generates the file and hands it to the technician
  on USB for fully offline deployments

---

### 6. 📖 Onsite Installation Documentation

Guides for field technicians and school administrators. Both render in the
live docs portal.

| Doc | Audience | Location |
|---|---|---|
| **Onsite & Activation Guide (Admin)** | School admins | `docs/onsite-installation/sch.md` → `/portal/docs/onsite-installation` |
| **Onsite & Licensing Guide (Developer/Tech)** | Field technicians | `docs/onsite-installation/tech.md` → `/sovereign/docs/onsite-installation/tech` |

**Status:** ✅ Written and rendering in portal. See `nexusos` repo.

---

### 7. 🖥️ Terminal Architecture, Staff Accounts & Revoke Compromised Device Flow

Complete the decentralized device registration, authentication, staff roles, and device revocation flow for Nexus School OS V2.

#### 🔍 Findings & Security Gaps Identified
- **In-Memory Revocation (Security Leak):** The server `Set` (`app.locals.revoked_devices`) in `private_engine/src/server.js` is ephemeral. App restarts silently restore access to all revoked devices.
- **Handshake Vulnerability:** The `/handshake` endpoint delivers entire student rosters and configs to clients, but lacks a check for revoked devices. Compromised devices could easily pull the full roster.
- **UI Disconnect:** The "Revoke Compromised Device" form button (`#revoke-device-btn`) in `public_shell/electron/index.html` has no event listener bound to it.
- **Android Ready:** The Kotlin Android client already handles `403` responses containing `"REVOKED"` securely by purging its local Room database and returning to `HandshakeActivity`.

#### 📋 Technical Execution Plan
1. **Persistent Revoked Whitelist (SQLite):**
   - Create table `revoked_devices` in `database.js` during migration init:
     ```sql
     CREATE TABLE IF NOT EXISTS revoked_devices (
         device_id TEXT PRIMARY KEY,
         revoked_at DATETIME DEFAULT CURRENT_TIMESTAMP
     );
     ```
2. **Server Revocation Checks:**
   - In `server.js`, lazy-load or load the revoked devices from the SQLite database into `app.locals.revoked_devices` on server startup.
   - Enforce check at both `/sync` and `/handshake` POST endpoints. If device is revoked, return `403 Forbidden` with `{ error: "REVOKED" }`.
   - Update `revokeDevice(deviceId)` in `server.js` to write to the persistent DB table:
     ```javascript
     db.prepare('INSERT OR IGNORE INTO revoked_devices (device_id) VALUES (?)').run(deviceId);
     ```
3. **Frontend Action Wiring:**
   - In `public_shell/electron/js/sync.js`, wire up `#revoke-device-btn` inside `initSyncListeners()`.
   - Read `#revoke-device-id`, show a red-tinted warning confirmation modal (`Swal.fire`), and call `window.electronAPI.revokeDevice(deviceId)`.

---

### 8. 🎓 Internal CBT Exam Automation & Academic Pipeline Integration

This initiative connects the CBT Arena directly to the student ledger, making internal exams first-class citizens of the academic reporting pipeline. It resolves three architectural gaps discovered during V2 review:
1. **Class system is flat** — No concept of class arms (SS1A/SS1B/SS1C). The promotion engine fails silently when `class_name` includes an arm suffix.
2. **Internal exam deploy is disconnected** — Target Class is a free-text input. No students are auto-fetched, no tokens auto-generated, session/term are hardcoded.
3. **Multi-batch exams have no anti-collusion layer** — Students writing later batches (next day) can be briefed. No per-student question randomisation, no batch window enforcement, no token identity locking.

#### A. Class Arms Architecture
Schools use class variants: SS1A, SS1B, SS1C. These are arms of the same academic level.
* **Model:** Academic Level (stored in `class_hierarchy`) + Class Arm (stored in `class_arms` system setting) = Full Display (level + arm, e.g., SS1A).
* **Promotion Logic:** Promotes by level only. Arm is preserved across promotions (SS1A → SS2A) unless overridden by admin. Admin can migrate students between arms at any time with no record loss.
* **Schema changes:**
  ```sql
  ALTER TABLE students ADD COLUMN class_arm TEXT DEFAULT '';
  ALTER TABLE cbt_tokens ADD COLUMN question_seed TEXT;
  ```
* **System Settings new keys:**
  - `class_arms`: list of arm labels (e.g. `["A", "B", "C"]`).
  - `terms`: optional list of term labels overriding defaults (e.g. `["First", "Second", "Third"]`).

#### B. Internal Exam Automation
When an internal exam is deployed:
1. Admin selects **Class Level** (from `class_hierarchy`) + **Class Arm** (All / A / B / C).
2. Admin inputs **number of functional PCs** → system auto-calculates batch count (e.g., 48 students ÷ 20 PCs = 3 batches, named Batch 1 / 2 / 3) and auto-splits candidate assignments.
3. **Academic Session** is read-only and auto-pulled from `system_settings.current_academic_session`.
4. **Term** is selected from the configured term options.
5. On deploy, system queries matching students and auto-generates CBT tokens pre-assigned to the generated batches.

#### C. CBT Security Hardening — Anti-Collusion Layer
Three security layers are implemented to safeguard multi-batch exams:
1. **Question Diversity (Seeded Shuffle):** An 8-character `question_seed` is stored on each token. During the CBT Portal serve request, a seeded Fisher-Yates shuffle is run to randomize the questions and option ordering per candidate. This is highly resource-efficient (~8 bytes per student vs kilobytes for snapshots) and matches the target hardware specs (8GB RAM, 250GB HDD).
2. **Temporal Lockout (Batch Windows):** CBT Portal validates that `start_time <= now <= end_time` for the token's batch.
3. **Identity Binding (One-Time-Use):** Token changes status to `in_progress` on first load, and `completed` on submit. No re-entry allowed.
4. **Result Release Policy:** Portal enforces blackout policies (`immediate`, `delayed_1h`, `delayed_24h`, or `manual`) to hide scores until the exam window is completed.

#### D. Reporting Surface
Internal exam scores in `cbt_tokens` link to `student_id` and the `cbt_exams` details (session, term, class), enabling direct SQL querying of academic records for student reporting profiles and Phase 7 analytics.

#### Files Affected
* `private_engine/src/database.js` — Schema migrations for `class_arm` and `question_seed`.
* `public_shell/electron/cbt-ipc-handlers.js` — Promotion engine updates; student queries; token seed & batch auto-generation; batch window enforcement.
* `public_shell/electron/preload.js` — Expose student retrieval and setting handlers.
* `public_shell/electron/js/settings.js` — Settings panel tag builder for `class_arms` & `terms`.
* `public_shell/electron/src/views/CbtArena.tsx` — Deploy form overhaul (level/arm selectors, PC count, academic session displays).
* Students ledger UI — Split single class field into Level and Arm dropdowns.
* CBT Portal server — Seeded question shuffle, batch window, token status checks.

**Priority:** Phase R+1 (after core React views stabilize)

---

### 9. 📦 Standalone Pack — Admin Extension Product

A one-time-purchase product created from field experience and active school demos. Schools hesitant about recurring subscription fees can acquire this as an entry point into the Nexus ecosystem.

This is **not the Silver plan**. The Silver plan (termly payments) remains completely unaffected. The Standalone Pack is a distinct internal tier identified as `"Standalone"` in all code paths.

#### What It Is
- A stripped-down, reporting-only version of Nexus School OS sold at a flat one-time price.
- Mobile sync is included but acts as an **Admin Extension** — not teacher-specific. The school admin (or their assistant) can enter grades for any class from the device, acting as an extension of the admin's desktop.
- Maximum 2 paired mobile devices.
- No teacher-allocation model: the device sees all classes and all students. All actions are attributed to "Admin" in activity logs (device metadata tracked — see Initiative 10).

#### Feature Scope
| Feature | Status |
|---|---|
| Student Database | ✅ |
| Teacher Directory | ✅ |
| Result Studio (Entire School scope only) | ✅ |
| Print Hub (Clean Slate + class_photo template) | ✅ |
| Sync Hub (2 devices, Admin Extension mode) | ✅ |
| Attendance Module | ❌ Locked |
| Financial Hub | ❌ Locked |
| Nexus Pulse | ❌ Locked |
| Sovereign Portal | ❌ Locked |
| Nexus Scholar / CBT Arena | ❌ Locked |

#### Key Technical Differences from All Subscription Plans
1. **`STANDALONE_ADMIN` Identity**: Handshake generates an admin QR with no teacher picker. Server validates a special `STANDALONE_ADMIN` identity, skips `teacher_allocations` checks, and delivers the full student roster.
2. **Device limit enforced at handshake**: If a 3rd device attempts to pair, server returns `403` — *"Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."*
3. **Photo Report Template**: Standalone includes the `class_photo` report template that renders student passport photographs inline with results. Also available to Silver+ plans.
4. **Grade attribution**: All grades from a Standalone device are attributed to `"Admin"` using device metadata rather than teacher identity.

#### Upgrade Messaging
At any device-limit or locked-feature encounter:
> *"Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."*

**See full product details:** `docs/plan-details/standalone.md`

---

### 10. 🪵 Activity Log & Device Ledger (Device-Attributed Audit Trail)

Currently, actions (grade entries, student registrations, syncs) are attributed only to a teacher name string — fragile and unsearchable. There is no persistent audit trail of which device performed which action at what time.

This initiative establishes a device-attributed activity log foundational to RBAC (Initiative 4), the Standalone Pack (Initiative 9), and the Technician Console (Initiative 5).

#### Why It Matters
- **Standalone Pack**: No teacher identities exist — only admin device identities. Logs must be device-attributed.
- **RBAC**: Role-based access control requires every action to be auditable by actor.
- **Accountability**: Schools with multiple devices need to know which device submitted what, especially for grade disputes.

#### What Gets Logged
Every processed sync event is recorded with:
- `device_id` — unique hardware-fingerprinted identifier (already captured at handshake)
- `device_model` — Android device model string (to be added to handshake payload)
- `actor_label` — `teacher_name` for subscription plans; `"Admin"` for Standalone; role name for future RBAC
- `event_type` — `UPDATE_GRADE`, `ADD_STUDENT`, `ATTENDANCE_UPDATE`, etc.
- `payload_hash` — SHA-256 of the event payload (integrity check)
- `received_at` — server timestamp

#### Schema
```sql
CREATE TABLE IF NOT EXISTS activity_log (
    log_id       TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(8)))),
    device_id    TEXT NOT NULL,
    device_model TEXT,
    actor_label  TEXT NOT NULL,
    event_type   TEXT NOT NULL,
    payload_hash TEXT,
    received_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### Files Affected
- `private_engine/src/database.js` — Add `activity_log` table migration
- `private_engine/src/server.js` — Write to `activity_log` on every processed sync event; intake `device_model` from handshake
- `public_shell/android/.../network/HandshakeService.kt` — Add `device_model: String` to `DeviceResponse`
- `public_shell/android/.../security/IdentityManager.kt` — Add `saveDeviceModel()` / `getDeviceModel()`
- `public_shell/android/.../network/SyncWorker.kt` — Include `device_model` in `SyncPayload`
- `public_shell/electron/js/sync.js` — Surface activity log in Sync Hub UI (Admin Activity Feed)

**Priority:** Implement alongside Standalone Pack (Initiative 9). Required for RBAC.

---

### 11. ⚡ Live Quiz Arena (Redefined Local Event System)

**Status:** Scoped for **Diamond plan schools** (but can be enabled in demo mode to win school admins during marketing pitches).
**Priority:** Coming-up / Low Priority ATM (not part of immediate V2 cash-generation tasks).

#### What It Is
A local, gamified classroom/hall event quiz system designed to digitize school quiz/debate competitions without needing internet connectivity or expensive hardware gadgets.

#### How It Works
1. **The Host Stage**: The school admin's laptop runs the master quiz console and is projected onto a hall screen or TV. It renders questions, option lists, countdown timers, and the real-time scoreboard.
2. **The Contestants**: Contestants/teams use tablets or phones connected to the host laptop's local Wi-Fi hotspot.
3. **The Connection**: Contestants join by scanning a QR code shown on the projector screen, which automatically opens the contestant screen in their web browser (hosted locally by the desktop app's built-in server).
4. **Real-time Play**: The projector displays the question, and contestants tap options (A, B, C, D) or hit a large "Buzzer" button on their screens. Scores are tabulated automatically based on correctness and speed.

#### Technical Architecture
- **Local WebSocket Hub**: Embedded in the server layer (`private_engine/src/server.js`) to handle low-latency real-time events (buzzer clicks, timers, score syncs).
- **Contestant View**: A light, responsive, zero-install HTML5/JS page served locally from the hub.
- **Scoreboard Interface**: A dynamic, animated React component in the desktop app designed to show real-time changes and high scores to the hall.

### 12. 📱 Mobile Dynamic Role-Based Layouts (Sprint 2 Extension)

Provide tailored interfaces on the Android client depending on the logged-in staff role:
* **Super Admin / Principal**: Opens a mobile "Command Center" dashboard displaying school statistics, real-time sync feeds, and attendance aggregates.
* **Bursar**: Displays student payment status lists, incoming receipts queue, and fee waiver approvals.
* **Teacher**: Loads the standard Class Roster, grading grid, and student attendance sheets.

---

## 📅 Recommended V2 Build Order

```
[NOW]      1. Extract logic → src/lib/  +  Write test suite
           2. All tests green on vanilla JS

[PHASE R0] 3. React: Vite scaffold + .env toggle (USE_REACT_UI)
           4. React: Design system components

[PHASE R1] 5. React: Migrate views one-by-one (tests stay green throughout)

[PARALLEL] 6. Standalone Pack + Activity Log & Device Ledger (cash-generation priority)
           7. Internal CBT Automation & Class Arms (schema + backend — no React dependency)
           8. Technician Console API (backend — no React dependency)
           9. RBAC schema + role definitions in DB
           10. Wire up persistent Device Revocation flow (DB + Server + UI)

[PHASE R2] 10. React: RBAC-aware NavSidebar + role login screen

[PHASE R3] 11. Coming Soon features built in React from day one:
               - Live Quiz Arena (Redefined Local Event System — Diamond Only)
               - Analytics Dashboard
               - Notes Marketplace
               - Skill Mastery Tracking

[PHASE R4] 12. Missing Gold features:

               - Assignment Hub
               - Verified Student Public Profiles
               - Parent Portal admin view

[FUTURE]   13. Multi-Campus Sync
           14. Mobile Admin Command Center
           15. Biometric Staff Attendance
           16. Exam Hall Clearance QR
```

---

## 🔗 Related Documents

| Document | Location | Purpose |
|---|---|---|
| Master Plan | `private_engine/nexus_master_plan.md` | Product strategy, business model, tier definitions |
| React Migration | `private_engine/docs/tasks/react-migration.md` | Full frontend architecture plan |
| Design System Spec | `docs/system/design.md` | Visual guidelines, component variables, and CSS style standards |
| Networking Upgrade | `private_engine/docs/tasks/networking-upgrade.md` | Single-port routing design and specs |
| Standalone Pack | `private_engine/docs/plan-details/standalone.md` | One-time purchase product, admin extension mobile mode |
| This File | `private_engine/docs/tasks/version2_dev.md` | V2 feature tracker |
| Student Exits | `private_engine/docs/tasks/student-exit-status.md` | Database schemas, sync filters, and progress rollover spec |
| Letterhead Builder | `private_engine/docs/tasks/letterhead-builder.md` | WYSIWYG letter editor and letterhead canvas layout spec |
| Archive & Transcripts | `private_engine/docs/tasks/archive-transcripts-registry.md` | Multi-session transcript engine and official credentials spec |
| Transfer Badge | `private_engine/docs/tasks/nexus-transfer-badge.md` | CBOR binary QR, ECDSA validation, and 3-Party Split-Token Protocol spec |
| Pitch Document | `private_engine/Nexus_School_OS_Pitch_Document.md` | Customer-facing feature promises |
| Onsite Admin Guide | `nexusos/docs/onsite-installation/sch.md` | School admin setup |
| Onsite Tech Guide | `nexusos/docs/onsite-installation/tech.md` | Developer onsite guide |
| Business Analysis | `docs/business/honest_analysis.md` | Field observations and business model discussion |
