/**
 * Nexus School OS — Staff Web Portal Client
 * Bank-Grade Security: 10-Minute Idle Inactivity Lock
 */

(function () {
  'use strict';

  // ── Session & Idle Timeout State ───────────────────────────────────────────
  const IDLE_LIMIT_MS = 10 * 60 * 1000; // 10 minutes
  const WARNING_MS = 9 * 60 * 1000;    // 9 minutes (warning at 60s left)
  let lastActiveTime = Date.now();
  let idleCheckInterval = null;

  let currentTeacher = null;
  let currentSession = null; // { token, ... }
  let cachedStudents = [];
  let teacherArmsMap = {};
  let teacherAllocations = [];
  let currentCurriculum = null;
  let currentScoreComponents = [];
  let currentJointData = { is_joint: false, arms: [] }; // joint grading state for loaded sheet

  // DOM Elements
  const loginView = document.getElementById('login-view');
  const portalView = document.getElementById('portal-view');
  const loginForm = document.getElementById('login-form');
  const loginError = document.getElementById('login-error');
  const idleWarning = document.getElementById('idle-warning');
  const idleCountdown = document.getElementById('idle-countdown');
  const logoutBtn = document.getElementById('logout-btn');

  // ── Universal In-App Toast & Modal Notifications ─────────────────────────
  function showToast(message, type = 'error') {
    let toast = document.getElementById('nexus-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'nexus-toast';
      toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%) translateY(100px);
        background: #0f172a;
        color: #f8fafc;
        padding: 12px 20px;
        border-radius: 14px;
        font-size: 13px;
        font-weight: 700;
        box-shadow: 0 12px 36px rgba(0,0,0,0.6);
        border: 1px solid rgba(255,255,255,0.12);
        z-index: 10000;
        transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s ease;
        opacity: 0;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 90vw;
        pointer-events: none;
      `;
      document.body.appendChild(toast);
    }
    const icon = type === 'error' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️';
    const borderColor = type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#00e5ff';
    toast.style.borderColor = borderColor;
    toast.innerHTML = `<span style="font-size:16px;">${icon}</span><span>${message}</span>`;
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';

    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-50%) translateY(100px)';
    }, 3800);
  }

  // ── Idle Inactivity Watcher ────────────────────────────────────────────────
  function recordUserActivity() {
    lastActiveTime = Date.now();
    if (!idleWarning.classList.contains('hidden')) {
      idleWarning.classList.add('hidden');
    }
  }

  function startIdleWatcher() {
    ['mousemove', 'keydown', 'scroll', 'click', 'touchstart'].forEach(evt => {
      window.addEventListener(evt, recordUserActivity, { passive: true });
    });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        const elapsed = Date.now() - lastActiveTime;
        if (elapsed >= IDLE_LIMIT_MS && currentSession) {
          lockSession('Session expired while inactive in background.');
        } else {
          recordUserActivity();
        }
      }
    });

    if (idleCheckInterval) clearInterval(idleCheckInterval);
    idleCheckInterval = setInterval(checkIdleStatus, 2000);
  }

  function checkIdleStatus() {
    if (!currentSession) return;
    const elapsed = Date.now() - lastActiveTime;
    const remainingMs = IDLE_LIMIT_MS - elapsed;

    if (remainingMs <= 0) {
      lockSession('Session locked due to 10 minutes of inactivity.');
    } else if (remainingMs <= (IDLE_LIMIT_MS - WARNING_MS)) {
      idleWarning.classList.remove('hidden');
      idleCountdown.textContent = Math.ceil(remainingMs / 1000);
    } else {
      idleWarning.classList.add('hidden');
    }
  }

  function lockSession(reason) {
    if (currentSession?.token) {
      fetch('/api/staff/logout', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${currentSession.token}` }
      }).catch(() => {});
    }
    sessionStorage.removeItem('nexus_staff_session');
    currentSession = null;
    currentTeacher = null;
    idleWarning.classList.add('hidden');

    portalView.classList.add('hidden');
    loginView.classList.remove('active');
    loginView.classList.remove('hidden');
    loginView.classList.add('active');

    if (reason) {
      loginError.textContent = reason;
      loginError.classList.remove('hidden');
    }
  }

  // ── Network Helper with Auth ──────────────────────────────────────────────
  async function apiFetch(url, options = {}) {
    if (!currentSession?.token) {
      lockSession('Please log in.');
      throw new Error('Not authenticated');
    }
    const headers = options.headers || {};
    headers['Authorization'] = `Bearer ${currentSession.token}`;
    if (!headers['Content-Type'] && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }
    options.headers = headers;

    const res = await fetch(url, options);
    if (res.status === 401 || res.status === 403) {
      lockSession('Session expired or unauthorized. Please re-authenticate.');
      throw new Error('Session expired');
    }
    recordUserActivity();
    return res;
  }

  // ── App Initialization ────────────────────────────────────────────────────
  async function initApp() {
    startIdleWatcher();
    const saved = sessionStorage.getItem('nexus_staff_session');
    if (saved) {
      try {
        currentSession = JSON.parse(saved);
        await loadPortalData();
        return;
      } catch (e) {
        sessionStorage.removeItem('nexus_staff_session');
      }
    }
    showLogin();
  }

  function showLogin() {
    loginView.classList.remove('hidden');
    loginView.classList.add('active');
    portalView.classList.add('hidden');
    loginError.classList.add('hidden');
  }

  function showPortal() {
    loginView.classList.remove('active');
    loginView.classList.add('hidden');
    portalView.classList.remove('hidden');
    portalView.classList.add('active');
  }

  // ── Login Handler ─────────────────────────────────────────────────────────
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hidden');
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const btn = document.getElementById('login-btn');

    btn.disabled = true;
    btn.textContent = 'Verifying credentials…';

    try {
      const res = await fetch('/api/staff/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      currentSession = { token: data.token, teacher: data.teacher };
      sessionStorage.setItem('nexus_staff_session', JSON.stringify(currentSession));
      recordUserActivity();
      await loadPortalData();
    } catch (err) {
      loginError.textContent = err.message;
      loginError.classList.remove('hidden');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Sign In to Portal →';
    }
  });

  logoutBtn.addEventListener('click', () => {
    lockSession('You have logged out.');
  });

  // ── Navigation Tabs ───────────────────────────────────────────────────────
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active', 'hidden'));

      tab.classList.add('active');
      const targetId = tab.getAttribute('data-tab');
      document.querySelectorAll('.tab-content').forEach(c => {
        if (c.id === targetId) c.classList.add('active');
        else c.classList.add('hidden');
      });
    });
  });

  // Module switcher: Attendance vs Grades
  const modeAttendanceBtn = document.getElementById('mode-attendance-btn');
  const modeGradesBtn = document.getElementById('mode-grades-btn');
  const attendanceSection = document.getElementById('attendance-section');
  const gradesSection = document.getElementById('grades-section');

  modeAttendanceBtn.addEventListener('click', () => {
    modeAttendanceBtn.classList.add('active');
    modeGradesBtn.classList.remove('active');
    attendanceSection.classList.remove('hidden');
    gradesSection.classList.add('hidden');
  });

  modeGradesBtn.addEventListener('click', () => {
    modeGradesBtn.classList.add('active');
    modeAttendanceBtn.classList.remove('active');
    gradesSection.classList.remove('hidden');
    attendanceSection.classList.add('hidden');
  });

  // ── Load Portal Data ──────────────────────────────────────────────────────
  async function loadPortalData() {
    try {
      const res = await apiFetch('/api/staff/me');
      const data = await res.json();

      currentTeacher = data.teacher;
      document.getElementById('nav-staff-name').textContent = currentTeacher.name || 'Educator';
      document.getElementById('nav-school-name').textContent = data.school_name || 'Nexus School';

      // Term & Session
      document.getElementById('grade-term-display').value = `${data.current_term} (${data.current_session})`;

      // Profile View in Settings
      document.getElementById('set-staff-id').textContent = currentTeacher.id;
      document.getElementById('set-staff-name').textContent = currentTeacher.name;
      document.getElementById('set-form-class').textContent =
        (currentTeacher.form_classes && currentTeacher.form_classes.length > 0)
          ? currentTeacher.form_classes.join(', ')
          : 'None (Subject Teacher)';
      document.getElementById('set-scope-policy').textContent =
        data.attendance_scope === 'any_taught_class'
          ? 'Any class taught'
          : 'Form master class only';

      document.getElementById('set-email-input').value = currentTeacher.email || '';
      document.getElementById('set-phone-input').value = currentTeacher.phone || '';

      // Initialize dropdowns for attendance and grades
      await initRosterDropdowns();
      showPortal();
    } catch (err) {
      console.error('[Portal Init Error]', err);
    }
  }

  // ── Populate Class & Subject Dropdowns ────────────────────────────────────
  async function initRosterDropdowns() {
    try {
      const res = await apiFetch('/api/staff/students');
      const data = await res.json();

      teacherArmsMap = data.teacher_arms_map || {};
      teacherAllocations = data.allocations || [];

      // Attendance Class Dropdown (Clean Base Classes)
      const attClassSelect = document.getElementById('att-class-select');
      attClassSelect.innerHTML = '<option value="">Select Class...</option>';
      const attClasses = data.allowed_attendance_classes || [];
      attClasses.forEach(cls => {
        const opt = document.createElement('option');
        opt.value = cls;
        opt.textContent = cls;
        attClassSelect.appendChild(opt);
      });

      const scopeNotice = document.getElementById('att-scope-notice');
      if (attClasses.length === 0) {
        scopeNotice.textContent = 'ℹ️ Attendance notice: Your school policy limits attendance to Form Masters. Contact IT Admin to expand scope.';
        scopeNotice.classList.remove('hidden');
      } else {
        scopeNotice.textContent = `Policy: Taking attendance is permitted for: ${attClasses.join(', ')}`;
        scopeNotice.classList.remove('hidden');
      }

      // Default attendance date to today
      const today = new Date().toISOString().split('T')[0];
      document.getElementById('att-date-input').value = today;

      // Grades Class Dropdown (Clean Base Classes)
      const gradeClassSelect = document.getElementById('grade-class-select');
      gradeClassSelect.innerHTML = '<option value="">Select Class...</option>';
      const gradeClasses = data.allowed_grading_classes || [];
      gradeClasses.forEach(cls => {
        const opt = document.createElement('option');
        opt.value = cls;
        opt.textContent = cls;
        gradeClassSelect.appendChild(opt);
      });

      // Grade Subject Dropdown
      populateGradeSubjects('');
    } catch (err) {
      console.error('[Dropdowns Error]', err);
    }
  }

  // ── Helper: Populate & Deduplicate Arm Dropdown ───────────────────────────
  // If the class has only 1 arm, auto-select it.
  // If the class has NO arms, hide the arm container and set arm to empty.
  // If the selected class label already includes an arm (composite), hide arm selector.
  async function updateArmDropdown(classSelectId, armSelectId, isAttendance = true) {
    const classSelect = document.getElementById(classSelectId);
    const armSelect = document.getElementById(armSelectId);
    const armContainer = armSelect.closest('.filter-item') || armSelect.parentElement;
    const cls = classSelect.value;

    armSelect.innerHTML = isAttendance 
      ? '<option value="">All Arms</option>' 
      : '<option value="ALL">🌐 All Arms (Joint Cohort)</option>';

    if (!cls) {
      if (armContainer) armContainer.style.display = '';
      return;
    }

    let arms = teacherArmsMap[cls] || [];

    // Fallback: If not in teacherArmsMap, fetch dynamically
    if (arms.length === 0) {
      try {
        const res = await apiFetch(`/api/staff/students?class_name=${encodeURIComponent(cls)}`);
        const data = await res.json();
        arms = Array.from(new Set((data.students || []).map(s => s.class_arm).filter(Boolean))).sort();
        if (arms.length > 0) teacherArmsMap[cls] = arms;
      } catch (_) {}
    }

    // Check if class string already has an appended arm (e.g. "Grade 5 ACE")
    const isAppendedArm = arms.some(arm => cls.endsWith(` ${arm}`) || cls.toLowerCase().endsWith(`-${arm.toLowerCase()}`));

    if (arms.length === 0) {
      // Class has no arms configured (e.g. Nursery or undivided grade)
      if (armContainer) armContainer.style.display = 'none';
      armSelect.value = '';
    } else if (isAppendedArm) {
      // Arm is already in the class name itself — suppress redundant arm selector
      const matchingArm = arms.find(arm => cls.endsWith(` ${arm}`) || cls.toLowerCase().endsWith(`-${arm.toLowerCase()}`));
      armSelect.innerHTML = `<option value="${escapeHtml(matchingArm || '')}">${escapeHtml(matchingArm || '')}</option>`;
      armSelect.value = matchingArm || '';
      if (armContainer) armContainer.style.display = 'none';
    } else {
      // Normal base class: Show available arms for teacher
      if (armContainer) armContainer.style.display = '';
      // For grades mode: prepend 'All Arms (Joint Cohort)' as default
      if (!isAttendance) {
        const allOpt = document.createElement('option');
        allOpt.value = 'ALL';
        allOpt.textContent = '🌐 All Arms (Joint Cohort)';
        // Already in innerHTML — just add individual arms after
      }
      arms.forEach(arm => {
        const opt = document.createElement('option');
        opt.value = arm;
        opt.textContent = arm;
        armSelect.appendChild(opt);
      });

      // For grades: keep 'ALL' selected by default so joint mode is the entry point
      // For attendance: if only 1 arm, pre-select it
      if (isAttendance && arms.length === 1) {
        armSelect.value = arms[0];
      }
    }
  }

  // Populate subjects allocated to teacher, optionally filtered by selected class & arm
  function populateGradeSubjects(selectedClass, selectedArm = '') {
    const gradeSubjectSelect = document.getElementById('grade-subject-select');
    gradeSubjectSelect.innerHTML = '<option value="">Select Subject...</option>';

    let matching = teacherAllocations;
    if (selectedClass) {
      matching = teacherAllocations.filter(a => {
        const classMatch = a.class_name === selectedClass || a.raw_class === selectedClass || (a.raw_class && a.raw_class.startsWith(selectedClass));
        if (!classMatch) return false;
        if (selectedArm && a.arm && a.arm !== selectedArm) return false;
        return true;
      });
    }

    const distinctSubjects = Array.from(new Set(matching.map(a => a.subject))).sort();
    // Fallback to all teacher subjects if filtered match is empty
    const subjectsToShow = distinctSubjects.length > 0 ? distinctSubjects : Array.from(new Set(teacherAllocations.map(a => a.subject))).sort();
    subjectsToShow.forEach(sub => {
      const opt = document.createElement('option');
      opt.value = sub;
      opt.textContent = sub;
      gradeSubjectSelect.appendChild(opt);
    });

    if (subjectsToShow.length === 1) {
      gradeSubjectSelect.value = subjectsToShow[0];
    }
  }

  // When class changes in attendance, extract available arms
  document.getElementById('att-class-select').addEventListener('change', async () => {
    await updateArmDropdown('att-class-select', 'att-arm-select', true);
  });

  // When class changes in grades, extract available arms & update subjects
  document.getElementById('grade-class-select').addEventListener('change', async (e) => {
    await updateArmDropdown('grade-class-select', 'grade-arm-select', false);
    const cls = e.target.value;
    const arm = document.getElementById('grade-arm-select').value;
    populateGradeSubjects(cls, arm);
  });

  // When arm changes in grades, refresh subject list
  document.getElementById('grade-arm-select').addEventListener('change', (e) => {
    const cls = document.getElementById('grade-class-select').value;
    populateGradeSubjects(cls, e.target.value);
  });

  // ── ATTENDANCE: Load and Record Roll Call ──────────────────────────────────
  const attLoadBtn = document.getElementById('att-load-btn');
  const attSaveBtn = document.getElementById('att-save-btn');
  const attMarkAllBtn = document.getElementById('att-mark-all-btn');
  const attTableBody = document.getElementById('att-table-body');
  const attStatusMsg = document.getElementById('att-status-msg');

  attLoadBtn.addEventListener('click', async () => {
    const className = document.getElementById('att-class-select').value;
    const classArm = document.getElementById('att-arm-select').value;
    const date = document.getElementById('att-date-input').value;

    if (!className) {
      showToast('Please select a class first.', 'error');
      if (attStatusMsg) {
        attStatusMsg.className = 'status-msg error';
        attStatusMsg.textContent = '⚠️ Please select a class first.';
      }
      return;
    }
    if (!date) {
      showToast('Please select an attendance date.', 'error');
      if (attStatusMsg) {
        attStatusMsg.className = 'status-msg error';
        attStatusMsg.textContent = '⚠️ Please select an attendance date.';
      }
      return;
    }

    attLoadBtn.disabled = true;
    attLoadBtn.textContent = 'Loading…';
    attTableBody.innerHTML = '<tr><td colspan="5" class="empty-state">Loading student roster and roll call…</td></tr>';
    attStatusMsg.textContent = '';

    try {
      let stuUrl = `/api/staff/students?class_name=${encodeURIComponent(className)}`;
      if (classArm) stuUrl += `&class_arm=${encodeURIComponent(classArm)}`;

      let attUrl = `/api/staff/attendance?class_name=${encodeURIComponent(className)}&date=${encodeURIComponent(date)}`;
      if (classArm) attUrl += `&class_arm=${encodeURIComponent(classArm)}`;

      // Concurrent fetch: student roster + saved roll call for this date
      const [stuRes, attRes] = await Promise.all([
        apiFetch(stuUrl),
        apiFetch(attUrl).catch(() => ({ ok: false }))
      ]);

      const stuData = await stuRes.json();
      cachedStudents = stuData.students || [];

      const savedRecordsMap = {};
      let recordedCount = 0;
      if (attRes.ok) {
        try {
          const attData = await attRes.json();
          (attData.records || []).forEach(r => {
            if (r.student_id) {
              savedRecordsMap[r.student_id] = r.status;
              recordedCount++;
            }
          });
        } catch (_) {}
      }

      document.getElementById('att-summary-badge').textContent = `${cachedStudents.length} Students`;

      if (cachedStudents.length === 0) {
        attTableBody.innerHTML = '<tr><td colspan="5" class="empty-state">No active students found in this class/arm.</td></tr>';
        attSaveBtn.disabled = true;
        attMarkAllBtn.disabled = true;
        return;
      }

      renderAttendanceTable(cachedStudents, savedRecordsMap);
      attSaveBtn.disabled = false;
      attMarkAllBtn.disabled = false;

      if (recordedCount > 0) {
        attStatusMsg.className = 'status-msg success';
        attStatusMsg.textContent = `📋 Loaded saved roll call for ${date} (${recordedCount} recorded)`;
      } else {
        attStatusMsg.className = 'status-msg';
        attStatusMsg.textContent = `🆕 New roll call for ${date} (Default: All Present)`;
      }
    } catch (err) {
      attTableBody.innerHTML = `<tr><td colspan="5" class="empty-state error">Failed: ${err.message}</td></tr>`;
    } finally {
      attLoadBtn.disabled = false;
      attLoadBtn.textContent = 'Load Roll Call';
    }
  });

  function renderAttendanceTable(students, savedRecordsMap = {}) {
    attTableBody.innerHTML = '';
    students.forEach((stu, idx) => {
      const savedStatus = savedRecordsMap[stu.id] || 'present';
      const tr = document.createElement('tr');
      tr.className = 'staff-student-row att-row';
      tr.innerHTML = `
        <td class="col-num">${idx + 1}</td>
        <td class="col-name"><strong>${escapeHtml(stu.name)}</strong></td>
        <td class="col-adm"><code>${escapeHtml(stu.admission_no || '—')}</code></td>
        <td class="col-arm"><span class="badge">${escapeHtml(stu.class_arm || 'Main')}</span></td>
        <td class="col-status" style="text-align: center;">
          <div class="att-chip-group" data-student-id="${stu.id}">
            <button type="button" class="att-chip ${savedStatus === 'present' ? 'selected-present' : ''}" data-status="present">Present</button>
            <button type="button" class="att-chip ${savedStatus === 'absent' ? 'selected-absent' : ''}" data-status="absent">Absent</button>
            <button type="button" class="att-chip ${savedStatus === 'late' ? 'selected-late' : ''}" data-status="late">Late</button>
          </div>
        </td>
      `;
      attTableBody.appendChild(tr);
    });

    // Handle chip clicks
    attTableBody.querySelectorAll('.att-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const group = chip.parentElement;
        group.querySelectorAll('.att-chip').forEach(c => {
          c.className = 'att-chip';
        });
        const status = chip.getAttribute('data-status');
        chip.classList.add(`selected-${status}`);
      });
    });
  }

  attMarkAllBtn.addEventListener('click', () => {
    attTableBody.querySelectorAll('.att-chip-group').forEach(group => {
      group.querySelectorAll('.att-chip').forEach(c => {
        c.className = 'att-chip';
        if (c.getAttribute('data-status') === 'present') {
          c.classList.add('selected-present');
        }
      });
    });
  });

  attSaveBtn.addEventListener('click', async () => {
    const className = document.getElementById('att-class-select').value;
    const date = document.getElementById('att-date-input').value;
    const records = [];

    attTableBody.querySelectorAll('.att-chip-group').forEach(group => {
      const studentId = group.getAttribute('data-student-id');
      const activeChip = group.querySelector('.att-chip[class*="selected-"]');
      const status = activeChip ? activeChip.getAttribute('data-status') : 'present';
      records.push({ student_id: studentId, status });
    });

    if (records.length === 0) return;

    attSaveBtn.disabled = true;
    attSaveBtn.textContent = 'Saving…';
    attStatusMsg.textContent = '';

    try {
      const res = await apiFetch('/api/staff/attendance', {
        method: 'POST',
        body: JSON.stringify({ class_name: className, date, records })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save');

      attStatusMsg.className = 'status-msg success';
      attStatusMsg.textContent = `✅ Saved ${data.saved} student records for ${date}`;
      setTimeout(() => { attStatusMsg.textContent = ''; }, 4000);
    } catch (err) {
      attStatusMsg.className = 'status-msg error';
      attStatusMsg.textContent = `❌ ${err.message}`;
    } finally {
      attSaveBtn.disabled = false;
      attSaveBtn.textContent = '💾 Save Attendance';
    }
  });

  // ── GRADES: Load Grade Sheet & Conditional Rendering (Standard vs ACE/ILS) ─
  const gradeLoadBtn = document.getElementById('grade-load-btn');
  const gradeSaveBtn = document.getElementById('grade-save-btn');
  const gradesTableHead = document.getElementById('grades-table-head');
  const gradesTableBody = document.getElementById('grades-table-body');
  const gradeStatusMsg = document.getElementById('grade-status-msg');
  const curriculumBadgeRow = document.getElementById('curriculum-badge-row');
  const curriculumModePill = document.getElementById('curriculum-mode-pill');
  const curriculumDesc = document.getElementById('curriculum-desc');

  gradeLoadBtn.addEventListener('click', async () => {
    const className = document.getElementById('grade-class-select').value;
    const classArm = document.getElementById('grade-arm-select').value;  // may be 'ALL' or specific arm
    const subject = document.getElementById('grade-subject-select').value;

    if (!className || !subject) {
      showToast('Please select both Class and Subject.', 'error');
      if (gradeStatusMsg) {
        gradeStatusMsg.className = 'status-msg error';
        gradeStatusMsg.textContent = '⚠️ Please select both Class and Subject.';
      }
      return;
    }

    gradeLoadBtn.disabled = true;
    gradeLoadBtn.textContent = 'Loading…';
    gradesTableBody.innerHTML = '<tr><td colspan="4" class="empty-state">Loading grade records…</td></tr>';

    // Clear any existing joint banner / pill bar
    const oldBanner = document.getElementById('joint-grade-banner');
    if (oldBanner) oldBanner.remove();
    const oldPills = document.getElementById('joint-pill-bar');
    if (oldPills) oldPills.remove();

    try {
      // Always send class_arm — 'ALL' triggers joint detection on the backend
      let url = `/api/staff/grades?class_name=${encodeURIComponent(className)}&subject=${encodeURIComponent(subject)}`;
      if (classArm) url += `&class_arm=${encodeURIComponent(classArm)}`;

      const res = await apiFetch(url);
      const data = await res.json();

      currentCurriculum = data.curriculum || { type: 'STANDARD_NIGERIAN', pacCount: 12, pacLabels: [] };
      currentScoreComponents = data.score_components || [];
      currentJointData = { is_joint: data.is_joint || false, arms: data.arms || [] };
      const students = data.students || [];

      const summaryBadge = document.getElementById('grade-summary-badge');
      summaryBadge.textContent = `${students.length} Students`;
      if (currentJointData.is_joint) {
        summaryBadge.textContent += ` · ${currentJointData.arms.length} Arms Joint`;
      }

      // Update Curriculum Badge Banner
      curriculumBadgeRow.classList.remove('hidden');
      if (currentCurriculum.type === 'ILS') {
        curriculumModePill.className = 'curriculum-pill ils';
        curriculumModePill.textContent = '📚 ILS (ACE PAC)';
        curriculumDesc.textContent = `Individualized Learning: ${currentCurriculum.pacCount} PACs configured (Pass threshold ≥ 85).`;
      } else {
        curriculumModePill.className = 'curriculum-pill';
        curriculumModePill.textContent = '🇳🇬 Standard Nigerian';
        curriculumDesc.textContent = 'Assessment model: CA1, CA2 & Final Exam scores.';
      }

      if (students.length === 0) {
        gradesTableBody.innerHTML = '<tr><td colspan="4" class="empty-state">No students found for this selection.</td></tr>';
        gradeSaveBtn.disabled = true;
        return;
      }

      renderGradesTable(students, currentCurriculum, currentScoreComponents, currentJointData);
      gradeSaveBtn.disabled = false;
    } catch (err) {
      gradesTableBody.innerHTML = `<tr><td colspan="4" class="empty-state error">Failed: ${err.message}</td></tr>`;
    } finally {
      gradeLoadBtn.disabled = false;
      gradeLoadBtn.textContent = 'Load Grade Sheet';
    }
  });

  function renderGradesTable(students, curriculum, scoreComponents, jointData = {}) {
    const isJoint = jointData.is_joint || false;
    const jointArms = jointData.arms || [];

    // ── Joint Banner & Arm Filter Pills (injected above the table wrapper) ───
    const tableWrapper = gradesTableBody.closest('.table-wrapper') || gradesTableBody.parentElement;

    if (isJoint && jointArms.length > 1) {
      // Banner
      const banner = document.createElement('div');
      banner.id = 'joint-grade-banner';
      banner.className = 'joint-banner';
      banner.innerHTML = `🌐 <strong>Joint Grading Mode</strong> — showing students from ${jointArms.length} arms: <strong>${jointArms.join(', ')}</strong>. Scores are saved per student individually.`;
      tableWrapper.insertAdjacentElement('beforebegin', banner);

      // Arm filter pill bar
      const pillBar = document.createElement('div');
      pillBar.id = 'joint-pill-bar';
      pillBar.className = 'joint-pill-bar';

      // Build arm → count map
      const armCounts = {};
      for (const arm of jointArms) armCounts[arm] = 0;
      students.forEach(s => { if (s.class_arm && armCounts[s.class_arm] !== undefined) armCounts[s.class_arm]++; });

      // "All" pill
      const allPill = document.createElement('button');
      allPill.className = 'joint-pill active';
      allPill.dataset.armFilter = 'ALL';
      allPill.textContent = `All (${students.length})`;
      pillBar.appendChild(allPill);

      // Individual arm pills
      for (const arm of jointArms) {
        const pill = document.createElement('button');
        pill.className = 'joint-pill';
        pill.dataset.armFilter = arm;
        pill.textContent = `${arm} (${armCounts[arm] || 0})`;
        pillBar.appendChild(pill);
      }

      tableWrapper.insertAdjacentElement('beforebegin', pillBar);

      // Pill click handler (client-side filter — no reload)
      pillBar.addEventListener('click', (e) => {
        const pill = e.target.closest('.joint-pill');
        if (!pill) return;
        pillBar.querySelectorAll('.joint-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        const filter = pill.dataset.armFilter;
        gradesTableBody.querySelectorAll('tr[data-arm]').forEach(row => {
          row.style.display = (filter === 'ALL' || row.dataset.arm === filter) ? '' : 'none';
        });
      });
    }

    if (curriculum.type === 'ILS') {

      // ── ACE / ILS PAC RENDER ──────────────────────────────────────────────
      gradesTableHead.innerHTML = `
        <tr>
          <th style="width: 40px;">#</th>
          <th>Student Name</th>
          <th style="width: 100px;">Arm</th>
          <th>PAC Scores (0–100, Pass ≥ 85)</th>
        </tr>
      `;

      gradesTableBody.innerHTML = '';
      const pacCount = curriculum.pacCount || 12;
      const pacLabels = curriculum.pacLabels || [];

      students.forEach((stu, idx) => {
        const tr = document.createElement('tr');
        tr.className = 'staff-student-row pac-row';
        if (stu.class_arm) tr.dataset.arm = stu.class_arm; // for joint arm filter pills
        const pacMap = stu.grades || {};

        let pacBoxesHtml = '<div class="pac-grid-row">';
        for (let i = 1; i <= pacCount; i++) {
          const label = pacLabels[i - 1] || `P${i}`;
          const existingScore = pacMap[i]?.score ?? '';
          const isPassed = existingScore !== '' && Number(existingScore) >= 85;
          const isFailed = existingScore !== '' && Number(existingScore) < 85;

          const statusClass = isPassed ? 'passed' : (isFailed ? 'failed' : '');
          pacBoxesHtml += `
            <div class="pac-box">
              <span class="pac-label">${escapeHtml(label)}</span>
              <input type="number" min="0" max="100" class="pac-input ${statusClass}"
                     data-student-id="${stu.id}" data-pack="${i}" value="${existingScore}" placeholder="—">
            </div>
          `;
        }
        pacBoxesHtml += '</div>';

        tr.innerHTML = `
          <td class="col-num">${idx + 1}</td>
          <td class="col-name"><strong>${escapeHtml(stu.name)}</strong></td>
          <td class="col-arm"><span class="badge">${escapeHtml(stu.class_arm || 'Main')}</span></td>
          <td class="col-scores">
            <div class="mobile-pac-header">12 PAC Tests (Pass ≥ 85)</div>
            ${pacBoxesHtml}
          </td>
        `;
        gradesTableBody.appendChild(tr);
      });

      // Color coding on PAC score input change
      gradesTableBody.querySelectorAll('.pac-input').forEach(inp => {
        inp.addEventListener('input', () => {
          const val = inp.value.trim();
          inp.classList.remove('passed', 'failed');
          if (val !== '') {
            const num = Number(val);
            if (num >= 85) inp.classList.add('passed');
            else inp.classList.add('failed');
          }
        });
      });
    } else {
      // ── STANDARD NIGERIAN / BRITISH RENDER ────────────────────────────────
      const components = (scoreComponents && scoreComponents.length > 0)
        ? scoreComponents
        : [{ key: 'CA1', label: 'CA 1', max: 20 }, { key: 'CA2', label: 'CA 2', max: 20 }, { key: 'Exam', label: 'Exam', max: 60 }];

      let compHeaders = '';
      components.forEach(c => {
        if (c.auto) {
          // Auto-computed column (e.g. Attendance) — visually distinct
          compHeaders += `<th style="width: 100px; text-align: center; opacity: 0.6;" title="Auto-computed from daily attendance records">${escapeHtml(c.label || c.key)} (${c.max}) 🔒</th>`;
        } else {
          compHeaders += `<th style="width: 100px; text-align: center;">${escapeHtml(c.label || c.key)} (${c.max || 100})</th>`;
        }
      });

      gradesTableHead.innerHTML = `
        <tr>
          <th style="width: 40px;">#</th>
          <th>Student Name</th>
          <th style="width: 100px;">Arm</th>
          ${compHeaders}
        </tr>
      `;

      gradesTableBody.innerHTML = '';
      students.forEach((stu, idx) => {
        const tr = document.createElement('tr');
        tr.className = 'staff-student-row std-row';
        if (stu.class_arm) tr.dataset.arm = stu.class_arm; // for joint arm filter pills
        const breakdown = stu.grades?.breakdown || {};

        let inputsHtml = '';
        components.forEach(c => {
          const val = breakdown[c.key] ?? (c.key === 'Exam' ? (stu.grades?.score ?? '') : '');
          if (c.auto) {
            // Attendance: read-only, auto-computed — not editable by teacher
            inputsHtml += `
              <td class="col-std-score" style="text-align: center;">
                <span class="mobile-comp-label">${escapeHtml(c.label || c.key)} (${c.max}) 🔒</span>
                <input type="number" min="0" max="${c.max}" class="std-score-input"
                       data-student-id="${stu.id}" data-comp="${c.key}" data-max="${c.max}"
                       data-auto="true" value="${val}" disabled
                       style="width: 80px; text-align: center; opacity: 0.5; cursor: not-allowed;"
                       title="Auto-computed from daily attendance records">
              </td>
            `;
          } else {
            inputsHtml += `
              <td class="col-std-score" style="text-align: center;">
                <span class="mobile-comp-label">${escapeHtml(c.label || c.key)} (${c.max || 100})</span>
                <input type="number" min="0" max="${c.max || 100}" class="std-score-input"
                       data-student-id="${stu.id}" data-comp="${c.key}" data-max="${c.max || 100}"
                       value="${val}" style="width: 80px; text-align: center;">
              </td>
            `;
          }
        });

        tr.innerHTML = `
          <td class="col-num">${idx + 1}</td>
          <td class="col-name"><strong>${escapeHtml(stu.name)}</strong></td>
          <td class="col-arm"><span class="badge">${escapeHtml(stu.class_arm || 'Main')}</span></td>
          ${inputsHtml}
        `;
        gradesTableBody.appendChild(tr);
      });
    }
  }

  // ── Save All Grades ───────────────────────────────────────────────────────
  gradeSaveBtn.addEventListener('click', async () => {
    const className = document.getElementById('grade-class-select').value;
    // In joint mode class_arm is irrelevant for saving — student_records key on student_id
    const classArm = currentJointData.is_joint ? '' : document.getElementById('grade-arm-select').value;
    const subject = document.getElementById('grade-subject-select').value;

    const records = [];

    if (currentCurriculum?.type === 'ILS') {
      // Collect from ALL rows regardless of arm filter visibility
      gradesTableBody.querySelectorAll('.pac-input').forEach(inp => {
        const val = inp.value.trim();
        if (val !== '') {
          records.push({
            student_id: inp.getAttribute('data-student-id'),
            curriculum_type: 'ILS',
            pack_number: parseInt(inp.getAttribute('data-pack')),
            score: Number(val)
          });
        }
      });
    } else {
      // Group standard component inputs per student; skip auto-computed columns (e.g. Attendance)
      // querySelectorAll hits ALL rows including arm-filtered hidden rows — intentional for joint save
      const studentMap = {};
      gradesTableBody.querySelectorAll('.std-score-input').forEach(inp => {
        if (inp.getAttribute('data-auto') === 'true') return; // auto-computed, not saved here
        const studentId = inp.getAttribute('data-student-id');
        const comp = inp.getAttribute('data-comp');
        const val = inp.value.trim();
        if (!studentMap[studentId]) studentMap[studentId] = { breakdown: {}, total: 0 };
        if (val !== '') {
          const num = Number(val);
          studentMap[studentId].breakdown[comp] = num;
          studentMap[studentId].total += num;
        }
      });

      for (const [studentId, data] of Object.entries(studentMap)) {
        if (Object.keys(data.breakdown).length > 0) {
          records.push({
            student_id: studentId,
            curriculum_type: 'STANDARD_NIGERIAN',
            assessment: 'Exam',
            score: data.total,
            breakdown: data.breakdown
          });
        }
      }
    }

    if (records.length === 0) {
      showToast('Please enter at least one score before saving.', 'error');
      if (gradeStatusMsg) {
        gradeStatusMsg.className = 'status-msg error';
        gradeStatusMsg.textContent = '⚠️ Please enter at least one score before saving.';
      }
      return;
    }

    gradeSaveBtn.disabled = true;
    gradeSaveBtn.textContent = 'Saving…';
    gradeStatusMsg.textContent = '';

    try {
      const res = await apiFetch('/api/staff/grades', {
        method: 'POST',
        body: JSON.stringify({
          class_name: className,
          class_arm: classArm,
          subject,
          records
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save');

      gradeStatusMsg.className = 'status-msg success';
      gradeStatusMsg.textContent = `✅ Successfully saved ${data.saved} grade entries.`;
      setTimeout(() => { gradeStatusMsg.textContent = ''; }, 4000);
    } catch (err) {
      gradeStatusMsg.className = 'status-msg error';
      gradeStatusMsg.textContent = `❌ ${err.message}`;
    } finally {
      gradeSaveBtn.disabled = false;
      gradeSaveBtn.textContent = '💾 Save All Grades';
    }
  });

  // ── SETTINGS: Update Contact Info & Change Password ───────────────────────
  const profileEditForm = document.getElementById('profile-edit-form');
  const profileStatusMsg = document.getElementById('profile-status-msg');

  profileEditForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('set-email-input').value.trim();
    const phone = document.getElementById('set-phone-input').value.trim();
    const btn = document.getElementById('save-profile-btn');

    btn.disabled = true;
    profileStatusMsg.textContent = '';

    try {
      const res = await apiFetch('/api/staff/profile', {
        method: 'PATCH',
        body: JSON.stringify({ email, phone })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update');

      profileStatusMsg.className = 'status-msg success';
      profileStatusMsg.textContent = '✅ Contact info saved successfully';
      setTimeout(() => { profileStatusMsg.textContent = ''; }, 4000);
    } catch (err) {
      profileStatusMsg.className = 'status-msg error';
      profileStatusMsg.textContent = `❌ ${err.message}`;
    } finally {
      btn.disabled = false;
    }
  });

  const passwordEditForm = document.getElementById('password-edit-form');
  const passwordStatusMsg = document.getElementById('password-status-msg');

  passwordEditForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const curr = document.getElementById('set-curr-password').value;
    const newPwd = document.getElementById('set-new-password').value;
    const confirmPwd = document.getElementById('set-confirm-password').value;
    const btn = document.getElementById('save-password-btn');

    if (newPwd !== confirmPwd) {
      passwordStatusMsg.className = 'status-msg error';
      passwordStatusMsg.textContent = '❌ New passwords do not match';
      return;
    }

    btn.disabled = true;
    passwordStatusMsg.textContent = '';

    try {
      const res = await apiFetch('/api/staff/password', {
        method: 'PATCH',
        body: JSON.stringify({ current_password: curr, new_password: newPwd })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to change password');

      passwordStatusMsg.className = 'status-msg success';
      passwordStatusMsg.textContent = '✅ Password updated successfully';
      passwordEditForm.reset();
      setTimeout(() => { passwordStatusMsg.textContent = ''; }, 4000);
    } catch (err) {
      passwordStatusMsg.className = 'status-msg error';
      passwordStatusMsg.textContent = `❌ ${err.message}`;
    } finally {
      btn.disabled = false;
    }
  });

  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"']/g, m => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[m]);
  }

  // Start app
  initApp();
})();
