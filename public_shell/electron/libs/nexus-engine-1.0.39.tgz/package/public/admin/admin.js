(() => {
  'use strict';

  // ── State ──────────────────────────────────────────────────────────────────
  let sessionToken = localStorage.getItem('nexus_admin_token') || null;
  let currentAdmin = null;

  // ── DOM Elements ───────────────────────────────────────────────────────────
  const loginView = document.getElementById('login-view');
  const dashboardView = document.getElementById('dashboard-view');
  const loginForm = document.getElementById('login-form');
  const loginUsername = document.getElementById('login-username');
  const loginPassword = document.getElementById('login-password');
  const loginError = document.getElementById('login-error');
  const loginBtn = document.getElementById('login-btn');
  const logoutBtn = document.getElementById('logout-btn');

  // KPI elements
  const kpiStudents = document.getElementById('kpi-students');
  const kpiTeachers = document.getElementById('kpi-teachers');
  const kpiDevices = document.getElementById('kpi-devices');
  const kpiTerm = document.getElementById('kpi-term');

  // Navigation / Admin Info
  const adminName = document.getElementById('admin-name');
  const navSchoolName = document.getElementById('nav-school-name');

  // Policy Controls
  const scopeSelect = document.getElementById('scope-select');
  const saveScopeBtn = document.getElementById('save-scope-btn');
  const policyAlert = document.getElementById('policy-alert');

  // Tables
  const devicesTableBody = document.getElementById('devices-table-body');
  const refreshDevicesBtn = document.getElementById('refresh-devices-btn');
  const auditTableBody = document.getElementById('audit-table-body');

  // ── Fetch Wrapper with Auth Header ─────────────────────────────────────────
  async function apiFetch(url, options = {}) {
    options.headers = options.headers || {};
    if (sessionToken) {
      options.headers['Authorization'] = `Bearer ${sessionToken}`;
    }
    options.headers['Content-Type'] = 'application/json';
    const res = await fetch(url, options);
    if (res.status === 401) {
      // Session expired
      logout();
      throw new Error('Session expired');
    }
    return res;
  }

  // ── Views Management ───────────────────────────────────────────────────────
  function showLogin() {
    loginView.classList.remove('hidden');
    loginView.classList.add('active');
    dashboardView.classList.add('hidden');
    dashboardView.classList.remove('active');
  }

  function showDashboard() {
    loginView.classList.add('hidden');
    loginView.classList.remove('active');
    dashboardView.classList.remove('hidden');
    dashboardView.classList.add('active');
  }

  // ── Login Action ───────────────────────────────────────────────────────────
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hidden');
    loginBtn.disabled = true;
    loginBtn.textContent = 'Verifying credentials…';

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: loginUsername.value.trim(),
          password: loginPassword.value
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      sessionToken = data.token;
      currentAdmin = data.admin;
      localStorage.setItem('nexus_admin_token', sessionToken);

      showDashboard();
      await loadDashboardData();
    } catch (err) {
      loginError.textContent = err.message;
      loginError.classList.remove('hidden');
    } finally {
      loginBtn.disabled = false;
      loginBtn.textContent = 'Access Admin Console →';
    }
  });

  // ── Logout Action ──────────────────────────────────────────────────────────
  async function logout() {
    try {
      if (sessionToken) {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${sessionToken}`,
            'Content-Type': 'application/json'
          }
        });
      }
    } catch (_) {}
    sessionToken = null;
    currentAdmin = null;
    localStorage.removeItem('nexus_admin_token');
    showLogin();
  }

  logoutBtn.addEventListener('click', logout);

  // ── Load Dashboard Data ────────────────────────────────────────────────────
  async function loadDashboardData() {
    try {
      // Load current admin info
      const meRes = await apiFetch('/api/admin/me');
      const meData = await meRes.json();
      currentAdmin = meData.admin;
      adminName.textContent = currentAdmin.username || 'Superadmin';

      // Load overview KPIs, settings, devices, audit logs
      const overviewRes = await apiFetch('/api/admin/overview');
      const data = await overviewRes.json();

      // Render KPIs
      kpiStudents.textContent = data.kpis.students || '0';
      kpiTeachers.textContent = data.kpis.teachers || '0';
      kpiDevices.textContent = data.kpis.devices || '0';
      kpiTerm.textContent = `${data.kpis.term} (${data.kpis.academic_session})`;

      if (data.settings && data.settings.school_name) {
        navSchoolName.textContent = data.settings.school_name;
      }

      // Render Teacher Attendance Scope policy
      if (data.settings && data.settings.teacher_attendance_scope) {
        scopeSelect.value = data.settings.teacher_attendance_scope;
      } else {
        scopeSelect.value = 'form_class_only';
      }

      // Render Devices Table
      renderDevicesTable(data.devices || []);

      // Render Audit Table
      renderAuditTable(data.recent_logs || []);
    } catch (err) {
      console.error('[Dashboard Load Error]', err);
    }
  }

  // ── Render Devices Table ───────────────────────────────────────────────────
  function renderDevicesTable(devices) {
    if (!devices || devices.length === 0) {
      devicesTableBody.innerHTML = '<tr><td colspan="5" class="empty-state">No active mobile devices paired yet.</td></tr>';
      return;
    }

    devicesTableBody.innerHTML = '';
    devices.forEach(dev => {
      const tr = document.createElement('tr');
      const pairedDate = dev.paired_at ? new Date(dev.paired_at).toLocaleString() : 'Recent';
      tr.innerHTML = `
        <td><strong>${escapeHtml(dev.device_model || 'Unknown Model')}</strong><br><small style="color:var(--text-secondary);">${escapeHtml(dev.device_id || '')}</small></td>
        <td>${escapeHtml(dev.label || 'Unlabeled Device')}</td>
        <td><span class="badge badge-tier">${escapeHtml(dev.tier || 'Standard')}</span></td>
        <td>${pairedDate}</td>
        <td>
          <button class="btn btn-danger btn-sm revoke-btn" data-id="${escapeHtml(dev.device_id)}">Revoke 🚫</button>
        </td>
      `;
      devicesTableBody.appendChild(tr);
    });

    // Wire Revoke buttons
    document.querySelectorAll('.revoke-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.getAttribute('data-id');
        if (!confirm(`Are you sure you want to revoke sync access for device ${id}? The teacher will be locked out until re-paired.`)) {
          return;
        }
        try {
          const res = await apiFetch('/api/admin/revoke-device', {
            method: 'POST',
            body: JSON.stringify({ device_id: id })
          });
          if (res.ok) {
            await loadDashboardData();
          } else {
            alert('Failed to revoke device.');
          }
        } catch (err) {
          alert(err.message);
        }
      });
    });
  }

  refreshDevicesBtn.addEventListener('click', loadDashboardData);

  // ── Render Audit Table ─────────────────────────────────────────────────────
  function renderAuditTable(logs) {
    if (!logs || logs.length === 0) {
      auditTableBody.innerHTML = '<tr><td colspan="4" class="empty-state">No recent activity logged.</td></tr>';
      return;
    }

    auditTableBody.innerHTML = '';
    logs.forEach(log => {
      const tr = document.createElement('tr');
      const time = log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : 'Just now';
      let details = '';
      if (typeof log.payload === 'object' && log.payload !== null) {
        details = JSON.stringify(log.payload);
      } else {
        details = log.payload || '';
      }
      tr.innerHTML = `
        <td>${time}</td>
        <td><span class="badge">${escapeHtml(log.actor_label || 'SYSTEM')}</span></td>
        <td><strong>${escapeHtml(log.event_type || '')}</strong></td>
        <td><code style="font-size:12px;color:var(--text-secondary);">${escapeHtml(details)}</code></td>
      `;
      auditTableBody.appendChild(tr);
    });
  }

  // ── Save Attendance Scope Policy ───────────────────────────────────────────
  saveScopeBtn.addEventListener('click', async () => {
    saveScopeBtn.disabled = true;
    saveScopeBtn.textContent = 'Saving…';
    policyAlert.classList.add('hidden');

    try {
      const selectedScope = scopeSelect.value;
      const res = await apiFetch('/api/system/settings', {
        method: 'PATCH',
        body: JSON.stringify({
          key: 'teacher_attendance_scope',
          value: selectedScope
        })
      });

      if (!res.ok) {
        throw new Error('Failed to update policy');
      }

      policyAlert.textContent = `✅ Policy saved: Teachers can now take attendance for ${selectedScope === 'any_taught_class' ? 'Any Class Taught' : 'Form Master Class Only'}.`;
      policyAlert.classList.remove('hidden');
      setTimeout(() => policyAlert.classList.add('hidden'), 5000);
    } catch (err) {
      alert(`Error updating policy: ${err.message}`);
    } finally {
      saveScopeBtn.disabled = false;
      saveScopeBtn.textContent = 'Save Policy';
    }
  });

  // ── Utility: Escape HTML ───────────────────────────────────────────────────
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // ── Initialize ─────────────────────────────────────────────────────────────
  if (sessionToken) {
    showDashboard();
    loadDashboardData().catch(() => showLogin());
  } else {
    showLogin();
  }
})();
