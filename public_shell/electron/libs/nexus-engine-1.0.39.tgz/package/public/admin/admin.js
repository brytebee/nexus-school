(() => {
  'use strict';

  // ── State ──────────────────────────────────────────────────────────────────
  let sessionToken = localStorage.getItem('nexus_admin_token') || null;
  let currentAdmin = null;

  // ── DOM Elements ───────────────────────────────────────────────────────────
  const loginView = document.getElementById('login-view');
  const dashboardView = document.getElementById('dashboard-view');
  const loginForm = document.getElementById('login-form');
  const loginUsername = document.getElementById('login-username');
  const loginPassword = document.getElementById('login-password');
  const loginError = document.getElementById('login-error');
  const loginBtn = document.getElementById('login-btn');
  const logoutBtn = document.getElementById('logout-btn');

  // KPI elements
  const kpiStudents = document.getElementById('kpi-students');
  const kpiTeachers = document.getElementById('kpi-teachers');
  const kpiDevices = document.getElementById('kpi-devices');
  const kpiTerm = document.getElementById('kpi-term');

  // Navigation / Admin Info
  const adminName = document.getElementById('admin-name');
  const navSchoolName = document.getElementById('nav-school-name');

  // Policy Controls
  const scopeSelect = document.getElementById('scope-select');
  const saveScopeBtn = document.getElementById('save-scope-btn');
  const policyAlert = document.getElementById('policy-alert');

  // Tables
  const devicesTableBody = document.getElementById('devices-table-body');
  const refreshDevicesBtn = document.getElementById('refresh-devices-btn');
  const auditTableBody = document.getElementById('audit-table-body');

  // ── Universal In-App Toast & Confirmation Modal ────────────────────────────
  function showToast(message, type = 'error') {
    let toast = document.getElementById('nexus-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'nexus-toast';
      toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%) translateY(100px);
        background: #0f172a;
        color: #f8fafc;
        padding: 12px 20px;
        border-radius: 14px;
        font-size: 13px;
        font-weight: 700;
        box-shadow: 0 12px 36px rgba(0,0,0,0.6);
        border: 1px solid rgba(255,255,255,0.12);
        z-index: 10000;
        transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s ease;
        opacity: 0;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 90vw;
        pointer-events: none;
      `;
      document.body.appendChild(toast);
    }
    const icon = type === 'error' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️';
    const borderColor = type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#00e5ff';
    toast.style.borderColor = borderColor;
    toast.innerHTML = `<span style="font-size:16px;">${icon}</span><span>${message}</span>`;
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';

    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(-50%) translateY(100px)';
    }, 3800);
  }

  function showConfirmModal(title, message, onConfirm) {
    let overlay = document.getElementById('nexus-confirm-modal');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'nexus-confirm-modal';
      overlay.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(4px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        padding: 20px;
      `;
      document.body.appendChild(overlay);
    }
    overlay.innerHTML = `
      <div style="background: #151e32; border: 1px solid rgba(255,255,255,0.12); border-radius: 20px; padding: 24px; max-width: 440px; width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.6);">
        <h3 style="color: #fff; font-size: 16px; font-weight: 800; margin-bottom: 8px;">${title}</h3>
        <p style="color: #94a3b8; font-size: 13px; line-height: 1.5; margin-bottom: 20px;">${message}</p>
        <div style="display: flex; justify-content: flex-end; gap: 10px;">
          <button id="modal-cancel-btn" style="padding: 8px 16px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); background: rgba(255,255,255,0.05); color: #cbd5e1; font-weight: 700; font-size: 13px; cursor: pointer;">Cancel</button>
          <button id="modal-confirm-btn" style="padding: 8px 16px; border-radius: 10px; border: none; background: #ef4444; color: #fff; font-weight: 700; font-size: 13px; cursor: pointer;">Revoke Access</button>
        </div>
      </div>
    `;
    overlay.style.display = 'flex';
    document.getElementById('modal-cancel-btn').onclick = () => { overlay.style.display = 'none'; };
    document.getElementById('modal-confirm-btn').onclick = () => {
      overlay.style.display = 'none';
      onConfirm();
    };
  }

  // ── Fetch Wrapper with Auth Header ─────────────────────────────────────────
  async function apiFetch(url, options = {}) {
    options.headers = options.headers || {};
    if (sessionToken) {
      options.headers['Authorization'] = `Bearer ${sessionToken}`;
    }
    options.headers['Content-Type'] = 'application/json';
    const res = await fetch(url, options);
    if (res.status === 401) {
      // Session expired
      logout();
      throw new Error('Session expired');
    }
    return res;
  }

  // ── Views Management ───────────────────────────────────────────────────────
  function showLogin() {
    loginView.classList.remove('hidden');
    loginView.classList.add('active');
    dashboardView.classList.add('hidden');
    dashboardView.classList.remove('active');
  }

  function showDashboard() {
    loginView.classList.add('hidden');
    loginView.classList.remove('active');
    dashboardView.classList.remove('hidden');
    dashboardView.classList.add('active');
  }

  // ── Login Action ───────────────────────────────────────────────────────────
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hidden');
    loginBtn.disabled = true;
    loginBtn.textContent = 'Verifying credentials…';

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: loginUsername.value.trim(),
          password: loginPassword.value
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      sessionToken = data.token;
      currentAdmin = data.admin;
      localStorage.setItem('nexus_admin_token', sessionToken);

      showDashboard();
      await loadDashboardData();
    } catch (err) {
      loginError.textContent = err.message;
      loginError.classList.remove('hidden');
    } finally {
      loginBtn.disabled = false;
      loginBtn.textContent = 'Access Admin Console →';
    }
  });

  // ── Logout Action ──────────────────────────────────────────────────────────
  async function logout() {
    try {
      if (sessionToken) {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${sessionToken}`,
            'Content-Type': 'application/json'
          }
        });
      }
    } catch (_) {}
    sessionToken = null;
    currentAdmin = null;
    localStorage.removeItem('nexus_admin_token');
    showLogin();
  }

  logoutBtn.addEventListener('click', logout);

  // ── Load Dashboard Data ────────────────────────────────────────────────────
  async function loadDashboardData() {
    try {
      // Load current admin info
      const meRes = await apiFetch('/api/admin/me');
      const meData = await meRes.json();
      currentAdmin = meData.admin;
      adminName.textContent = currentAdmin.username || 'Superadmin';

      // Load overview KPIs, settings, devices, audit logs
      const overviewRes = await apiFetch('/api/admin/overview');
      const data = await overviewRes.json();

      // Render KPIs
      kpiStudents.textContent = data.kpis.students || '0';
      kpiTeachers.textContent = data.kpis.teachers || '0';
      kpiDevices.textContent = data.kpis.devices || '0';
      kpiTerm.textContent = `${data.kpis.term} (${data.kpis.academic_session})`;

      if (data.settings && data.settings.school_name) {
        navSchoolName.textContent = data.settings.school_name;
      }

      // Render Teacher Attendance Scope policy
      if (data.settings && data.settings.teacher_attendance_scope) {
        scopeSelect.value = data.settings.teacher_attendance_scope;
      } else {
        scopeSelect.value = 'form_class_only';
      }

      // Render Devices Table
      renderDevicesTable(data.devices || []);

      // Render Audit Table
      renderAuditTable(data.recent_logs || []);
    } catch (err) {
      console.error('[Dashboard Load Error]', err);
    }
  }

  // ── Render Devices Table ───────────────────────────────────────────────────
  function renderDevicesTable(devices) {
    if (!devices || devices.length === 0) {
      devicesTableBody.innerHTML = '<tr><td colspan="5" class="empty-state">No active mobile devices paired yet.</td></tr>';
      return;
    }

    devicesTableBody.innerHTML = '';
    devices.forEach(dev => {
      const tr = document.createElement('tr');
      const pairedDate = dev.paired_at ? new Date(dev.paired_at).toLocaleString() : 'Recent';
      tr.innerHTML = `
        <td><strong>${escapeHtml(dev.device_model || 'Unknown Model')}</strong><br><small style="color:var(--text-secondary);">${escapeHtml(dev.device_id || '')}</small></td>
        <td>${escapeHtml(dev.label || 'Unlabeled Device')}</td>
        <td><span class="badge badge-tier">${escapeHtml(dev.tier || 'Standard')}</span></td>
        <td>${pairedDate}</td>
        <td>
          <button class="btn btn-danger btn-sm revoke-btn" data-id="${escapeHtml(dev.device_id)}">Revoke 🚫</button>
        </td>
      `;
      devicesTableBody.appendChild(tr);
    });

    // Wire Revoke buttons
    document.querySelectorAll('.revoke-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.getAttribute('data-id');
        showConfirmModal(
          'Revoke Device Sync',
          `Are you sure you want to revoke sync access for device ${id}? The teacher will be locked out until re-paired.`,
          async () => {
            try {
              const res = await apiFetch('/api/admin/revoke-device', {
                method: 'POST',
                body: JSON.stringify({ device_id: id })
              });
              if (res.ok) {
                showToast('Device sync access revoked.', 'success');
                await loadDashboardData();
              } else {
                showToast('Failed to revoke device.', 'error');
              }
            } catch (err) {
              showToast(err.message, 'error');
            }
          }
        );
      });
    });
  }

  refreshDevicesBtn.addEventListener('click', loadDashboardData);

  // ── Render Audit Table ─────────────────────────────────────────────────────
  function renderAuditTable(logs) {
    if (!logs || logs.length === 0) {
      auditTableBody.innerHTML = '<tr><td colspan="4" class="empty-state">No recent activity logged.</td></tr>';
      return;
    }

    auditTableBody.innerHTML = '';
    logs.forEach(log => {
      const tr = document.createElement('tr');
      const time = log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : 'Just now';
      let details = '';
      if (typeof log.payload === 'object' && log.payload !== null) {
        details = JSON.stringify(log.payload);
      } else {
        details = log.payload || '';
      }
      tr.innerHTML = `
        <td>${time}</td>
        <td><span class="badge">${escapeHtml(log.actor_label || 'SYSTEM')}</span></td>
        <td><strong>${escapeHtml(log.event_type || '')}</strong></td>
        <td><code style="font-size:12px;color:var(--text-secondary);">${escapeHtml(details)}</code></td>
      `;
      auditTableBody.appendChild(tr);
    });
  }

  // ── Save Attendance Scope Policy ───────────────────────────────────────────
  saveScopeBtn.addEventListener('click', async () => {
    saveScopeBtn.disabled = true;
    saveScopeBtn.textContent = 'Saving…';
    policyAlert.classList.add('hidden');

    try {
      const selectedScope = scopeSelect.value;
      const res = await apiFetch('/api/system/settings', {
        method: 'PATCH',
        body: JSON.stringify({
          key: 'teacher_attendance_scope',
          value: selectedScope
        })
      });

      if (!res.ok) {
        throw new Error('Failed to update policy');
      }

      policyAlert.textContent = `✅ Policy saved: Teachers can now take attendance for ${selectedScope === 'any_taught_class' ? 'Any Class Taught' : 'Form Master Class Only'}.`;
      policyAlert.classList.remove('hidden');
      setTimeout(() => policyAlert.classList.add('hidden'), 5000);
    } catch (err) {
      showToast(`Error updating policy: ${err.message}`, 'error');
    } finally {
      saveScopeBtn.disabled = false;
      saveScopeBtn.textContent = 'Save Policy';
    }
  });

  // ── Utility: Escape HTML ───────────────────────────────────────────────────
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // ── Initialize ─────────────────────────────────────────────────────────────
  if (sessionToken) {
    showDashboard();
    loadDashboardData().catch(() => showLogin());
  } else {
    showLogin();
  }
})();
