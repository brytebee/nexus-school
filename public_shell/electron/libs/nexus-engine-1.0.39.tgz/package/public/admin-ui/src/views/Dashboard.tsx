import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  Users,
  CalendarCheck,
  Wallet,
  ArrowUpRight,
  RefreshCw,
  School,
  BookOpen,
  Smartphone,
  ShieldCheck,
  AlertCircle,
  Clock,
  CheckCircle2,
  Activity,
  Layers,
  ChevronRight,
} from 'lucide-react';
import Header from '../components/Header';

interface DashboardProps {
  token: string;
}

export default function Dashboard({ token }: DashboardProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchOverview = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/overview', {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (!res.ok) {
        throw new Error(`Failed to load overview (HTTP ${res.status})`);
      }
      const json = await res.json();
      if (!json.ok) {
        throw new Error(json.error || 'Server error loading dashboard data');
      }
      setData(json);
    } catch (err: any) {
      setError(err.message || 'Error connecting to Nexus engine');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchOverview();
  }, [token]);

  const kpis = data?.kpis || {};
  const settings = data?.settings || {};
  const devices = data?.devices || [];
  const logs = data?.recent_logs || [];
  const att = data?.attendance_today || { total: 0, present: 0, rate: 0 };
  const fees = data?.fees_summary || { billed: 0, paid: 0, outstanding: 0 };
  const sync = data?.cloud_sync || {};

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header
        title="Admin Control Hub"
        subtitle="Sovereign Campus Overview & Live Telemetry"
        academicSession={kpis.academic_session}
        term={kpis.term}
        cloudSync={sync}
        onRefresh={() => fetchOverview(true)}
        refreshing={refreshing}
      />

      <div className="p-8 space-y-8 max-w-7xl mx-auto w-full">
        {error && (
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
            <button
              onClick={() => fetchOverview(true)}
              className="px-3 py-1 bg-rose-500/20 hover:bg-rose-500/30 rounded-lg text-[11px] font-bold text-rose-200 transition-colors"
            >
              Retry
            </button>
          </div>
        )}

        {/* ── KPI Row (4 Cards) ────────────────────────────────────────────── */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Students */}
          <div
            onClick={() => navigate('/students')}
            className="p-5 rounded-3xl bg-slate-800/60 border border-slate-700/60 hover:border-emerald-500/40 transition-all cursor-pointer group shadow-lg shadow-black/20 hover:bg-slate-800/80"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            </div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Active Students
            </p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black text-white tracking-tight">
                {loading ? '—' : kpis.students ?? 0}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">
                across {data?.classes_count ?? '—'} classes
              </span>
            </div>
          </div>

          {/* Card 2: Faculty */}
          <div
            onClick={() => navigate('/teachers')}
            className="p-5 rounded-3xl bg-slate-800/60 border border-slate-700/60 hover:border-sky-500/40 transition-all cursor-pointer group shadow-lg shadow-black/20 hover:bg-slate-800/80"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/20 text-sky-400 group-hover:scale-105 transition-transform">
                <Users className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-sky-400 transition-colors" />
            </div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Teachers &amp; Faculty
            </p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black text-white tracking-tight">
                {loading ? '—' : kpis.teachers ?? 0}
              </span>
              <span className="text-[10px] text-sky-400/90 font-medium">
                Active Staff Roster
              </span>
            </div>
          </div>

          {/* Card 3: Today's Attendance */}
          <div
            onClick={() => navigate('/teachers')}
            className="p-5 rounded-3xl bg-slate-800/60 border border-slate-700/60 hover:border-purple-500/40 transition-all cursor-pointer group shadow-lg shadow-black/20 hover:bg-slate-800/80"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-3 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 group-hover:scale-105 transition-transform">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30">
                Today
              </span>
            </div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Roll Call Attendance
            </p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black text-white tracking-tight">
                {loading ? '—' : `${att.rate ?? 0}%`}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">
                {att.present ?? 0} present today
              </span>
            </div>
          </div>

          {/* Card 4: Fee Arrears */}
          <div
            onClick={() => navigate('/finance')}
            className="p-5 rounded-3xl bg-slate-800/60 border border-slate-700/60 hover:border-amber-500/40 transition-all cursor-pointer group shadow-lg shadow-black/20 hover:bg-slate-800/80"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 group-hover:scale-105 transition-transform">
                <Wallet className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
            </div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Outstanding Arrears
            </p>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-2xl font-black text-amber-400 tracking-tight">
                ₦{Number(fees.outstanding || 0).toLocaleString()}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              ₦{Number(fees.paid || 0).toLocaleString()} Collected
            </p>
          </div>
        </section>

        {/* ── Quick Action Shortcuts ───────────────────────────────────────── */}
        <section className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Quick Operational Actions
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <button
              onClick={() => navigate('/classes')}
              className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/50 hover:bg-slate-800 hover:border-emerald-500/40 text-left transition-all group"
            >
              <School className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-xs font-bold text-white">Class Hierarchy</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Manage arms &amp; intake</p>
            </button>

            <button
              onClick={() => navigate('/subjects')}
              className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/50 hover:bg-slate-800 hover:border-purple-500/40 text-left transition-all group"
            >
              <BookOpen className="w-5 h-5 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-xs font-bold text-white">Joint Grading</p>
              <p className="text-[10px] text-slate-400 mt-0.5">3-way scope configuration</p>
            </button>

            <button
              onClick={() => navigate('/cbt')}
              className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/50 hover:bg-slate-800 hover:border-indigo-500/40 text-left transition-all group"
            >
              <Layers className="w-5 h-5 text-indigo-400 mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-xs font-bold text-white">CBT Exam Room</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Sittings, papers &amp; tokens</p>
            </button>

            <button
              onClick={() => navigate('/settings')}
              className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/50 hover:bg-slate-800 hover:border-amber-500/40 text-left transition-all group"
            >
              <ShieldCheck className="w-5 h-5 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-xs font-bold text-white">Sync &amp; Policies</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Hybrid 2-way cloud worker</p>
            </button>
          </div>
        </section>

        {/* ── Two-Column Operational Hub ───────────────────────────────────── */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Connected Mobile Teachers Table */}
          <div className="lg:col-span-2 p-6 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Paired Mobile Devices</h3>
                  <p className="text-[11px] text-slate-400">Teacher roll-call and grading terminals</p>
                </div>
              </div>
              <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                {devices.length} Active
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-700/60 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    <th className="py-2.5 px-3">Device Model</th>
                    <th className="py-2.5 px-3">Teacher / Label</th>
                    <th className="py-2.5 px-3">Security Tier</th>
                    <th className="py-2.5 px-3">Paired Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {devices.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-slate-500 text-xs">
                        No mobile devices paired yet. Teachers pair via QR scan on the desktop app.
                      </td>
                    </tr>
                  ) : (
                    devices.slice(0, 6).map((d: any, idx: number) => (
                      <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3">
                          <p className="font-bold text-white">{d.device_model || 'Android Terminal'}</p>
                          <p className="text-[10px] text-slate-500 font-mono">{d.device_id}</p>
                        </td>
                        <td className="py-3 px-3 text-slate-300 font-medium">
                          {d.label || 'Unlabeled Staff Device'}
                        </td>
                        <td className="py-3 px-3">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {d.tier || 'Standard'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-400 text-[11px]">
                          {d.paired_at ? new Date(d.paired_at).toLocaleDateString() : 'Active'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Col: Live Activity Stream */}
          <div className="p-6 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <Activity className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Activity Trail</h3>
                <p className="text-[11px] text-slate-400">Real-time local event ledger</p>
              </div>
            </div>

            <div className="space-y-2.5 overflow-y-auto max-h-[380px] pr-1">
              {logs.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs">
                  No recent audit activity logged.
                </div>
              ) : (
                logs.slice(0, 10).map((log: any, idx: number) => {
                  const time = log.timestamp
                    ? new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    : 'Recent';
                  return (
                    <div
                      key={idx}
                      className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/40 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-emerald-400 uppercase tracking-wider">
                          {log.event_type || 'SYSTEM'}
                        </span>
                        <span className="text-slate-500 font-mono">{time}</span>
                      </div>
                      <p className="text-slate-300 text-[11px] font-medium truncate">
                        {typeof log.payload === 'object'
                          ? JSON.stringify(log.payload)
                          : log.payload || log.actor_label || 'Event recorded'}
                      </p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
