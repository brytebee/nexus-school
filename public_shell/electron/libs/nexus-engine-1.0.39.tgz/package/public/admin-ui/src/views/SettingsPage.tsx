import React from 'react';
import Header from '../components/Header';
import { Settings, ShieldCheck, Database, RefreshCw, CheckCircle2 } from 'lucide-react';

export default function SettingsPage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="System & Sync Settings" subtitle="School branding, 2-way cloud worker & backup policies (Phase 7g)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Campus Sovereignty &amp; Identity Center</h3>
              <p className="text-xs text-slate-400">Configure cloud website synchronization, local SQLite backup routines, and school visual identity</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Manage your hybrid synchronization tokens, configure school branding themes (Phase 6), and perform one-click emergency SQLite database backups.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7g Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
