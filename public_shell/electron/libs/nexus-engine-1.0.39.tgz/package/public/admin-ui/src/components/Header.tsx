import React from 'react';
import { Calendar, RefreshCw, Wifi, WifiOff, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle?: string;
  academicSession?: string;
  term?: string;
  cloudSync?: {
    enabled?: boolean;
    last_sync_time?: string;
    website_url?: string;
  };
  onRefresh?: () => void;
  refreshing?: boolean;
}

export default function Header({
  title,
  subtitle,
  academicSession = '2025/2026',
  term = 'First Term',
  cloudSync,
  onRefresh,
  refreshing = false,
}: HeaderProps) {
  return (
    <header className="h-16 px-8 border-b border-slate-800/80 bg-slate-900/40 backdrop-blur-md flex items-center justify-between shrink-0 sticky top-0 z-20">
      <div>
        <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
          {title}
        </h2>
        {subtitle && <p className="text-[11px] text-slate-400">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-3">
        {/* Session / Term Pill */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs">
          <Calendar className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-bold text-white">{academicSession}</span>
          <span className="text-slate-500">·</span>
          <span className="text-slate-300 font-medium">{term}</span>
        </div>

        {/* Sync Status Indicator */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs">
          {cloudSync?.enabled ? (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-400 font-bold text-[11px]">Cloud Synced</span>
            </>
          ) : (
            <>
              <span className="w-2 h-2 rounded-full bg-slate-500" />
              <span className="text-slate-400 font-semibold text-[11px]">Offline Sovereign</span>
            </>
          )}
        </div>

        {/* Refresh button */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={refreshing}
            title="Refresh dashboard metrics"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all disabled:opacity-50 border border-slate-700/60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-emerald-400' : ''}`} />
          </button>
        )}
      </div>
    </header>
  );
}
