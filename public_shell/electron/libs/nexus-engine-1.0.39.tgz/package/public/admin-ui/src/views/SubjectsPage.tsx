import React from 'react';
import Header from '../components/Header';
import { BookOpen, Layers, CheckCircle2 } from 'lucide-react';

export default function SubjectsPage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Subjects & Joint Grading" subtitle="Curriculum subjects & 3-way cohort grading scope (Phase 7e)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Curriculum &amp; Joint Grading Manager</h3>
              <p className="text-xs text-slate-400">Configure compulsory and elective subjects across Nigerian Standard and ACE systems</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Configure 3-way grading scope (<code className="text-purple-400 font-mono">auto</code> / <code className="text-purple-400 font-mono">joint</code> / <code className="text-purple-400 font-mono">per_arm</code>) with automatic bidirectional synchronization between local SQLite and cloud Neon PostgreSQL.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7e Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
