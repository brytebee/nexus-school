import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import Header from '../components/Header';
import {
  BookOpen, Plus, Trash2, Search, X, ChevronDown, ChevronRight,
  Loader2, CheckCircle2, AlertCircle, Layers, Sliders, RefreshCw,
  GraduationCap, School, Check,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────────────────

type GradingScope = 'auto' | 'joint' | 'per_arm';
type CurriculumFilter = 'all' | 'assigned' | 'nigerian' | 'ace' | 'british' | 'custom';

interface SubjectRow {
  name: string;
  category: string;
  curriculum: string;
  grading_scope: GradingScope;
  usage_count: number;
  is_custom: boolean;
  created_at?: string;
}

interface ClassMapping {
  class_name: string;
  subjects: string[];
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getToken(): string {
  return localStorage.getItem('nexus_admin_token') || '';
}

function authHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${getToken()}`,
    'Content-Type': 'application/json',
  };
}

function isSeniorSecondary(className: string) {
  return /^(sss|ss)\s/i.test(className) || /senior/i.test(className);
}

function curriculumLabel(curriculum: string) {
  if (curriculum === 'Nigerian Standard') return '🇳🇬';
  if (curriculum === 'ACE') return '✝️';
  if (curriculum === 'British/Cambridge') return '🎓';
  if (curriculum === 'Custom') return '⭐';
  return '';
}

const SCOPE_OPTIONS: { val: GradingScope; label: string; title: string; color: string }[] = [
  { val: 'auto',    label: '⚙️', title: 'Auto — system decides based on arms count', color: 'bg-slate-600' },
  { val: 'joint',   label: '🌐', title: 'Joint — all arms graded as one cohort',     color: 'bg-purple-600' },
  { val: 'per_arm', label: '🏫', title: 'Per-Arm — each arm graded separately',      color: 'bg-sky-600' },
];

// ─── Scope Toggle (reusable inline component) ─────────────────────────────────

function ScopeToggle({
  name, scope, saving, onSet,
}: {
  name: string;
  scope: GradingScope;
  saving: boolean;
  onSet: (name: string, val: GradingScope) => void;
}) {
  if (saving) {
    return (
      <div className="flex items-center justify-center w-24 h-7">
        <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
      </div>
    );
  }
  return (
    <div className="flex items-center rounded-lg bg-slate-900 border border-slate-700 p-0.5 shrink-0">
      {SCOPE_OPTIONS.map(({ val, label, title, color }) => (
        <button
          key={val}
          type="button"
          title={title}
          onClick={() => scope !== val && onSet(name, val)}
          className={`w-7 h-6 flex items-center justify-center rounded-md text-xs transition-all ${
            scope === val ? `${color} text-white shadow` : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800'
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

// ─── Add Subject Modal ────────────────────────────────────────────────────────

function AddSubjectModal({
  onClose,
  onAdded,
}: {
  onClose: () => void;
  onAdded: (s: SubjectRow) => void;
}) {
  const [name, setName] = useState('');
  const [curriculum, setCurriculum] = useState<'Nigerian Standard' | 'ACE' | 'Custom'>('Nigerian Standard');
  const [scope, setScope] = useState<GradingScope>('auto');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) { setError('Subject name is required'); return; }
    setSaving(true);
    setError('');
    try {
      const r = await fetch('/api/admin/subjects', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ name: trimmed, grading_scope: scope }),
      });
      const data = await r.json();
      if (!r.ok) { setError(data.error || 'Failed to add subject'); return; }
      onAdded({
        name: trimmed,
        category: 'Custom',
        curriculum: 'Custom',
        grading_scope: scope,
        usage_count: 0,
        is_custom: true,
      });
      onClose();
    } catch {
      setError('Network error — try again');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <Plus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Add Custom Subject</h3>
              <p className="text-[11px] text-slate-400">Add a new subject to the school pool</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Subject Name *
            </label>
            <input
              ref={inputRef}
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Technical Drawing, French Language"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Curriculum Type
            </label>
            <div className="flex gap-2">
              {(['Nigerian Standard', 'ACE', 'Custom'] as const).map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCurriculum(c)}
                  className={`flex-1 py-2 rounded-xl border text-[11px] font-semibold transition-all ${
                    curriculum === c
                      ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-400'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Grading Scope
            </label>
            <div className="flex gap-2">
              {SCOPE_OPTIONS.map(({ val, label, title }) => (
                <button
                  key={val}
                  type="button"
                  title={title}
                  onClick={() => setScope(val)}
                  className={`flex-1 py-2 rounded-xl border text-[11px] font-semibold transition-all ${
                    scope === val
                      ? val === 'joint'   ? 'bg-purple-500/15 border-purple-500/50 text-purple-400'
                      : val === 'per_arm' ? 'bg-sky-500/15 border-sky-500/50 text-sky-400'
                                          : 'bg-slate-600/30 border-slate-500/50 text-slate-300'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600'
                  }`}
                >
                  {label} {val}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-400 text-xs px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/20">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}
        </form>

        {/* Footer */}
        <div className="flex gap-3 px-6 pb-6">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-sm font-semibold hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit as any}
            disabled={saving || !name.trim()}
            className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {saving ? 'Adding…' : 'Add Subject'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Delete Confirm Dialog ────────────────────────────────────────────────────

function DeleteConfirmDialog({
  subject,
  onClose,
  onDeleted,
}: {
  subject: SubjectRow;
  onClose: () => void;
  onDeleted: (name: string) => void;
}) {
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState('');

  async function handleDelete() {
    setDeleting(true);
    setError('');
    try {
      const r = await fetch(`/api/admin/subjects/${encodeURIComponent(subject.name)}`, {
        method: 'DELETE',
        headers: authHeaders(),
      });
      const data = await r.json();
      if (!r.ok) { setError(data.error || 'Failed to delete'); return; }
      onDeleted(subject.name);
      onClose();
    } catch {
      setError('Network error — try again');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 shrink-0">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Delete Subject</h3>
            <p className="text-[11px] text-slate-400">This action cannot be undone</p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Remove <span className="font-bold text-white">"{subject.name}"</span> from the custom subject pool?
          {subject.usage_count > 0 && (
            <span className="block mt-1 text-amber-400">
              ⚠️ This subject is used in {subject.usage_count} class allocation(s). Delete will be blocked.
            </span>
          )}
        </p>

        {error && (
          <div className="flex items-center gap-2 text-red-400 text-xs px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/20">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-sm font-semibold hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-sm font-semibold hover:bg-red-500 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
          >
            {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
            {deleting ? 'Deleting…' : 'Delete'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Joint Grading Drawer ─────────────────────────────────────────────────────

function JointGradingDrawer({
  allSubjects,
  classMappings,
  gradingScopes,
  savingScopeFor,
  onSetScope,
  onClose,
}: {
  allSubjects: SubjectRow[];
  classMappings: ClassMapping[];
  gradingScopes: Record<string, GradingScope>;
  savingScopeFor: string | null;
  onSetScope: (name: string, val: GradingScope) => void;
  onClose: () => void;
}) {
  const [search, setSearch] = useState('');

  // Build the set of subjects actually used in allocations
  const usedSubjectNames = useMemo(() => {
    const s = new Set<string>();
    classMappings.forEach(cm => cm.subjects.forEach(sub => s.add(sub.toLowerCase().trim())));
    return s;
  }, [classMappings]);

  // Get subjects in use, enriched with scope
  const drawerSubjects = useMemo(() => {
    return allSubjects
      .filter(s => usedSubjectNames.has(s.name.toLowerCase().trim()))
      .map(s => ({
        ...s,
        grading_scope: gradingScopes[s.name.toLowerCase().trim()] || s.grading_scope || 'auto',
      }))
      .filter(s => !search || s.name.toLowerCase().includes(search.toLowerCase()));
  }, [allSubjects, usedSubjectNames, gradingScopes, search]);

  const sssSubjects = drawerSubjects.filter(s => {
    const classes = classMappings
      .filter(cm => cm.subjects.some(sub => sub.toLowerCase().trim() === s.name.toLowerCase().trim()))
      .map(cm => cm.class_name);
    return classes.some(isSeniorSecondary);
  });
  const sssNames = new Set(sssSubjects.map(s => s.name.toLowerCase()));
  const otherSubjects = drawerSubjects.filter(s => !sssNames.has(s.name.toLowerCase()));

  const showSssDivider = sssSubjects.length > 0;
  const showOtherDivider = otherSubjects.length > 0 && sssSubjects.length > 0;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-40 bg-black/50" onClick={onClose} />

      {/* Panel */}
      <div className="fixed right-0 top-0 bottom-0 z-50 w-full max-w-sm bg-slate-950 border-l border-slate-800 flex flex-col shadow-2xl">
        {/* Drawer header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Joint Grading Scope</h3>
              <p className="text-[11px] text-slate-400">
                {drawerSubjects.length} subject{drawerSubjects.length !== 1 ? 's' : ''} in use
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="px-4 py-3 border-b border-slate-800 shrink-0">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search subjects…"
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Subject list */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-1.5">
          {drawerSubjects.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs text-slate-500">
                {search ? 'No subjects match your search' : 'No subjects assigned to any class yet'}
              </p>
            </div>
          ) : (
            <>
              {showSssDivider && (
                <div className="flex items-center gap-2 px-1 pt-1 pb-1.5">
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">🎓 Senior Secondary</span>
                  <div className="flex-1 h-px bg-amber-500/20" />
                </div>
              )}
              {sssSubjects.map(s => (
                <SubjectDrawerRow key={s.name} subject={s} saving={savingScopeFor === s.name} onSet={onSetScope} />
              ))}
              {showOtherDivider && (
                <div className="flex items-center gap-2 px-1 pt-2 pb-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">📘 Other Classes</span>
                  <div className="flex-1 h-px bg-slate-700" />
                </div>
              )}
              {otherSubjects.map(s => (
                <SubjectDrawerRow key={s.name} subject={s} saving={savingScopeFor === s.name} onSet={onSetScope} />
              ))}
            </>
          )}
        </div>

        {/* Legend */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 shrink-0">
          <p className="text-[10px] text-slate-500 leading-relaxed space-y-0.5">
            <span className="block">🌐 <strong className="text-slate-400">Joint</strong> — all arms graded as one cohort</span>
            <span className="block">🏫 <strong className="text-slate-400">Per-Arm</strong> — each arm graded separately</span>
            <span className="block">⚙️ <strong className="text-slate-400">Auto</strong> — multi-arm → joint · single-arm → independent</span>
          </p>
        </div>
      </div>
    </>
  );
}

function SubjectDrawerRow({
  subject,
  saving,
  onSet,
}: {
  subject: SubjectRow;
  saving: boolean;
  onSet: (name: string, val: GradingScope) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 transition-colors">
      <div className="min-w-0 flex-1">
        <p className="text-xs font-semibold text-white truncate">{subject.name}</p>
        <p className="text-[10px] text-slate-400 truncate">{subject.category}</p>
      </div>
      <ScopeToggle
        name={subject.name}
        scope={subject.grading_scope}
        saving={saving}
        onSet={onSet}
      />
    </div>
  );
}

// ─── Class Mapping Accordion Item ─────────────────────────────────────────────

function ClassMappingItem({ cm, i }: { cm: ClassMapping; i: number }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={i % 2 === 0 ? 'bg-slate-800/20' : ''}>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-5 py-2.5 hover:bg-slate-700/30 transition-colors"
      >
        <div className="flex items-center gap-3">
          {isSeniorSecondary(cm.class_name) ? (
            <GraduationCap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          ) : (
            <School className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          )}
          <span className="text-xs font-semibold text-white">{cm.class_name}</span>
          <span className="px-2 py-0.5 rounded-full bg-slate-700 text-slate-400 text-[10px] font-semibold">
            {cm.subjects.length} subjects
          </span>
        </div>
        <ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${open ? 'rotate-90' : ''}`} />
      </button>
      {open && (
        <div className="px-5 pb-3 flex flex-wrap gap-1.5">
          {cm.subjects.map(sub => (
            <span key={sub} className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-[10px] text-slate-300 font-medium">
              {sub}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Reusable Subject Table Component ─────────────────────────────────────────

function SubjectTableView({
  subjects,
  gradingScopes,
  savingScopeFor,
  onSetScope,
  expandedRows,
  onToggleExpand,
  getUsageClasses,
  onDeleteClick,
}: {
  subjects: SubjectRow[];
  gradingScopes: Record<string, GradingScope>;
  savingScopeFor: string | null;
  onSetScope: (name: string, val: GradingScope) => void;
  expandedRows: Set<string>;
  onToggleExpand: (name: string) => void;
  getUsageClasses: (name: string) => string[];
  onDeleteClick: (s: SubjectRow) => void;
}) {
  return (
    <div className="rounded-2xl bg-slate-800/40 border border-slate-700/60 overflow-hidden">
      {/* Table header */}
      <div className="grid grid-cols-[minmax(0,1fr)_130px_90px_100px_40px] gap-2 px-4 py-2.5 border-b border-slate-700 bg-slate-800/60">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Subject</span>
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Category</span>
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Used In</span>
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Scope</span>
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Del</span>
      </div>

      {/* Rows */}
      <div className="divide-y divide-slate-700/40">
        {subjects.map((s, i) => {
          const usageClasses = getUsageClasses(s.name);
          const isExpanded = expandedRows.has(s.name);
          return (
            <React.Fragment key={s.name}>
              <div
                className={`grid grid-cols-[minmax(0,1fr)_130px_90px_100px_40px] gap-2 px-4 py-2.5 items-center transition-colors ${
                  i % 2 === 0 ? 'bg-slate-800/20' : ''
                } hover:bg-slate-700/30`}
              >
                {/* Name */}
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-white truncate">{s.name}</span>
                    {s.is_custom && (
                      <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 text-[9px] font-bold border border-emerald-500/20 shrink-0">
                        CUSTOM
                      </span>
                    )}
                    <span className="text-xs shrink-0">{curriculumLabel(s.curriculum)}</span>
                  </div>
                  {s.curriculum !== 'Custom' && (
                    <p className="text-[10px] text-slate-500 truncate">{s.curriculum}</p>
                  )}
                </div>

                {/* Category */}
                <span className="text-[11px] text-slate-400 truncate">{s.category}</span>

                {/* Used In */}
                <div className="text-center">
                  {s.usage_count > 0 ? (
                    <button
                      onClick={() => onToggleExpand(s.name)}
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-400 text-[10px] font-bold border border-sky-500/20 hover:bg-sky-500/25 transition-colors"
                    >
                      {s.usage_count} cls
                      <ChevronDown className={`w-2.5 h-2.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                    </button>
                  ) : (
                    <span className="text-[10px] text-slate-600">—</span>
                  )}
                </div>

                {/* Scope toggle */}
                <div className="flex justify-center">
                  <ScopeToggle
                    name={s.name}
                    scope={gradingScopes[s.name.toLowerCase().trim()] || s.grading_scope || 'auto'}
                    saving={savingScopeFor === s.name}
                    onSet={onSetScope}
                  />
                </div>

                {/* Delete */}
                <div className="flex justify-center">
                  {s.is_custom ? (
                    <button
                      onClick={() => onDeleteClick(s)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                      title="Delete custom subject"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <span className="text-slate-700 text-[10px]">—</span>
                  )}
                </div>
              </div>

              {/* Expanded usage row */}
              {isExpanded && usageClasses.length > 0 && (
                <div className="px-4 py-2.5 bg-sky-500/5 border-t border-sky-500/10">
                  <div className="flex flex-wrap gap-1.5">
                    <span className="text-[10px] text-slate-500 mr-1">Used in:</span>
                    {usageClasses.map(cls => (
                      <span key={cls} className="px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 text-[10px] font-semibold border border-sky-500/20">
                        {cls}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Table footer */}
      <div className="px-4 py-2.5 border-t border-slate-700 bg-slate-800/30 flex items-center justify-between">
        <span className="text-[10px] text-slate-500">
          {subjects.length} subject{subjects.length !== 1 ? 's' : ''} listed
        </span>
        <div className="flex items-center gap-3 text-[10px] text-slate-500">
          <span>⚙️ Auto</span>
          <span className="text-purple-400">🌐 Joint</span>
          <span className="text-sky-400">🏫 Per-Arm</span>
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function SubjectsPage() {
  const [customSubjects, setCustomSubjects] = useState<SubjectRow[]>([]);
  const [standardSubjects, setStandardSubjects] = useState<SubjectRow[]>([]);
  const [classMappings, setClassMappings] = useState<ClassMapping[]>([]);
  const [gradingScopes, setGradingScopes] = useState<Record<string, GradingScope>>({});
  const [savingScopeFor, setSavingScopeFor] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [curriculumFilter, setCurriculumFilter] = useState<CurriculumFilter>('all');
  const [unassignedExpanded, setUnassignedExpanded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [addModalOpen, setAddModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<SubjectRow | null>(null);
  const [jointDrawerOpen, setJointDrawerOpen] = useState(false);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  // ── Data loading ────────────────────────────────────────────────────────────
  const loadData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [subR, clsR] = await Promise.allSettled([
        fetch('/api/admin/subjects', { headers: authHeaders() }).then(r => r.json()),
        fetch('/api/admin/subjects/classes', { headers: authHeaders() }).then(r => r.json()),
      ]);

      if (subR.status === 'fulfilled' && subR.value?.ok) {
        const subData = subR.value;
        setCustomSubjects(subData.custom_subjects || []);
        setStandardSubjects(subData.standard_subjects || []);
        const map: Record<string, GradingScope> = {};
        [...(subData.custom_subjects || []), ...(subData.standard_subjects || [])].forEach((s: SubjectRow) => {
          map[s.name.toLowerCase().trim()] = s.grading_scope || 'auto';
        });
        setGradingScopes(map);
      } else {
        const msg = subR.status === 'fulfilled' ? (subR.value?.error || 'API error') : subR.reason?.message;
        setError(`Failed to load subjects — ${msg}`);
      }

      if (clsR.status === 'fulfilled' && clsR.value?.ok) {
        setClassMappings(clsR.value.classes || []);
      }
    } catch {
      setError('Failed to load subjects data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // ── Grading scope update ────────────────────────────────────────────────────
  const handleSetScope = useCallback(async (name: string, val: GradingScope) => {
    setSavingScopeFor(name);
    try {
      const r = await fetch(`/api/admin/subjects/${encodeURIComponent(name)}/grading-scope`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify({ grading_scope: val }),
      });
      const data = await r.json();
      if (!r.ok) { console.error('scope update error', data.error); return; }

      // Optimistic update
      setGradingScopes(prev => ({ ...prev, [name.toLowerCase().trim()]: val }));
      setCustomSubjects(prev =>
        prev.map(s => s.name.toLowerCase() === name.toLowerCase() ? { ...s, grading_scope: val } : s)
      );
      setStandardSubjects(prev =>
        prev.map(s => s.name.toLowerCase() === name.toLowerCase() ? { ...s, grading_scope: val } : s)
      );
    } catch {
      console.error('scope update network error');
    } finally {
      setSavingScopeFor(null);
    }
  }, []);

  // ── Derived subjects list ───────────────────────────────────────────────────
  const allSubjects: SubjectRow[] = useMemo(() => {
    const all = [...customSubjects, ...standardSubjects];
    return all.map(s => ({
      ...s,
      grading_scope: gradingScopes[s.name.toLowerCase().trim()] || s.grading_scope || 'auto',
    }));
  }, [customSubjects, standardSubjects, gradingScopes]);

  const filteredSubjects = useMemo(() => {
    return allSubjects.filter(s => {
      const matchSearch = !search || s.name.toLowerCase().includes(search.toLowerCase())
        || s.category.toLowerCase().includes(search.toLowerCase());
      const matchCurr = curriculumFilter === 'all'
        || (curriculumFilter === 'assigned' && s.usage_count > 0)
        || (curriculumFilter === 'nigerian' && s.curriculum === 'Nigerian Standard')
        || (curriculumFilter === 'ace'      && s.curriculum === 'ACE')
        || (curriculumFilter === 'british'  && s.curriculum === 'British/Cambridge')
        || (curriculumFilter === 'custom'   && s.is_custom);
      return matchSearch && matchCurr;
    });
  }, [allSubjects, search, curriculumFilter]);

  const assignedSubjects = useMemo(() => {
    return filteredSubjects.filter(s => s.usage_count > 0);
  }, [filteredSubjects]);

  const unassignedSubjects = useMemo(() => {
    return filteredSubjects.filter(s => s.usage_count === 0);
  }, [filteredSubjects]);

  // If user is searching and matches unassigned subjects, automatically open the accordion
  const isUnassignedOpen = unassignedExpanded || (Boolean(search) && unassignedSubjects.length > 0);

  // ── Stats ───────────────────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const total = allSubjects.length;
    const custom = customSubjects.length;
    const joint = allSubjects.filter(s =>
      (gradingScopes[s.name.toLowerCase().trim()] || s.grading_scope) === 'joint'
    ).length;
    const perArm = allSubjects.filter(s =>
      (gradingScopes[s.name.toLowerCase().trim()] || s.grading_scope) === 'per_arm'
    ).length;
    const inUse = allSubjects.filter(s => s.usage_count > 0).length;
    return { total, custom, joint, perArm, inUse };
  }, [allSubjects, customSubjects, gradingScopes]);

  // ── Build usage tooltip (class names) ──────────────────────────────────────
  function getUsageClasses(subjectName: string): string[] {
    return classMappings
      .filter(cm => cm.subjects.some(s => s.toLowerCase().trim() === subjectName.toLowerCase().trim()))
      .map(cm => cm.class_name);
  }

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header
        title="Subjects & Joint Grading"
        subtitle="Manage school subject pool, curriculum assignments, and 3-way joint grading scope"
      />

      <div className="p-6 max-w-7xl mx-auto w-full space-y-6">

        {/* ── Action Bar ─────────────────────────────────────────────────── */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Curriculum filter chips */}
            {(
              [
                { val: 'all',      label: 'All Subjects' },
                { val: 'assigned', label: `✅ Assigned to Classes (${stats.inUse})` },
                { val: 'nigerian', label: '🇳🇬 Nigerian Standard' },
                { val: 'ace',      label: '✝️ ACE' },
                { val: 'british',  label: '🎓 British/Cambridge' },
                { val: 'custom',   label: `⭐ Custom (${stats.custom})` },
              ] as { val: CurriculumFilter; label: string }[]
            ).map(({ val, label }) => (
              <button
                key={val}
                onClick={() => setCurriculumFilter(val)}
                className={`px-3 py-1.5 rounded-full text-[11px] font-semibold border transition-all ${
                  curriculumFilter === val
                    ? val === 'assigned'
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow'
                      : 'bg-purple-500/20 border-purple-500/50 text-purple-300 shadow'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600 hover:text-slate-300'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setJointDrawerOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors"
            >
              <Sliders className="w-3.5 h-3.5" />
              Joint Grading Scope
            </button>
            <button
              onClick={() => setAddModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Subject
            </button>
            <button
              onClick={loadData}
              title="Refresh"
              className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ── Stats Bar ──────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {[
            { label: 'Total Catalog',   value: stats.total,  color: 'text-white' },
            { label: 'Assigned in Use', value: stats.inUse,  color: 'text-emerald-400' },
            { label: 'Custom Subjects', value: stats.custom, color: 'text-amber-400' },
            { label: '🌐 Joint Scope',  value: stats.joint,  color: 'text-purple-400' },
            { label: '🏫 Per-Arm Scope',value: stats.perArm, color: 'text-sky-400' },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-2xl bg-slate-800/40 border border-slate-700/60 px-4 py-3 text-center">
              <p className={`text-xl font-black ${color}`}>{value}</p>
              <p className="text-[10px] text-slate-400 font-semibold mt-0.5">{label}</p>
            </div>
          ))}
        </div>

        {/* ── Search ─────────────────────────────────────────────────────── */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search subjects by name or category…"
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* ── Content ────────────────────────────────────────────────────── */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
            <p className="text-sm text-slate-400">Loading subjects…</p>
          </div>
        ) : error ? (
          <div className="flex items-center gap-3 px-5 py-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p className="text-sm">{error}</p>
            <button onClick={loadData} className="ml-auto text-xs underline hover:no-underline">Retry</button>
          </div>
        ) : filteredSubjects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <BookOpen className="w-10 h-10 text-slate-600" />
            <p className="text-sm text-slate-400">No subjects match your filters</p>
            {(search || curriculumFilter !== 'all') && (
              <button
                onClick={() => { setSearch(''); setCurriculumFilter('all'); }}
                className="text-xs text-purple-400 hover:underline"
              >
                Clear filters
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-6">

            {/* ── SECTION 1: Active Assigned Subjects ─────────────────────── */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <h3 className="text-sm font-bold text-white">Active School Subjects (Assigned to Classes)</h3>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                    {assignedSubjects.length} active
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 hidden sm:inline">
                  Allocated to teachers &amp; taught in classes
                </span>
              </div>

              {assignedSubjects.length > 0 ? (
                <SubjectTableView
                  subjects={assignedSubjects}
                  gradingScopes={gradingScopes}
                  savingScopeFor={savingScopeFor}
                  onSetScope={handleSetScope}
                  expandedRows={expandedRows}
                  onToggleExpand={name => setExpandedRows(prev => {
                    const n = new Set(prev);
                    n.has(name) ? n.delete(name) : n.add(name);
                    return n;
                  })}
                  getUsageClasses={getUsageClasses}
                  onDeleteClick={setDeleteTarget}
                />
              ) : (
                <div className="p-6 rounded-2xl bg-slate-800/30 border border-dashed border-slate-700 text-center">
                  <p className="text-xs text-slate-400">No assigned school subjects match your current filter.</p>
                </div>
              )}
            </div>

            {/* ── SECTION 2: Master Curriculum Catalog (Collapsible) ──────── */}
            {curriculumFilter !== 'assigned' && unassignedSubjects.length > 0 && (
              <div className="space-y-3 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setUnassignedExpanded(v => !v)}
                  className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/40 hover:bg-slate-800/70 border border-slate-700/60 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-lg">🏛️</span>
                    <div className="text-left">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">Master Curriculum Pool / Unassigned Catalog</span>
                        <span className="px-2 py-0.5 rounded-full bg-slate-700 text-slate-300 text-[10px] font-semibold">
                          {unassignedSubjects.length} subjects
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Library subjects from Nigerian Standard, ACE, Cambridge &amp; custom not yet assigned to classes
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 shrink-0">
                    <span className="text-[11px] font-medium">{isUnassignedOpen ? 'Collapse Catalog' : 'Expand Catalog'}</span>
                    <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isUnassignedOpen ? 'rotate-180' : ''}`} />
                  </div>
                </button>

                {isUnassignedOpen && (
                  <SubjectTableView
                    subjects={unassignedSubjects}
                    gradingScopes={gradingScopes}
                    savingScopeFor={savingScopeFor}
                    onSetScope={handleSetScope}
                    expandedRows={expandedRows}
                    onToggleExpand={name => setExpandedRows(prev => {
                      const n = new Set(prev);
                      n.has(name) ? n.delete(name) : n.add(name);
                      return n;
                    })}
                    getUsageClasses={getUsageClasses}
                    onDeleteClick={setDeleteTarget}
                  />
                )}
              </div>
            )}
          </div>
        )}

        {/* ── Class-Subject Map Accordion ─────────────────────────────────── */}
        {classMappings.length > 0 && (
          <div className="rounded-2xl bg-slate-800/40 border border-slate-700/60 overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-700 flex items-center gap-3">
              <School className="w-4 h-4 text-slate-400" />
              <h3 className="text-sm font-bold text-white">Class–Subject Assignments</h3>
              <span className="text-[10px] text-slate-500 ml-auto">From teacher allocations</span>
            </div>
            <div className="divide-y divide-slate-700/40">
              {classMappings.map((cm, i) => (
                <ClassMappingItem key={cm.class_name} cm={cm} i={i} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── Modals & Drawers ─────────────────────────────────────────────── */}
      {addModalOpen && (
        <AddSubjectModal
          onClose={() => setAddModalOpen(false)}
          onAdded={s => setCustomSubjects(prev => [s, ...prev])}
        />
      )}

      {deleteTarget && (
        <DeleteConfirmDialog
          subject={deleteTarget}
          onClose={() => setDeleteTarget(null)}
          onDeleted={name => {
            setCustomSubjects(prev => prev.filter(s => s.name !== name));
            setDeleteTarget(null);
          }}
        />
      )}

      {jointDrawerOpen && (
        <JointGradingDrawer
          allSubjects={allSubjects}
          classMappings={classMappings}
          gradingScopes={gradingScopes}
          savingScopeFor={savingScopeFor}
          onSetScope={handleSetScope}
          onClose={() => setJointDrawerOpen(false)}
        />
      )}
    </div>
  );
}
