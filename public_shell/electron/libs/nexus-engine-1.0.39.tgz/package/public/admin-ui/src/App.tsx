import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import LoginView from './views/LoginView';
import Dashboard from './views/Dashboard';
import ClassesPage from './views/ClassesPage';
import TeachersPage from './views/TeachersPage';
import StudentsPage from './views/StudentsPage';
import FinancePage from './views/FinancePage';
import SubjectsPage from './views/SubjectsPage';
import CbtPage from './views/CbtPage';
import SettingsPage from './views/SettingsPage';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('nexus_admin_token'));
  const [admin, setAdmin] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const verifySession = async (existingToken: string) => {
    try {
      const res = await fetch('/api/admin/me', {
        headers: {
          Authorization: `Bearer ${existingToken}`,
          'Content-Type': 'application/json',
        },
      });
      if (res.ok) {
        const data = await res.json();
        setAdmin(data.admin || { username: 'Superadmin', role_level: 9 });
      } else {
        // Token expired
        localStorage.removeItem('nexus_admin_token');
        setToken(null);
        setAdmin(null);
      }
    } catch (_) {
      // Offline fallback: keep session if server briefly unreachable
      setAdmin({ username: 'Superadmin', role_level: 9 });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      verifySession(token);
    } else {
      setLoading(false);
    }
  }, [token]);

  const handleLoginSuccess = (newToken: string, adminProfile: any) => {
    setToken(newToken);
    setAdmin(adminProfile);
  };

  const handleLogout = async () => {
    if (token) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });
      } catch (_) {}
    }
    localStorage.removeItem('nexus_admin_token');
    setToken(null);
    setAdmin(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-3 text-slate-400">
        <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
        <p className="text-xs font-semibold tracking-wider uppercase font-mono">
          Initializing Sovereign Admin OS...
        </p>
      </div>
    );
  }

  if (!token) {
    return <LoginView onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 font-sans">
      <Sidebar admin={admin} onLogout={handleLogout} />
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard token={token} />} />
          <Route path="/classes" element={<ClassesPage />} />
          <Route path="/teachers" element={<TeachersPage />} />
          <Route path="/students" element={<StudentsPage />} />
          <Route path="/finance" element={<FinancePage />} />
          <Route path="/subjects" element={<SubjectsPage />} />
          <Route path="/cbt" element={<CbtPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
    </div>
  );
}
