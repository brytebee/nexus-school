import React, { useEffect, useState, useCallback } from 'react';
import Header from '../components/Header';
import {
  School, ChevronDown, ChevronRight, Plus, Pencil, Trash2,
  Upload, Download, X, Check, Loader2, AlertTriangle, RefreshCw
} from 'lucide-react';

// ── Types ─────────────────────────────────────────────────────────────────────
interface ArmEntry {
  id: number;
  arm: string;
  student_count: number;
  curriculum_type?: string;
  pac_count?: number;
}

interface ClassConfig {
  hierarchy_class: string;
  max_subjects: number;
  pass_mark_override: number | null;
  curriculum_type: string;
  arms: ArmEntry[];
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function getToken() { return localStorage.getItem('nexus_admin_token') || ''; }

function authHeaders(): Record<string, string> {
  return { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' };
}

// ── Inline Toast ──────────────────────────────────────────────────────────────
function Toast({ msg, type, onClose }: { msg: string; type: 'ok' | 'err'; onClose: () => void }) {
  useEffect(() => { const t = setTimeout(onClose, 4000); return () => clearTimeout(t); }, [onClose]);
  return (
    <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl shadow-2xl text-sm font-semibold border ${
      type === 'ok'
        ? 'bg-emerald-900/90 border-emerald-600 text-emerald-200'
        : 'bg-rose-900/90 border-rose-600 text-rose-200'
    }`}>
      {type === 'ok' ? <Check className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-rose-400" />}
      {msg}
      <button onClick={onClose} className="ml-2 opacity-60 hover:opacity-100"><X className="w-3.5 h-3.5" /></button>
    </div>
  );
}

// ── Confirm Dialog (no window.confirm) ────────────────────────────────────────
function ConfirmDialog({ message, onConfirm, onCancel }: { message: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-8 w-full max-w-sm mx-4 space-y-5">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <p className="text-sm text-slate-200 leading-relaxed">{message}</p>
        </div>
        <div className="flex gap-3 justify-end">
          <button onClick={onCancel} className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 hover:text-white bg-slate-700/60 hover:bg-slate-700 transition-all">
            Cancel
          </button>
          <button onClick={onConfirm} className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white transition-all">
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Add Arm Modal ─────────────────────────────────────────────────────────────
function AddArmModal({
  hierarchyClass,
  onSave,
  onClose,
}: { hierarchyClass: string; onSave: (arm: string, curriculumType: string) => Promise<void>; onClose: () => void }) {
  const [arm, setArm] = useState('');
  const [curriculumType, setCurriculumType] = useState<string>('STANDARD_NIGERIAN');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async () => {
    if (!arm.trim()) { setErr('Arm name cannot be empty'); return; }
    setSaving(true); setErr('');
    try { await onSave(arm.trim(), curriculumType); }
    catch (e: unknown) { setErr(e instanceof Error ? e.message : 'Error'); setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-8 w-full max-w-sm mx-4 space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-black text-base">Add Arm to {hierarchyClass}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Arm Name</label>
          <input
            autoFocus
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors"
            placeholder="e.g. Gold, Diamond, Art"
            value={arm}
            onChange={e => setArm(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handle()}
          />
          {err && <p className="text-xs text-rose-400">{err}</p>}
        </div>

        {/* Curriculum Selector */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Curriculum System</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setCurriculumType('STANDARD_NIGERIAN')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                curriculumType !== 'ILS'
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              Nigerian / British
            </button>
            <button
              type="button"
              onClick={() => setCurriculumType('ILS')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                curriculumType === 'ILS'
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              ILS (ACE PAC)
            </button>
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700 transition-all">Cancel</button>
          <button
            onClick={handle}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            Add Arm
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Rename / Configure Arm Modal ──────────────────────────────────────────────
function RenameArmModal({
  arm,
  onSave,
  onClose,
}: { arm: ArmEntry; onSave: (newName: string, curriculumType: string) => Promise<void>; onClose: () => void }) {
  const [name, setName] = useState(arm.arm);
  const [curriculumType, setCurriculumType] = useState<string>(
    arm.curriculum_type || (/(?:ACE|ILS|PAC)/i.test(arm.arm) ? 'ILS' : 'STANDARD_NIGERIAN')
  );
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async () => {
    if (!name.trim()) { setErr('Name cannot be empty'); return; }
    setSaving(true); setErr('');
    try { await onSave(name.trim(), curriculumType); }
    catch (e: unknown) { setErr(e instanceof Error ? e.message : 'Error'); setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-8 w-full max-w-sm mx-4 space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-black text-base">Configure Arm</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Arm Name</label>
          <input
            autoFocus
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handle()}
          />
          {err && <p className="text-xs text-rose-400">{err}</p>}
        </div>

        {/* Curriculum Selector */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Curriculum System</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setCurriculumType('STANDARD_NIGERIAN')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                curriculumType !== 'ILS'
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              Nigerian / British
            </button>
            <button
              type="button"
              onClick={() => setCurriculumType('ILS')}
              className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                curriculumType === 'ILS'
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              ILS (ACE PAC)
            </button>
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700">Cancel</button>
          <button
            onClick={handle}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Import Modal ──────────────────────────────────────────────────────────────
function ImportModal({ onImport, onClose }: { onImport: (text: string) => Promise<void>; onClose: () => void }) {
  const [text, setText] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async () => {
    if (!text.trim()) { setErr('Paste JSON content to import'); return; }
    setSaving(true); setErr('');
    try { await onImport(text.trim()); }
    catch (e: unknown) { setErr(e instanceof Error ? e.message : 'Error'); setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-8 w-full max-w-lg mx-4 space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-black text-base">Import Class Hierarchy</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          Paste JSON exported from school-website or nexus-school. Accepted formats:
          <code className="text-emerald-400 ml-1">[&#123;hierarchyClass, arms[]&#125;]</code> or a flat list of class names.
        </p>
        <textarea
          autoFocus
          className="w-full h-40 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500 resize-none"
          placeholder={'[{"hierarchyClass":"JSS 1","arms":["Gold","Diamond"]},...]'}
          value={text}
          onChange={e => setText(e.target.value)}
        />
        {err && <p className="text-xs text-rose-400">{err}</p>}
        <p className="text-[11px] text-amber-400/80">
          ⚠ This will <strong>overwrite</strong> the current class hierarchy.
        </p>
        <div className="flex gap-3 justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700">Cancel</button>
          <button
            onClick={handle}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
            Import &amp; Overwrite
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Class Row Card ─────────────────────────────────────────────────────────────
function ClassCard({
  cls,
  onAddArm,
  onRenameArm,
  onDeleteArm,
}: {
  cls: ClassConfig;
  onAddArm: (hierarchyClass: string, arm: string, curriculumType: string) => Promise<void>;
  onRenameArm: (armId: number, newName: string, curriculumType: string) => Promise<void>;
  onDeleteArm: (armId: number, armName: string) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const [addArmOpen, setAddArmOpen] = useState(false);
  const [renamingArm, setRenamingArm] = useState<ArmEntry | null>(null);

  const totalStudents = cls.arms.reduce((s, a) => s + a.student_count, 0);

  return (
    <div className="rounded-2xl border border-slate-700/60 bg-slate-800/40 shadow overflow-hidden">
      {/* Class header */}
      <button
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-slate-800/60 transition-colors"
        onClick={() => setExpanded(v => !v)}
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <School className="w-4 h-4" />
          </div>
          <div className="text-left">
            <p className="text-sm font-black text-white">{cls.hierarchy_class}</p>
            <p className="text-[11px] text-slate-400">
              {cls.arms.length} arm{cls.arms.length !== 1 ? 's' : ''} · {totalStudents} active student{totalStudents !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            className="p-2 rounded-xl bg-slate-700/60 hover:bg-emerald-500/20 text-slate-400 hover:text-emerald-400 transition-colors"
            title="Add arm"
            onClick={e => { e.stopPropagation(); setAddArmOpen(true); }}
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          {expanded ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
        </div>
      </button>

      {/* Arms list */}
      {expanded && (
        <div className="border-t border-slate-700/60">
          {cls.arms.length === 0 ? (
            <p className="text-xs text-slate-500 italic px-6 py-4">No arms configured. Click + to add one.</p>
          ) : (
            <div className="divide-y divide-slate-700/40">
              {cls.arms.map(arm => {
                const isIls = arm.curriculum_type === 'ILS' || /(?:ACE|ILS|PAC)/i.test(arm.arm);
                return (
                  <div key={arm.id} className="flex items-center justify-between px-6 py-3 group hover:bg-slate-800/30 transition-colors">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{arm.arm}</span>
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${
                        isIls
                          ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                          : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      }`}>
                        {isIls ? 'ILS' : 'Standard'}
                      </span>
                      <span className="text-[11px] text-slate-400">{arm.student_count} student{arm.student_count !== 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"
                        title="Configure arm & curriculum"
                        onClick={() => setRenamingArm(arm)}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                        title="Delete arm"
                        onClick={() => onDeleteArm(arm.id, arm.arm)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          <div className="px-6 py-3 border-t border-slate-700/40">
            <button
              className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-400/70 hover:text-emerald-400 transition-colors"
              onClick={() => setAddArmOpen(true)}
            >
              <Plus className="w-3.5 h-3.5" /> Add arm to {cls.hierarchy_class}
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      {addArmOpen && (
        <AddArmModal
          hierarchyClass={cls.hierarchy_class}
          onSave={async (arm, curriculumType) => { await onAddArm(cls.hierarchy_class, arm, curriculumType); setAddArmOpen(false); }}
          onClose={() => setAddArmOpen(false)}
        />
      )}
      {renamingArm && (
        <RenameArmModal
          arm={renamingArm}
          onSave={async (newName, curriculumType) => { await onRenameArm(renamingArm.id, newName, curriculumType); setRenamingArm(null); }}
          onClose={() => setRenamingArm(null)}
        />
      )}
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export default function ClassesPage() {
  const [classes, setClasses] = useState<ClassConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<{ armId: number; armName: string } | null>(null);
  const [importOpen, setImportOpen] = useState(false);

  const showToast = (msg: string, type: 'ok' | 'err') => setToast({ msg, type });

  const loadClasses = useCallback(async (silent = false) => {
    if (!silent) setLoading(true); else setRefreshing(true);
    try {
      const res = await fetch('/api/admin/classes', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) setClasses(data.classes || []);
      else showToast(data.error || 'Failed to load classes', 'err');
    } catch {
      showToast('Network error loading classes', 'err');
    } finally {
      setLoading(false); setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadClasses(); }, [loadClasses]);

  const handleAddArm = async (hierarchyClass: string, arm: string, curriculumType: string = 'STANDARD_NIGERIAN') => {
    const res = await fetch('/api/admin/classes', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ hierarchy_class: hierarchyClass, arm, curriculum_type: curriculumType }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Failed to add arm');
    showToast(`Arm "${arm}" added to ${hierarchyClass} (${curriculumType === 'ILS' ? 'ILS' : 'Standard'})`, 'ok');
    await loadClasses(true);
  };

  const handleRenameArm = async (armId: number, newName: string, curriculumType: string = 'STANDARD_NIGERIAN') => {
    const res = await fetch('/api/admin/classes/arm', {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify({ arm_id: armId, new_arm: newName, curriculum_type: curriculumType }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Failed to update arm');
    showToast(`Arm updated to "${newName}" (${curriculumType === 'ILS' ? 'ILS' : 'Standard'})`, 'ok');
    await loadClasses(true);
  };

  const handleDeleteArm = (armId: number, armName: string) => {
    setConfirmDelete({ armId, armName });
  };

  const confirmDeleteArm = async () => {
    if (!confirmDelete) return;
    try {
      const res = await fetch('/api/admin/classes/arm', {
        method: 'DELETE',
        headers: authHeaders(),
        body: JSON.stringify({ arm_id: confirmDelete.armId }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      showToast(`Arm "${confirmDelete.armName}" deleted`, 'ok');
      await loadClasses(true);
    } catch (e: unknown) {
      showToast(e instanceof Error ? e.message : 'Delete failed', 'err');
    } finally {
      setConfirmDelete(null);
    }
  };

  const handleExport = () => {
    const payload = classes.map(c => ({
      hierarchyClass: c.hierarchy_class,
      arms: c.arms.map(a => a.arm),
    }));
    const blob = new Blob([JSON.stringify({ hierarchy: payload }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'nexus_class_hierarchy.json'; a.click();
    URL.revokeObjectURL(url);
    showToast('Class hierarchy exported', 'ok');
  };

  const handleImport = async (text: string) => {
    let payload: unknown;
    try { payload = JSON.parse(text); }
    catch { throw new Error('Invalid JSON — cannot parse'); }

    let hierarchy: unknown[] = [];
    let fullList: string[] = [];

    if (Array.isArray(payload)) {
      if (payload.length > 0 && typeof payload[0] === 'string') fullList = payload as string[];
      else hierarchy = payload;
    } else if (payload && typeof payload === 'object') {
      const p = payload as Record<string, unknown>;
      if (p.hierarchy) hierarchy = p.hierarchy as unknown[];
      else if (p.fullList || p.full_list) fullList = (p.fullList || p.full_list) as string[];
    }

    const res = await fetch('/api/admin/classes/import', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ hierarchy, fullList }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Import failed');
    showToast(`Imported ${data.imported} class${data.imported !== 1 ? 'es' : ''}`, 'ok');
    setImportOpen(false);
    await loadClasses(true);
  };

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Class Hierarchy &amp; Arms" subtitle="Canonical class levels, arms, and student distribution" />

      <div className="p-6 max-w-5xl mx-auto w-full space-y-5">
        {/* Toolbar */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <p className="text-xs text-slate-400">
            {classes.length} class level{classes.length !== 1 ? 's' : ''} · {classes.reduce((s, c) => s + c.arms.length, 0)} arms total
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => loadClasses(true)}
              disabled={refreshing}
              className="p-2 rounded-xl bg-slate-800/60 border border-slate-700/60 text-slate-400 hover:text-white hover:bg-slate-700 transition-all disabled:opacity-50"
              title="Refresh"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => setImportOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800/60 border border-slate-700/60 text-slate-300 hover:text-white hover:bg-slate-700 text-xs font-bold transition-all"
            >
              <Upload className="w-3.5 h-3.5" /> Import JSON
            </button>
            <button
              onClick={handleExport}
              disabled={classes.length === 0}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-700/60 border border-slate-600/60 text-slate-200 hover:text-white hover:bg-slate-600 text-xs font-bold transition-all disabled:opacity-40"
            >
              <Download className="w-3.5 h-3.5" /> Export JSON
            </button>
          </div>
        </div>

        {/* Class list */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3 text-slate-500">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
            <p className="text-xs font-semibold">Loading class hierarchy…</p>
          </div>
        ) : classes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4 text-slate-500">
            <School className="w-12 h-12 opacity-30" />
            <p className="text-sm font-bold">No classes configured</p>
            <p className="text-xs text-slate-600 text-center max-w-sm">
              Import a JSON hierarchy from school-website or configure classes via the desktop app CSV import.
            </p>
            <button
              onClick={() => setImportOpen(true)}
              className="mt-2 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all"
            >
              <Upload className="w-3.5 h-3.5" /> Import Class Hierarchy
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {classes.map(cls => (
              <ClassCard
                key={cls.hierarchy_class}
                cls={cls}
                onAddArm={handleAddArm}
                onRenameArm={handleRenameArm}
                onDeleteArm={handleDeleteArm}
              />
            ))}
          </div>
        )}
      </div>

      {/* Modals / Overlays */}
      {confirmDelete && (
        <ConfirmDialog
          message={`Delete arm "${confirmDelete.armName}"? This removes the arm configuration. Students currently assigned to this arm are NOT deleted — they retain their class assignment.`}
          onConfirm={confirmDeleteArm}
          onCancel={() => setConfirmDelete(null)}
        />
      )}
      {importOpen && (
        <ImportModal onImport={handleImport} onClose={() => setImportOpen(false)} />
      )}
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
