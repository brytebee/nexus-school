import React from 'react';
import Header from '../components/Header';
import { School, Layers, Plus, Upload, CheckCircle2 } from 'lucide-react';

export default function ClassesPage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Class Hierarchy & Arms" subtitle="Class intake management & arm structures (Phase 7b)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <School className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Class Management Engine</h3>
              <p className="text-xs text-slate-400">Configure canonical class levels, arms (Gold, Ruby, Emerald), and capacity limits</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            This module mirrors the authoritative class hierarchy from the desktop app and cloud website, allowing local LAN admins to inspect class rosters and add arms directly.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7b Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
