import React, { useEffect, useState, useCallback, useMemo } from 'react';
import Header from '../components/Header';
import {
  Wallet, Receipt, CreditCard, CheckCircle2, DollarSign, Search, Plus, Filter,
  Download, Printer, ArrowUpRight, AlertTriangle, X, Check, Loader2, Building2,
  ChevronRight, Clock, User, FileText, Trash2, Layers, Calendar, ArrowRight,
  TrendingUp, Banknote, ShieldAlert
} from 'lucide-react';

// ── Types ─────────────────────────────────────────────────────────────────────

interface FinanceSummary {
  academic_session: string;
  term: string;
  total_billed: number;
  total_paid: number;
  total_outstanding: number;
  today_intake: number;
  today_count: number;
  status_counts: { cleared: number; partial: number; unpaid: number };
  unbilled_count: number;
  total_active_students: number;
  methods: Array<{ payment_method: string; count: number; total: number }>;
}

interface LedgerStudent {
  id: string;
  name: string;
  class_name: string;
  class_arm: string;
  admission_no: string;
  gender: string;
  parent_name: string;
  parent_phone: string;
  total_billed: number;
  total_paid: number;
  balance: number;
  status: 'cleared' | 'partial' | 'unpaid';
  next_due_date: string;
  last_payment_date: string | null;
}

interface FeeTransaction {
  id: number;
  student_id: string;
  student_name: string;
  class_name: string;
  class_arm: string;
  admission_no: string;
  academic_session: string;
  term: string;
  amount: number;
  payment_method: 'cash' | 'pos' | 'transfer' | 'bank_teller';
  reference_number: string;
  recorded_by: string;
  note: string;
  created_at: string;
  receipt_url: string | null;
}

interface FeeStructureItem {
  id: number;
  class_name: string;
  item_name: string;
  amount: number;
  term: string;
  is_optional: number;
}

interface ClassConfig {
  hierarchy_class: string;
  arms: Array<{ id: number; arm: string }>;
}

interface StudentDossier {
  student: {
    id: string;
    name: string;
    class_name: string;
    class_arm: string;
    admission_no: string;
    parent_name: string;
    parent_phone: string;
    parent_email: string;
  };
  fee: {
    total_billed: number;
    total_paid: number;
    balance: number;
    status: string;
    next_due_date: string;
  };
  transactions: FeeTransaction[];
  adjustments: Array<{
    id: number;
    adjustment_type: string;
    description: string;
    amount: number;
    approved_by: string;
    created_at: string;
  }>;
  structure: FeeStructureItem[];
  academic_session: string;
  term: string;
}

interface PrintableReceipt {
  id: number;
  reference_number: string;
  amount: number;
  payment_method: string;
  created_at: string;
  student_name: string;
  class_name: string;
  class_arm: string;
  admission_no: string;
  academic_session: string;
  term: string;
  total_billed: number;
  total_paid: number;
  balance: number;
  recorded_by: string;
  note?: string;
  school: {
    name: string;
    address: string;
    phone: string;
    motto: string;
  };
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function getToken(): string {
  return localStorage.getItem('nexus_admin_token') || '';
}

function authHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${getToken()}`,
    'Content-Type': 'application/json',
  };
}

function formatNaira(amount: number): string {
  return `₦${(amount || 0).toLocaleString('en-NG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

function formatMethod(method: string): string {
  switch (method?.toLowerCase()) {
    case 'pos': return 'POS Terminal';
    case 'transfer': return 'Bank Transfer';
    case 'bank_teller': return 'Bank Teller';
    case 'cash':
    default: return 'Cash';
  }
}

function getMethodBadge(method: string) {
  switch (method?.toLowerCase()) {
    case 'pos':
      return 'bg-purple-500/10 text-purple-300 border-purple-500/30';
    case 'transfer':
      return 'bg-sky-500/10 text-sky-300 border-sky-500/30';
    case 'bank_teller':
      return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
    case 'cash':
    default:
      return 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30';
  }
}

// ── Modals & Subcomponents ───────────────────────────────────────────────────

// 1. Record Payment Modal
function RecordPaymentModal({
  student,
  session,
  term,
  onSave,
  onClose,
}: {
  student: LedgerStudent;
  session: string;
  term: string;
  onSave: (payload: any) => Promise<any>;
  onClose: () => void;
}) {
  const [amount, setAmount] = useState<string>(student.balance > 0 ? String(student.balance) : '');
  const [method, setMethod] = useState<'cash' | 'pos' | 'transfer' | 'bank_teller'>('cash');
  const [reference, setReference] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) {
      setErr('Please enter a valid amount greater than ₦0');
      return;
    }
    setSaving(true);
    setErr('');
    try {
      await onSave({
        student_id: student.id,
        amount: num,
        payment_method: method,
        reference_number: reference.trim(),
        note: note.trim(),
      });
    } catch (e: any) {
      setErr(e.message || 'Failed to record payment');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">Record Bursary Payment</h3>
              <p className="text-[11px] text-slate-400">{session} · {term}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Student Info Card */}
        <div className="p-5 border-b border-slate-800 bg-slate-800/30">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-black text-white">{student.name}</p>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {student.admission_no || student.id} · <span className="text-emerald-400 font-bold">{student.class_name} {student.class_arm}</span>
              </p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-500 block">Current Arrears</span>
              <span className="text-base font-black text-amber-400">{formatNaira(student.balance)}</span>
            </div>
          </div>
        </div>

        <form onSubmit={handle} className="p-6 space-y-4">
          {err && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{err}</span>
            </div>
          )}

          {/* Amount Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex justify-between">
              <span>Amount to Collect (₦) *</span>
              {student.balance > 0 && (
                <button
                  type="button"
                  onClick={() => setAmount(String(student.balance))}
                  className="text-[11px] text-emerald-400 hover:underline font-normal"
                >
                  Fill full balance ({formatNaira(student.balance)})
                </button>
              )}
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-sm">₦</span>
              <input
                type="number"
                step="any"
                min="1"
                required
                autoFocus
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white font-mono text-base font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Payment Method Pills */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300">Payment Channel *</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { key: 'cash', label: 'Cash' },
                { key: 'pos', label: 'POS' },
                { key: 'transfer', label: 'Transfer' },
                { key: 'bank_teller', label: 'Teller' },
              ].map(m => (
                <button
                  key={m.key}
                  type="button"
                  onClick={() => setMethod(m.key as any)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                    method === m.key
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Reference Number */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex justify-between">
              <span>Reference Number / Receipt ID</span>
              <span className="text-[10px] text-slate-500">(Auto-generated if blank)</span>
            </label>
            <input
              type="text"
              value={reference}
              onChange={e => setReference(e.target.value)}
              placeholder="e.g. POS-98231 or BANK-TXN-492"
              className="w-full px-3.5 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Note */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300">Remarks / Note</label>
            <input
              type="text"
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="e.g. Paid by Mother (Mrs. Adeleke)"
              className="w-full px-3.5 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-800 hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-lg shadow-emerald-950/40 disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
              Complete &amp; Print Receipt
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// 2. Printable Official Receipt Modal
function ReceiptModal({
  receipt,
  onClose,
}: {
  receipt: PrintableReceipt;
  onClose: () => void;
}) {
  const handlePrint = () => {
    // Print exclusively the receipt voucher using an isolated invisible iframe.
    // This ensures neither the admin navigation, background ledger, nor modal
    // overlays are captured in the browser's print dialog.
    let iframe = document.getElementById('nexus-receipt-print-frame') as HTMLIFrameElement;
    if (!iframe) {
      iframe = document.createElement('iframe');
      iframe.id = 'nexus-receipt-print-frame';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);
    }

    const doc = iframe.contentWindow?.document;
    if (!doc) return;

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Receipt - ${receipt.reference_number}</title>
  <style>
    @page { size: portrait; margin: 10mm 15mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color: #111;
      background: #fff;
      font-size: 12px;
      line-height: 1.4;
      padding: 16px;
      max-width: 460px;
      margin: 0 auto;
    }
    .header { text-align: center; border-bottom: 1px dashed #666; padding-bottom: 12px; margin-bottom: 14px; }
    .school-name { font-size: 16px; font-weight: 900; text-transform: uppercase; letter-spacing: -0.02em; color: #000; }
    .motto { font-size: 10px; font-style: italic; color: #555; margin-top: 2px; }
    .address { font-size: 11px; color: #444; margin-top: 2px; }
    .phone { font-size: 10px; font-family: monospace; color: #555; margin-top: 1px; }
    .badge { display: inline-block; padding: 2px 10px; border: 1px solid #111; border-radius: 9999px; font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 8px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; row-gap: 8px; font-size: 11px; border-bottom: 1px dashed #666; padding-bottom: 12px; margin-bottom: 12px; }
    .right { text-align: right; }
    .label { font-size: 9px; text-transform: uppercase; font-weight: bold; color: #666; display: block; }
    .mono { font-family: monospace; }
    .bold { font-weight: bold; }
    .student-sec { border-bottom: 1px dashed #666; padding-bottom: 12px; margin-bottom: 12px; }
    .student-name { font-size: 14px; font-weight: 900; color: #000; }
    .amount-box { display: flex; justify-content: space-between; align-items: center; background: #f3f4f6; border: 1px solid #d1d5db; border-radius: 8px; padding: 8px 12px; margin-bottom: 8px; }
    .amount-val { font-size: 17px; font-weight: 900; font-family: monospace; color: #000; }
    .num-row { display: flex; justify-content: space-between; font-size: 11px; color: #444; padding: 2px 2px; }
    .bal-row { display: flex; justify-content: space-between; font-size: 12px; font-weight: bold; padding: 4px 2px 0 2px; border-top: 1px dashed #ccc; margin-top: 4px; color: #000; }
    .sigs { display: flex; justify-content: space-between; padding-top: 28px; margin-top: 14px; font-size: 10px; color: #555; }
    .sig-col { border-top: 1px solid #333; width: 110px; text-align: center; padding-top: 4px; }
    .footer { font-size: 9px; text-align: center; color: #777; font-family: monospace; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="school-name">${receipt.school?.name || 'Nexus School'}</div>
    ${receipt.school?.motto ? `<div class="motto">${receipt.school.motto}</div>` : ''}
    ${receipt.school?.address ? `<div class="address">${receipt.school.address}</div>` : ''}
    ${receipt.school?.phone ? `<div class="phone">Tel: ${receipt.school.phone}</div>` : ''}
    <div><span class="badge">Official Bursary Receipt</span></div>
  </div>

  <div class="grid">
    <div>
      <span class="label">Receipt Ref:</span>
      <span class="mono bold">${receipt.reference_number}</span>
    </div>
    <div class="right">
      <span class="label">Date &amp; Time:</span>
      <span class="mono">${new Date(receipt.created_at).toLocaleDateString()} ${new Date(receipt.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
    </div>
    <div>
      <span class="label">Session / Term:</span>
      <span class="bold">${receipt.academic_session} · ${receipt.term}</span>
    </div>
    <div class="right">
      <span class="label">Channel:</span>
      <span class="bold">${formatMethod(receipt.payment_method)}</span>
    </div>
  </div>

  <div class="student-sec">
    <span class="label">Student Received From:</span>
    <div class="student-name">${receipt.student_name}</div>
    <div style="font-size: 11px; color: #333; margin-top: 2px;">
      Adm No: <span class="mono bold">${receipt.admission_no || 'N/A'}</span> · Class: <span class="bold">${receipt.class_name} ${receipt.class_arm || ''}</span>
    </div>
    ${receipt.note ? `<div style="font-size: 10px; font-style: italic; color: #555; margin-top: 3px;">Note: ${receipt.note}</div>` : ''}
  </div>

  <div style="border-bottom: 1px dashed #666; padding-bottom: 12px; margin-bottom: 12px;">
    <div class="amount-box">
      <span style="font-size: 11px; font-weight: bold; color: #111;">AMOUNT PAID:</span>
      <span class="amount-val">${formatNaira(receipt.amount)}</span>
    </div>
    <div class="num-row">
      <span>Total Term Billing:</span>
      <span class="mono">${formatNaira(receipt.total_billed)}</span>
    </div>
    <div class="num-row">
      <span>Cumulative Paid:</span>
      <span class="mono">${formatNaira(receipt.total_paid)}</span>
    </div>
    <div class="bal-row">
      <span>Balance Remaining:</span>
      <span class="mono">${formatNaira(receipt.balance)}</span>
    </div>
  </div>

  <div class="sigs">
    <div class="sig-col">Bursar Signature</div>
    <div class="sig-col">School Stamp</div>
  </div>

  <div class="footer">
    Generated by Nexus Sovereign OS · Offline cryptographic verification voucher
  </div>
</body>
</html>`;

    doc.open();
    doc.write(html);
    doc.close();

    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 print:p-0 print:bg-white print:static">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col print:border-none print:shadow-none print:w-full print:max-w-none print:bg-white">
        {/* Screen Controls */}
        <div className="px-6 py-3 border-b border-slate-800 bg-slate-850 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-white text-xs">Official Payment Voucher</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Receipt Voucher Body (Thermal & Standard print ready) */}
        <div id="nexus-receipt-modal-body" className="p-8 space-y-6 text-slate-100 print:text-black print:p-4 print:font-sans">
          {/* School Header */}
          <div className="text-center space-y-1 border-b border-dashed border-slate-700 pb-5 print:border-black">
            <h2 className="text-lg font-black tracking-tight uppercase text-white print:text-black">
              {receipt.school?.name || 'Nexus School'}
            </h2>
            {receipt.school?.motto && (
              <p className="text-[10px] text-slate-400 italic print:text-gray-600">{receipt.school.motto}</p>
            )}
            {receipt.school?.address && (
              <p className="text-[11px] text-slate-400 print:text-gray-700">{receipt.school.address}</p>
            )}
            {receipt.school?.phone && (
              <p className="text-[10px] text-slate-500 font-mono print:text-gray-700">Tel: {receipt.school.phone}</p>
            )}
            <div className="pt-2">
              <span className="inline-block px-3 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 print:border-black print:text-black">
                Official Bursary Receipt
              </span>
            </div>
          </div>

          {/* Reference & Metadata Grid */}
          <div className="grid grid-cols-2 gap-y-2 text-xs border-b border-dashed border-slate-700 pb-4 print:border-black print:text-xs">
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold print:text-gray-600">Receipt Ref:</span>
              <span className="font-mono font-bold text-white print:text-black">{receipt.reference_number}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase font-bold print:text-gray-600">Date &amp; Time:</span>
              <span className="font-mono text-slate-300 print:text-gray-800">
                {new Date(receipt.created_at).toLocaleDateString()} {new Date(receipt.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-bold print:text-gray-600">Session / Term:</span>
              <span className="font-medium text-slate-200 print:text-gray-900">{receipt.academic_session} · {receipt.term}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase font-bold print:text-gray-600">Channel:</span>
              <span className="font-bold text-emerald-400 print:text-black">{formatMethod(receipt.payment_method)}</span>
            </div>
          </div>

          {/* Student Dossier */}
          <div className="space-y-1.5 border-b border-dashed border-slate-700 pb-4 print:border-black text-xs">
            <span className="text-slate-500 block text-[10px] uppercase font-bold print:text-gray-600">Student Received From:</span>
            <p className="text-sm font-black text-white print:text-black">{receipt.student_name}</p>
            <p className="text-[11px] text-slate-300 print:text-gray-800">
              Adm No: <span className="font-mono font-bold">{receipt.admission_no || 'N/A'}</span> · Class: <span className="font-bold">{receipt.class_name} {receipt.class_arm}</span>
            </p>
            {receipt.note && (
              <p className="text-[11px] text-slate-400 italic pt-1 print:text-gray-600">Note: {receipt.note}</p>
            )}
          </div>

          {/* Ledger Numbers */}
          <div className="space-y-2 border-b border-dashed border-slate-700 pb-4 print:border-black">
            <div className="flex justify-between items-center py-2 px-3 rounded-xl bg-slate-800/80 border border-slate-700/60 print:bg-gray-100 print:border-gray-300">
              <span className="text-xs font-bold text-slate-300 print:text-black">AMOUNT PAID:</span>
              <span className="text-lg font-black text-emerald-400 font-mono print:text-black">
                {formatNaira(receipt.amount)}
              </span>
            </div>
            <div className="flex justify-between text-xs text-slate-400 px-1 pt-1 print:text-gray-700">
              <span>Total Term Billing:</span>
              <span className="font-mono">{formatNaira(receipt.total_billed)}</span>
            </div>
            <div className="flex justify-between text-xs text-slate-400 px-1 print:text-gray-700">
              <span>Cumulative Paid:</span>
              <span className="font-mono">{formatNaira(receipt.total_paid)}</span>
            </div>
            <div className="flex justify-between text-xs font-bold px-1 pt-1">
              <span className="text-slate-300 print:text-black">Balance Remaining:</span>
              <span className={`font-mono ${receipt.balance <= 0 ? 'text-emerald-400' : 'text-amber-400'} print:text-black`}>
                {formatNaira(receipt.balance)}
              </span>
            </div>
          </div>

          {/* Signature & Verification Footnote */}
          <div className="pt-2 text-center space-y-3">
            <div className="flex justify-between text-[10px] text-slate-400 print:text-gray-600 pt-6">
              <div className="border-t border-slate-700 print:border-black w-28 pt-1">
                Bursar Signature
              </div>
              <div className="border-t border-slate-700 print:border-black w-28 pt-1">
                School Stamp
              </div>
            </div>
            <p className="text-[9px] text-slate-500 font-mono pt-2 print:text-gray-500">
              Generated by Nexus Sovereign OS · Offline cryptographic verification voucher
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// 3. Student Full Fee Dossier Slide-over Drawer
function StudentFeeDossierDrawer({
  studentId,
  onClose,
  onRecordPayment,
  onViewReceipt,
}: {
  studentId: string;
  onClose: () => void;
  onRecordPayment: (st: LedgerStudent) => void;
  onViewReceipt: (txId: number) => void;
}) {
  const [data, setData] = useState<StudentDossier | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/admin/finance/ledger/${studentId}`, { headers: authHeaders() })
      .then(r => r.json())
      .then(resp => {
        if (resp.ok) setData(resp);
      })
      .finally(() => setLoading(false));
  }, [studentId]);

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-xl bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base">Student Fee Dossier</h3>
              <p className="text-xs text-slate-400 font-mono">
                {data?.academic_session || '2026/2027'} · {data?.term || 'First Term'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-emerald-400" />
          </div>
        ) : !data ? (
          <div className="p-6 text-center text-slate-400 text-xs">Failed to load student fee ledger.</div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Student Profile Overview */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 flex items-center justify-between">
              <div>
                <h4 className="font-black text-white text-base">{data.student.name}</h4>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  {data.student.admission_no || data.student.id} · <span className="text-emerald-400 font-bold">{data.student.class_name} {data.student.class_arm}</span>
                </p>
                {data.student.parent_phone && (
                  <p className="text-[11px] text-slate-400 mt-1">
                    Guardian: {data.student.parent_name || 'Parent'} ({data.student.parent_phone})
                  </p>
                )}
              </div>
              <button
                onClick={() => {
                  onClose();
                  onRecordPayment({
                    ...data.student,
                    total_billed: data.fee.total_billed,
                    total_paid: data.fee.total_paid,
                    balance: data.fee.balance,
                    status: data.fee.status as any,
                    next_due_date: data.fee.next_due_date,
                    last_payment_date: null,
                    gender: 'Male',
                  });
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/40"
              >
                <Plus className="w-3.5 h-3.5" />
                Record Pay
              </button>
            </div>

            {/* Balances Card */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Total Billed</span>
                <span className="text-base font-black text-white mt-1 block font-mono">{formatNaira(data.fee.total_billed)}</span>
              </div>
              <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Total Paid</span>
                <span className="text-base font-black text-emerald-400 mt-1 block font-mono">{formatNaira(data.fee.total_paid)}</span>
              </div>
              <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Balance Owed</span>
                <span className={`text-base font-black mt-1 block font-mono ${data.fee.balance <= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {formatNaira(data.fee.balance)}
                </span>
              </div>
            </div>

            {/* Applicable Fee Items Breakdown */}
            <div className="space-y-3">
              <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-emerald-400" /> Applicable Term Fee Items
              </h5>
              <div className="rounded-xl border border-slate-700/60 overflow-hidden bg-slate-800/20">
                {data.structure.length === 0 ? (
                  <p className="p-4 text-xs text-slate-500 text-center">No fee structure configured for this class level.</p>
                ) : (
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-800/60 text-slate-400 font-bold border-b border-slate-700/60">
                      <tr>
                        <th className="py-2 px-3">Item Description</th>
                        <th className="py-2 px-3 text-right">Amount</th>
                        <th className="py-2 px-3 text-center">Type</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {data.structure.map(it => (
                        <tr key={it.id} className="hover:bg-slate-800/30">
                          <td className="py-2 px-3 font-medium text-slate-200">{it.item_name}</td>
                          <td className="py-2 px-3 text-right font-mono text-white">{formatNaira(it.amount)}</td>
                          <td className="py-2 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${it.is_optional ? 'bg-slate-700 text-slate-300' : 'bg-emerald-500/10 text-emerald-400'}`}>
                              {it.is_optional ? 'Optional' : 'Compulsory'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>

            {/* Transaction Journal */}
            <div className="space-y-3">
              <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-sky-400" /> Payment &amp; Receipt History
              </h5>
              {data.transactions.length === 0 ? (
                <div className="p-5 rounded-xl border border-slate-800 text-center text-xs text-slate-500">
                  No payment transactions recorded yet.
                </div>
              ) : (
                <div className="space-y-2">
                  {data.transactions.map(tx => (
                    <div
                      key={tx.id}
                      className="p-3.5 rounded-xl bg-slate-800/30 border border-slate-750 hover:border-slate-700 flex items-center justify-between transition-all"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-white">{formatNaira(tx.amount)}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getMethodBadge(tx.payment_method)}`}>
                            {formatMethod(tx.payment_method)}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono">
                          Ref: <span className="text-slate-300">{tx.reference_number}</span> · {new Date(tx.created_at).toLocaleDateString()}
                        </p>
                        {tx.note && <p className="text-[10px] text-slate-500 italic">Note: {tx.note}</p>}
                      </div>
                      <button
                        onClick={() => onViewReceipt(tx.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold"
                      >
                        <Printer className="w-3.5 h-3.5 text-emerald-400" />
                        Receipt
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// 4. Add Fee Structure Modal
function AddFeeItemModal({
  classes,
  onSave,
  onClose,
}: {
  classes: ClassConfig[];
  onSave: (payload: any) => Promise<void>;
  onClose: () => void;
}) {
  const [className, setClassName] = useState(classes[0]?.hierarchy_class || 'JSS 1');
  const currentClassObj = classes.find(c => c.hierarchy_class === className);
  const currentArms = currentClassObj?.arms || [];
  const [targetArm, setTargetArm] = useState('ALL');

  const [itemName, setItemName] = useState('');
  const [amount, setAmount] = useState('');
  const [term, setTerm] = useState('All Terms');
  const [isOptional, setIsOptional] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) { setErr('Item name is required'); return; }
    const num = parseFloat(amount);
    if (isNaN(num) || num < 0) { setErr('Valid amount is required'); return; }
    setSaving(true);
    setErr('');
    try {
      await onSave({
        class_name: targetArm === 'ALL' ? className : `${className} ${targetArm}`,
        apply_to_all_arms: targetArm === 'ALL',
        item_name: itemName.trim(),
        amount: num,
        term,
        is_optional: isOptional ? 1 : 0,
      });
    } catch (e: any) {
      setErr(e.message || 'Failed to save fee structure');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-white text-sm">Add Class Fee Item</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        {err && <p className="text-xs text-rose-400 p-2 rounded bg-rose-500/10 border border-rose-500/20">{err}</p>}

        <form onSubmit={handle} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-slate-300 font-bold">Class Level *</label>
            <select
              value={className}
              onChange={e => {
                setClassName(e.target.value);
                setTargetArm('ALL');
              }}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-none focus:border-emerald-500"
            >
              {classes.map(c => (
                <option key={c.hierarchy_class} value={c.hierarchy_class}>{c.hierarchy_class}</option>
              ))}
            </select>
          </div>

          {currentArms.length > 0 && (
            <div className="space-y-1">
              <label className="text-slate-300 font-bold">Target Arm / Track</label>
              <select
                value={targetArm}
                onChange={e => setTargetArm(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-none focus:border-emerald-500"
              >
                <option value="ALL">All Arms (Entire Class Level)</option>
                {currentArms.map(arm => (
                  <option key={arm} value={arm}>{arm} Arm</option>
                ))}
              </select>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-slate-300 font-bold">Fee Item Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. Tuition, PTA Levy, ICT Laboratory"
              value={itemName}
              onChange={e => setItemName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-bold">Amount (₦) *</label>
            <input
              type="number"
              step="any"
              min="0"
              required
              placeholder="e.g. 45000"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-bold">Term Applicability</label>
            <select
              value={term}
              onChange={e => setTerm(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-none focus:border-emerald-500"
            >
              <option value="All Terms">All Terms (Every Term)</option>
              <option value="First Term">First Term Only</option>
              <option value="Second Term">Second Term Only</option>
              <option value="Third Term">Third Term Only</option>
            </select>
          </div>

          <label className="flex items-center gap-2 pt-1 cursor-pointer">
            <input
              type="checkbox"
              checked={isOptional}
              onChange={e => setIsOptional(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-0"
            />
            <span className="text-slate-300 font-medium">Optional Levy (Exclude from automatic billing)</span>
          </label>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button type="button" onClick={onClose} className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700">Cancel</button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
              Save Fee Item
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// 5. Batch Apply Bills Modal
function ApplyBillsModal({
  classes,
  onApply,
  onClose,
}: {
  classes: ClassConfig[];
  onApply: (scope: 'all' | 'class', targetClass?: string) => Promise<any>;
  onClose: () => void;
}) {
  const [scope, setScope] = useState<'all' | 'class'>('all');
  const [selectedClass, setSelectedClass] = useState(classes[0]?.hierarchy_class || 'JSS 1');
  const [confirmed, setConfirmed] = useState(false);
  const [saving, setSaving] = useState(false);
  const [resMsg, setResMsg] = useState('');

  const handle = async () => {
    if (!confirmed) return;
    setSaving(true);
    try {
      const res = await onApply(scope, scope === 'class' ? selectedClass : undefined);
      setResMsg(`Successfully billed ${res.billed_count} students.`);
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (e: any) {
      setResMsg(e.message || 'Failed to apply billing.');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4">
        <div className="flex items-center gap-2.5 text-amber-400">
          <ShieldAlert className="w-5 h-5" />
          <h3 className="font-bold text-white text-sm">Batch Generate Term Invoices</h3>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          This will calculate the mandatory fee structure items and assign invoice totals to enrolled active students for the active academic term.
        </p>

        {resMsg ? (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center font-bold">
            {resMsg}
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <div className="space-y-2">
              <label className="text-slate-300 font-bold block">Scope</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setScope('all')}
                  className={`flex-1 py-2 rounded-xl font-bold border transition-all ${scope === 'all' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
                >
                  All Campus Students
                </button>
                <button
                  type="button"
                  onClick={() => setScope('class')}
                  className={`flex-1 py-2 rounded-xl font-bold border transition-all ${scope === 'class' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
                >
                  Specific Class
                </button>
              </div>
            </div>

            {scope === 'class' && (
              <div className="space-y-1">
                <label className="text-slate-300 font-bold">Select Target Class</label>
                <select
                  value={selectedClass}
                  onChange={e => setSelectedClass(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-none"
                >
                  {classes.map(c => (
                    <option key={c.hierarchy_class} value={c.hierarchy_class}>{c.hierarchy_class}</option>
                  ))}
                </select>
              </div>
            )}

            <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 cursor-pointer">
              <input
                type="checkbox"
                checked={confirmed}
                onChange={e => setConfirmed(e.target.checked)}
                className="rounded bg-slate-800 border-slate-600 text-emerald-500 focus:ring-0"
              />
              <span className="text-[11px] text-slate-200">
                I understand this will update fee balances for enrolled students.
              </span>
            </label>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button onClick={onClose} className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700">Cancel</button>
              <button
                onClick={handle}
                disabled={!confirmed || saving}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold disabled:opacity-40"
              >
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                Generate Invoices
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main Page Component ────────────────────────────────────────────────────────

export default function FinancePage() {
  const [activeTab, setActiveTab] = useState<'ledger' | 'audit' | 'structures'>('ledger');
  const [summary, setSummary] = useState<FinanceSummary | null>(null);
  const [classes, setClasses] = useState<ClassConfig[]>([]);

  // Tab 1 (Ledger) State
  const [students, setStudents] = useState<LedgerStudent[]>([]);
  const [totalStudents, setTotalStudents] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [search, setSearch] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedArm, setSelectedArm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'cleared' | 'partial' | 'unpaid'>('all');

  // Tab 2 (Audit) State
  const [transactions, setTransactions] = useState<FeeTransaction[]>([]);
  const [txTotal, setTxTotal] = useState(0);
  const [txPage, setTxPage] = useState(1);
  const [txPages, setTxPages] = useState(1);
  const [txMethod, setTxMethod] = useState('all');
  const [txSearch, setTxSearch] = useState('');

  // Tab 3 (Structures) State
  const [structures, setStructures] = useState<FeeStructureItem[]>([]);

  // Loading & Modals
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [payStudent, setPayStudent] = useState<LedgerStudent | null>(null);
  const [dossierStudentId, setDossierStudentId] = useState<string | null>(null);
  const [receiptData, setReceiptData] = useState<PrintableReceipt | null>(null);
  const [addStructureOpen, setAddStructureOpen] = useState(false);
  const [applyBillsOpen, setApplyBillsOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);

  const showToast = (msg: string, type: 'ok' | 'err' = 'ok') => {
    setToastMsg({ msg, type });
    setTimeout(() => setToastMsg(null), 4000);
  };

  // ── Data Fetching ────────────────────────────────────────────────────────────

  const loadSummary = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/finance/summary', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) setSummary(data);
    } catch (_) {}
  }, []);

  const loadClasses = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/classes', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) setClasses(data.classes || []);
    } catch (_) {}
  }, []);

  const loadLedger = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    try {
      const params = new URLSearchParams();
      params.set('page', String(page));
      params.set('limit', '50');
      if (selectedClass) params.set('class', selectedClass);
      if (selectedArm) params.set('arm', selectedArm);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (search.trim()) params.set('q', search.trim());

      const res = await fetch(`/api/admin/finance/ledger?${params.toString()}`, { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) {
        setStudents(data.students || []);
        setTotalStudents(data.total || 0);
        setPages(data.pages || 1);
      }
    } catch {
      showToast('Error loading finance ledger', 'err');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [page, selectedClass, selectedArm, statusFilter, search]);

  const loadTransactions = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      params.set('page', String(txPage));
      params.set('limit', '50');
      if (txMethod !== 'all') params.set('method', txMethod);
      if (txSearch.trim()) params.set('q', txSearch.trim());

      const res = await fetch(`/api/admin/finance/transactions?${params.toString()}`, { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) {
        setTransactions(data.transactions || []);
        setTxTotal(data.total || 0);
        setTxPages(data.pages || 1);
      }
    } catch (_) {}
  }, [txPage, txMethod, txSearch]);

  const loadStructures = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/finance/structures', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) {
        setStructures(data.structures || []);
      }
    } catch (_) {}
  }, []);

  // Initial load
  useEffect(() => {
    loadSummary();
    loadClasses();
  }, [loadSummary, loadClasses]);

  // Tab reactive load
  useEffect(() => {
    if (activeTab === 'ledger') loadLedger();
    else if (activeTab === 'audit') loadTransactions();
    else if (activeTab === 'structures') loadStructures();
  }, [activeTab, loadLedger, loadTransactions, loadStructures]);

  // Derived arms for class filter
  const filterArms = useMemo(() => {
    if (!selectedClass) return [];
    return classes.find(c => c.hierarchy_class === selectedClass)?.arms || [];
  }, [classes, selectedClass]);

  // Record Payment Submit Handler
  const handleRecordPayment = async (payload: any) => {
    const res = await fetch('/api/admin/finance/payments', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Payment failed');

    showToast(`Payment of ${formatNaira(payload.amount)} recorded successfully!`, 'ok');
    setPayStudent(null);

    // Fetch full printable receipt
    const rRes = await fetch(`/api/admin/finance/receipt/${data.receipt.transaction_id}`, { headers: authHeaders() });
    const rData = await rRes.json();
    if (rData.ok) {
      setReceiptData(rData.receipt);
    }

    loadSummary();
    loadLedger(true);
  };

  // View Receipt Handler
  const handleOpenReceipt = async (txId: number) => {
    try {
      const res = await fetch(`/api/admin/finance/receipt/${txId}`, { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) setReceiptData(data.receipt);
      else showToast('Receipt not found', 'err');
    } catch {
      showToast('Error loading receipt', 'err');
    }
  };

  // Delete Fee Item Handler (single ID or batch of IDs across arms)
  const handleDeleteStructure = async (ids: number | number[]) => {
    const idArray = Array.isArray(ids) ? ids : [ids];
    try {
      await Promise.all(
        idArray.map(id =>
          fetch(`/api/admin/finance/structures/${id}`, {
            method: 'DELETE',
            headers: authHeaders(),
          })
        )
      );
      showToast(idArray.length > 1 ? 'Fee items removed' : 'Fee item removed');
      loadStructures();
    } catch (_) {
      showToast('Error removing fee item', 'err');
    }
  };

  // Export Arrears CSV
  const handleExportCSV = () => {
    if (students.length === 0) return;
    const headers = ['Student ID', 'Student Name', 'Class', 'Arm', 'Admission No', 'Total Billed (NGN)', 'Total Paid (NGN)', 'Balance (NGN)', 'Status', 'Guardian Phone'];
    const rows = students.map(s => [
      `"${s.id}"`,
      `"${s.name}"`,
      `"${s.class_name}"`,
      `"${s.class_arm || ''}"`,
      `"${s.admission_no || ''}"`,
      s.total_billed,
      s.total_paid,
      s.balance,
      `"${s.status}"`,
      `"${s.parent_phone || ''}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `bursary_arrears_${summary?.academic_session.replace('/', '_')}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported arrears report successfully');
  };

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header
        title="Finance & Bursary"
        subtitle="Tuition billing ledger, offline receipting & payment settlement"
        academicSession={summary?.academic_session || '2026/2027'}
        term={summary?.term || 'First Term'}
        onRefresh={() => {
          loadSummary();
          if (activeTab === 'ledger') loadLedger(true);
          else if (activeTab === 'audit') loadTransactions();
          else loadStructures();
        }}
        refreshing={refreshing}
      />

      {/* Toast */}
      {toastMsg && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl shadow-2xl text-xs font-bold border ${
          toastMsg.type === 'ok' ? 'bg-emerald-900/90 border-emerald-600 text-emerald-200' : 'bg-rose-900/90 border-rose-600 text-rose-200'
        }`}>
          {toastMsg.type === 'ok' ? <Check className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-rose-400" />}
          {toastMsg.msg}
        </div>
      )}

      <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Billed</span>
              <p className="text-xl font-black text-white font-mono">{formatNaira(summary?.total_billed || 0)}</p>
              <span className="text-[10px] text-slate-500 font-medium">Active Term Enrolled</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400">
              <FileText className="w-5 h-5 text-slate-300" />
            </div>
          </div>

          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Collected</span>
              <p className="text-xl font-black text-emerald-400 font-mono">{formatNaira(summary?.total_paid || 0)}</p>
              <span className="text-[10px] text-emerald-500 font-medium font-mono">
                {summary?.status_counts.cleared || 0} students cleared
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Outstanding Arrears</span>
              <p className="text-xl font-black text-amber-400 font-mono">{formatNaira(summary?.total_outstanding || 0)}</p>
              <span className="text-[10px] text-amber-500 font-medium font-mono">
                {(summary?.status_counts.partial || 0) + (summary?.status_counts.unpaid || 0)} owing balances
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Today's Collections</span>
              <p className="text-xl font-black text-sky-400 font-mono">{formatNaira(summary?.today_intake || 0)}</p>
              <span className="text-[10px] text-slate-400 font-medium">
                {summary?.today_count || 0} vouchers issued today
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
              <Banknote className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('ledger')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'ledger'
                ? 'bg-slate-800 border border-slate-700 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <Wallet className="w-4 h-4 text-emerald-400" />
            Student Fee Ledger
            <span className="px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-[10px]">
              {totalStudents}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'audit'
                ? 'bg-slate-800 border border-slate-700 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <Clock className="w-4 h-4 text-sky-400" />
            Payment Audit Journal &amp; Receipts
            <span className="px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-[10px]">
              {txTotal}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('structures')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'structures'
                ? 'bg-slate-800 border border-slate-700 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <Layers className="w-4 h-4 text-purple-400" />
            Class Fee Structures
          </button>
        </div>

        {/* ── TAB 1: STUDENT FEE LEDGER ─────────────────────────────────────── */}
        {activeTab === 'ledger' && (
          <div className="space-y-4">
            {/* Filter Toolbar */}
            <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
              <div className="flex flex-wrap items-center gap-2.5 flex-1">
                {/* Search */}
                <div className="relative min-w-[200px] flex-1 max-w-xs">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Search student, adm no, phone..."
                    value={search}
                    onChange={e => { setSearch(e.target.value); setPage(1); }}
                    className="w-full bg-slate-800/80 border border-slate-700/70 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Class Filter */}
                <select
                  value={selectedClass}
                  onChange={e => { setSelectedClass(e.target.value); setSelectedArm(''); setPage(1); }}
                  className="bg-slate-800/80 border border-slate-700/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="">All Classes</option>
                  {classes.map(c => (
                    <option key={c.hierarchy_class} value={c.hierarchy_class}>{c.hierarchy_class}</option>
                  ))}
                </select>

                {/* Arm Filter */}
                {filterArms.length > 0 && (
                  <select
                    value={selectedArm}
                    onChange={e => { setSelectedArm(e.target.value); setPage(1); }}
                    className="bg-slate-800/80 border border-slate-700/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="">All Arms</option>
                    {filterArms.map(a => (
                      <option key={a.id} value={a.arm}>{a.arm}</option>
                    ))}
                  </select>
                )}

                {/* Status Chips */}
                <div className="flex rounded-xl overflow-hidden border border-slate-700/60 bg-slate-800/40 p-0.5">
                  {(['all', 'cleared', 'partial', 'unpaid'] as const).map(s => (
                    <button
                      key={s}
                      onClick={() => { setStatusFilter(s); setPage(1); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all ${
                        statusFilter === s ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {s === 'all' ? 'All Ledger' : s === 'cleared' ? 'Cleared' : s === 'partial' ? 'Partial' : 'Owing'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleExportCSV}
                  disabled={students.length === 0}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 hover:text-white text-xs font-bold transition-all disabled:opacity-40"
                  title="Download Arrears CSV"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  Arrears CSV
                </button>
                <button
                  onClick={() => setApplyBillsOpen(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-bold transition-all shadow"
                >
                  <Layers className="w-3.5 h-3.5 text-purple-400" />
                  Apply Billing
                </button>
              </div>
            </div>

            {/* Ledger Table */}
            <div className="rounded-2xl border border-slate-700/60 bg-slate-800/30 overflow-hidden shadow-xl">
              {loading ? (
                <div className="p-16 flex items-center justify-center gap-3 text-slate-400 text-xs">
                  <Loader2 className="w-5 h-5 animate-spin text-emerald-400" />
                  Loading student fee ledgers...
                </div>
              ) : students.length === 0 ? (
                <div className="p-16 text-center space-y-2">
                  <Wallet className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-slate-400 font-bold text-sm">No student fee records found</p>
                  <p className="text-slate-500 text-xs">Try adjusting your search filters or click "Apply Billing" to generate invoices.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-700/80 bg-slate-850/60 text-slate-400 font-bold tracking-wider uppercase text-[10px]">
                        <th className="py-3 px-4">Student</th>
                        <th className="py-3 px-4">Class</th>
                        <th className="py-3 px-4 text-right">Billed</th>
                        <th className="py-3 px-4 text-right">Paid</th>
                        <th className="py-3 px-4 text-right">Balance</th>
                        <th className="py-3 px-4 text-center">Status</th>
                        <th className="py-3 px-4 text-right">Quick Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {students.map(s => (
                        <tr key={s.id} className="hover:bg-slate-800/40 transition-colors group">
                          {/* Student Info */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-[11px] text-slate-300 shrink-0">
                                {s.name.slice(0, 2).toUpperCase()}
                              </div>
                              <div>
                                <span className="font-bold text-white text-sm block group-hover:text-emerald-300 transition-colors">
                                  {s.name}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  {s.admission_no || s.id}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Class & Arm */}
                          <td className="py-3 px-4">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-200 text-[11px] font-bold">
                              {s.class_name} {s.class_arm && <span className="text-emerald-400">{s.class_arm}</span>}
                            </span>
                          </td>

                          {/* Billed */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-200">
                            {formatNaira(s.total_billed)}
                          </td>

                          {/* Paid */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                            {formatNaira(s.total_paid)}
                          </td>

                          {/* Balance */}
                          <td className="py-3 px-4 text-right font-mono font-bold">
                            <span className={s.balance <= 0 ? 'text-emerald-400' : 'text-amber-400'}>
                              {formatNaira(s.balance)}
                            </span>
                          </td>

                          {/* Status Badge */}
                          <td className="py-3 px-4 text-center">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              s.status === 'cleared'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : s.status === 'partial'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                s.status === 'cleared' ? 'bg-emerald-400' : s.status === 'partial' ? 'bg-amber-400' : 'bg-rose-400'
                              }`} />
                              {s.status === 'cleared' ? 'Cleared' : s.status === 'partial' ? 'Partial' : 'Paid ₦0'}
                            </span>
                          </td>

                          {/* Quick Actions */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setPayStudent(s)}
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-[11px] transition-all shadow"
                                title="Collect & Record Payment"
                              >
                                <CreditCard className="w-3.5 h-3.5" />
                                Pay
                              </button>
                              <button
                                onClick={() => setDossierStudentId(s.id)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition-colors"
                                title="View Complete Ledger Dossier"
                              >
                                <FileText className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Pagination */}
              {pages > 1 && (
                <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span>Page {page} of {pages} ({totalStudents} records)</span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => setPage(p => Math.max(1, p - 1))}
                      disabled={page === 1}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 disabled:opacity-40"
                    >
                      Prev
                    </button>
                    <button
                      onClick={() => setPage(p => Math.min(pages, p + 1))}
                      disabled={page === pages}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 disabled:opacity-40"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB 2: PAYMENT AUDIT JOURNAL ─────────────────────────────────── */}
        {activeTab === 'audit' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 flex-1 max-w-lg">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Search receipt ref, student name, remarks..."
                    value={txSearch}
                    onChange={e => { setTxSearch(e.target.value); setTxPage(1); }}
                    className="w-full bg-slate-800/80 border border-slate-700/70 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <select
                  value={txMethod}
                  onChange={e => { setTxMethod(e.target.value); setTxPage(1); }}
                  className="bg-slate-800/80 border border-slate-700/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">All Channels</option>
                  <option value="cash">Cash</option>
                  <option value="pos">POS</option>
                  <option value="transfer">Transfer</option>
                  <option value="bank_teller">Bank Teller</option>
                </select>
              </div>

              <span className="text-xs text-slate-400 font-mono">
                {txTotal} transactions recorded in total
              </span>
            </div>

            <div className="rounded-2xl border border-slate-700/60 bg-slate-800/30 overflow-hidden shadow-xl">
              {transactions.length === 0 ? (
                <div className="p-16 text-center text-slate-500 text-xs">No transactions match your query.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-700/80 bg-slate-850/60 text-slate-400 font-bold uppercase text-[10px]">
                        <th className="py-3 px-4">Receipt Ref</th>
                        <th className="py-3 px-4">Student</th>
                        <th className="py-3 px-4">Class</th>
                        <th className="py-3 px-4 text-right">Amount</th>
                        <th className="py-3 px-4 text-center">Channel</th>
                        <th className="py-3 px-4">Date / Time</th>
                        <th className="py-3 px-4">Cashier</th>
                        <th className="py-3 px-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {transactions.map(tx => (
                        <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-white text-xs">{tx.reference_number}</td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-white block">{tx.student_name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{tx.admission_no}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-slate-300 font-medium">{tx.class_name} {tx.class_arm}</span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                            {formatNaira(tx.amount)}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getMethodBadge(tx.payment_method)}`}>
                              {formatMethod(tx.payment_method)}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                            {new Date(tx.created_at).toLocaleDateString()} {new Date(tx.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-xs">{tx.recorded_by}</td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={() => handleOpenReceipt(tx.id)}
                              className="flex items-center gap-1 ml-auto px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold transition-all"
                            >
                              <Printer className="w-3 h-3 text-emerald-400" />
                              Receipt
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB 3: CLASS FEE STRUCTURES ──────────────────────────────────── */}
        {activeTab === 'structures' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white text-sm">Class Tuition &amp; Fee Items</h3>
                <p className="text-xs text-slate-400">Configure itemized compulsory and optional fees per class level</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setAddStructureOpen(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40"
                >
                  <Plus className="w-4 h-4" />
                  Add Fee Item
                </button>
              </div>
            </div>

            {/* Grid of Class Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {classes.map(c => {
                const hc = c.hierarchy_class;
                const matching = structures.filter(s =>
                  s.class_name === hc ||
                  s.class_name.startsWith(hc + ' ') ||
                  s.class_name.startsWith(hc + '-')
                );

                // Group items by item_name + term to deduplicate across arms
                const groupedMap = new Map<string, {
                  ids: number[];
                  item_name: string;
                  amount: number;
                  term: string;
                  is_optional: number;
                  arms: string[];
                }>();

                matching.forEach(s => {
                  const key = `${s.item_name}|${s.term}`;
                  let armName = '';
                  if (s.class_name !== hc && s.class_name.startsWith(hc)) {
                    armName = s.class_name.slice(hc.length).trim().replace(/^[-–—]\s*/, '');
                  }

                  const existing = groupedMap.get(key);
                  if (existing) {
                    existing.ids.push(s.id);
                    if (armName && !existing.arms.includes(armName)) {
                      existing.arms.push(armName);
                    }
                  } else {
                    groupedMap.set(key, {
                      ids: [s.id],
                      item_name: s.item_name,
                      amount: s.amount,
                      term: s.term,
                      is_optional: s.is_optional,
                      arms: armName ? [armName] : [],
                    });
                  }
                });

                const classItems = Array.from(groupedMap.values());

                // Calculate Term Invoice: Mandatory fee total per arm
                const armTotals: number[] = [];
                if (c.arms && c.arms.length > 0) {
                  c.arms.forEach(arm => {
                    const armComposite = `${hc} ${arm}`.toLowerCase();
                    let total = 0;
                    matching.forEach(s => {
                      if (s.is_optional) return;
                      const sLower = s.class_name.toLowerCase();
                      if (sLower === hc.toLowerCase() || sLower === armComposite) {
                        total += s.amount;
                      }
                    });
                    armTotals.push(total);
                  });
                } else {
                  let total = 0;
                  matching.forEach(s => {
                    if (!s.is_optional) total += s.amount;
                  });
                  armTotals.push(total);
                }

                const minBill = armTotals.length > 0 ? Math.min(...armTotals) : 0;
                const maxBill = armTotals.length > 0 ? Math.max(...armTotals) : 0;
                const invoiceLabel = minBill === 0 && maxBill === 0
                  ? formatNaira(0)
                  : minBill === maxBill
                    ? formatNaira(minBill)
                    : `${formatNaira(minBill)} – ${formatNaira(maxBill)}`;

                return (
                  <div key={c.hierarchy_class} className="rounded-2xl border border-slate-700/60 bg-slate-800/40 overflow-hidden shadow-xl flex flex-col">
                    <div className="p-4 border-b border-slate-800 bg-slate-850 flex items-center justify-between">
                      <div>
                        <h4 className="font-black text-white text-sm">{c.hierarchy_class}</h4>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {classItems.length} fee item{classItems.length === 1 ? '' : 's'}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Term Invoice</span>
                        <span className="text-sm font-black text-emerald-400 font-mono">{invoiceLabel}</span>
                      </div>
                    </div>

                    <div className="p-4 flex-1 space-y-2">
                      {classItems.length === 0 ? (
                        <p className="p-6 text-xs text-slate-500 text-center italic">No fee items configured</p>
                      ) : (
                        classItems.map(it => {
                          const isArmSpecific = it.arms.length > 0 && c.arms && it.arms.length < c.arms.length;
                          return (
                            <div
                              key={it.ids[0]}
                              className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-750 flex items-center justify-between text-xs"
                            >
                              <div className="min-w-0 pr-2">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-medium text-slate-200 truncate">{it.item_name}</span>
                                  {it.is_optional ? (
                                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 font-semibold border border-amber-500/20">
                                      Optional
                                    </span>
                                  ) : null}
                                  {isArmSpecific && (
                                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/10 text-purple-300 font-mono border border-purple-500/20" title={`Applies to: ${it.arms.join(', ')}`}>
                                      {it.arms.length <= 2 ? it.arms.join(', ') : `${it.arms.length} arms`}
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-500">{it.term}</span>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <span className="font-mono font-bold text-white">{formatNaira(it.amount)}</span>
                                <button
                                  onClick={() => handleDeleteStructure(it.ids)}
                                  className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10"
                                  title="Remove Fee Item"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Record Payment Modal */}
      {payStudent && summary && (
        <RecordPaymentModal
          student={payStudent}
          session={summary.academic_session}
          term={summary.term}
          onSave={handleRecordPayment}
          onClose={() => setPayStudent(null)}
        />
      )}

      {/* Official Voucher Printable Modal */}
      {receiptData && (
        <ReceiptModal
          receipt={receiptData}
          onClose={() => setReceiptData(null)}
        />
      )}

      {/* Student Dossier Drawer */}
      {dossierStudentId && (
        <StudentFeeDossierDrawer
          studentId={dossierStudentId}
          onClose={() => setDossierStudentId(null)}
          onRecordPayment={st => {
            setDossierStudentId(null);
            setPayStudent(st);
          }}
          onViewReceipt={handleOpenReceipt}
        />
      )}

      {/* Add Fee Item Modal */}
      {addStructureOpen && (
        <AddFeeItemModal
          classes={classes}
          onSave={async payload => {
            const res = await fetch('/api/admin/finance/structures', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.error || 'Failed');
            showToast('Fee item added successfully');
            setAddStructureOpen(false);
            loadStructures();
          }}
          onClose={() => setAddStructureOpen(false)}
        />
      )}

      {/* Batch Apply Bills Modal */}
      {applyBillsOpen && (
        <ApplyBillsModal
          classes={classes}
          onApply={async (scope, targetClass) => {
            const res = await fetch('/api/admin/finance/apply-structure', {
              method: 'POST',
              headers: authHeaders(),
              body: JSON.stringify({ scope, target_class: targetClass }),
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.error || 'Failed');
            loadSummary();
            loadLedger(true);
            return data;
          }}
          onClose={() => setApplyBillsOpen(false)}
        />
      )}
    </div>
  );
}
