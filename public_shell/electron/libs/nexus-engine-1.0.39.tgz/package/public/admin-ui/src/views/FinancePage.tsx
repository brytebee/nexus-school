import React from 'react';
import Header from '../components/Header';
import { Wallet, Receipt, CreditCard, CheckCircle2 } from 'lucide-react';

export default function FinancePage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Finance & Bursary" subtitle="Fee ledger, offline receipting & payment settlement (Phase 7d)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Campus Fee Ledger &amp; Arrears</h3>
              <p className="text-xs text-slate-400">Track student tuition balances, issue thermal receipts, and reconcile online Paystack settlements</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Local offline bursary operations integrate seamlessly with cloud parent payments via the 2-way sync worker, keeping receipts and balances synchronized.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7d Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
