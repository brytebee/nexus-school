import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  School,
  Users,
  GraduationCap,
  Wallet,
  BookOpen,
  MonitorCheck,
  Settings,
  LogOut,
  Shield,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  admin: any;
  schoolName?: string;
  onLogout: () => void;
}

const navItems = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, badge: null },
  { name: 'Classes', path: '/classes', icon: School, badge: null },
  { name: 'Teachers', path: '/teachers', icon: Users, badge: null },
  { name: 'Students', path: '/students', icon: GraduationCap, badge: null },
  { name: 'Finance', path: '/finance', icon: Wallet, badge: null },
  { name: 'Subjects', path: '/subjects', icon: BookOpen, badge: null },
  { name: 'CBT Portal', path: '/cbt', icon: MonitorCheck, badge: 'Live' },
  { name: 'Settings', path: '/settings', icon: Settings, badge: null },
];

export default function Sidebar({ admin, schoolName = 'Nexus School', onLogout }: SidebarProps) {
  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col h-screen shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800/80 flex items-center gap-3">
        <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/10 border border-emerald-500/30 text-emerald-400 shrink-0">
          <Shield className="w-5 h-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="font-black text-sm text-white tracking-tight truncate">Nexus OS</span>
            <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Admin
            </span>
          </div>
          <p className="text-[11px] text-slate-400 truncate font-medium">
            {schoolName}
          </p>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          Main Navigation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 transition-colors ${
                        isActive ? 'text-emerald-400' : 'text-slate-500 group-hover:text-slate-300'
                      }`}
                    />
                    <span className="truncate">{item.name}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300">
                      {item.badge}
                    </span>
                  )}
                </>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Admin User Footer & Sign Out */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/60">
        <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0">
              {admin?.username?.[0]?.toUpperCase() || 'A'}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate leading-tight">
                {admin?.username || 'Superadmin'}
              </p>
              <p className="text-[10px] text-slate-400 truncate leading-tight">
                Level {admin?.role_level ?? 9} Clearance
              </p>
            </div>
          </div>
          <button
            onClick={onLogout}
            title="Sign out of local admin"
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
