import React from 'react';
import Header from '../components/Header';
import { GraduationCap, UserCheck, ArrowRightLeft, CheckCircle2 } from 'lucide-react';

export default function StudentsPage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Student Directory" subtitle="Student enrollment register, profiles & bulk promotion (Phase 7c)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Sovereign Student Register</h3>
              <p className="text-xs text-slate-400">Complete student roster with admission numbers, class arms, and academic records</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Manage student bio data, class enrollments, and execute session-end bulk promotions with automatic conflict resolution and report card history preservation.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7c Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
