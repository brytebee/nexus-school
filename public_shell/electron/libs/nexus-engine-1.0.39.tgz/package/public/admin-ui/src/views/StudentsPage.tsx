import React, { useEffect, useState, useCallback, useMemo } from 'react';
import Header from '../components/Header';
import {
  GraduationCap, Search, Plus, Filter, ArrowRight, ArrowRightLeft,
  Pencil, Trash2, X, Check, Loader2, AlertTriangle, RefreshCw,
  Phone, Mail, Calendar, User, ChevronLeft, ChevronRight, Download,
  ExternalLink, LogOut, ShieldCheck, ShieldAlert, FileText, CheckCircle2,
  Clock, Award, DollarSign, BookOpen
} from 'lucide-react';

// ── Types ─────────────────────────────────────────────────────────────────────
interface Student {
  id: string;
  name: string;
  class_name: string;
  class_arm: string;
  admission_no: string;
  reg_no: string;
  gender: string;
  dob: string;
  photo: string | null;
  parent_name: string;
  parent_phone: string;
  parent_phone_2: string;
  parent_email: string;
  fee_status: string;
  computed_payment_status: string | null;
  total_billed: number;
  total_paid: number;
  balance: number;
  is_active: number;
  enrollment_status: string;
  session_history: string | null;
  created_at: string;
}

// ── Gender Helpers ────────────────────────────────────────────────────────────
function isFemale(gender: string): boolean {
  return (gender || '').trim().toUpperCase().startsWith('F');
}

function formatGender(gender: string): string {
  if (!gender) return '—';
  return isFemale(gender) ? 'Female' : 'Male';
}

// ── Payment Status Helpers ────────────────────────────────────────────────────
function computedPayLabel(s: Student): string {
  const ps = s.computed_payment_status;
  if (ps === 'paid') return 'Completely Paid';
  if (ps === 'partial') return 'Partial Pay';
  if (ps === 'paid_0') return 'Paid ₦0';
  // Legacy fallback
  if (s.fee_status === 'cleared') return 'Completely Paid';
  if (s.fee_status === 'partial') return 'Partial Pay';
  return 'Paid ₦0';
}

function computedPayColor(s: Student): string {
  const ps = s.computed_payment_status || s.fee_status;
  if (ps === 'paid' || ps === 'cleared') return 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
  if (ps === 'partial') return 'bg-amber-500/10 text-amber-400 border border-amber-500/20';
  return 'bg-rose-500/10 text-rose-400 border border-rose-500/20';
}

interface StudentDetail extends Student {
  session_history: any[];
  attendance: {
    total: number;
    present: number;
    late: number;
    absent: number;
    rate: number;
  };
  fees: {
    billed: number;
    paid: number;
    balance: number;
    status: string;
  };
  academic: {
    standard_grades_count: number;
    ils_packs_count: number;
    subjects_enrolled: number;
    subjects?: string[];
  };
}

interface ClassArm {
  id: number;
  arm: string;
}

interface ClassConfig {
  hierarchy_class: string;
  arms: ClassArm[];
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function getToken(): string {
  return localStorage.getItem('nexus_admin_token') || '';
}

function authHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${getToken()}`,
    'Content-Type': 'application/json',
  };
}

// ── Toast Notification (Zero-blocking) ────────────────────────────────────────
function Toast({ msg, type, onClose }: { msg: string; type: 'ok' | 'err'; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 4000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <div
      className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl shadow-2xl text-sm font-semibold border ${
        type === 'ok'
          ? 'bg-emerald-900/90 border-emerald-600 text-emerald-200'
          : 'bg-rose-900/90 border-rose-600 text-rose-200'
      }`}
    >
      {type === 'ok' ? (
        <Check className="w-4 h-4 text-emerald-400" />
      ) : (
        <AlertTriangle className="w-4 h-4 text-rose-400" />
      )}
      {msg}
      <button onClick={onClose} className="ml-2 opacity-60 hover:opacity-100">
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

// ── Confirm Dialog (Zero-blocking replacement for window.confirm) ──────────────
function ConfirmDialog({
  title,
  message,
  confirmLabel = 'Confirm',
  danger = false,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-6 sm:p-8 w-full max-w-sm space-y-5">
        <div className="flex items-start gap-3">
          <div
            className={`p-2.5 rounded-xl border shrink-0 ${
              danger
                ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
            }`}
          >
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">{title}</h4>
            <p className="text-xs text-slate-300 leading-relaxed mt-1">{message}</p>
          </div>
        </div>
        <div className="flex gap-3 justify-end pt-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700 transition-all"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className={`px-4 py-2 rounded-xl text-xs font-bold text-white transition-all ${
              danger ? 'bg-rose-600 hover:bg-rose-500' : 'bg-amber-600 hover:bg-amber-500'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Student Profile Drawer ────────────────────────────────────────────────────
function StudentProfileDrawer({
  studentId,
  onClose,
  onEdit,
}: {
  studentId: string;
  onClose: () => void;
  onEdit: (student: Student) => void;
}) {
  const [detail, setDetail] = useState<StudentDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const res = await fetch(`/api/admin/students/${studentId}`, { headers: authHeaders() });
        const data = await res.json();
        if (isMounted && data.ok) {
          setDetail(data.student);
        }
      } catch (_) {
        // ignore
      } finally {
        if (isMounted) setLoading(false);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, [studentId]);

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-slate-900 border-l border-slate-700 shadow-2xl h-full flex flex-col overflow-hidden animate-in slide-in-from-right duration-200">
        {/* Top bar */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-900/60">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold">
              Student Profile Card
            </span>
            <h3 className="text-lg font-black text-white">{detail ? detail.name : 'Loading...'}</h3>
          </div>
          <div className="flex items-center gap-2">
            {detail && (
              <button
                onClick={() => onEdit(detail)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all text-xs flex items-center gap-1.5 border border-slate-700 font-semibold"
                title="Edit Student"
              >
                <Pencil className="w-3.5 h-3.5" /> Edit
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 text-slate-400">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
            <p className="text-xs">Fetching student record...</p>
          </div>
        ) : !detail ? (
          <div className="flex-1 flex items-center justify-center text-slate-400 text-xs">
            Student profile not found.
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Header Card */}
            <div className="p-5 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-4">
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-black shrink-0 ${
                  isFemale(detail.gender)
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                }`}
              >
                {detail.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {detail.class_name} {detail.class_arm}
                  </span>
                  {detail.is_active ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                      Active
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-700 text-slate-300">
                      {detail.enrollment_status || 'Inactive'}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1 font-mono">
                  ID: <span className="text-slate-200">{detail.id}</span>
                  {detail.admission_no && (
                    <span className="ml-2">
                      · Adm: <span className="text-slate-200">{detail.admission_no}</span>
                    </span>
                  )}
                </p>
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
                <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-1">
                  <DollarSign className="w-4 h-4 text-emerald-400" /> Fee Balance
                </div>
                <p
                  className={`text-lg font-black ${
                    detail.fees.balance <= 0 ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  ₦{detail.fees.balance.toLocaleString()}
                </p>
                <p className="text-[10px] text-slate-500 capitalize">
                  Status: {detail.fees.status} (Paid ₦{detail.fees.paid.toLocaleString()})
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
                <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-1">
                  <CheckCircle2 className="w-4 h-4 text-sky-400" /> Attendance Rate
                </div>
                <p className="text-lg font-black text-sky-400">
                  {detail.attendance.total > 0 ? `${detail.attendance.rate}%` : 'N/A'}
                </p>
                <p className="text-[10px] text-slate-500">
                  {detail.attendance.present} present of {detail.attendance.total} days marked
                </p>
              </div>
            </div>

            {/* Bio Information */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <User className="w-3.5 h-3.5 text-emerald-400" /> Bio &amp; Registration
              </h4>
              <div className="grid grid-cols-2 gap-y-2 text-xs">
                <div>
                  <span className="text-slate-500 block text-[11px]">Gender:</span>
                  <span className="text-slate-200 font-medium">
                    {formatGender(detail.gender)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Date of Birth:</span>
                  <span className="text-slate-200 font-medium">{detail.dob || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Exam Reg No:</span>
                  <span className="text-slate-200 font-mono">{detail.reg_no || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Enrolled Since:</span>
                  <span className="text-slate-200 font-medium">
                    {detail.created_at ? new Date(detail.created_at).toLocaleDateString() : '—'}
                  </span>
                </div>
              </div>
            </div>

            {/* Parent & Emergency Contact */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-sky-400" /> Guardian &amp; Emergency Contact
              </h4>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-slate-700/40">
                  <span className="text-slate-400">Primary Guardian:</span>
                  <span className="text-slate-200 font-semibold">{detail.parent_name || '—'}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-700/40">
                  <span className="text-slate-400">Primary Phone:</span>
                  {detail.parent_phone ? (
                    <a
                      href={`tel:${detail.parent_phone}`}
                      className="text-emerald-400 font-mono font-bold hover:underline flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" /> {detail.parent_phone}
                    </a>
                  ) : (
                    <span className="text-slate-500">—</span>
                  )}
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-700/40">
                  <span className="text-slate-400">Secondary Phone:</span>
                  <span className="text-slate-200 font-mono">{detail.parent_phone_2 || '—'}</span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-400">Email Address:</span>
                  <span className="text-slate-200 font-mono">{detail.parent_email || '—'}</span>
                </div>
              </div>
            </div>

            {/* Academic Snapshot */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Award className="w-3.5 h-3.5 text-amber-400" /> Academic Assessments
              </h4>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-slate-900/60">
                  <span className="text-slate-500 block text-[10px]">Subjects:</span>
                  <span className="text-slate-200 font-bold text-sm">
                    {detail.academic.subjects_enrolled || (detail.academic.subjects || []).length}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/60">
                  <span className="text-slate-500 block text-[10px]">Standard Grades:</span>
                  <span className="text-slate-200 font-bold text-sm">
                    {detail.academic.standard_grades_count} records
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/60">
                  <span className="text-slate-500 block text-[10px]">ACE / ILS PACs:</span>
                  <span className="text-slate-200 font-bold text-sm">
                    {detail.academic.ils_packs_count} pacs
                  </span>
                </div>
              </div>
            </div>

            {/* Enrolled Subjects */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <BookOpen className="w-3.5 h-3.5 text-purple-400" /> Enrolled Subjects
                </h4>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-300 text-[10px] font-bold border border-purple-500/20">
                  {(detail.academic.subjects || []).length} registered
                </span>
              </div>
              {Array.isArray(detail.academic.subjects) && detail.academic.subjects.length > 0 ? (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {detail.academic.subjects.map((sub: string) => (
                    <span
                      key={sub}
                      className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                      {sub}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">No subjects registered for this student yet.</p>
              )}
            </div>

            {/* Session History */}
            <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/60 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-emerald-400" /> Class Progression History
              </h4>
              {Array.isArray(detail.session_history) && detail.session_history.length > 0 ? (
                <div className="space-y-2 border-l-2 border-emerald-500/40 pl-3 ml-1">
                  {detail.session_history.map((h: any, idx: number) => (
                    <div key={idx} className="text-xs space-y-0.5 relative">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 absolute -left-[17px] top-1.5" />
                      <p className="font-bold text-white">
                        {h.type === 'promotion'
                          ? `Promoted to ${h.to_class} ${h.to_arm || ''}`
                          : h.type === 'transfer_out'
                          ? `Transferred out (${h.destination || 'External'})`
                          : h.class || 'Class Progression'}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {h.session && <span>Session: {h.session} · </span>}
                        {h.promoted_at
                          ? new Date(h.promoted_at).toLocaleDateString()
                          : h.date || ''}
                      </p>
                      {h.reason && <p className="text-[11px] text-slate-500 italic">Reason: {h.reason}</p>}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">No historical transfers or promotions logged yet.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Add / Edit Student Modal ──────────────────────────────────────────────────
function StudentModal({
  student,
  classes,
  onSave,
  onClose,
}: {
  student?: Student | null;
  classes: ClassConfig[];
  onSave: (data: Partial<Student>) => Promise<void>;
  onClose: () => void;
}) {
  const isEdit = Boolean(student);
  const [name, setName] = useState(student?.name || '');
  const [className, setClassName] = useState(student?.class_name || (classes[0]?.hierarchy_class || ''));
  const [classArm, setClassArm] = useState(student?.class_arm || '');
  const [admissionNo, setAdmissionNo] = useState(student?.admission_no || '');
  const [regNo, setRegNo] = useState(student?.reg_no || '');
  const [gender, setGender] = useState(() => {
    const g = student?.gender || 'Male';
    return isFemale(g) ? 'Female' : 'Male';
  });
  const [dob, setDob] = useState(student?.dob || '');
  const [parentName, setParentName] = useState(student?.parent_name || '');
  const [parentPhone, setParentPhone] = useState(student?.parent_phone || '');
  const [parentPhone2, setParentPhone2] = useState(student?.parent_phone_2 || '');
  const [parentEmail, setParentEmail] = useState(student?.parent_email || '');
  const [feeStatus, setFeeStatus] = useState(student?.fee_status || 'cleared');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  // Available arms for chosen class
  const availableArms = useMemo(() => {
    const found = classes.find(c => c.hierarchy_class === className);
    return found ? found.arms : [];
  }, [classes, className]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErr('Student name is required');
      return;
    }
    if (!className.trim()) {
      setErr('Please select a class');
      return;
    }

    setSaving(true);
    setErr('');
    try {
      await onSave({
        name: name.trim(),
        class_name: className.trim(),
        class_arm: classArm.trim(),
        admission_no: admissionNo.trim(),
        reg_no: regNo.trim(),
        gender,
        dob,
        parent_name: parentName.trim(),
        parent_phone: parentPhone.trim(),
        parent_phone_2: parentPhone2.trim(),
        parent_email: parentEmail.trim(),
        fee_status: feeStatus,
      });
    } catch (e: any) {
      setErr(e.message || 'Failed to save student record');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-6 sm:p-8 w-full max-w-xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60 shrink-0">
          <div>
            <h3 className="text-white font-black text-base">
              {isEdit ? 'Edit Student Record' : 'Intake New Student'}
            </h3>
            <p className="text-[11px] text-slate-400">
              {isEdit ? `Updating ${student?.name}` : 'Enrolling student to active register'}
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 py-4 space-y-4 pr-1">
          {err && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {err}
            </div>
          )}

          {/* Full Name */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Student Full Name *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Adebayo Emmanuel"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Class and Arm Selector */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Class Level *
              </label>
              <select
                value={className}
                onChange={e => {
                  setClassName(e.target.value);
                  setClassArm('');
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
              >
                {classes.map(c => (
                  <option key={c.hierarchy_class} value={c.hierarchy_class}>
                    {c.hierarchy_class}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Arm / Stream
              </label>
              <select
                value={classArm}
                onChange={e => setClassArm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="">— Standalone / No Arm —</option>
                {availableArms.map(a => (
                  <option key={a.id} value={a.arm}>
                    {a.arm}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Admission & Reg Numbers */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Admission No
              </label>
              <input
                type="text"
                placeholder="e.g. 2024/042"
                value={admissionNo}
                onChange={e => setAdmissionNo(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Exam Reg No
              </label>
              <input
                type="text"
                placeholder="Optional"
                value={regNo}
                onChange={e => setRegNo(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Gender & DOB */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Gender
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setGender('Male')}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all ${
                    !isFemale(gender)
                      ? 'bg-sky-500/20 border-sky-500 text-sky-300'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  Male
                </button>
                <button
                  type="button"
                  onClick={() => setGender('Female')}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all ${
                    isFemale(gender)
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  Female
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Date of Birth
              </label>
              <input
                type="date"
                value={dob}
                onChange={e => setDob(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Guardian Info */}
          <div className="pt-2 border-t border-slate-700/60 space-y-3">
            <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              Guardian Details
            </h4>
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Guardian Full Name
              </label>
              <input
                type="text"
                placeholder="e.g. Mr. & Mrs. Adebayo"
                value={parentName}
                onChange={e => setParentName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Primary Phone
                </label>
                <input
                  type="tel"
                  placeholder="08012345678"
                  value={parentPhone}
                  onChange={e => setParentPhone(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Secondary Phone
                </label>
                <input
                  type="tel"
                  placeholder="Optional emergency"
                  value={parentPhone2}
                  onChange={e => setParentPhone2(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Email Address
              </label>
              <input
                type="email"
                placeholder="parent@example.com"
                value={parentEmail}
                onChange={e => setParentEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex gap-3 justify-end pt-4 border-t border-slate-700/60 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              {isEdit ? 'Save Changes' : 'Enroll Student'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Bulk Promote Modal (Session-end advancement with speed-bump guard) ─────────
function BulkPromoteModal({
  classes,
  onPromote,
  onClose,
}: {
  classes: ClassConfig[];
  onPromote: (data: {
    from_class: string;
    from_arm: string;
    to_class: string;
    to_arm: string;
    session_snapshot: string;
  }) => Promise<void>;
  onClose: () => void;
}) {
  const [fromClass, setFromClass] = useState(classes[0]?.hierarchy_class || '');
  const [fromArm, setFromArm] = useState('');
  const [toClass, setToClass] = useState('');
  const [toArm, setToArm] = useState('');
  const [session, setSession] = useState('2024/2025');
  const [confirmedTyped, setConfirmedTyped] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  // Auto suggest next class when fromClass changes
  useEffect(() => {
    const idx = classes.findIndex(c => c.hierarchy_class === fromClass);
    if (idx !== -1 && idx + 1 < classes.length) {
      setToClass(classes[idx + 1].hierarchy_class);
      setToArm(fromArm); // default preserve same arm name
    } else {
      setToClass('');
      setToArm('');
    }
  }, [fromClass, fromArm, classes]);

  const sourceArms = useMemo(() => {
    return classes.find(c => c.hierarchy_class === fromClass)?.arms || [];
  }, [classes, fromClass]);

  const destArms = useMemo(() => {
    return classes.find(c => c.hierarchy_class === toClass)?.arms || [];
  }, [classes, toClass]);

  const canProceed = confirmedTyped.trim().toLowerCase() === toClass.trim().toLowerCase() && Boolean(toClass);

  const handleExecute = async () => {
    if (!canProceed) return;
    setSaving(true);
    setErr('');
    try {
      await onPromote({
        from_class: fromClass,
        from_arm: fromArm,
        to_class: toClass,
        to_arm: toArm,
        session_snapshot: session,
      });
    } catch (e: any) {
      setErr(e.message || 'Bulk promotion failed');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-6 sm:p-8 w-full max-w-lg space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-700/60">
          <div>
            <h3 className="text-white font-black text-base flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5 text-emerald-400" />
              Session-End Bulk Promotion
            </h3>
            <p className="text-[11px] text-slate-400">
              Advance student cohort to the next academic level
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {err && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
            {err}
          </div>
        )}

        <div className="space-y-4 text-xs">
          {/* Academic Session Snapshot */}
          <div className="space-y-1">
            <label className="font-bold text-slate-400 uppercase tracking-wider text-[10px]">
              Ending Session Watermark
            </label>
            <input
              type="text"
              value={session}
              onChange={e => setSession(e.target.value)}
              placeholder="e.g. 2024/2025"
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Source Cohort */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-700/40 space-y-2">
            <span className="font-bold text-slate-300 text-[11px] uppercase tracking-wider block">
              1. Source Cohort (Currently Enrolled)
            </span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">Class Level</label>
                <select
                  value={fromClass}
                  onChange={e => {
                    setFromClass(e.target.value);
                    setFromArm('');
                  }}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-xs"
                >
                  {classes.map(c => (
                    <option key={c.hierarchy_class} value={c.hierarchy_class}>
                      {c.hierarchy_class}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">Arm / Stream</label>
                <select
                  value={fromArm}
                  onChange={e => setFromArm(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-xs"
                >
                  <option value="">All Arms in {fromClass}</option>
                  {sourceArms.map(a => (
                    <option key={a.id} value={a.arm}>
                      {a.arm}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Destination Cohort */}
          <div className="p-3.5 rounded-2xl bg-emerald-500/5 border border-emerald-500/20 space-y-2">
            <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider block">
              2. Target Promotion Level
            </span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">Target Class</label>
                <select
                  value={toClass}
                  onChange={e => {
                    setToClass(e.target.value);
                    setToArm('');
                  }}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-xs focus:border-emerald-500"
                >
                  <option value="">— Select Target Class —</option>
                  {classes.map(c => (
                    <option key={c.hierarchy_class} value={c.hierarchy_class}>
                      {c.hierarchy_class}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block mb-1">Target Arm</label>
                <select
                  value={toArm}
                  onChange={e => setToArm(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-xs"
                >
                  <option value="">Preserve Same / No Arm</option>
                  {destArms.map(a => (
                    <option key={a.id} value={a.arm}>
                      {a.arm}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Speed bump guard */}
          {toClass && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-2">
              <p className="text-[11px] text-amber-300">
                To prevent accidental promotions, type <span className="font-black underline">{toClass}</span> to unlock:
              </p>
              <input
                type="text"
                placeholder={`Type "${toClass}" here`}
                value={confirmedTyped}
                onChange={e => setConfirmedTyped(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>
          )}
        </div>

        <div className="flex gap-3 justify-end pt-3 border-t border-slate-700/60">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700"
          >
            Cancel
          </button>
          <button
            onClick={handleExecute}
            disabled={!canProceed || saving}
            className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40 transition-all shadow-lg shadow-emerald-900/30"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ArrowRight className="w-3.5 h-3.5" />}
            Promote Cohort
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Transfer Dialog ───────────────────────────────────────────────────────────
function TransferModal({
  student,
  onTransfer,
  onClose,
}: {
  student: Student;
  onTransfer: (data: { destination_school: string; reason: string; transfer_date: string }) => Promise<void>;
  onClose: () => void;
}) {
  const [destination, setDestination] = useState('');
  const [reason, setReason] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async () => {
    setSaving(true);
    setErr('');
    try {
      await onTransfer({
        destination_school: destination.trim(),
        reason: reason.trim(),
        transfer_date: date,
      });
    } catch (e: any) {
      setErr(e.message || 'Transfer failed');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-6 sm:p-8 w-full max-w-sm space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-700/60">
          <div>
            <h3 className="text-white font-bold text-sm">Transfer Out Student</h3>
            <p className="text-[11px] text-slate-400">{student.name}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {err && <p className="text-xs text-rose-400">{err}</p>}

        <p className="text-xs text-slate-300">
          Mark student as transferred. This sets their status to Inactive while safely preserving their grade records and fee history.
        </p>

        <div className="space-y-2 text-xs">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Destination School
            </label>
            <input
              type="text"
              placeholder="e.g. King's College Lagos"
              value={destination}
              onChange={e => setDestination(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Reason / Notes
            </label>
            <input
              type="text"
              placeholder="e.g. Relocated out of state"
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Transfer Date
            </label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
            />
          </div>
        </div>

        <div className="flex gap-2 justify-end pt-3">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700"
          >
            Cancel
          </button>
          <button
            onClick={handle}
            disabled={saving}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LogOut className="w-3.5 h-3.5" />}
            Confirm Transfer
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page Component ────────────────────────────────────────────────────────
export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<ClassConfig[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [stats, setStats] = useState({ total: 0, active: 0, inactive: 0 });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedArm, setSelectedArm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'transferred'>('active');
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'paid' | 'partial' | 'paid_0'>('all');

  // Modals & Drawers state
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);
  const [profileId, setProfileId] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [editStudent, setEditStudent] = useState<Student | null>(null);
  const [promoteOpen, setPromoteOpen] = useState(false);
  const [transferStudent, setTransferStudent] = useState<Student | null>(null);
  const [toggleConfirm, setToggleConfirm] = useState<Student | null>(null);

  const showToast = (msg: string, type: 'ok' | 'err') => setToast({ msg, type });

  // Load Classes list for dropdowns
  const loadClasses = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/classes', { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) {
        setClasses(data.classes || []);
      }
    } catch (_) {}
  }, []);

  // Load Students with current filters and pagination
  const loadStudents = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      else setRefreshing(true);
      try {
        const params = new URLSearchParams();
        params.set('page', String(page));
        params.set('limit', '50');
        if (selectedClass) params.set('class', selectedClass);
        if (selectedArm) params.set('arm', selectedArm);
        if (statusFilter !== 'all') params.set('status', statusFilter);
        if (paymentFilter !== 'all') params.set('payment', paymentFilter);
        if (search.trim()) params.set('q', search.trim());

        const res = await fetch(`/api/admin/students?${params.toString()}`, {
          headers: authHeaders(),
        });
        const data = await res.json();
        if (data.ok) {
          setStudents(data.students || []);
          setTotal(data.total || 0);
          setPages(data.pages || 1);
          if (data.stats) setStats(data.stats);
        } else {
          showToast(data.error || 'Failed to fetch student register', 'err');
        }
      } catch {
        showToast('Network error loading students', 'err');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [page, selectedClass, selectedArm, statusFilter, paymentFilter, search]
  );

  useEffect(() => {
    loadClasses();
  }, [loadClasses]);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  // Derived arms for filter dropdown
  const filterArms = useMemo(() => {
    if (!selectedClass) return [];
    return classes.find(c => c.hierarchy_class === selectedClass)?.arms || [];
  }, [classes, selectedClass]);

  // Action handlers
  const handleAdd = async (data: Partial<Student>) => {
    const res = await fetch('/api/admin/students', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(data),
    });
    const resp = await res.json();
    if (!resp.ok) throw new Error(resp.error || 'Failed to enroll student');
    showToast(`Student "${data.name}" enrolled successfully`, 'ok');
    setAddOpen(false);
    await loadStudents(true);
  };

  const handleEdit = async (data: Partial<Student>) => {
    if (!editStudent) return;
    const res = await fetch(`/api/admin/students/${editStudent.id}`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify(data),
    });
    const resp = await res.json();
    if (!resp.ok) throw new Error(resp.error || 'Failed to update student');
    showToast(`Profile updated for ${data.name || editStudent.name}`, 'ok');
    setEditStudent(null);
    if (profileId === editStudent.id) {
      setProfileId(null); // re-trigger fetch if open
      setTimeout(() => setProfileId(editStudent.id), 50);
    }
    await loadStudents(true);
  };

  const handleToggleActive = async (student: Student) => {
    const nextActive = student.is_active ? 0 : 1;
    const res = await fetch(`/api/admin/students/${student.id}`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify({
        is_active: nextActive,
        enrollment_status: nextActive ? 'active' : 'inactive',
      }),
    });
    const resp = await res.json();
    if (!resp.ok) {
      showToast(resp.error || 'Failed to toggle status', 'err');
      return;
    }
    showToast(
      `${student.name} marked as ${nextActive ? 'Active' : 'Inactive'}`,
      'ok'
    );
    setToggleConfirm(null);
    await loadStudents(true);
  };

  const handleTransfer = async (data: { destination_school: string; reason: string; transfer_date: string }) => {
    if (!transferStudent) return;
    const res = await fetch(`/api/admin/students/${transferStudent.id}/transfer`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(data),
    });
    const resp = await res.json();
    if (!resp.ok) throw new Error(resp.error || 'Failed to transfer student');
    showToast(`${transferStudent.name} recorded as transferred out`, 'ok');
    setTransferStudent(null);
    await loadStudents(true);
  };

  const handleBulkPromote = async (data: {
    from_class: string;
    from_arm: string;
    to_class: string;
    to_arm: string;
    session_snapshot: string;
  }) => {
    const res = await fetch('/api/admin/students/bulk-promote', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(data),
    });
    const resp = await res.json();
    if (!resp.ok) throw new Error(resp.error || 'Bulk promotion failed');
    showToast(
      `🎉 Successfully promoted ${resp.promoted} student(s) to ${data.to_class} ${data.to_arm || ''}`,
      'ok'
    );
    setPromoteOpen(false);
    await loadStudents(true);
  };

  // Export current table view as CSV
  const handleExportCSV = () => {
    if (students.length === 0) return;
    const headers = [
      'ID',
      'Name',
      'Class',
      'Arm',
      'Admission No',
      'Gender',
      'Parent Name',
      'Parent Phone',
      'Fee Status',
      'Status',
    ];
    const rows = students.map(s => [
      `"${s.id}"`,
      `"${s.name}"`,
      `"${s.class_name}"`,
      `"${s.class_arm || ''}"`,
      `"${s.admission_no || ''}"`,
      `"${s.gender || ''}"`,
      `"${s.parent_name || ''}"`,
      `"${s.parent_phone || ''}"`,
      `"${s.fee_status || ''}"`,
      s.is_active ? 'Active' : s.enrollment_status,
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `students_register_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported CSV successfully', 'ok');
  };

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header
        title="Student Register"
        subtitle="Sovereign enrollment directory, profiles &amp; bulk promotions"
        onRefresh={() => loadStudents(true)}
        refreshing={refreshing}
      />

      <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
        {/* KPI Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4">
            <p className="text-2xl font-black text-white">{stats.total}</p>
            <p className="text-[11px] text-slate-400 font-medium">All Time Intake</p>
          </div>
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4">
            <p className="text-2xl font-black text-emerald-400">{stats.active}</p>
            <p className="text-[11px] text-slate-400 font-medium">Active Enrolled</p>
          </div>
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4">
            <p className="text-2xl font-black text-slate-400">{stats.inactive}</p>
            <p className="text-[11px] text-slate-400 font-medium">Inactive / Alumni</p>
          </div>
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4">
            <p className="text-2xl font-black text-sky-400">{total}</p>
            <p className="text-[11px] text-slate-400 font-medium">Filtered Results</p>
          </div>
        </div>

        {/* Toolbar & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="flex flex-1 flex-wrap gap-2 items-center">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search name, phone, admission..."
                value={search}
                onChange={e => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                className="w-full bg-slate-800/80 border border-slate-700/70 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Class Filter */}
            <select
              value={selectedClass}
              onChange={e => {
                setSelectedClass(e.target.value);
                setSelectedArm('');
                setPage(1);
              }}
              className="bg-slate-800/80 border border-slate-700/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              <option value="">All Classes</option>
              {classes.map(c => (
                <option key={c.hierarchy_class} value={c.hierarchy_class}>
                  {c.hierarchy_class}
                </option>
              ))}
            </select>

            {/* Arm Filter (conditional) */}
            {filterArms.length > 0 && (
              <select
                value={selectedArm}
                onChange={e => {
                  setSelectedArm(e.target.value);
                  setPage(1);
                }}
                className="bg-slate-800/80 border border-slate-700/70 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="">All Arms</option>
                {filterArms.map(a => (
                  <option key={a.id} value={a.arm}>
                    {a.arm}
                  </option>
                ))}
              </select>
            )}

            {/* Status Filter Chips */}
            <div className="flex rounded-xl overflow-hidden border border-slate-700/60 bg-slate-800/40 p-0.5">
              {(['active', 'all', 'inactive', 'transferred'] as const).map(s => (
                <button
                  key={s}
                  onClick={() => {
                    setStatusFilter(s);
                    setPage(1);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all ${
                    statusFilter === s
                      ? 'bg-slate-700 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Payment Filter Chips */}
            <div className="flex rounded-xl overflow-hidden border border-slate-700/60 bg-slate-800/40 p-0.5">
              {([
                { value: 'all', label: 'All Fees' },
                { value: 'paid', label: 'Completely Paid' },
                { value: 'partial', label: 'Partial' },
                { value: 'paid_0', label: 'Paid ₦0' },
              ] as const).map(({ value, label }) => (
                <button
                  key={value}
                  onClick={() => {
                    setPaymentFilter(value);
                    setPage(1);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    paymentFilter === value
                      ? value === 'paid'
                        ? 'bg-emerald-600/80 text-white shadow'
                        : value === 'partial'
                        ? 'bg-amber-600/80 text-white shadow'
                        : value === 'paid_0'
                        ? 'bg-rose-600/80 text-white shadow'
                        : 'bg-slate-700 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setPromoteOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 hover:text-white hover:bg-slate-750 text-xs font-bold transition-all"
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-emerald-400" />
              Bulk Promote
            </button>
            <button
              onClick={handleExportCSV}
              disabled={students.length === 0}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 hover:text-white hover:bg-slate-750 text-xs font-bold transition-all disabled:opacity-40"
              title="Download CSV"
            >
              <Download className="w-3.5 h-3.5" />
              CSV
            </button>
            <button
              onClick={() => setAddOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-900/30"
            >
              <Plus className="w-4 h-4" />
              Add Student
            </button>
          </div>
        </div>

        {/* Students Table */}
        <div className="rounded-2xl border border-slate-700/60 bg-slate-800/30 overflow-hidden shadow-xl">
          {loading ? (
            <div className="py-24 flex flex-col items-center justify-center gap-3 text-slate-400">
              <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
              <p className="text-xs font-semibold">Loading student roster...</p>
            </div>
          ) : students.length === 0 ? (
            <div className="py-20 flex flex-col items-center justify-center gap-3 text-slate-500">
              <GraduationCap className="w-12 h-12 opacity-30" />
              <p className="text-sm font-bold text-slate-300">No students found</p>
              <p className="text-xs text-slate-500">Try adjusting your search query or class filter.</p>
              <button
                onClick={() => setAddOpen(true)}
                className="mt-2 flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
              >
                <Plus className="w-4 h-4" /> Add First Student
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-700/60 bg-slate-850/50 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-4">Student</th>
                    <th className="py-3 px-4">Class &amp; Arm</th>
                    <th className="py-3 px-4">Guardian Contact</th>
                    <th className="py-3 px-4 text-center">Fee Status</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/40">
                  {students.map(s => (
                    <tr
                      key={s.id}
                      onClick={() => setProfileId(s.id)}
                      className="hover:bg-slate-700/20 transition-colors cursor-pointer group"
                    >
                      {/* Name & ID */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-[11px] shrink-0 ${
                              isFemale(s.gender)
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                : 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
                            }`}
                          >
                            {s.name.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-white text-sm group-hover:text-emerald-300 transition-colors">
                              {s.name}
                            </span>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                              <span>{s.admission_no || s.id}</span>
                              {s.gender && <span>· {isFemale(s.gender) ? 'Fem' : 'Male'}</span>}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Class */}
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-200 text-[11px] font-bold">
                          {s.class_name} {s.class_arm && <span className="text-emerald-400 font-semibold">{s.class_arm}</span>}
                        </span>
                      </td>

                      {/* Guardian */}
                      <td className="py-3 px-4">
                        <div>
                          <p className="text-slate-300 font-medium">{s.parent_name || '—'}</p>
                          <p className="text-slate-500 font-mono text-[11px]">{s.parent_phone || 'No phone'}</p>
                        </div>
                      </td>

                      {/* Fee Badge */}
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${computedPayColor(s)}`}
                        >
                          {computedPayLabel(s)}
                        </span>
                      </td>

                      {/* Active Status */}
                      <td className="py-3 px-4 text-center">
                        {s.is_active ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
                            {s.enrollment_status || 'Inactive'}
                          </span>
                        )}
                      </td>

                      {/* Action buttons */}
                      <td className="py-3 px-4 text-right" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => setProfileId(s.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60"
                            title="View Profile"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditStudent(s)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10"
                            title="Edit Record"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setTransferStudent(s)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-amber-500/10"
                            title="Transfer Out"
                          >
                            <LogOut className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setToggleConfirm(s)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              s.is_active
                                ? 'text-slate-400 hover:text-rose-400 hover:bg-rose-500/10'
                                : 'text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10'
                            }`}
                            title={s.is_active ? 'Deactivate Student' : 'Reactivate Student'}
                          >
                            {s.is_active ? (
                              <ShieldAlert className="w-3.5 h-3.5" />
                            ) : (
                              <ShieldCheck className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination Footer */}
          {total > 0 && (
            <div className="p-4 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400 bg-slate-850/40">
              <p>
                Showing <span className="text-white font-bold">{(page - 1) * 50 + 1}</span> to{' '}
                <span className="text-white font-bold">{Math.min(page * 50, total)}</span> of{' '}
                <span className="text-white font-bold">{total}</span> students
              </p>
              <div className="flex items-center gap-2">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition-all flex items-center gap-1 font-semibold"
                >
                  <ChevronLeft className="w-3.5 h-3.5" /> Prev
                </button>
                <span className="px-2 font-mono text-[11px] text-slate-300">
                  Page {page} of {pages}
                </span>
                <button
                  disabled={page >= pages}
                  onClick={() => setPage(p => Math.min(pages, p + 1))}
                  className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition-all flex items-center gap-1 font-semibold"
                >
                  Next <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Profile Slide-Over Drawer */}
      {profileId && (
        <StudentProfileDrawer
          studentId={profileId}
          onClose={() => setProfileId(null)}
          onEdit={student => {
            setProfileId(null);
            setEditStudent(student);
          }}
        />
      )}

      {/* Add Student Modal */}
      {addOpen && (
        <StudentModal
          classes={classes}
          onSave={handleAdd}
          onClose={() => setAddOpen(false)}
        />
      )}

      {/* Edit Student Modal */}
      {editStudent && (
        <StudentModal
          student={editStudent}
          classes={classes}
          onSave={handleEdit}
          onClose={() => setEditStudent(null)}
        />
      )}

      {/* Bulk Promote Modal */}
      {promoteOpen && (
        <BulkPromoteModal
          classes={classes}
          onPromote={handleBulkPromote}
          onClose={() => setPromoteOpen(false)}
        />
      )}

      {/* Transfer Dialog */}
      {transferStudent && (
        <TransferModal
          student={transferStudent}
          onTransfer={handleTransfer}
          onClose={() => setTransferStudent(null)}
        />
      )}

      {/* Deactivate / Reactivate Confirm Dialog */}
      {toggleConfirm && (
        <ConfirmDialog
          title={toggleConfirm.is_active ? 'Deactivate Student' : 'Reactivate Student'}
          message={`${
            toggleConfirm.is_active
              ? `Deactivate "${toggleConfirm.name}"? They will be excluded from attendance roll-calls, exam CBT, and report sheets. All existing grade and fee records remain preserved.`
              : `Reactivate "${toggleConfirm.name}"? They will immediately regain active standing on their class roll call.`
          }`}
          confirmLabel={toggleConfirm.is_active ? 'Deactivate' : 'Reactivate'}
          danger={Boolean(toggleConfirm.is_active)}
          onConfirm={() => handleToggleActive(toggleConfirm)}
          onCancel={() => setToggleConfirm(null)}
        />
      )}

      {/* Toast Feedback */}
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
