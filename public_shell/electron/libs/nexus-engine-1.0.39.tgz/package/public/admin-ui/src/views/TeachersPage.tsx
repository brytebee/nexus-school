import React, { useEffect, useState, useCallback, useMemo } from 'react';
import Header from '../components/Header';
import {
  Users, UserPlus, Pencil, Trash2, X, Check, Loader2, AlertTriangle,
  RefreshCw, Search, KeyRound, BookOpen, GraduationCap, ChevronDown,
  ShieldCheck, ShieldOff, Plus
} from 'lucide-react';

// ── Types ─────────────────────────────────────────────────────────────────────
interface Teacher {
  id: string;
  name: string;
  phone: string;
  email: string;
  is_active: 0 | 1;
  sync_revoked: 0 | 1;
  form_class: string | null;
  allocation_count: number;
}

interface Allocation {
  id: number;
  class_name: string;
  subject: string;
}

interface ArmEntry { id: number; arm: string; student_count: number; }
interface ClassConfig { hierarchy_class: string; arms: ArmEntry[]; }
interface SubjectEntry { name: string; grading_scope: string; }

// ── Helpers ───────────────────────────────────────────────────────────────────
function getToken() { return localStorage.getItem('nexus_admin_token') || ''; }
function authHeaders(): Record<string, string> {
  return { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' };
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function Toast({ msg, type, onClose }: { msg: string; type: 'ok' | 'err'; onClose: () => void }) {
  useEffect(() => { const t = setTimeout(onClose, 4000); return () => clearTimeout(t); }, [onClose]);
  return (
    <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl shadow-2xl text-sm font-semibold border ${
      type === 'ok'
        ? 'bg-emerald-900/90 border-emerald-600 text-emerald-200'
        : 'bg-rose-900/90 border-rose-600 text-rose-200'
    }`}>
      {type === 'ok' ? <Check className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-rose-400" />}
      {msg}
      <button onClick={onClose} className="ml-2 opacity-60 hover:opacity-100"><X className="w-3.5 h-3.5" /></button>
    </div>
  );
}

// ── Confirm Dialog ────────────────────────────────────────────────────────────
function ConfirmDialog({
  message, confirmLabel = 'Confirm', danger = false, onConfirm, onCancel
}: { message: string; confirmLabel?: string; danger?: boolean; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-8 w-full max-w-sm mx-4 space-y-5">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-xl border shrink-0 ${danger ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' : 'bg-amber-500/10 border-amber-500/20 text-amber-400'}`}>
            <AlertTriangle className="w-5 h-5" />
          </div>
          <p className="text-sm text-slate-200 leading-relaxed">{message}</p>
        </div>
        <div className="flex gap-3 justify-end">
          <button onClick={onCancel} className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700 transition-all">Cancel</button>
          <button onClick={onConfirm} className={`px-4 py-2 rounded-xl text-xs font-bold text-white transition-all ${danger ? 'bg-rose-600 hover:bg-rose-500' : 'bg-amber-600 hover:bg-amber-500'}`}>
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Add / Edit Teacher Modal ───────────────────────────────────────────────────
function TeacherModal({
  teacher,
  onSave,
  onClose,
}: {
  teacher?: Teacher;
  onSave: (data: { name: string; phone: string; email: string; reset_password?: boolean }) => Promise<void>;
  onClose: () => void;
}) {
  const isEdit = Boolean(teacher);
  const [name, setName] = useState(teacher?.name || '');
  const [phone, setPhone] = useState(teacher?.phone || '');
  const [email, setEmail] = useState(teacher?.email || '');
  const [resetPwd, setResetPwd] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handle = async () => {
    if (!name.trim()) { setErr('Name is required'); return; }
    setSaving(true); setErr('');
    try {
      await onSave({ name: name.trim(), phone: phone.trim(), email: email.trim(), reset_password: resetPwd });
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : 'Error saving teacher');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl p-8 w-full max-w-md mx-4 space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-black text-base">{isEdit ? 'Edit Teacher Profile' : 'Add New Teacher'}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Full Name *</label>
            <input
              autoFocus
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors"
              placeholder="e.g. Mrs. Adaeze Okafor"
              value={name}
              onChange={e => setName(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Phone</label>
            <input
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors"
              placeholder="08012345678"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              type="tel"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Email (login ID)</label>
            <input
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors"
              placeholder="teacher@school.edu"
              value={email}
              onChange={e => setEmail(e.target.value)}
              type="email"
            />
          </div>

          {isEdit && (
            <label className="flex items-center gap-3 cursor-pointer group">
              <div
                onClick={() => setResetPwd(v => !v)}
                className={`w-10 h-6 rounded-full transition-all ${resetPwd ? 'bg-amber-500' : 'bg-slate-700'} relative flex items-center cursor-pointer`}
              >
                <span className={`absolute w-4 h-4 bg-white rounded-full shadow transition-all ${resetPwd ? 'left-5' : 'left-1'}`} />
              </div>
              <span className="text-xs text-slate-300 group-hover:text-white">
                Reset password to <code className="text-amber-400 font-mono">staff001$</code>
              </span>
            </label>
          )}

          {!isEdit && (
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
              <p className="text-xs text-amber-300">Default login password: <code className="font-mono font-bold">staff001$</code></p>
            </div>
          )}
        </div>

        {err && <p className="text-xs text-rose-400">{err}</p>}

        <div className="flex gap-3 justify-end pt-1">
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-slate-700/60 hover:bg-slate-700">Cancel</button>
          <button
            onClick={handle}
            disabled={saving}
            className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            {isEdit ? 'Save Changes' : 'Create Teacher'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Allocation Manager Slide-Over ─────────────────────────────────────────────
function AllocationManager({
  teacher,
  classes,
  subjectPool,
  onClose,
  onUpdated,
}: {
  teacher: Teacher;
  classes: ClassConfig[];
  subjectPool: SubjectEntry[];
  onClose: () => void;
  onUpdated: () => void;
}) {
  const [allocations, setAllocations] = useState<Allocation[]>([]);
  const [loadingAllocs, setLoadingAllocs] = useState(true);
  const [selClass, setSelClass] = useState('');
  const [selArm, setSelArm] = useState('');
  const [selSubject, setSelSubject] = useState('');
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [formClass, setFormClass] = useState(teacher.form_class || '');
  const [savingFormClass, setSavingFormClass] = useState(false);
  const [err, setErr] = useState('');
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);

  const showToast = (msg: string, type: 'ok' | 'err') => setToast({ msg, type });

  const availableArms = useMemo(() => {
    const found = classes.find(c => c.hierarchy_class === selClass);
    return found ? found.arms : [];
  }, [classes, selClass]);

  const compositeClass = useMemo(() => {
    if (!selClass) return '';
    return selArm ? `${selClass} ${selArm}` : selClass;
  }, [selClass, selArm]);

  const flatClassOptions = useMemo(() => {
    const opts: string[] = [];
    for (const c of classes) {
      if (c.arms.length > 0) c.arms.forEach(a => opts.push(`${c.hierarchy_class} ${a.arm}`));
      else opts.push(c.hierarchy_class);
    }
    return opts;
  }, [classes]);

  const loadAllocations = useCallback(async () => {
    setLoadingAllocs(true);
    try {
      const res = await fetch(`/api/admin/teachers/${teacher.id}/allocations`, { headers: authHeaders() });
      const data = await res.json();
      if (data.ok) setAllocations(data.allocations || []);
    } catch { /* ignore */ }
    finally { setLoadingAllocs(false); }
  }, [teacher.id]);

  useEffect(() => { loadAllocations(); }, [loadAllocations]);

  const handleAddAlloc = async () => {
    if (!compositeClass || !selSubject) { setErr('Select a class and subject'); return; }
    setSaving(true); setErr('');
    try {
      const res = await fetch(`/api/admin/teachers/${teacher.id}/allocations`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ class_name: compositeClass, subject: selSubject }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Failed to add allocation');
      showToast(`${selSubject} → ${compositeClass} added`, 'ok');
      setSelSubject('');
      await loadAllocations();
      onUpdated();
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : 'Error');
    } finally { setSaving(false); }
  };

  const handleDeleteAlloc = async (id: number) => {
    setDeletingId(id);
    try {
      const res = await fetch(`/api/admin/teachers/allocations/${id}`, { method: 'DELETE', headers: authHeaders() });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      await loadAllocations();
      onUpdated();
    } catch (e: unknown) {
      showToast(e instanceof Error ? e.message : 'Error deleting', 'err');
    } finally { setDeletingId(null); }
  };

  const handleSaveFormClass = async () => {
    setSavingFormClass(true);
    try {
      const res = await fetch(`/api/admin/teachers/${teacher.id}/form-class`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ class_name: formClass }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      showToast(formClass ? `Form class set to ${formClass}` : 'Form class unassigned', 'ok');
      onUpdated();
    } catch (e: unknown) {
      showToast(e instanceof Error ? e.message : 'Error', 'err');
    } finally { setSavingFormClass(false); }
  };

  const groupedAllocs = useMemo(() => {
    const map: Record<string, Allocation[]> = {};
    for (const a of allocations) {
      if (!map[a.class_name]) map[a.class_name] = [];
      map[a.class_name].push(a);
    }
    return map;
  }, [allocations]);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-t-3xl sm:rounded-3xl shadow-2xl w-full max-w-xl mx-0 sm:mx-4 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-700/60 shrink-0">
          <div>
            <h3 className="text-white font-black text-base">{teacher.name}</h3>
            <p className="text-[11px] text-slate-400">Allocation Manager</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="overflow-y-auto flex-1 px-6 py-5 space-y-6">
          {/* Form Class */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-sky-400" /> Form Class
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <select
                  value={formClass}
                  onChange={e => setFormClass(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-sky-500 appearance-none pr-8"
                >
                  <option value="">— No form class —</option>
                  {flatClassOptions.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
              </div>
              <button
                onClick={handleSaveFormClass}
                disabled={savingFormClass}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-sky-600 hover:bg-sky-500 text-white disabled:opacity-50 transition-all shrink-0"
              >
                {savingFormClass ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                Save
              </button>
            </div>
          </div>

          {/* 3-column cascading allocation picker */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-emerald-400" /> Add Subject Allocation
            </label>
            <div className="grid grid-cols-3 gap-2">
              <div className="relative">
                <select
                  value={selClass}
                  onChange={e => { setSelClass(e.target.value); setSelArm(''); setSelSubject(''); }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 appearance-none pr-5"
                >
                  <option value="">Class</option>
                  {classes.map(c => <option key={c.hierarchy_class} value={c.hierarchy_class}>{c.hierarchy_class}</option>)}
                </select>
                <ChevronDown className="absolute right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none" />
              </div>
              <div className="relative">
                <select
                  value={selArm}
                  onChange={e => setSelArm(e.target.value)}
                  disabled={availableArms.length === 0}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 appearance-none pr-5 disabled:opacity-40"
                >
                  <option value="">All arms</option>
                  {availableArms.map(a => <option key={a.id} value={a.arm}>{a.arm}</option>)}
                </select>
                <ChevronDown className="absolute right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none" />
              </div>
              <div className="relative">
                <select
                  value={selSubject}
                  onChange={e => setSelSubject(e.target.value)}
                  disabled={!selClass}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 appearance-none pr-5 disabled:opacity-40"
                >
                  <option value="">Subject</option>
                  {subjectPool.map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
                </select>
                <ChevronDown className="absolute right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none" />
              </div>
            </div>
            {err && <p className="text-xs text-rose-400">{err}</p>}
            <button
              onClick={handleAddAlloc}
              disabled={saving || !compositeClass || !selSubject}
              className="flex items-center gap-2 mt-1 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50 transition-all"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
              Add Allocation
            </button>
          </div>

          {/* Current allocations */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Current Allocations ({allocations.length})
            </label>
            {loadingAllocs ? (
              <div className="flex items-center gap-2 text-xs text-slate-500 py-4">
                <Loader2 className="w-4 h-4 animate-spin" /> Loading…
              </div>
            ) : allocations.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-3">No subject allocations assigned yet.</p>
            ) : (
              <div className="space-y-2">
                {Object.entries(groupedAllocs).map(([className, classAllocs]) => (
                  <div key={className} className="rounded-xl border border-slate-700/60 bg-slate-900/40 overflow-hidden">
                    <div className="px-4 py-2 bg-slate-800/60 border-b border-slate-700/40">
                      <p className="text-[11px] font-black text-slate-300 uppercase tracking-wider">{className}</p>
                    </div>
                    <div className="divide-y divide-slate-700/30">
                      {classAllocs.map(alloc => (
                        <div key={alloc.id} className="flex items-center justify-between px-4 py-2.5 group hover:bg-slate-800/30">
                          <span className="text-xs text-slate-200">{alloc.subject}</span>
                          <button
                            onClick={() => handleDeleteAlloc(alloc.id)}
                            disabled={deletingId === alloc.id}
                            className="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all disabled:opacity-50"
                          >
                            {deletingId === alloc.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      </div>
    </div>
  );
}

// ── Teacher Table Row ─────────────────────────────────────────────────────────
function TeacherRow({
  teacher,
  onEdit,
  onToggleActive,
  onOpenAllocations,
}: {
  teacher: Teacher;
  onEdit: () => void;
  onToggleActive: () => void;
  onOpenAllocations: () => void;
}) {
  return (
    <tr className="group border-b border-slate-800/60 hover:bg-slate-800/30 transition-colors">
      <td className="px-4 py-3">
        <div>
          <p className="text-sm font-bold text-white">{teacher.name}</p>
          {teacher.email && <p className="text-[11px] text-slate-400 font-mono">{teacher.email}</p>}
          {teacher.phone && <p className="text-[11px] text-slate-500">{teacher.phone}</p>}
        </div>
      </td>
      <td className="px-4 py-3 text-center">
        {teacher.is_active ? (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Active
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-700/40 border border-slate-600/40 text-slate-400 text-[11px] font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" /> Inactive
          </span>
        )}
      </td>
      <td className="px-4 py-3 text-center">
        {teacher.form_class ? (
          <span className="px-2.5 py-1 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-400 text-[11px] font-bold">
            {teacher.form_class}
          </span>
        ) : (
          <span className="text-[11px] text-slate-600">—</span>
        )}
      </td>
      <td className="px-4 py-3 text-center">
        <button
          onClick={onOpenAllocations}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-bold transition-all"
        >
          <BookOpen className="w-3 h-3" /> {teacher.allocation_count}
        </button>
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-1.5 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={onEdit}
            className="p-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"
            title="Edit profile"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onToggleActive}
            className={`p-1.5 rounded-lg transition-colors ${teacher.is_active ? 'text-slate-400 hover:text-amber-400 hover:bg-amber-500/10' : 'text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10'}`}
            title={teacher.is_active ? 'Deactivate' : 'Activate'}
          >
            {teacher.is_active ? <ShieldOff className="w-3.5 h-3.5" /> : <ShieldCheck className="w-3.5 h-3.5" />}
          </button>
        </div>
      </td>
    </tr>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export default function TeachersPage() {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [classes, setClasses] = useState<ClassConfig[]>([]);
  const [subjectPool, setSubjectPool] = useState<SubjectEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [editTeacher, setEditTeacher] = useState<Teacher | null>(null);
  const [allocTeacher, setAllocTeacher] = useState<Teacher | null>(null);
  const [toggleConfirm, setToggleConfirm] = useState<Teacher | null>(null);

  const showToast = (msg: string, type: 'ok' | 'err') => setToast({ msg, type });

  const loadAll = useCallback(async (silent = false) => {
    if (!silent) setLoading(true); else setRefreshing(true);
    try {
      const [tRes, cRes, sRes] = await Promise.all([
        fetch('/api/admin/teachers', { headers: authHeaders() }),
        fetch('/api/admin/classes', { headers: authHeaders() }),
        fetch('/api/admin/subjects/pool', { headers: authHeaders() }),
      ]);
      const [tData, cData, sData] = await Promise.all([tRes.json(), cRes.json(), sRes.json()]);
      if (tData.ok) setTeachers(tData.teachers || []);
      if (cData.ok) setClasses(cData.classes || []);
      if (sData.ok) {
        const combined: SubjectEntry[] = [
          ...(sData.custom_subjects || []),
          ...(sData.standard_subjects || []),
        ];
        setSubjectPool(combined);
      }
    } catch {
      showToast('Network error loading data', 'err');
    } finally {
      setLoading(false); setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const filteredTeachers = useMemo(() => {
    const q = search.toLowerCase();
    return teachers.filter(t => {
      const matchFilter = filter === 'all' || (filter === 'active' ? t.is_active : !t.is_active);
      const matchSearch = !q || t.name.toLowerCase().includes(q) || t.email.toLowerCase().includes(q) || t.phone.includes(q);
      return matchFilter && matchSearch;
    });
  }, [teachers, search, filter]);

  const handleAdd = async (data: { name: string; phone: string; email: string }) => {
    const res = await fetch('/api/admin/teachers', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(data),
    });
    const resp = await res.json();
    if (!resp.ok) throw new Error(resp.error || 'Failed to create teacher');
    showToast(`Teacher "${data.name}" created — password: staff001$`, 'ok');
    setAddOpen(false);
    await loadAll(true);
  };

  const handleEdit = async (data: { name: string; phone: string; email: string; reset_password?: boolean }) => {
    if (!editTeacher) return;
    const res = await fetch(`/api/admin/teachers/${editTeacher.id}`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify(data),
    });
    const resp = await res.json();
    if (!resp.ok) throw new Error(resp.error || 'Failed to update');
    showToast('Profile updated', 'ok');
    setEditTeacher(null);
    await loadAll(true);
  };

  const handleToggleActive = async (teacher: Teacher) => {
    const res = await fetch(`/api/admin/teachers/${teacher.id}`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify({ is_active: teacher.is_active ? 0 : 1 }),
    });
    const resp = await res.json();
    if (!resp.ok) { showToast(resp.error || 'Failed', 'err'); return; }
    showToast(`${teacher.name} ${teacher.is_active ? 'deactivated' : 'activated'}`, 'ok');
    setToggleConfirm(null);
    await loadAll(true);
  };

  const activeCount = teachers.filter(t => t.is_active).length;

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Faculty &amp; Allocations" subtitle="Teacher profiles, subject assignments &amp; form masters" />

      <div className="p-6 max-w-6xl mx-auto w-full space-y-5">
        {/* Stats bar */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Total Faculty', value: teachers.length, color: 'text-white' },
            { label: 'Active', value: activeCount, color: 'text-emerald-400' },
            { label: 'Inactive', value: teachers.length - activeCount, color: 'text-slate-400' },
          ].map(stat => (
            <div key={stat.label} className="bg-slate-800/40 border border-slate-700/60 rounded-2xl px-4 py-3">
              <p className={`text-xl font-black ${stat.color}`}>{stat.value}</p>
              <p className="text-[11px] text-slate-500">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
            <input
              className="w-full bg-slate-800/60 border border-slate-700/60 rounded-xl pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors placeholder-slate-500"
              placeholder="Search by name, email, phone…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="flex rounded-xl overflow-hidden border border-slate-700/60 shrink-0">
            {(['all', 'active', 'inactive'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-2 text-xs font-bold capitalize transition-all ${filter === f ? 'bg-slate-700 text-white' : 'bg-slate-800/40 text-slate-400 hover:text-white'}`}
              >
                {f}
              </button>
            ))}
          </div>
          <button
            onClick={() => loadAll(true)}
            disabled={refreshing}
            className="p-2 rounded-xl bg-slate-800/60 border border-slate-700/60 text-slate-400 hover:text-white hover:bg-slate-700 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setAddOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shrink-0"
          >
            <UserPlus className="w-3.5 h-3.5" /> Add Teacher
          </button>
        </div>

        {/* Table */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3 text-slate-500">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
            <p className="text-xs font-semibold">Loading faculty roster…</p>
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-700/60 bg-slate-800/20 overflow-hidden">
            {filteredTeachers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3 text-slate-500">
                <Users className="w-10 h-10 opacity-30" />
                <p className="text-sm font-bold">No teachers found</p>
                {search && <p className="text-xs">Try clearing the search filter</p>}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-700/60">
                      <th className="px-4 py-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Name</th>
                      <th className="px-4 py-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center">Status</th>
                      <th className="px-4 py-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center">Form Class</th>
                      <th className="px-4 py-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center">Subjects</th>
                      <th className="px-4 py-3" />
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTeachers.map(teacher => (
                      <TeacherRow
                        key={teacher.id}
                        teacher={teacher}
                        onEdit={() => setEditTeacher(teacher)}
                        onToggleActive={() => setToggleConfirm(teacher)}
                        onOpenAllocations={() => setAllocTeacher(teacher)}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      {addOpen && <TeacherModal onSave={handleAdd} onClose={() => setAddOpen(false)} />}
      {editTeacher && <TeacherModal teacher={editTeacher} onSave={handleEdit} onClose={() => setEditTeacher(null)} />}
      {allocTeacher && (
        <AllocationManager
          teacher={allocTeacher}
          classes={classes}
          subjectPool={subjectPool}
          onClose={() => setAllocTeacher(null)}
          onUpdated={() => loadAll(true)}
        />
      )}
      {toggleConfirm && (
        <ConfirmDialog
          message={`${toggleConfirm.is_active ? 'Deactivate' : 'Activate'} "${toggleConfirm.name}"? ${
            toggleConfirm.is_active
              ? 'They will lose access to the staff portal and grading.'
              : 'They will regain portal access immediately.'
          }`}
          confirmLabel={toggleConfirm.is_active ? 'Deactivate' : 'Activate'}
          danger={Boolean(toggleConfirm.is_active)}
          onConfirm={() => handleToggleActive(toggleConfirm)}
          onCancel={() => setToggleConfirm(null)}
        />
      )}
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
