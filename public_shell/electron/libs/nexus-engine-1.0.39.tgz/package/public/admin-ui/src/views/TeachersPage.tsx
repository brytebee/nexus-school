import React from 'react';
import Header from '../components/Header';
import { Users, UserPlus, CheckCircle2 } from 'lucide-react';

export default function TeachersPage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="Faculty & Allocations" subtitle="Teacher profiles, subject assignments & form masters (Phase 7b)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/20 text-sky-400">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Teacher &amp; Allocation Hub</h3>
              <p className="text-xs text-slate-400">Manage teaching faculty credentials, assigned class arms, and form teacher privileges</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Teachers assigned here immediately gain access to their class roll-call registers and grading sheets both on the local LAN staff portal (<code className="text-emerald-400 font-mono">/staff</code>) and on paired mobile Android devices.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7b Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
