import React, { useState, useEffect, useCallback, useRef } from 'react';
import Header from '../components/Header';
import {
  MonitorCheck, BookOpen, PlayCircle, BarChart3, Plus, Trash2, Eye,
  ChevronDown, ChevronRight, RefreshCw, X, Check, AlertCircle,
  Users, Clock, Award, TrendingUp, Zap, Shield, FileText,
  CheckCircle2, AlertTriangle, Upload, Download, Edit2, Search, Copy, ChevronLeft
} from 'lucide-react';

// ─── Auth helper ─────────────────────────────────────────────────────────────
function authHeaders(): Record<string, string> {
  const token = localStorage.getItem('nexus_admin_token');
  return token ? { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
}

// ─── Types ────────────────────────────────────────────────────────────────────
interface QuestionBank {
  id: number;
  name: string;
  subject: string;
  class_category: string;
  description: string;
  question_count: number;
  created_at: string;
}

interface Question {
  id: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: 'A' | 'B' | 'C' | 'D';
  marks: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

interface CbtExam {
  id: number;
  title: string;
  class_name: string;
  bank_name: string;
  bank_subject: string;
  academic_session: string;
  term: string;
  question_count: number;
  duration_minutes: number;
  status: 'draft' | 'active' | 'completed';
  pass_mark_percentage: number;
  exam_date: string | null;
  start_time: string | null;
  end_time: string | null;
  shuffle_questions: number;
  shuffle_options: number;
  assessment_mapping: string | null;
  result_release_policy: string;
  token_count: number;
  submitted_count: number;
  active_count: number;
  allow_mobile_clients?: number;
  created_at: string;
  // Pillar 1B additions
  pc_count?: number;
  negative_marks?: number;
  target_classes?: string;
  instructions?: string;
  calculator_type?: string;
}

interface CbtToken {
  id: number;
  token: string;
  status: 'unused' | 'active' | 'submitted';
  score: number | null;
  started_at: string | null;
  submitted_at: string | null;
  tab_switches: number;
  time_remaining_seconds?: number | null;
  last_sync_at?: string | null;
  answered_count?: number;
  hard_deadline_at?: string | null;
  makeup_reason?: string | null;
  active_session_id?: string | null;
  student_id?: string;
  student_name: string;
  class_name: string;
  class_arm: string;
  admission_no: string;
  parent_name?: string | null;
  parent_phone?: string | null;
}

interface QuestionReviewItem {
  index: number;
  id: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
  selected_option: string | null;
  is_correct: number;
  status: 'correct' | 'incorrect' | 'unattempted';
  marks: number;
  marks_awarded: number;
  difficulty: string;
}

interface StudentDetailedReview {
  student: {
    id: number;
    student_id: string;
    token: string;
    status: string;
    score: number;
    max_score: number;
    percentage: number;
    passed: boolean;
    pass_mark: number;
    submitted_at: string | null;
    started_at: string | null;
    tab_switches: number;
    student_name: string;
    admission_no: string;
    class_name: string;
    class_arm: string;
    parent_name?: string | null;
    parent_phone?: string | null;
    exam_title: string;
  };
  summary: {
    total_questions: number;
    attempted_count: number;
    unattempted_count: number;
    correct_count: number;
    wrong_count: number;
    score: number;
    max_score: number;
    percentage: number;
  };
  questions: QuestionReviewItem[];
}

interface ExamResult {
  summary: {
    total_students: number;
    passed: number;
    failed: number;
    pass_rate: number;
    avg_score: number;
    max_score: number;
    pass_mark: number;
  };
  students: Array<{ id: number; student_name: string; score: number; submitted_at: string; tab_switches: number; class_arm: string; admission_no: string }>;
  question_analytics: Array<{ id: number; question_text: string; correct_option: string; attempts: number; correct_count: number }>;
}

// ─── Toast ───────────────────────────────────────────────────────────────────
function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error' | 'info'; onClose: () => void }) {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, [onClose]);
  const colours = { success: 'bg-emerald-900/90 border-emerald-500/40 text-emerald-300', error: 'bg-red-900/90 border-red-500/40 text-red-300', info: 'bg-indigo-900/90 border-indigo-500/40 text-indigo-300' };
  const Icon = type === 'success' ? CheckCircle2 : type === 'error' ? AlertTriangle : AlertCircle;
  return (
    <div className={`fixed bottom-6 right-6 z-[9999] flex items-center gap-3 px-4 py-3 rounded-2xl border shadow-2xl backdrop-blur-sm ${colours[type]}`}>
      <Icon className="w-4 h-4 shrink-0" />
      <span className="text-sm font-medium">{message}</span>
      <button onClick={onClose} className="ml-2 opacity-60 hover:opacity-100"><X className="w-3.5 h-3.5" /></button>
    </div>
  );
}

// ─── ConfirmDialog ────────────────────────────────────────────────────────────
function ConfirmDialog({ title, message, onConfirm, onCancel, danger = false }: {
  title: string; message: string; onConfirm: () => void; onCancel: () => void; danger?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-xl ${danger ? 'bg-red-500/10 border border-red-500/20' : 'bg-amber-500/10 border border-amber-500/20'}`}>
            <AlertTriangle className={`w-5 h-5 ${danger ? 'text-red-400' : 'text-amber-400'}`} />
          </div>
          <div>
            <h3 className="font-bold text-white">{title}</h3>
            <p className="text-sm text-slate-400 mt-1">{message}</p>
          </div>
        </div>
        <div className="flex gap-3 justify-end">
          <button onClick={onCancel} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
          <button onClick={onConfirm} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${danger ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-amber-600 hover:bg-amber-500 text-white'}`}>Confirm</button>
        </div>
      </div>
    </div>
  );
}

// ─── Difficulty badge ─────────────────────────────────────────────────────────
function DiffBadge({ d }: { d: string }) {
  const map: Record<string, string> = { easy: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20', hard: 'bg-red-500/10 text-red-400 border-red-500/20' };
  return <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase ${map[d] || map.medium}`}>{d}</span>;
}

// ─── Status badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    draft: 'bg-slate-700 text-slate-300 border-slate-600',
    active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    completed: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
    unused: 'bg-slate-700 text-slate-400 border-slate-600',
    submitted: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  };
  return <span className={`px-2.5 py-0.5 rounded-full border text-[11px] font-semibold capitalize ${map[status] || map.draft}`}>{status}</span>;
}

// ─── Debounced Multi-Param Candidate Search Picker ─────────────────────────────
interface CandidateSearchPickerProps {
  examId: number;
  onSelect: (candidate: CbtToken) => void;
  selectedTokenId?: number | null;
  placeholder?: string;
}

function CandidateSearchPicker({ examId, onSelect, selectedTokenId, placeholder }: CandidateSearchPickerProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<CbtToken[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wrapperRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (val: string) => {
    setQuery(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (val.trim().length < 2) {
      setResults([]);
      setIsOpen(false);
      return;
    }
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/admin/cbt/exams/${examId}/candidates/search?q=${encodeURIComponent(val.trim())}`, {
          headers: authHeaders()
        });
        const d = await r.json();
        if (d.ok) {
          setResults(d.candidates || []);
          setIsOpen(true);
        }
      } catch (_) {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 300);
  };

  return (
    <div ref={wrapperRef} className="relative w-full">
      <div className="relative flex items-center">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={e => handleSearch(e.target.value)}
          onFocus={() => { if (results.length > 0) setIsOpen(true); }}
          placeholder={placeholder || "Search candidate by name, student ID, admission no, parent name, or phone..."}
          className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all shadow-inner"
        />
        {query && (
          <button
            onClick={() => { setQuery(''); setResults([]); setIsOpen(false); }}
            className="absolute right-3 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        {loading && (
          <div className="absolute right-9">
            <RefreshCw className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
          </div>
        )}
      </div>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden max-h-96 overflow-y-auto">
          {results.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-500">
              No matching candidate found in this exam for &quot;{query}&quot;
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              <div className="px-3.5 py-1.5 bg-slate-800/60 text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex justify-between items-center">
                <span>Matching Candidates ({results.length})</span>
                <span className="text-[10px] text-slate-500 normal-case">Click a candidate to view record</span>
              </div>
              {results.map(cand => (
                <div
                  key={cand.id}
                  onClick={() => {
                    onSelect(cand);
                    setIsOpen(false);
                  }}
                  className={`p-3.5 hover:bg-indigo-600/10 cursor-pointer transition-colors flex items-start justify-between gap-3 ${selectedTokenId === cand.id ? 'bg-indigo-600/20 border-l-4 border-indigo-500' : ''}`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-white text-sm">{cand.student_name}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-indigo-300 border border-slate-700">
                        {cand.class_name} {cand.class_arm}
                      </span>
                      <StatusBadge status={cand.status} />
                    </div>
                    <div className="mt-1 flex items-center gap-3 text-xs text-slate-400 flex-wrap">
                      {cand.admission_no && <span>Adm: <strong className="text-slate-300">{cand.admission_no}</strong></span>}
                      {cand.student_id && <span>ID: <strong className="text-slate-300">{cand.student_id}</strong></span>}
                      {cand.parent_name && (
                        <span>Parent: <strong className="text-slate-300">{cand.parent_name}</strong></span>
                      )}
                      {cand.parent_phone && (
                        <span>Phone: <strong className="text-slate-300">{cand.parent_phone}</strong></span>
                      )}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono text-xs font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-1 rounded-lg">
                      {cand.token}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 1: QUESTION BANKS
// ═══════════════════════════════════════════════════════════════════════════════
function QuestionBanksTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBank, setSelectedBank] = useState<QuestionBank | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [qPage, setQPage] = useState(1);
  const [qTotal, setQTotal] = useState(0);
  const [qLoading, setQLoading] = useState(false);
  const [showNewBank, setShowNewBank] = useState(false);
  const [showAddQuestion, setShowAddQuestion] = useState(false);
  const [editingBank, setEditingBank] = useState<QuestionBank | null>(null);
  const [editBankForm, setEditBankForm] = useState({ name: '', subject: '', class_category: 'General', description: '' });
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [editQForm, setEditQForm] = useState({ question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'A' as 'A' | 'B' | 'C' | 'D', marks: '1', difficulty: 'medium' as 'easy' | 'medium' | 'hard' });
  const [confirmDeleteBank, setConfirmDeleteBank] = useState<QuestionBank | null>(null);
  const [confirmDeleteQ, setConfirmDeleteQ] = useState<Question | null>(null);
  const [newBank, setNewBank] = useState({ name: '', subject: '', class_category: 'General', description: '' });
  const [newQ, setNewQ] = useState({ question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'A', marks: '1', difficulty: 'medium' });

  const fetchBanks = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/admin/cbt/banks', { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setBanks(d.banks);
    } catch { toast('Failed to load question banks', 'error'); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { fetchBanks(); }, [fetchBanks]);

  const fetchQuestions = useCallback(async (bankId: number, page: number) => {
    setQLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/banks/${bankId}/questions?page=${page}&limit=50`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { setQuestions(d.questions); setQTotal(d.total); }
    } catch { toast('Failed to load questions', 'error'); }
    finally { setQLoading(false); }
  }, [toast]);

  useEffect(() => {
    if (selectedBank) fetchQuestions(selectedBank.id, qPage);
  }, [selectedBank, qPage, fetchQuestions]);

  const handleCreateBank = async () => {
    if (!newBank.name || !newBank.subject) return toast('Name and subject required', 'error');
    try {
      const r = await fetch('/api/admin/cbt/banks', { method: 'POST', headers: authHeaders(), body: JSON.stringify(newBank) });
      const d = await r.json();
      if (d.ok) { toast('Bank created', 'success'); setShowNewBank(false); setNewBank({ name: '', subject: '', class_category: 'General', description: '' }); fetchBanks(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleDeleteBank = async (bank: QuestionBank) => {
    try {
      const r = await fetch(`/api/admin/cbt/banks/${bank.id}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Bank deleted', 'success'); fetchBanks(); if (selectedBank?.id === bank.id) setSelectedBank(null); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmDeleteBank(null);
  };

  const handleAddQuestion = async () => {
    if (!selectedBank) return;
    if (!newQ.question_text || !newQ.option_a || !newQ.option_b || !newQ.option_c || !newQ.option_d) {
      return toast('All fields required', 'error');
    }
    try {
      const r = await fetch(`/api/admin/cbt/banks/${selectedBank.id}/questions`, {
        method: 'POST', headers: authHeaders(), body: JSON.stringify(newQ)
      });
      const d = await r.json();
      if (d.ok) {
        toast(`Question added (${d.total} total)`, 'success');
        setShowAddQuestion(false);
        setNewQ({ question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'A', marks: '1', difficulty: 'medium' });
        fetchQuestions(selectedBank.id, qPage);
        fetchBanks();
      } else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleDeleteQuestion = async (q: Question) => {
    try {
      const r = await fetch(`/api/admin/cbt/questions/${q.id}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Question deleted', 'success'); if (selectedBank) fetchQuestions(selectedBank.id, qPage); fetchBanks(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmDeleteQ(null);
  };

  const handleUpdateBank = async () => {
    if (!editingBank) return;
    if (!editBankForm.name || !editBankForm.subject) return toast('Name and subject required', 'error');
    try {
      const r = await fetch(`/api/admin/cbt/banks/${editingBank.id}`, {
        method: 'PUT',
        headers: authHeaders(),
        body: JSON.stringify(editBankForm)
      });
      const d = await r.json();
      if (d.ok) {
        toast('Bank updated', 'success');
        setEditingBank(null);
        fetchBanks();
        if (selectedBank?.id === editingBank.id) {
          setSelectedBank(prev => prev ? { ...prev, ...editBankForm } : null);
        }
      } else toast(d.error || 'Failed to update bank', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleUpdateQuestion = async () => {
    if (!editingQuestion || !selectedBank) return;
    if (!editQForm.question_text || !editQForm.option_a || !editQForm.option_b || !editQForm.option_c || !editQForm.option_d) {
      return toast('All fields required', 'error');
    }
    try {
      const r = await fetch(`/api/admin/cbt/questions/${editingQuestion.id}`, {
        method: 'PUT',
        headers: authHeaders(),
        body: JSON.stringify(editQForm)
      });
      const d = await r.json();
      if (d.ok) {
        toast('Question updated', 'success');
        setEditingQuestion(null);
        fetchQuestions(selectedBank.id, qPage);
      } else toast(d.error || 'Failed to update question', 'error');
    } catch { toast('Network error', 'error'); }
  };

  return (
    <div className="space-y-6">
      {/* Banks grid */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Question Banks</h2>
          <p className="text-xs text-slate-400 mt-0.5">{banks.length} bank{banks.length !== 1 ? 's' : ''} available</p>
        </div>
        <button onClick={() => setShowNewBank(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold transition-colors">
          <Plus className="w-4 h-4" /> New Bank
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading banks…</div>
      ) : banks.length === 0 ? (
        <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
          <BookOpen className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-semibold">No question banks yet</p>
          <p className="text-slate-500 text-sm mt-1">Create your first bank to start adding questions</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {banks.map(bank => (
            <div
              key={bank.id}
              onClick={() => { setSelectedBank(bank); setQPage(1); }}
              className={`p-5 rounded-2xl border cursor-pointer transition-all ${selectedBank?.id === bank.id ? 'bg-indigo-900/30 border-indigo-500/40 ring-1 ring-indigo-500/30' : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                  <BookOpen className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={(e) => { e.stopPropagation(); setEditingBank(bank); setEditBankForm({ name: bank.name, subject: bank.subject, class_category: bank.class_category || 'General', description: bank.description || '' }); }} className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-400 hover:bg-indigo-500/10 transition-colors" title="Edit Bank">
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); setConfirmDeleteBank(bank); }} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors" title="Delete Bank">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <h3 className="font-bold text-white text-sm leading-tight">{bank.name}</h3>
              <p className="text-xs text-indigo-400 mt-0.5">{bank.subject}</p>
              {bank.description && <p className="text-xs text-slate-500 mt-1 line-clamp-2">{bank.description}</p>}
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs text-slate-400">{bank.class_category}</span>
                <span className="text-xs font-bold text-emerald-400">{bank.question_count} Q</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Question list panel */}
      {selectedBank && (
        <div className="bg-slate-800/40 border border-slate-700/60 rounded-3xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
            <div>
              <h3 className="font-bold text-white">{selectedBank.name}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{qTotal} question{qTotal !== 1 ? 's' : ''} · {selectedBank.subject}</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => { setShowAddQuestion(true); }} className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-semibold hover:bg-emerald-600/30 transition-colors">
                <Plus className="w-3.5 h-3.5" /> Add Question
              </button>
              <button onClick={() => setSelectedBank(null)} className="p-1.5 rounded-lg text-slate-500 hover:text-white transition-colors"><X className="w-4 h-4" /></button>
            </div>
          </div>

          {qLoading ? (
            <div className="flex items-center justify-center h-24 text-slate-500 text-sm">Loading questions…</div>
          ) : questions.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-sm">No questions yet. Add your first question.</div>
          ) : (
            <div className="divide-y divide-slate-700/40">
              {questions.map((q, i) => (
                <div key={q.id} className="px-5 py-4 hover:bg-slate-800/60 transition-colors">
                  <div className="flex items-start gap-3">
                    <span className="text-[11px] font-bold text-slate-500 mt-0.5 w-6 shrink-0">{(qPage - 1) * 50 + i + 1}.</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-200 leading-snug">{q.question_text}</p>
                      <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1">
                        {(['A', 'B', 'C', 'D'] as const).map(opt => (
                          <div key={opt} className={`text-xs flex items-center gap-1.5 ${q.correct_option === opt ? 'text-emerald-400 font-semibold' : 'text-slate-400'}`}>
                            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${q.correct_option === opt ? 'bg-emerald-500/20 border border-emerald-500/30' : 'bg-slate-700 border border-slate-600'}`}>{opt}</span>
                            {q[`option_${opt.toLowerCase()}` as keyof Question] as string}
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <DiffBadge d={q.difficulty} />
                        <span className="text-[10px] text-slate-500">{q.marks} mark{q.marks !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={(e) => { e.stopPropagation(); setEditingQuestion(q); setEditQForm({ question_text: q.question_text, option_a: q.option_a, option_b: q.option_b, option_c: q.option_c, option_d: q.option_d, correct_option: q.correct_option, marks: String(q.marks), difficulty: q.difficulty }); }} className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-400 hover:bg-indigo-500/10 transition-colors" title="Edit Question">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => setConfirmDeleteQ(q)} className="p-1.5 rounded-lg text-slate-600 hover:text-red-400 hover:bg-red-500/10 transition-colors shrink-0" title="Delete Question">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {qTotal > 50 && (
            <div className="px-5 py-3 border-t border-slate-700/60 flex items-center justify-between">
              <span className="text-xs text-slate-400">Showing {(qPage - 1) * 50 + 1}–{Math.min(qPage * 50, qTotal)} of {qTotal}</span>
              <div className="flex gap-2">
                <button disabled={qPage === 1} onClick={() => setQPage(p => p - 1)} className="px-3 py-1 rounded-lg bg-slate-700 text-slate-300 text-xs disabled:opacity-40">Prev</button>
                <button disabled={qPage * 50 >= qTotal} onClick={() => setQPage(p => p + 1)} className="px-3 py-1 rounded-lg bg-slate-700 text-slate-300 text-xs disabled:opacity-40">Next</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* New Bank Drawer */}
      {showNewBank && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">New Question Bank</h3>
              <button onClick={() => setShowNewBank(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Bank Name *</label>
                <input value={newBank.name} onChange={e => setNewBank(p => ({ ...p, name: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS 2 Mathematics Q3" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Subject *</label>
                <input value={newBank.subject} onChange={e => setNewBank(p => ({ ...p, subject: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. Mathematics" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Class Category</label>
                <input value={newBank.class_category} onChange={e => setNewBank(p => ({ ...p, class_category: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Description</label>
                <textarea value={newBank.description} onChange={e => setNewBank(p => ({ ...p, description: e.target.value }))} rows={2} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="Optional description" />
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowNewBank(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleCreateBank} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Create Bank</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Question Modal */}
      {showAddQuestion && selectedBank && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-4 my-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">Add Question — {selectedBank.name}</h3>
              <button onClick={() => setShowAddQuestion(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Question Text *</label>
                <textarea value={newQ.question_text} onChange={e => setNewQ(p => ({ ...p, question_text: e.target.value }))} rows={3} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="Enter the question…" />
              </div>
              {(['a', 'b', 'c', 'd'] as const).map(opt => (
                <div key={opt}>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Option {opt.toUpperCase()} *</label>
                  <input value={newQ[`option_${opt}` as keyof typeof newQ]} onChange={e => setNewQ(p => ({ ...p, [`option_${opt}`]: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              ))}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Correct Answer *</label>
                  <select value={newQ.correct_option} onChange={e => setNewQ(p => ({ ...p, correct_option: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Marks</label>
                  <input type="number" min="1" max="10" value={newQ.marks} onChange={e => setNewQ(p => ({ ...p, marks: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Difficulty</label>
                  <select value={newQ.difficulty} onChange={e => setNewQ(p => ({ ...p, difficulty: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowAddQuestion(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleAddQuestion} className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-colors">Save Question</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Bank Modal */}
      {editingBank && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">Edit Question Bank</h3>
              <button onClick={() => setEditingBank(null)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Bank Name *</label>
                <input value={editBankForm.name} onChange={e => setEditBankForm(p => ({ ...p, name: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS 2 Mathematics Q3" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Subject *</label>
                <input value={editBankForm.subject} onChange={e => setEditBankForm(p => ({ ...p, subject: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. Mathematics" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Class Category</label>
                <input value={editBankForm.class_category} onChange={e => setEditBankForm(p => ({ ...p, class_category: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Description</label>
                <textarea value={editBankForm.description} onChange={e => setEditBankForm(p => ({ ...p, description: e.target.value }))} rows={2} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="Optional description" />
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setEditingBank(null)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleUpdateBank} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Question Modal */}
      {editingQuestion && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-4 my-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">Edit Question</h3>
              <button onClick={() => setEditingQuestion(null)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Question Text *</label>
                <textarea value={editQForm.question_text} onChange={e => setEditQForm(p => ({ ...p, question_text: e.target.value }))} rows={3} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="Enter the question…" />
              </div>
              {(['a', 'b', 'c', 'd'] as const).map(opt => (
                <div key={opt}>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Option {opt.toUpperCase()} *</label>
                  <input value={editQForm[`option_${opt}` as keyof typeof editQForm]} onChange={e => setEditQForm(p => ({ ...p, [`option_${opt}`]: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              ))}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Correct Answer *</label>
                  <select value={editQForm.correct_option} onChange={e => setEditQForm(p => ({ ...p, correct_option: e.target.value as 'A' | 'B' | 'C' | 'D' }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Marks</label>
                  <input type="number" min="1" max="10" value={editQForm.marks} onChange={e => setEditQForm(p => ({ ...p, marks: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Difficulty</label>
                  <select value={editQForm.difficulty} onChange={e => setEditQForm(p => ({ ...p, difficulty: e.target.value as 'easy' | 'medium' | 'hard' }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setEditingQuestion(null)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleUpdateQuestion} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm delete bank */}
      {confirmDeleteBank && (
        <ConfirmDialog
          title="Delete Bank"
          message={`Delete "${confirmDeleteBank.name}" and all its ${confirmDeleteBank.question_count} questions? This cannot be undone.`}
          danger
          onConfirm={() => handleDeleteBank(confirmDeleteBank)}
          onCancel={() => setConfirmDeleteBank(null)}
        />
      )}

      {/* Confirm delete question */}
      {confirmDeleteQ && (
        <ConfirmDialog
          title="Delete Question"
          message="Remove this question from the bank?"
          danger
          onConfirm={() => handleDeleteQuestion(confirmDeleteQ)}
          onCancel={() => setConfirmDeleteQ(null)}
        />
      )}
    </div>
  );
}

// ─── Time Trio Helpers ────────────────────────────────────────────────────────
function calculateEndTime(start: string, durationMinutes: number): string {
  if (!start || isNaN(durationMinutes) || durationMinutes <= 0) return '';
  const [h, m] = start.split(':').map(Number);
  if (isNaN(h) || isNaN(m)) return '';
  const total = h * 60 + m + Number(durationMinutes);
  const endH = Math.floor(total / 60) % 24;
  const endM = total % 60;
  return `${String(endH).padStart(2, '0')}:${String(endM).padStart(2, '0')}`;
}

function calculateDuration(start: string, end: string): number {
  if (!start || !end) return 0;
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  if (isNaN(sh) || isNaN(sm) || isNaN(eh) || isNaN(em)) return 0;
  let diff = (eh * 60 + em) - (sh * 60 + sm);
  if (diff <= 0) diff += 24 * 60;
  return diff;
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 2: EXAMS
// ═══════════════════════════════════════════════════════════════════════════════
function ExamsTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [exams, setExams] = useState<CbtExam[]>([]);
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [classes, setClasses] = useState<string[]>([]);
  const [classArmsMap, setClassArmsMap] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(true);
  const [showNewExam, setShowNewExam] = useState(false);
  const [selectedExam, setSelectedExam] = useState<CbtExam | null>(null);
  const [tokens, setTokens] = useState<CbtToken[]>([]);
  const [tokensLoading, setTokensLoading] = useState(false);
  const [showTokens, setShowTokens] = useState(false);
  const [confirmActivate, setConfirmActivate] = useState<CbtExam | null>(null);
  const [confirmClose, setConfirmClose] = useState<CbtExam | null>(null);
  const [confirmGenTokens, setConfirmGenTokens] = useState<CbtExam | null>(null);
  const [confirmDeleteExam, setConfirmDeleteExam] = useState<CbtExam | null>(null);
  const [deleteSudoPin, setDeleteSudoPin] = useState('');
  const [deleteSudoError, setDeleteSudoError] = useState('');
  const [deleteSudoLoading, setDeleteSudoLoading] = useState(false);

  // Auto-Batch Scheduler state (Pillar 1B.1)
  const [showAutoBatch, setShowAutoBatch] = useState(false);
  const [autoBatchExam, setAutoBatchExam] = useState<CbtExam | null>(null);
  const [autoBatchDate, setAutoBatchDate] = useState('');
  const [autoBatchStart, setAutoBatchStart] = useState('08:00');
  const [autoBatchDuration, setAutoBatchDuration] = useState('60');
  const [autoBatchBuffer, setAutoBatchBuffer] = useState('15');
  const [autoBatchPcOverride, setAutoBatchPcOverride] = useState('');
  const [autoBatchLoading, setAutoBatchLoading] = useState(false);
  const [autoBatchTokens, setAutoBatchTokens] = useState<CbtToken[]>([]);
  const [autoBatchInferredCount, setAutoBatchInferredCount] = useState(0);

  // Makeup Token state (Pillar 1.4 & 1.5)
  const [showMakeupModal, setShowMakeupModal] = useState(false);
  const [makeupExam, setMakeupExam] = useState<CbtExam | null>(null);
  const [eligibleCandidates, setEligibleCandidates] = useState<Array<{
    id: string;
    name: string;
    class_name: string;
    class_arm?: string;
    admission_no?: string;
    token_id?: number | null;
    token?: string | null;
    token_status?: string | null;
    score?: number | null;
    makeup_reason?: string | null;
  }>>([]);
  const [candidatesLoading, setCandidatesLoading] = useState(false);
  const [makeupStudentId, setMakeupStudentId] = useState('');
  const [makeupReason, setMakeupReason] = useState('');
  const [makeupLoading, setMakeupLoading] = useState(false);
  const [makeupSearch, setMakeupSearch] = useState('');
  const [selectedMakeupStudent, setSelectedMakeupStudent] = useState<{ id: string; name: string; class_name: string; class_arm?: string; admission_no?: string } | null>(null);

  const [editingExam, setEditingExam] = useState<CbtExam | null>(null);
  const [editExamForm, setEditExamForm] = useState({
    title: '', class_name: '', question_count: '20', duration_minutes: '60',
    pass_mark_percentage: '50', shuffle_questions: true, shuffle_options: true,
    exam_date: '', start_time: '', end_time: '',
    assessment_mapping_assessment: '', assessment_mapping_subject: '',
    result_release_policy: 'immediate',
    allow_mobile_clients: true,
    pc_count: '30',
    instructions: '',
    negative_marks: '0',
    calculator_type: 'none',
    selected_arms: [] as string[],
    is_all_arms: true
  });
  const [newExam, setNewExam] = useState({
    title: '', bank_id: '', class_name: '', question_count: '20', duration_minutes: '60',
    pass_mark_percentage: '50', shuffle_questions: true, shuffle_options: true,
    exam_date: '', start_time: '', end_time: '',
    assessment_mapping_assessment: '', assessment_mapping_subject: '',
    result_release_policy: 'immediate',
    allow_mobile_clients: true,
    pc_count: '30',
    instructions: '',
    negative_marks: '0',
    calculator_type: 'none',
    selected_arms: [] as string[],
    is_all_arms: true
  });

  const fetchExams = useCallback(async () => {
    setLoading(true);
    try {
      const [er, br] = await Promise.all([
        fetch('/api/admin/cbt/exams', { headers: authHeaders() }),
        fetch('/api/admin/cbt/banks', { headers: authHeaders() }),
      ]);
      const [ed, bd] = await Promise.all([er.json(), br.json()]);
      if (ed.ok) setExams(ed.exams);
      if (bd.ok) setBanks(bd.banks);
    } catch { toast('Failed to load exams', 'error'); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { fetchExams(); }, [fetchExams]);

  // Fetch class list and arms for dropdowns and arm selector
  useEffect(() => {
    fetch('/api/admin/classes', { headers: authHeaders() })
      .then(r => r.json())
      .then(d => {
        if (d.ok || Array.isArray(d.classes)) {
          const armsMap: Record<string, string[]> = {};
          const cls: string[] = [];
          (d.classes || []).forEach((c: any) => {
            const name = c.class_name || c.hierarchy_class || '';
            if (name) {
              cls.push(name);
              if (Array.isArray(c.arms)) {
                armsMap[name] = c.arms.map((a: any) => (typeof a === 'string' ? a : a.arm)).filter(Boolean);
              }
            }
          });
          setClasses([...new Set(cls)] as string[]);
          setClassArmsMap(armsMap);
        }
      })
      .catch(() => {});
  }, []);

  const fetchTokens = useCallback(async (exam: CbtExam) => {
    setTokensLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/tokens`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setTokens(d.tokens);
    } catch { toast('Failed to load tokens', 'error'); }
    finally { setTokensLoading(false); }
  }, [toast]);

  const handleCreateExam = async () => {
    if (!newExam.title || !newExam.bank_id || !newExam.class_name || !newExam.question_count || !newExam.duration_minutes) {
      return toast('Fill all required fields', 'error');
    }
    const targetClasses = newExam.is_all_arms
      ? []
      : newExam.selected_arms.map(arm => `${newExam.class_name} ${arm}`);

    const payload: Record<string, unknown> = {
      title: newExam.title, bank_id: Number(newExam.bank_id),
      class_name: newExam.class_name, question_count: Number(newExam.question_count),
      duration_minutes: Number(newExam.duration_minutes),
      pass_mark_percentage: Number(newExam.pass_mark_percentage),
      shuffle_questions: newExam.shuffle_questions, shuffle_options: newExam.shuffle_options,
      exam_date: newExam.exam_date || null, start_time: newExam.start_time || null, end_time: newExam.end_time || null,
      result_release_policy: newExam.result_release_policy,
      allow_mobile_clients: newExam.allow_mobile_clients ? 1 : 0,
      pc_count: Number(newExam.pc_count) || 30,
      instructions: newExam.instructions || '',
      negative_marks: Number(newExam.negative_marks) || 0,
      calculator_type: newExam.calculator_type || 'none',
      target_classes: targetClasses,
    };
    if (newExam.assessment_mapping_assessment && newExam.assessment_mapping_subject) {
      payload.assessment_mapping = { assessment: newExam.assessment_mapping_assessment, subject: newExam.assessment_mapping_subject };
    }
    try {
      const r = await fetch('/api/admin/cbt/exams', { method: 'POST', headers: authHeaders(), body: JSON.stringify(payload) });
      const d = await r.json();
      if (d.ok) { toast('Exam created', 'success'); setShowNewExam(false); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleActivate = async (exam: CbtExam) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/activate`, { method: 'PATCH', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Exam activated', 'success'); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmActivate(null);
  };

  const handleClose = async (exam: CbtExam) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/close`, { method: 'PATCH', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Exam closed', 'success'); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmClose(null);
  };

  const handleGenTokens = async (exam: CbtExam) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/tokens`, { method: 'POST', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast(`${d.generated} token${d.generated !== 1 ? 's' : ''} generated (${d.total} students in class)`, 'success'); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmGenTokens(null);
  };

  const handleUpdateExam = async () => {
    if (!editingExam) return;
    try {
      const targetClasses = editExamForm.is_all_arms
        ? []
        : editExamForm.selected_arms.map(arm => `${editExamForm.class_name} ${arm}`);

      const payload: Record<string, unknown> = {
        title: editExamForm.title,
        class_name: editExamForm.class_name,
        target_classes: targetClasses,
        question_count: Number(editExamForm.question_count),
        duration_minutes: Number(editExamForm.duration_minutes),
        pass_mark_percentage: Number(editExamForm.pass_mark_percentage),
        exam_date: editExamForm.exam_date || null,
        start_time: editExamForm.start_time || null,
        end_time: editExamForm.end_time || null,
        shuffle_questions: editExamForm.shuffle_questions,
        shuffle_options: editExamForm.shuffle_options,
        allow_mobile_clients: editExamForm.allow_mobile_clients ? 1 : 0,
        result_release_policy: editExamForm.result_release_policy,
        pc_count: Number(editExamForm.pc_count) || 30,
        instructions: editExamForm.instructions,
        negative_marks: Number(editExamForm.negative_marks) || 0,
        calculator_type: editExamForm.calculator_type || 'none',
      };
      if (editExamForm.assessment_mapping_assessment && editExamForm.assessment_mapping_subject) {
        payload.assessment_mapping = {
          assessment: editExamForm.assessment_mapping_assessment,
          subject: editExamForm.assessment_mapping_subject
        };
      }
      const r = await fetch(`/api/admin/cbt/exams/${editingExam.id}`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify(payload)
      });
      const d = await r.json();
      if (d.ok) {
        toast('Exam updated successfully', 'success');
        setEditingExam(null);
        fetchExams();
      } else {
        toast(d.error || 'Failed to update exam', 'error');
      }
    } catch (err: any) {
      toast(err.message, 'error');
    }
  };

  const handleDeleteExam = async (exam: CbtExam) => {
    if (!deleteSudoPin.trim()) {
      setDeleteSudoError('Superadmin PIN or password is required.');
      return;
    }
    setDeleteSudoLoading(true);
    setDeleteSudoError('');
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}`, {
        method: 'DELETE',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ pin: deleteSudoPin.trim() })
      });
      const d = await r.json();
      if (d.ok) {
        toast(d.message || 'Exam deleted successfully', 'success');
        setConfirmDeleteExam(null);
        setDeleteSudoPin('');
        fetchExams();
      } else {
        setDeleteSudoError(d.error || 'Failed to delete exam');
      }
    } catch (err: any) {
      setDeleteSudoError(err.message || 'Network error');
    } finally {
      setDeleteSudoLoading(false);
    }
  };

  const handleOpenAutoBatch = async (exam: CbtExam) => {
    setAutoBatchExam(exam);
    setAutoBatchDate(exam.exam_date || new Date().toISOString().split('T')[0]);
    setAutoBatchStart(exam.start_time || '08:00');
    setAutoBatchDuration(String(exam.duration_minutes || 60));
    setAutoBatchBuffer('15');
    setAutoBatchPcOverride(String(exam.pc_count || 30));
    setAutoBatchInferredCount(0);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/tokens`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok && d.tokens) setAutoBatchTokens(d.tokens);
      else setAutoBatchTokens([]);
    } catch {
      setAutoBatchTokens([]);
    }
    // Always fetch inferred candidate count from enrolled students
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/eligible-candidates`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok && typeof d.total === 'number') setAutoBatchInferredCount(d.total);
    } catch {
      // non-critical — keep as 0
    }
    setShowAutoBatch(true);
  };

  const handleExecuteAutoBatch = async () => {
    if (!autoBatchExam) return;
    if (!autoBatchDate || !autoBatchStart) {
      toast('Exam date and start time are required', 'error');
      return;
    }
    setAutoBatchLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${autoBatchExam.id}/auto-batches`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          exam_date: autoBatchDate,
          start_time: autoBatchStart,
          duration_minutes: Number(autoBatchDuration) || Number(autoBatchExam.duration_minutes) || 60,
          inter_batch_buffer_minutes: Number(autoBatchBuffer) || 15,
          pc_count: autoBatchPcOverride ? Number(autoBatchPcOverride) : undefined,
        })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Auto-batch failed');
      toast(`${d.batches_created} batch${d.batches_created !== 1 ? 'es' : ''} created for ${d.total_candidates} candidates (${d.pc_count} PCs each)`, 'success');
      setShowAutoBatch(false);
      fetchExams();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setAutoBatchLoading(false);
    }
  };

  const handleOpenMakeup = async (exam: CbtExam) => {
    setMakeupExam(exam);
    setSelectedMakeupStudent(null);
    setMakeupStudentId('');
    setMakeupSearch('');
    setMakeupReason('');
    setShowMakeupModal(true);
    setCandidatesLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/eligible-candidates`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok && Array.isArray(d.candidates)) {
        setEligibleCandidates(d.candidates);
      } else {
        setEligibleCandidates([]);
      }
    } catch {
      setEligibleCandidates([]);
      toast('Failed to load eligible candidates for exam', 'error');
    } finally {
      setCandidatesLoading(false);
    }
  };

  const handleExecuteMakeup = async () => {
    if (!makeupExam) return;
    if (!makeupStudentId) {
      toast('Please select a student', 'error');
      return;
    }
    if (!makeupReason.trim()) {
      toast('Mandatory reason required for makeup token', 'error');
      return;
    }
    setMakeupLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${makeupExam.id}/tokens/individual`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          student_id: makeupStudentId,
          reason: makeupReason.trim()
        })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Failed to issue makeup token');
      toast(`Makeup token ${d.token} issued for ${d.student_name}!`, 'success');
      setShowMakeupModal(false);
      setMakeupStudentId('');
      setMakeupReason('');
      fetchExams();
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setMakeupLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Exams</h2>
          <p className="text-xs text-slate-400 mt-0.5">{exams.length} exam{exams.length !== 1 ? 's' : ''} configured</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchExams} className="p-2 rounded-xl bg-slate-700 text-slate-400 hover:text-white transition-colors"><RefreshCw className="w-4 h-4" /></button>
          <button onClick={() => setShowNewExam(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold transition-colors">
            <Plus className="w-4 h-4" /> New Exam
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading…</div>
      ) : exams.length === 0 ? (
        <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
          <PlayCircle className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-semibold">No exams created yet</p>
          <p className="text-slate-500 text-sm mt-1">Create an exam and link it to a question bank</p>
        </div>
      ) : (
        <div className="space-y-3">
          {exams.map(exam => (
            <div key={exam.id} className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden">
              <div className="p-5">
                <div className="flex items-start gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-white">{exam.title}</h3>
                      <StatusBadge status={exam.status} />
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-slate-400">
                      <span>📚 {exam.bank_name} ({exam.bank_subject})</span>
                      {(() => {
                        let targets: string[] = [];
                        try {
                          if (exam.target_classes) {
                            targets = typeof exam.target_classes === 'string'
                              ? JSON.parse(exam.target_classes)
                              : (Array.isArray(exam.target_classes) ? exam.target_classes : []);
                          }
                        } catch (_) {}
                        if (!targets.length || (targets.length === 1 && (targets[0] === exam.class_name || targets[0].includes('All Arms')))) {
                          return <span>🏫 {exam.class_name} <span className="text-slate-500 font-normal">(All Arms)</span></span>;
                        }
                        const armNames = targets.map(t => t.replace(exam.class_name, '').trim()).filter(Boolean);
                        return (
                          <span>
                            🏫 {exam.class_name}
                            <span className="text-indigo-400 font-medium"> ({armNames.length ? armNames.join(', ') : targets.join(', ')})</span>
                          </span>
                        );
                      })()}
                      <span>❓ {exam.question_count} Q</span>
                      <span>⏱ {exam.duration_minutes} min</span>
                      <span>✅ Pass: {exam.pass_mark_percentage}%</span>
                      {exam.exam_date && <span>📅 {exam.exam_date}</span>}
                    </div>
                    <div className="mt-2 flex items-center gap-3 text-xs">
                      <span className="text-slate-400">{exam.token_count} tokens</span>
                      <span className="text-emerald-400">{exam.submitted_count} submitted</span>
                      {exam.active_count > 0 && <span className="text-amber-400 animate-pulse">{exam.active_count} live now</span>}
                    </div>
                  </div>

                    {/* Actions */}
                  <div className="flex flex-wrap gap-2 shrink-0">
                    {exam.status === 'draft' && (
                      <button onClick={() => setConfirmActivate(exam)} className="px-3 py-1.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-semibold hover:bg-emerald-600/30 transition-colors flex items-center gap-1">
                        <Zap className="w-3 h-3" /> Activate
                      </button>
                    )}
                    {exam.status === 'active' && (
                      <button onClick={() => setConfirmClose(exam)} className="px-3 py-1.5 bg-red-600/20 border border-red-500/30 text-red-400 rounded-xl text-xs font-semibold hover:bg-red-600/30 transition-colors">
                        Close Exam
                      </button>
                    )}
                    <button onClick={() => setConfirmGenTokens(exam)} className="px-3 py-1.5 bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 rounded-xl text-xs font-semibold hover:bg-indigo-600/30 transition-colors flex items-center gap-1">
                      <Users className="w-3 h-3" /> Gen Tokens
                    </button>
                    <button
                      onClick={() => handleOpenAutoBatch(exam)}
                      className="px-3 py-1.5 bg-teal-600/20 border border-teal-500/30 text-teal-300 rounded-xl text-xs font-semibold hover:bg-teal-600/30 transition-colors flex items-center gap-1 shadow-xs"
                      title="Auto-Schedule Exam Batches & Sittings"
                    >
                      <span className="text-teal-400">⚡</span> Auto-Schedule
                    </button>
                    <button
                      onClick={() => handleOpenMakeup(exam)}
                      className="px-3 py-1.5 bg-purple-600/20 border border-purple-500/30 text-purple-300 rounded-xl text-xs font-semibold hover:bg-purple-600/30 transition-colors flex items-center gap-1 shadow-xs"
                      title="Issue Individual Makeup Token"
                    >
                      <Plus className="w-3 h-3" /> Makeup
                    </button>
                    <button
                      onClick={() => handleToggleMobile(exam)}
                      title={exam.allow_mobile_clients === 0 ? 'Mobile clients blocked — click to allow' : 'Mobile clients allowed — click to block'}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors flex items-center gap-1 ${exam.allow_mobile_clients === 0 ? 'bg-rose-600/20 border-rose-500/30 text-rose-400 hover:bg-rose-600/30' : 'bg-slate-700/60 border-slate-600 text-slate-400 hover:bg-slate-600 hover:text-slate-200'}`}
                    >
                      {exam.allow_mobile_clients === 0 ? '📵 Mobile Off' : '📱 Mobile On'}
                    </button>
                    <button onClick={() => { setSelectedExam(exam); setShowTokens(true); fetchTokens(exam); }} className="px-3 py-1.5 bg-slate-700 border border-slate-600 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-600 transition-colors flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Tokens
                    </button>
                    {/* Edit Exam */}
                    <button
                      onClick={() => {
                        let mapping = { assessment: '', subject: '' };
                        try { if (exam.assessment_mapping) mapping = JSON.parse(exam.assessment_mapping); } catch (_) {}

                        let parsedTargets: string[] = [];
                        try {
                          if (exam.target_classes) {
                            parsedTargets = typeof exam.target_classes === 'string'
                              ? JSON.parse(exam.target_classes)
                              : (Array.isArray(exam.target_classes) ? exam.target_classes : []);
                          }
                        } catch (_) {}

                        const isAll = !parsedTargets.length || (parsedTargets.length === 1 && (parsedTargets[0] === exam.class_name || parsedTargets[0].includes('All Arms')));
                        const initialArms: string[] = [];
                        if (!isAll) {
                          parsedTargets.forEach(t => {
                            const trimmed = t.replace(exam.class_name, '').trim();
                            if (trimmed) initialArms.push(trimmed);
                            else initialArms.push(t.trim());
                          });
                        }

                        setEditingExam(exam);
                        setEditExamForm({
                          title: exam.title,
                          class_name: exam.class_name,
                          question_count: String(exam.question_count),
                          duration_minutes: String(exam.duration_minutes),
                          pass_mark_percentage: String(exam.pass_mark_percentage),
                          shuffle_questions: exam.shuffle_questions !== 0,
                          shuffle_options: exam.shuffle_options !== 0,
                          exam_date: exam.exam_date || '',
                          start_time: exam.start_time || '',
                          end_time: exam.end_time || '',
                          assessment_mapping_assessment: mapping.assessment || '',
                          assessment_mapping_subject: mapping.subject || '',
                          result_release_policy: exam.result_release_policy || 'immediate',
                          allow_mobile_clients: exam.allow_mobile_clients !== 0,
                          pc_count: String(exam.pc_count || 30),
                          instructions: exam.instructions || '',
                          negative_marks: String(exam.negative_marks || 0),
                          calculator_type: exam.calculator_type || 'none',
                          selected_arms: initialArms,
                          is_all_arms: isAll
                        });
                      }}
                      className="px-3 py-1.5 bg-blue-600/20 border border-blue-500/30 text-blue-400 rounded-xl text-xs font-semibold hover:bg-blue-600/30 transition-colors flex items-center gap-1"
                      title="Edit Exam Configuration"
                    >
                      <Edit2 className="w-3 h-3" /> Edit
                    </button>
                    {/* Delete Exam (only if no submitted candidate answers) */}
                    {exam.submitted_count === 0 && (
                      <button
                        onClick={() => setConfirmDeleteExam(exam)}
                        className="px-3 py-1.5 bg-rose-600/20 border border-rose-500/30 text-rose-400 rounded-xl text-xs font-semibold hover:bg-rose-600/30 transition-colors flex items-center gap-1"
                        title="Delete Exam"
                      >
                        <Trash2 className="w-3 h-3" /> Delete
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tokens slide-over */}
      {showTokens && selectedExam && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-sm">
          <div className="bg-slate-900 border-l border-slate-700 w-full max-w-lg flex flex-col h-full shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
              <div>
                <h3 className="font-bold text-white">Tokens — {selectedExam.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{tokens.length} candidate{tokens.length !== 1 ? 's' : ''}</p>
              </div>
              <button onClick={() => setShowTokens(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {tokensLoading ? (
                <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading…</div>
              ) : tokens.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-sm">No tokens generated yet.</div>
              ) : (
                <div className="divide-y divide-slate-800">
                  {tokens.map(tk => (
                    <div key={tk.id} className="px-5 py-3 hover:bg-slate-800/40 transition-colors">
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-white truncate">{tk.student_name || '—'}</p>
                          <p className="text-xs text-slate-400">{tk.class_name} {tk.class_arm}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-mono text-xs text-indigo-400 font-bold tracking-widest">{tk.token}</p>
                          <div className="flex items-center justify-end gap-2 mt-0.5">
                            <StatusBadge status={tk.status} />
                            {tk.score !== null && <span className="text-xs text-emerald-400 font-bold">{tk.score} pts</span>}
                          </div>
                        </div>
                      </div>
                      {tk.tab_switches > 0 && (
                        <p className="text-[10px] text-amber-400 mt-1">⚠ {tk.tab_switches} tab switch{tk.tab_switches !== 1 ? 'es' : ''}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Exam Modal */}
      {showNewExam && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-4 my-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">New Exam</h3>
              <button onClick={() => setShowNewExam(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Title *</label>
                <input value={newExam.title} onChange={e => setNewExam(p => ({ ...p, title: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS 2 Mid-Term Mathematics" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Question Bank *</label>
                  <select value={newExam.bank_id} onChange={e => setNewExam(p => ({ ...p, bank_id: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="">Select bank…</option>
                    {banks.map(b => <option key={b.id} value={b.id}>{b.name} ({b.question_count}Q)</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Target Class *</label>
                  {classes.length > 0 ? (
                    <select
                      value={newExam.class_name}
                      onChange={e => setNewExam(p => ({ ...p, class_name: e.target.value, selected_arms: [], is_all_arms: true }))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">Select class…</option>
                      {classes.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  ) : (
                    <input
                      value={newExam.class_name}
                      onChange={e => setNewExam(p => ({ ...p, class_name: e.target.value, selected_arms: [], is_all_arms: true }))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                      placeholder="e.g. JSS 2"
                    />
                  )}
                </div>
              </div>

              {/* Arm Selector (Multi-arm with All Arms default) */}
              {newExam.class_name && (classArmsMap[newExam.class_name]?.length || 0) > 0 && (
                <div className="space-y-1.5 p-3 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-slate-400 font-semibold block">Target Arm(s)</label>
                    <span className="text-[11px] text-indigo-400 font-medium">
                      {newExam.is_all_arms
                        ? 'All arms included (Default)'
                        : `${newExam.selected_arms.length} arm${newExam.selected_arms.length !== 1 ? 's' : ''} selected`}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setNewExam(p => ({ ...p, is_all_arms: true, selected_arms: [] }))}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                        newExam.is_all_arms
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700/80'
                      }`}
                    >
                      ✓ All Arms (Default)
                    </button>
                    {(classArmsMap[newExam.class_name] || []).map(arm => {
                      const isSelected = !newExam.is_all_arms && newExam.selected_arms.includes(arm);
                      return (
                        <button
                          key={arm}
                          type="button"
                          onClick={() => {
                            const avail = classArmsMap[newExam.class_name] || [];
                            if (newExam.is_all_arms) {
                              setNewExam(p => ({ ...p, is_all_arms: false, selected_arms: [arm] }));
                            } else {
                              if (newExam.selected_arms.includes(arm)) {
                                const next = newExam.selected_arms.filter(a => a !== arm);
                                setNewExam(p => ({
                                  ...p,
                                  is_all_arms: next.length === 0,
                                  selected_arms: next
                                }));
                              } else {
                                const next = [...newExam.selected_arms, arm];
                                setNewExam(p => ({
                                  ...p,
                                  is_all_arms: next.length === avail.length,
                                  selected_arms: next.length === avail.length ? [] : next
                                }));
                              }
                            }
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                            isSelected
                              ? 'bg-indigo-500/20 border border-indigo-500/60 text-indigo-300 font-semibold'
                              : 'bg-slate-800 border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
                          }`}
                        >
                          {arm}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">No. of Questions *</label>
                  <input type="number" min="1" value={newExam.question_count} onChange={e => setNewExam(p => ({ ...p, question_count: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Duration (min) *</label>
                  <input
                    type="number"
                    min="5"
                    value={newExam.duration_minutes}
                    onChange={e => {
                      const d = e.target.value;
                      setNewExam(p => ({
                        ...p,
                        duration_minutes: d,
                        end_time: p.start_time && Number(d) > 0 ? calculateEndTime(p.start_time, Number(d)) : p.end_time
                      }));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Pass Mark %</label>
                  <input type="number" min="0" max="100" value={newExam.pass_mark_percentage} onChange={e => setNewExam(p => ({ ...p, pass_mark_percentage: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Date</label>
                  <input type="date" value={newExam.exam_date} onChange={e => setNewExam(p => ({ ...p, exam_date: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Start Time</label>
                  <input
                    type="time"
                    value={newExam.start_time}
                    onChange={e => {
                      const st = e.target.value;
                      setNewExam(p => ({
                        ...p,
                        start_time: st,
                        end_time: st && Number(p.duration_minutes) > 0 ? calculateEndTime(st, Number(p.duration_minutes)) : p.end_time
                      }));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">End Time</label>
                  <input
                    type="time"
                    value={newExam.end_time}
                    onChange={e => {
                      const et = e.target.value;
                      setNewExam(p => ({
                        ...p,
                        end_time: et,
                        duration_minutes: p.start_time && et ? String(calculateDuration(p.start_time, et)) : p.duration_minutes
                      }));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
              <div className="flex gap-6 flex-wrap">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={newExam.shuffle_questions} onChange={e => setNewExam(p => ({ ...p, shuffle_questions: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Shuffle Questions</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={newExam.shuffle_options} onChange={e => setNewExam(p => ({ ...p, shuffle_options: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Shuffle Options</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={!!newExam.allow_mobile_clients} onChange={e => setNewExam(p => ({ ...p, allow_mobile_clients: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Allow Mobile Clients</span>
                </label>
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Result Release</label>
                <select value={newExam.result_release_policy} onChange={e => setNewExam(p => ({ ...p, result_release_policy: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                  <option value="immediate">Immediate</option>
                  <option value="delayed_30m">After 30 min</option>
                  <option value="delayed_1h">After 1 hour</option>
                  <option value="delayed_12h">After 12 hours</option>
                  <option value="delayed_24h">After 24 hours</option>
                  <option value="manual">Manual (Push to Grades)</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Candidate Calculator Mode</label>
                <select value={newExam.calculator_type} onChange={e => setNewExam(p => ({ ...p, calculator_type: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                  <option value="none">No Calculator (Strict Mental Math)</option>
                  <option value="basic">Basic Calculator (+, -, *, /)</option>
                  <option value="scientific">Scientific Calculator (Trig, Log, Powers, Sqrt)</option>
                </select>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 space-y-2">
                <p className="text-xs text-slate-400 font-semibold">Grade Push Mapping (optional)</p>
                <div className="grid grid-cols-2 gap-2">
                  <input value={newExam.assessment_mapping_assessment} onChange={e => setNewExam(p => ({ ...p, assessment_mapping_assessment: e.target.value }))} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" placeholder="Assessment (e.g. Exam)" />
                  <input value={newExam.assessment_mapping_subject} onChange={e => setNewExam(p => ({ ...p, assessment_mapping_subject: e.target.value }))} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" placeholder="Subject (e.g. Mathematics)" />
                </div>
              </div>
              {/* ── Pillar 1B: Lab Capacity + Negative Marking ── */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Lab Capacity (PCs)</label>
                  <input type="number" min="1" value={newExam.pc_count} onChange={e => setNewExam(p => ({ ...p, pc_count: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. 30" />
                  <p className="text-xs text-slate-500 mt-1">Number of PCs in lab — used to auto-schedule sittings.</p>
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Negative Marking (per wrong answer)</label>
                  <input type="number" min="0" max="5" step="0.25" value={newExam.negative_marks} onChange={e => setNewExam(p => ({ ...p, negative_marks: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="0 = disabled" />
                  <p className="text-xs text-slate-500 mt-1">Points deducted per wrong answer. Score clamped at 0.</p>
                </div>
              </div>
              {/* ── Pillar 1B: Subject-specific instructions (1B.4) ── */}
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Instructions <span className="text-slate-600 font-normal">(optional — shown to candidate before start)</span></label>
                <textarea value={newExam.instructions} onChange={e => setNewExam(p => ({ ...p, instructions: e.target.value }))} rows={3} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="e.g. Show all workings. Calculator not allowed. Read each question carefully." />
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowNewExam(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleCreateExam} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Create Exam</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Exam Modal */}
      {editingExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white">Edit Exam Configuration</h3>
                <p className="text-xs text-slate-400 mt-0.5">{editingExam.bank_name} ({editingExam.bank_subject})</p>
              </div>
              <button onClick={() => setEditingExam(null)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Title *</label>
                <input value={editExamForm.title} onChange={e => setEditExamForm(p => ({ ...p, title: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Target Class *</label>
                {classes.length > 0 ? (
                  <select
                    value={editExamForm.class_name}
                    onChange={e => setEditExamForm(p => ({ ...p, class_name: e.target.value, selected_arms: [], is_all_arms: true }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">Select class…</option>
                    {classes.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                ) : (
                  <input
                    value={editExamForm.class_name}
                    onChange={e => setEditExamForm(p => ({ ...p, class_name: e.target.value, selected_arms: [], is_all_arms: true }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                )}
              </div>

              {/* Arm Selector in Edit Exam */}
              {editExamForm.class_name && (classArmsMap[editExamForm.class_name]?.length || 0) > 0 && (
                <div className="space-y-1.5 p-3 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-slate-400 font-semibold block">Target Arm(s)</label>
                    <span className="text-[11px] text-indigo-400 font-medium">
                      {editExamForm.is_all_arms
                        ? 'All arms included (Default)'
                        : `${editExamForm.selected_arms.length} arm${editExamForm.selected_arms.length !== 1 ? 's' : ''} selected`}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setEditExamForm(p => ({ ...p, is_all_arms: true, selected_arms: [] }))}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                        editExamForm.is_all_arms
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700/80'
                      }`}
                    >
                      ✓ All Arms (Default)
                    </button>
                    {(classArmsMap[editExamForm.class_name] || []).map(arm => {
                      const isSelected = !editExamForm.is_all_arms && editExamForm.selected_arms.includes(arm);
                      return (
                        <button
                          key={arm}
                          type="button"
                          onClick={() => {
                            const avail = classArmsMap[editExamForm.class_name] || [];
                            if (editExamForm.is_all_arms) {
                              setEditExamForm(p => ({ ...p, is_all_arms: false, selected_arms: [arm] }));
                            } else {
                              if (editExamForm.selected_arms.includes(arm)) {
                                const next = editExamForm.selected_arms.filter(a => a !== arm);
                                setEditExamForm(p => ({
                                  ...p,
                                  is_all_arms: next.length === 0,
                                  selected_arms: next
                                }));
                              } else {
                                const next = [...editExamForm.selected_arms, arm];
                                setEditExamForm(p => ({
                                  ...p,
                                  is_all_arms: next.length === avail.length,
                                  selected_arms: next.length === avail.length ? [] : next
                                }));
                              }
                            }
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                            isSelected
                              ? 'bg-indigo-500/20 border border-indigo-500/60 text-indigo-300 font-semibold'
                              : 'bg-slate-800 border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'
                          }`}
                        >
                          {arm}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">No. of Questions *</label>
                  <input
                    type="number"
                    min="1"
                    disabled={editingExam.submitted_count > 0}
                    value={editExamForm.question_count}
                    onChange={e => setEditExamForm(p => ({ ...p, question_count: e.target.value }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 disabled:opacity-50"
                  />
                  {editingExam.submitted_count > 0 && <span className="text-[10px] text-amber-400">Locked (submissions exist)</span>}
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Duration (min) *</label>
                  <input
                    type="number"
                    min="5"
                    value={editExamForm.duration_minutes}
                    onChange={e => {
                      const d = e.target.value;
                      setEditExamForm(p => ({
                        ...p,
                        duration_minutes: d,
                        end_time: p.start_time && Number(d) > 0 ? calculateEndTime(p.start_time, Number(d)) : p.end_time
                      }));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Pass Mark %</label>
                  <input type="number" min="0" max="100" value={editExamForm.pass_mark_percentage} onChange={e => setEditExamForm(p => ({ ...p, pass_mark_percentage: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Date</label>
                  <input type="date" value={editExamForm.exam_date} onChange={e => setEditExamForm(p => ({ ...p, exam_date: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Start Time</label>
                  <input
                    type="time"
                    value={editExamForm.start_time}
                    onChange={e => {
                      const st = e.target.value;
                      setEditExamForm(p => ({
                        ...p,
                        start_time: st,
                        end_time: st && Number(p.duration_minutes) > 0 ? calculateEndTime(st, Number(p.duration_minutes)) : p.end_time
                      }));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">End Time</label>
                  <input
                    type="time"
                    value={editExamForm.end_time}
                    onChange={e => {
                      const et = e.target.value;
                      setEditExamForm(p => ({
                        ...p,
                        end_time: et,
                        duration_minutes: p.start_time && et ? String(calculateDuration(p.start_time, et)) : p.duration_minutes
                      }));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
              <div className="flex gap-6 flex-wrap">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editExamForm.shuffle_questions} onChange={e => setEditExamForm(p => ({ ...p, shuffle_questions: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Shuffle Questions</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editExamForm.shuffle_options} onChange={e => setEditExamForm(p => ({ ...p, shuffle_options: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Shuffle Options</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={!!editExamForm.allow_mobile_clients} onChange={e => setEditExamForm(p => ({ ...p, allow_mobile_clients: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Allow Mobile Clients</span>
                </label>
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Result Release</label>
                <select value={editExamForm.result_release_policy} onChange={e => setEditExamForm(p => ({ ...p, result_release_policy: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                  <option value="immediate">Immediate</option>
                  <option value="delayed_30m">After 30 min</option>
                  <option value="delayed_1h">After 1 hour</option>
                  <option value="delayed_12h">After 12 hours</option>
                  <option value="delayed_24h">After 24 hours</option>
                  <option value="manual">Manual (Push to Grades)</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Candidate Calculator Mode</label>
                <select value={editExamForm.calculator_type} onChange={e => setEditExamForm(p => ({ ...p, calculator_type: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                  <option value="none">No Calculator (Strict Mental Math)</option>
                  <option value="basic">Basic Calculator (+, -, *, /)</option>
                  <option value="scientific">Scientific Calculator (Trig, Log, Powers, Sqrt)</option>
                </select>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 space-y-2">
                <p className="text-xs text-slate-400 font-semibold">Grade Push Mapping (optional)</p>
                <div className="grid grid-cols-2 gap-2">
                  <input value={editExamForm.assessment_mapping_assessment} onChange={e => setEditExamForm(p => ({ ...p, assessment_mapping_assessment: e.target.value }))} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" placeholder="Assessment (e.g. Exam)" />
                  <input value={editExamForm.assessment_mapping_subject} onChange={e => setEditExamForm(p => ({ ...p, assessment_mapping_subject: e.target.value }))} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" placeholder="Subject (e.g. Mathematics)" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Lab Capacity (PCs)</label>
                  <input type="number" min="1" value={editExamForm.pc_count} onChange={e => setEditExamForm(p => ({ ...p, pc_count: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Negative Marking (per wrong answer)</label>
                  <input type="number" min="0" max="5" step="0.25" value={editExamForm.negative_marks} onChange={e => setEditExamForm(p => ({ ...p, negative_marks: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Instructions</label>
                <textarea value={editExamForm.instructions} onChange={e => setEditExamForm(p => ({ ...p, instructions: e.target.value }))} rows={3} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" />
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setEditingExam(null)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleUpdateExam} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {confirmActivate && <ConfirmDialog title="Activate Exam" message={`Activate "${confirmActivate.title}"? Students with tokens will be able to start immediately.`} onConfirm={() => handleActivate(confirmActivate)} onCancel={() => setConfirmActivate(null)} />}
      {confirmClose && <ConfirmDialog title="Close Exam" message={`Close "${confirmClose.title}"? Active sessions will be forcibly ended.`} danger onConfirm={() => handleClose(confirmClose)} onCancel={() => setConfirmClose(null)} />}
      {confirmGenTokens && <ConfirmDialog title="Generate Tokens" message={`Generate exam tokens for all active students in ${confirmGenTokens.class_name}? Existing tokens will not be duplicated.`} onConfirm={() => handleGenTokens(confirmGenTokens)} onCancel={() => setConfirmGenTokens(null)} />}
      {confirmDeleteExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">Authorize Exam Deletion</h3>
                <p className="text-xs text-slate-400 mt-0.5">High-Value Action · Superadmin Verification</p>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Permanently delete exam <strong className="text-white">"{confirmDeleteExam.title}"</strong>? All associated candidate tokens, batches, and records will be deleted. This action is irreversible.
            </p>
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Superadmin PIN or Password *
              </label>
              <input
                type="password"
                autoFocus
                value={deleteSudoPin}
                onChange={e => { setDeleteSudoPin(e.target.value); setDeleteSudoError(''); }}
                onKeyDown={e => { if (e.key === 'Enter') handleDeleteExam(confirmDeleteExam); }}
                placeholder="Enter Superadmin PIN or password"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 font-mono"
              />
              {deleteSudoError && (
                <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-2.5 py-1.5">
                  ⚠️ {deleteSudoError}
                </p>
              )}
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button
                onClick={() => { setConfirmDeleteExam(null); setDeleteSudoPin(''); setDeleteSudoError(''); }}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteExam(confirmDeleteExam)}
                disabled={deleteSudoLoading || !deleteSudoPin.trim()}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all disabled:opacity-50 flex items-center gap-1.5"
              >
                {deleteSudoLoading ? 'Authorizing…' : '🗑️ Authorize Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Auto-Batch Scheduler Modal */}
      {showAutoBatch && autoBatchExam && (() => {
        const pc = Number(autoBatchPcOverride) || Number(autoBatchExam.pc_count) || 30;
        const totalCandidates = autoBatchTokens.length || autoBatchInferredCount || Number(autoBatchExam.token_count) || 0;
        const willAutoGenTokens = autoBatchTokens.length === 0 && totalCandidates > 0;
        const numBatches = totalCandidates > 0 ? Math.ceil(totalCandidates / pc) : 0;
        const dur = Number(autoBatchDuration) || Number(autoBatchExam.duration_minutes) || 60;
        const buf = Number(autoBatchBuffer) || 15;

        const projection: Array<{ name: string; count: number; time: string }> = [];
        let totalWindowStr = '';
        if (autoBatchStart && numBatches > 0) {
          const [sh, sm] = autoBatchStart.split(':').map(Number);
          const startMins = (isNaN(sh) ? 8 : sh) * 60 + (isNaN(sm) ? 0 : sm);
          const toTime = (m: number) => {
            const hh = Math.floor(m / 60) % 24;
            const mm = m % 60;
            return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
          };
          for (let b = 0; b < numBatches; b++) {
            const bStartMins = startMins + b * (dur + buf);
            const bEndMins = bStartMins + dur;
            const count = b === numBatches - 1 ? (totalCandidates - b * pc) : pc;
            projection.push({ name: `Batch ${b + 1}`, count, time: `${toTime(bStartMins)} - ${toTime(bEndMins)}` });
          }
          if (projection.length > 0) {
            const finalEndMins = startMins + (numBatches - 1) * (dur + buf) + dur;
            totalWindowStr = `${toTime(startMins)} → ${toTime(finalEndMins)}`;
          }
        }

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-white flex items-center gap-2">
                    <span className="p-1 rounded-lg bg-teal-500/20 text-teal-400">⚡</span>
                    Auto-Schedule Batches
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">{autoBatchExam.title} · {autoBatchExam.class_name}</p>
                </div>
                <button onClick={() => setShowAutoBatch(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
              </div>

              {/* Exam Blueprint Card */}
              <div className="p-3 bg-slate-900/60 rounded-2xl border border-slate-700/60 grid grid-cols-3 gap-2 text-center">
                <div className="p-2 rounded-xl bg-slate-800/40">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Sitting Dur</div>
                  <div className="text-sm font-bold text-teal-400">{dur} min</div>
                </div>
                <div className="p-2 rounded-xl bg-slate-800/40">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Lab Capacity</div>
                  <div className="text-sm font-bold text-indigo-400">{pc} PCs</div>
                </div>
                <div className="p-2 rounded-xl bg-slate-800/40">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Candidates</div>
                  <div className="text-sm font-bold text-amber-400">{totalCandidates}</div>
                  {willAutoGenTokens && (
                    <div className="text-[9px] text-teal-400 font-semibold mt-0.5">⚡ Tokens auto-generated</div>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Date *</label>
                    <input type="date" value={autoBatchDate} onChange={e => setAutoBatchDate(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-teal-500" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">First Batch Start Time *</label>
                    <input type="time" value={autoBatchStart} onChange={e => setAutoBatchStart(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-teal-500" />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">Sitting (min) *</label>
                    <input type="number" min="1" value={autoBatchDuration} onChange={e => setAutoBatchDuration(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-teal-500" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">Buffer (min)</label>
                    <input type="number" min="0" value={autoBatchBuffer} onChange={e => setAutoBatchBuffer(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-teal-500" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 font-semibold mb-1 block">Lab PCs</label>
                    <input type="number" min="1" value={autoBatchPcOverride} onChange={e => setAutoBatchPcOverride(e.target.value)} placeholder={`Default: ${autoBatchExam.pc_count || 30}`} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-teal-500" />
                  </div>
                </div>

                {/* Live Schedule Projection */}
                {projection.length > 0 && (
                  <div className="p-3 bg-slate-900/90 rounded-2xl border border-teal-500/30 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-teal-300">Projected Schedule ({projection.length} Batches)</span>
                      <span className="font-mono text-emerald-400 font-bold">{totalWindowStr}</span>
                    </div>
                    <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                      {projection.map(p => (
                        <div key={p.name} className="flex items-center justify-between text-xs p-2 rounded-xl bg-slate-800/80 border border-slate-700/50">
                          <span className="font-semibold text-white">{p.name} <span className="text-slate-400 font-normal">({p.count} candidates)</span></span>
                          <span className="font-mono text-teal-300 font-medium">{p.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <p className="text-xs text-amber-400/80 bg-amber-500/10 rounded-xl px-3 py-2 border border-amber-500/20">
                  ⚠️ This will <strong>replace</strong> existing auto-generated batches for this exam and interleave candidate seeds to prevent collusion.
                </p>
              </div>
              <div className="flex gap-3 justify-end">
                <button onClick={() => setShowAutoBatch(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
                <button onClick={handleExecuteAutoBatch} disabled={autoBatchLoading} className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-sm font-semibold transition-colors disabled:opacity-50 shadow-md">
                  {autoBatchLoading ? 'Scheduling…' : 'Generate Batches'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Issue Makeup Modal */}
      {showMakeupModal && makeupExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-purple-400">
                <Plus className="w-5 h-5" />
                <h3 className="font-bold text-white">Issue Makeup Token</h3>
              </div>
              <button onClick={() => setShowMakeupModal(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <p className="text-xs text-slate-400">
              Generate an individual 8-character makeup token for a candidate in <strong className="text-white">{makeupExam.title}</strong>.
            </p>

            {/* Target Scope Restriction Badge */}
            <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-800/40 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-purple-300">Target Eligibility Scope</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-200">
                  {candidatesLoading ? 'Loading…' : `${eligibleCandidates.length} enrolled`}
                </span>
              </div>
              <p className="text-xs text-white font-medium">
                {(() => {
                  let targets: string[] = [];
                  try {
                    if (makeupExam.target_classes) {
                      targets = typeof makeupExam.target_classes === 'string'
                        ? JSON.parse(makeupExam.target_classes)
                        : (Array.isArray(makeupExam.target_classes) ? makeupExam.target_classes : []);
                    }
                  } catch (_) {}
                  return targets.length > 0 ? targets.join(', ') : `${makeupExam.class_name} (All Arms)`;
                })()}
              </p>
              <p className="text-[11px] text-slate-400">
                Only active students in this exam's configured target class and arms are eligible for makeup tokens.
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Candidate *</label>
                {selectedMakeupStudent ? (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-purple-950/40 border border-purple-500/40">
                    <div>
                      <p className="font-bold text-white text-sm">{selectedMakeupStudent.name}</p>
                      <p className="text-xs text-purple-300">
                        {selectedMakeupStudent.class_name} {selectedMakeupStudent.class_arm || ''} · <span className="font-mono">{selectedMakeupStudent.id}</span>
                        {selectedMakeupStudent.admission_no && ` · Adm: ${selectedMakeupStudent.admission_no}`}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => { setSelectedMakeupStudent(null); setMakeupStudentId(''); setMakeupSearch(''); }}
                      className="text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 transition-colors"
                    >
                      Change
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="relative">
                      <input
                        type="text"
                        value={makeupSearch}
                        onChange={e => setMakeupSearch(e.target.value)}
                        placeholder={candidatesLoading ? "Loading eligible candidates..." : "Search student by name, ID, arm..."}
                        disabled={candidatesLoading}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500 disabled:opacity-50"
                      />
                      {makeupSearch && (
                        <button
                          type="button"
                          onClick={() => setMakeupSearch('')}
                          className="absolute right-2.5 top-2.5 text-slate-500 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    {candidatesLoading ? (
                      <div className="p-4 text-xs text-slate-400 text-center animate-pulse">Loading candidates in target scope…</div>
                    ) : (
                      <div className="max-h-48 overflow-y-auto rounded-xl bg-slate-900 border border-slate-700 divide-y divide-slate-800">
                        {eligibleCandidates
                          .filter(s => {
                            if (!makeupSearch.trim()) return true;
                            const q = makeupSearch.toLowerCase();
                            return (s.name || '').toLowerCase().includes(q) ||
                                   (s.id || '').toLowerCase().includes(q) ||
                                   ((s.admission_no || '')).toLowerCase().includes(q) ||
                                   (s.class_name || '').toLowerCase().includes(q) ||
                                   ((s.class_arm || '')).toLowerCase().includes(q);
                          })
                          .slice(0, 10)
                          .map(s => (
                            <div
                              key={s.id}
                              onClick={() => {
                                setSelectedMakeupStudent(s);
                                setMakeupStudentId(s.id);
                                setMakeupSearch('');
                              }}
                              className="p-2.5 hover:bg-slate-800 cursor-pointer transition-colors text-left flex items-center justify-between"
                            >
                              <div className="min-w-0 pr-2">
                                <p className="text-sm font-semibold text-white truncate">{s.name}</p>
                                <p className="text-xs text-slate-400 truncate">
                                  {s.class_name} {s.class_arm || ''} · <span className="font-mono text-slate-500">{s.id}</span>
                                  {s.admission_no && ` · Adm: ${s.admission_no}`}
                                </p>
                              </div>
                              {s.token_status && (
                                <span className={`text-[10px] px-2 py-0.5 rounded font-mono shrink-0 ${
                                  s.token_status === 'submitted'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                    : 'bg-slate-700 text-slate-300'
                                }`}>
                                  {s.token_status === 'submitted' ? `Submitted (${s.score ?? 0}%)` : s.token_status}
                                </span>
                              )}
                            </div>
                          ))}
                        {eligibleCandidates.filter(s => {
                          if (!makeupSearch.trim()) return true;
                          const q = makeupSearch.toLowerCase();
                          return (s.name || '').toLowerCase().includes(q) ||
                                 (s.id || '').toLowerCase().includes(q) ||
                                 ((s.admission_no || '')).toLowerCase().includes(q) ||
                                 ((s.class_arm || '')).toLowerCase().includes(q);
                        }).length === 0 && (
                          <div className="p-3 text-xs text-slate-500 text-center">
                            {makeupSearch.trim() ? `No candidates found matching "${makeupSearch}" in target scope` : 'No eligible candidates found'}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Mandatory Reason for Makeup *</label>
                <textarea
                  value={makeupReason}
                  onChange={e => setMakeupReason(e.target.value)}
                  placeholder="e.g. Medical absence approved by school / Power outage during Batch 1"
                  rows={2}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setShowMakeupModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors"
              >
                Cancel
              </button>
              <button
                disabled={makeupLoading || !makeupStudentId}
                onClick={handleExecuteMakeup}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold transition-colors disabled:opacity-50"
              >
                {makeupLoading ? 'Issuing…' : 'Generate Token'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 3: LIVE MONITOR
// ═══════════════════════════════════════════════════════════════════════════════
function LiveMonitorTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [exams, setExams] = useState<CbtExam[]>([]);
  const [selectedExam, setSelectedExam] = useState<CbtExam | null>(null);
  const [tokens, setTokens] = useState<CbtToken[]>([]);
  const [loading, setLoading] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [extendToken, setExtendToken] = useState<CbtToken | null>(null);
  const [extendMinutes, setExtendMinutes] = useState(10);
  const [extendReason, setExtendReason] = useState('Invigilator Extension');
  const [extendLoading, setExtendLoading] = useState(false);
  const [unlockingTokenId, setUnlockingTokenId] = useState<number | null>(null);
  const [selectedCandidate, setSelectedCandidate] = useState<CbtToken | null>(null);
  const [showAllTokens, setShowAllTokens] = useState(false);
  const [rosterConcealSeconds, setRosterConcealSeconds] = useState(300);

  // Modal / Confirm state
  const [confirmUnlockToken, setConfirmUnlockToken] = useState<CbtToken | null>(null);

  // Auto-conceal timer for full candidate roster (5 minutes)
  useEffect(() => {
    if (!showAllTokens) return;
    setRosterConcealSeconds(300);
    const interval = setInterval(() => {
      setRosterConcealSeconds(prev => {
        if (prev <= 1) {
          setShowAllTokens(false);
          return 300;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [showAllTokens]);

  const liveSelectedCandidate = selectedCandidate
    ? (tokens.find(t => t.id === selectedCandidate.id) || selectedCandidate)
    : null;

  const handleExtendTime = async () => {
    if (!extendToken || !selectedExam) return;
    if (extendMinutes <= 0) {
      toast('Minutes must be greater than 0', 'error');
      return;
    }
    setExtendLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/tokens/${extendToken.id}/extend`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          extra_minutes: extendMinutes,
          reason: extendReason.trim()
        })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Failed to extend time');
      toast(`Extended ${extendToken.student_name} by +${d.extra_minutes} minutes!`, 'success');
      setExtendToken(null);
      fetchTokens(selectedExam.id);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setExtendLoading(false);
    }
  };

  const handleUnlockSession = (tk: CbtToken) => {
    setConfirmUnlockToken(tk);
  };

  const executeUnlockSession = async (tk: CbtToken) => {
    setUnlockingTokenId(tk.id);
    try {
      const r = await fetch(`/api/admin/cbt/tokens/${tk.id}/unlock-session`, { method: 'POST', headers: authHeaders() });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Failed to unlock session');
      toast(`Session unlocked for ${tk.student_name}`, 'success');
      if (selectedExam) fetchTokens(selectedExam.id);
    } catch (err: any) {
      toast(err.message, 'error');
    } finally {
      setUnlockingTokenId(null);
    }
  };

  const handleToggleMobile = async (exam: CbtExam) => {
    const newVal = exam.allow_mobile_clients === 0 ? 1 : 0;
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/toggle-mobile`, {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ allow_mobile_clients: newVal })
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Failed');
      toast(newVal === 1 ? 'Mobile clients enabled' : 'Mobile clients disabled', 'success');
      fetchExams();
    } catch (err: any) {
      toast(err.message, 'error');
    }
  };

  const fetchActive = useCallback(async () => {
    try {
      const r = await fetch('/api/admin/cbt/exams', { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) {
        const active = d.exams.filter((e: CbtExam) => e.status === 'active');
        setExams(active);
        if (active.length > 0 && !selectedExam) setSelectedExam(active[0]);
      }
    } catch {}
    finally { setLoading(false); }
  }, [selectedExam]);

  const fetchTokens = useCallback(async (examId: number) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${examId}/tokens`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setTokens(d.tokens);
    } catch {}
  }, []);

  useEffect(() => {
    fetchActive();
    intervalRef.current = setInterval(fetchActive, 10000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [fetchActive]);

  useEffect(() => {
    if (!selectedExam) return;
    fetchTokens(selectedExam.id);
    const t = setInterval(() => fetchTokens(selectedExam.id), 5000);
    return () => clearInterval(t);
  }, [selectedExam, fetchTokens]);

  const submitted = tokens.filter(t => t.status === 'submitted');
  const active = tokens.filter(t => t.status === 'active');
  const unused = tokens.filter(t => t.status === 'unused');

  if (loading) return <div className="flex items-center justify-center h-48 text-slate-500 text-sm">Loading…</div>;

  if (exams.length === 0) {
    return (
      <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
        <Shield className="w-10 h-10 text-slate-600 mx-auto mb-3" />
        <p className="text-slate-400 font-semibold">No active exams right now</p>
        <p className="text-slate-500 text-sm mt-1">Activate an exam from the Exams tab to see live monitoring here</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h2 className="text-lg font-bold text-white">Live Monitor</h2>
            {selectedExam && (
              <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {selectedExam.title} · {selectedExam.class_name}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">Auto-refreshes every 5 seconds</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold px-2.5 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Live
          </span>
        </div>
      </div>

      {/* Exam selector */}
      {exams.length > 1 && (
        <div className="flex gap-2 flex-wrap">
          {exams.map(e => (
            <button key={e.id} onClick={() => setSelectedExam(e)} className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${selectedExam?.id === e.id ? 'bg-indigo-600/30 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:border-slate-600'}`}>
              {e.title}
            </button>
          ))}
        </div>
      )}

      {selectedExam && (
        <>
          {/* KPIs */}
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: 'Total', value: tokens.length, colour: 'text-white' },
              { label: 'Live', value: active.length, colour: 'text-amber-400' },
              { label: 'Submitted', value: submitted.length, colour: 'text-emerald-400' },
              { label: 'Not Started', value: unused.length, colour: 'text-slate-400' },
            ].map(kpi => (
              <div key={kpi.label} className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 text-center">
                <p className={`text-2xl font-bold ${kpi.colour}`}>{kpi.value}</p>
                <p className="text-xs text-slate-400 mt-0.5">{kpi.label}</p>
              </div>
            ))}
          </div>

          {/* Candidate Search & Selection Bar */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex-1 min-w-[280px]">
              <CandidateSearchPicker
                examId={selectedExam.id}
                selectedTokenId={liveSelectedCandidate?.id}
                onSelect={(cand) => setSelectedCandidate(cand)}
                placeholder="Search candidate by name, admission no, student ID, parent name, or phone..."
              />
            </div>
            <div className="flex items-center gap-2">
              {liveSelectedCandidate && (
                <button
                  onClick={() => setSelectedCandidate(null)}
                  className="text-xs text-slate-400 hover:text-white px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 transition-colors flex items-center gap-1.5"
                >
                  <X className="w-3.5 h-3.5" /> Clear Selection
                </button>
              )}
              <button
                onClick={() => setShowAllTokens(!showAllTokens)}
                className={`text-xs px-3 py-2 rounded-xl border transition-colors ${showAllTokens ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-300'}`}
              >
                {showAllTokens ? 'Hide Full Roster' : `Show Full Roster (${tokens.length})`}
              </button>
              {showAllTokens && (
                <span className="text-[11px] text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1.5 rounded-xl font-mono">
                  ⏳ Auto-conceals in {Math.floor(rosterConcealSeconds / 60)}:{String(rosterConcealSeconds % 60).padStart(2, '0')}
                </span>
              )}
            </div>
          </div>

          {/* Single Selected Candidate Monitor Card */}
          {liveSelectedCandidate ? (
            <div className="p-6 rounded-3xl bg-slate-800/60 border border-slate-700 shadow-2xl space-y-6">
              {/* Student Bio & Token Header */}
              <div className="flex items-start justify-between gap-4 flex-wrap border-b border-slate-700/60 pb-5">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-xl font-bold text-white">{liveSelectedCandidate.student_name}</h3>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {liveSelectedCandidate.class_name} {liveSelectedCandidate.class_arm}
                    </span>
                    <StatusBadge status={liveSelectedCandidate.status} />
                  </div>
                  <div className="mt-2 flex items-center gap-4 text-xs text-slate-400 flex-wrap">
                    {liveSelectedCandidate.admission_no && <span>Adm No: <strong className="text-slate-200">{liveSelectedCandidate.admission_no}</strong></span>}
                    {liveSelectedCandidate.student_id && <span>Student ID: <strong className="text-slate-200">{liveSelectedCandidate.student_id}</strong></span>}
                    {liveSelectedCandidate.parent_name && <span>Parent: <strong className="text-slate-200">{liveSelectedCandidate.parent_name}</strong></span>}
                    {liveSelectedCandidate.parent_phone && <span>Phone: <strong className="text-slate-200">{liveSelectedCandidate.parent_phone}</strong></span>}
                  </div>
                </div>

                {/* Prominent Token Display */}
                <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-3 px-5 text-center shrink-0 shadow-lg">
                  <p className="text-[10px] text-amber-400/80 font-bold uppercase tracking-wider mb-0.5">Candidate Token</p>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-2xl font-extrabold text-amber-400 tracking-widest">{liveSelectedCandidate.token}</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(liveSelectedCandidate.token);
                        toast('Token copied to clipboard', 'success');
                      }}
                      title="Copy token"
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Live Telemetry Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <p className="text-xs text-slate-400 mb-1">Time Remaining</p>
                  <p className="text-lg font-bold text-white font-mono">
                    {liveSelectedCandidate.status === 'active' && typeof liveSelectedCandidate.time_remaining_seconds === 'number' ? (
                      <span className={liveSelectedCandidate.time_remaining_seconds < 300 ? 'text-rose-400 font-bold animate-pulse' : 'text-slate-200'}>
                        {Math.floor(liveSelectedCandidate.time_remaining_seconds / 60)}m {liveSelectedCandidate.time_remaining_seconds % 60}s
                      </span>
                    ) : liveSelectedCandidate.status === 'submitted' ? (
                      <span className="text-emerald-400">Finished</span>
                    ) : (
                      <span className="text-slate-500">Not Started</span>
                    )}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <p className="text-xs text-slate-400 mb-1">Questions Answered</p>
                  <p className="text-lg font-bold text-emerald-400">
                    {liveSelectedCandidate.answered_count ?? 0} <span className="text-xs text-slate-500 font-normal">/ {selectedExam.question_count} Qs</span>
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <p className="text-xs text-slate-400 mb-1">Tab / App Switches</p>
                  <p className={`text-lg font-bold ${liveSelectedCandidate.tab_switches > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                    {liveSelectedCandidate.tab_switches > 0 ? `⚠ ${liveSelectedCandidate.tab_switches}` : '0'}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <p className="text-xs text-slate-400 mb-1">Current Score</p>
                  <p className="text-lg font-bold text-white">
                    {liveSelectedCandidate.score !== null ? (
                      <span className="text-emerald-400">{liveSelectedCandidate.score} / {selectedExam.question_count}</span>
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </p>
                </div>
              </div>

              {/* Candidate Actions Bar */}
              <div className="flex items-center justify-between gap-4 pt-2 border-t border-slate-700/60 flex-wrap">
                <div className="flex items-center gap-2">
                  {liveSelectedCandidate.status === 'active' && (
                    <button
                      onClick={() => {
                        setExtendMinutes(10);
                        setExtendReason('Invigilator Extension');
                        setExtendToken(liveSelectedCandidate);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-600/50 text-xs font-semibold transition-colors"
                    >
                      <Clock className="w-3.5 h-3.5" /> Extend Time (+10m)
                    </button>
                  )}
                  {liveSelectedCandidate.active_session_id && (
                    <button
                      onClick={() => handleUnlockSession(liveSelectedCandidate)}
                      disabled={unlockingTokenId === liveSelectedCandidate.id}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-600/20 border border-amber-500/40 text-amber-300 hover:bg-amber-600/40 text-xs font-semibold transition-colors disabled:opacity-50"
                    >
                      🔓 {unlockingTokenId === liveSelectedCandidate.id ? 'Unlocking…' : 'Unlock Device Session'}
                    </button>
                  )}
                  {liveSelectedCandidate.makeup_reason && (
                    <span className="text-xs text-purple-300 bg-purple-900/40 border border-purple-500/40 px-2.5 py-1 rounded-full font-mono">
                      Makeup Reason: {liveSelectedCandidate.makeup_reason}
                    </span>
                  )}
                </div>

                <button
                  onClick={() => setSelectedCandidate(null)}
                  className="text-xs text-slate-400 hover:text-white px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 transition-colors"
                >
                  Close Student Card
                </button>
              </div>
            </div>
          ) : (
            !showAllTokens && (
              <div className="p-12 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto border border-indigo-500/20">
                  <Search className="w-6 h-6" />
                </div>
                <h3 className="text-white font-semibold text-base">Search to Monitor Candidate</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  Type a student&apos;s name, student ID, admission number, parent name, or parent phone number above to select a candidate and inspect their live exam status.
                </p>
              </div>
            )
          )}

          {/* Full Exam Roster (Collapsible) */}
          {showAllTokens && (
            <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden mt-4">
              <div className="px-4 py-3 border-b border-slate-700/60 flex justify-between items-center">
                <h3 className="font-semibold text-white text-sm">{selectedExam.title} — Full Roster ({tokens.length})</h3>
                <button onClick={() => setShowAllTokens(false)} className="text-xs text-slate-400 hover:text-white">Hide</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-[11px] text-slate-500 uppercase border-b border-slate-700/60">
                      <th className="text-left px-4 py-2">Student</th>
                      <th className="text-left px-4 py-2">Class</th>
                      <th className="text-left px-4 py-2">Token</th>
                      <th className="text-left px-4 py-2">Status</th>
                      <th className="text-left px-4 py-2">Progress</th>
                      <th className="text-left px-4 py-2">Time Left</th>
                      <th className="text-left px-4 py-2">Tab Switches</th>
                      <th className="text-left px-4 py-2">Score</th>
                      <th className="text-right px-4 py-2">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {tokens.map(tk => (
                      <tr key={tk.id} className={`hover:bg-slate-800/60 transition-colors ${tk.status === 'active' ? 'bg-amber-500/5' : ''}`}>
                        <td className="px-4 py-2.5 text-white font-medium">
                          <button
                            onClick={() => setSelectedCandidate(tk)}
                            className="hover:text-indigo-400 text-left font-semibold transition-colors"
                          >
                            {tk.student_name || '—'}
                          </button>
                        </td>
                        <td className="px-4 py-2.5 text-slate-400">{tk.class_name} {tk.class_arm}</td>
                        <td className="px-4 py-2.5 font-mono text-indigo-400 text-xs tracking-widest">{tk.token}</td>
                        <td className="px-4 py-2.5"><StatusBadge status={tk.status} /></td>
                        <td className="px-4 py-2.5 text-xs">
                          {tk.status === 'unused' ? (
                            <span className="text-slate-600">—</span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 font-medium text-emerald-400">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                              {tk.answered_count ?? 0} / {selectedExam.question_count || '?'} Qs
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-2.5 text-slate-300 text-xs font-mono">
                          {tk.status === 'active' && typeof tk.time_remaining_seconds === 'number' ? (
                            <span className={tk.time_remaining_seconds < 300 ? 'text-rose-400 font-bold animate-pulse' : 'text-slate-300'}>
                              {Math.floor(tk.time_remaining_seconds / 60)}m {tk.time_remaining_seconds % 60}s
                            </span>
                          ) : tk.status === 'submitted' ? (
                            <span className="text-slate-500">Finished</span>
                          ) : (
                            <span className="text-slate-600">—</span>
                          )}
                        </td>
                        <td className="px-4 py-2.5">
                          {tk.tab_switches > 0 ? <span className="text-amber-400 font-semibold">⚠ {tk.tab_switches}</span> : <span className="text-slate-600">0</span>}
                        </td>
                        <td className="px-4 py-2.5">
                          {tk.score !== null ? <span className="text-emerald-400 font-bold">{tk.score}</span> : <span className="text-slate-600">—</span>}
                        </td>
                        <td className="px-4 py-2.5 text-right">
                          <div className="inline-flex items-center gap-1.5 justify-end flex-wrap">
                            {tk.status === 'active' && (
                              <button
                                onClick={() => {
                                  setExtendMinutes(10);
                                  setExtendReason('Invigilator Extension');
                                  setExtendToken(tk);
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-600/50 text-xs font-medium transition-colors"
                                title="Extend Candidate Time"
                              >
                                <Clock className="w-3 h-3" /> +Time
                              </button>
                            )}
                            {tk.active_session_id && (
                              <button
                                onClick={() => handleUnlockSession(tk)}
                                disabled={unlockingTokenId === tk.id}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600/20 border border-amber-500/40 text-amber-300 hover:bg-amber-600/40 text-xs font-medium transition-colors disabled:opacity-50"
                                title="Unlock device session — allows student to log in from a new device"
                              >
                                🔓 {unlockingTokenId === tk.id ? '…' : 'Unlock'}
                              </button>
                            )}
                            <button
                              onClick={() => setSelectedCandidate(tk)}
                              className="px-2.5 py-1 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 text-xs font-medium transition-colors"
                            >
                              Inspect
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Unlock Student Device Session Confirmation Modal */}
      {confirmUnlockToken && (
        <ConfirmDialog
          title="Unlock Device Session"
          message={`Unlock session for "${confirmUnlockToken.student_name}" (${confirmUnlockToken.token})? This will release their workstation lock and allow them to log in from a new computer or browser.`}
          danger={false}
          onConfirm={() => {
            const tk = confirmUnlockToken;
            setConfirmUnlockToken(null);
            executeUnlockSession(tk);
          }}
          onCancel={() => setConfirmUnlockToken(null)}
        />
      )}

      {/* Extend Time Modal */}
      {extendToken && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-400">
                <Clock className="w-5 h-5" />
                <h3 className="font-bold text-white">Extend Candidate Time</h3>
              </div>
              <button onClick={() => setExtendToken(null)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-700/60 text-xs space-y-1">
              <p className="text-slate-300 font-semibold">{extendToken.student_name}</p>
              <p className="text-slate-500 font-mono">Token: {extendToken.token}</p>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Extra Minutes to Add</label>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {[5, 10, 15, 30].map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setExtendMinutes(m)}
                      className={`py-1.5 rounded-lg text-xs font-bold border transition-colors ${extendMinutes === m ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'}`}
                    >
                      +{m}m
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="1"
                  max="180"
                  value={extendMinutes}
                  onChange={e => setExtendMinutes(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Audit Reason</label>
                <input
                  type="text"
                  value={extendReason}
                  onChange={e => setExtendReason(e.target.value)}
                  placeholder="e.g. Lab power failure"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setExtendToken(null)}
                className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors"
              >
                Cancel
              </button>
              <button
                disabled={extendLoading}
                onClick={handleExtendTime}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors disabled:opacity-50"
              >
                {extendLoading ? 'Extending…' : `Add +${extendMinutes} Mins`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 4: RESULTS
// ═══════════════════════════════════════════════════════════════════════════════
function ResultsTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [exams, setExams] = useState<CbtExam[]>([]);
  const [selectedExam, setSelectedExam] = useState<CbtExam | null>(null);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [resultLoading, setResultLoading] = useState(false);
  const [confirmRelease, setConfirmRelease] = useState(false);
  const [regradeLoading, setRegradeLoading] = useState(false);

  const [selectedCandidate, setSelectedCandidate] = useState<CbtToken | null>(null);
  const [detailedReview, setDetailedReview] = useState<StudentDetailedReview | null>(null);
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewPage, setReviewPage] = useState(1);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const questionsPerPage = 5;

  const loadDetailedReview = async (cand: CbtToken) => {
    setSelectedCandidate(cand);
    setReviewLoading(true);
    setReviewPage(1);
    try {
      const r = await fetch(`/api/admin/cbt/tokens/${cand.id}/detailed-review`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) {
        setDetailedReview(d);
      } else {
        toast(d.error || 'Failed to load question sheet', 'error');
      }
    } catch {
      toast('Network error loading question sheet', 'error');
    } finally {
      setReviewLoading(false);
    }
  };

  const handleRegrade = async () => {
    if (!selectedExam) return;
    setRegradeLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${selectedExam.id}/regrade`, { method: 'POST', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) {
        toast(`Successfully re-graded ${d.regraded} submission${d.regraded !== 1 ? 's' : ''}`, 'success');
        fetchResult(selectedExam);
      } else {
        toast(d.error || 'Failed to re-grade', 'error');
      }
    } catch {
      toast('Network error', 'error');
    } finally {
      setRegradeLoading(false);
    }
  };

  useEffect(() => {
    fetch('/api/admin/cbt/exams', { headers: authHeaders() })
      .then(r => r.json())
      .then(d => { if (d.ok) setExams(d.exams.filter((e: CbtExam) => e.submitted_count > 0)); })
      .catch(() => toast('Failed to load exams', 'error'))
      .finally(() => setLoading(false));
  }, [toast]);

  const fetchResult = useCallback(async (exam: CbtExam) => {
    setResultLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/results`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setResult(d);
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    finally { setResultLoading(false); }
  }, [toast]);

  const handleRelease = async () => {
    if (!selectedExam) return;
    try {
      const r = await fetch(`/api/admin/cbt/exams/${selectedExam.id}/release`, { method: 'POST', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) toast(`${d.released} score${d.released !== 1 ? 's' : ''} pushed to student records`, 'success');
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmRelease(false);
  };

  if (loading) return <div className="flex items-center justify-center h-48 text-slate-500 text-sm">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Results</h2>
          <p className="text-xs text-slate-400 mt-0.5">{exams.length} exam{exams.length !== 1 ? 's' : ''} with submissions</p>
        </div>
        {selectedExam && (
          <button
            onClick={handleRegrade}
            disabled={regradeLoading}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 disabled:opacity-50"
            title="Recalculate scores for all submitted candidates with the correct option mapping"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${regradeLoading ? 'animate-spin' : ''}`} />
            {regradeLoading ? 'Re-grading…' : 'Re-grade Exam'}
          </button>
        )}
      </div>

      {exams.length === 0 ? (
        <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
          <BarChart3 className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-semibold">No results yet</p>
          <p className="text-slate-500 text-sm mt-1">Results appear here once students have submitted an exam</p>
        </div>
      ) : (
        <>
          {/* Exam selector */}
          <div className="flex gap-2 flex-wrap">
            {exams.map(e => (
              <button key={e.id} onClick={() => { setSelectedExam(e); fetchResult(e); }} className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${selectedExam?.id === e.id ? 'bg-indigo-600/30 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:border-slate-600'}`}>
                {e.title} <span className="opacity-60">({e.submitted_count})</span>
              </button>
            ))}
          </div>

          {selectedExam && resultLoading && (
            <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading results…</div>
          )}

          {selectedExam && result && !resultLoading && (
            <div className="space-y-5">
              {/* Summary KPIs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: 'Submissions', value: result.summary.total_students, colour: 'text-white', icon: Users },
                  { label: 'Pass Rate', value: `${result.summary.pass_rate}%`, colour: result.summary.pass_rate >= 50 ? 'text-emerald-400' : 'text-red-400', icon: TrendingUp },
                  { label: 'Avg Score', value: `${result.summary.avg_score}/${result.summary.max_score}`, colour: 'text-indigo-400', icon: Award },
                  { label: 'Pass Mark', value: `${result.summary.pass_mark}`, colour: 'text-amber-400', icon: CheckCircle2 },
                ].map(kpi => (
                  <div key={kpi.label} className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60">
                    <kpi.icon className={`w-5 h-5 ${kpi.colour} mb-2`} />
                    <p className={`text-2xl font-bold ${kpi.colour}`}>{kpi.value}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{kpi.label}</p>
                  </div>
                ))}
              </div>

              {/* Push to Grades */}
              {selectedExam.assessment_mapping && (
                <div className="p-4 rounded-2xl bg-indigo-900/20 border border-indigo-500/20 flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-indigo-300">Push Scores to Grade Book</p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {(() => { try { const m = JSON.parse(selectedExam.assessment_mapping!); return `${m.assessment} · ${m.subject}`; } catch { return selectedExam.assessment_mapping; } })()}
                    </p>
                  </div>
                  <button onClick={() => setConfirmRelease(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center gap-2">
                    <Upload className="w-4 h-4" /> Push to Grades
                  </button>
                </div>
              )}

              {/* Candidate Search Bar */}
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex-1 min-w-[280px]">
                  <CandidateSearchPicker
                    examId={selectedExam.id}
                    selectedTokenId={selectedCandidate?.id}
                    onSelect={(cand) => loadDetailedReview(cand)}
                    placeholder="Search candidate by name, admission no, student ID, parent name, or phone..."
                  />
                </div>
                <div className="flex items-center gap-2">
                  {selectedCandidate && (
                    <button
                      onClick={() => { setSelectedCandidate(null); setDetailedReview(null); }}
                      className="text-xs text-slate-400 hover:text-white px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 transition-colors flex items-center gap-1.5"
                    >
                      <X className="w-3.5 h-3.5" /> Clear Student
                    </button>
                  )}
                  <button
                    onClick={() => setShowScoreboard(!showScoreboard)}
                    className={`text-xs px-3 py-2 rounded-xl border transition-colors ${showScoreboard ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-300'}`}
                  >
                    {showScoreboard ? 'Hide Scoreboard' : `Show Scoreboard (${result.students.length})`}
                  </button>
                </div>
              </div>

              {/* Single Student Detailed Performance & Question Review */}
              {reviewLoading && (
                <div className="p-12 text-center text-sm text-slate-400 bg-slate-800/40 border border-slate-700/60 rounded-3xl flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin" /> Loading student&apos;s exam question sheet…
                </div>
              )}

              {selectedCandidate && detailedReview && !reviewLoading && (
                <div className="space-y-5">
                  {/* Student Performance Header */}
                  <div className="p-6 rounded-3xl bg-slate-800/60 border border-slate-700 shadow-2xl space-y-5">
                    <div className="flex items-start justify-between gap-4 flex-wrap border-b border-slate-700/60 pb-5">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-xl font-bold text-white">{detailedReview.student.student_name}</h3>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            {detailedReview.student.class_name} {detailedReview.student.class_arm}
                          </span>
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${detailedReview.student.passed ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400'}`}>
                            {detailedReview.student.passed ? 'PASS' : 'FAIL'}
                          </span>
                        </div>
                        <div className="mt-2 flex items-center gap-4 text-xs text-slate-400 flex-wrap">
                          {detailedReview.student.admission_no && <span>Adm: <strong className="text-slate-200">{detailedReview.student.admission_no}</strong></span>}
                          {detailedReview.student.student_id && <span>Student ID: <strong className="text-slate-200">{detailedReview.student.student_id}</strong></span>}
                          {detailedReview.student.parent_name && <span>Parent: <strong className="text-slate-200">{detailedReview.student.parent_name}</strong></span>}
                          {detailedReview.student.parent_phone && <span>Phone: <strong className="text-slate-200">{detailedReview.student.parent_phone}</strong></span>}
                          {detailedReview.student.submitted_at && <span>Submitted: <strong className="text-slate-200">{new Date(detailedReview.student.submitted_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong></span>}
                        </div>
                      </div>

                      <div className="bg-slate-900 border border-indigo-500/30 rounded-2xl p-3 px-6 text-center shrink-0">
                        <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider mb-0.5">Final Score</p>
                        <p className="text-2xl font-black text-white">
                          <span className={detailedReview.student.passed ? 'text-emerald-400' : 'text-red-400'}>{detailedReview.student.score}</span>
                          <span className="text-slate-500 text-sm font-normal"> / {detailedReview.student.max_score}</span>
                          <span className="text-xs text-slate-400 font-medium ml-2">({detailedReview.student.percentage}%)</span>
                        </p>
                      </div>
                    </div>

                    {/* Breakdown Metric Pills */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 text-center">
                        <p className="text-xs text-slate-400">Total Questions</p>
                        <p className="text-base font-bold text-white mt-0.5">{detailedReview.summary.total_questions}</p>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 text-center">
                        <p className="text-xs text-emerald-400">Correct Answers</p>
                        <p className="text-base font-bold text-emerald-400 mt-0.5">{detailedReview.summary.correct_count}</p>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 text-center">
                        <p className="text-xs text-rose-400">Incorrect Answers</p>
                        <p className="text-base font-bold text-rose-400 mt-0.5">{detailedReview.summary.wrong_count}</p>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 text-center">
                        <p className="text-xs text-slate-400">Unattempted</p>
                        <p className="text-base font-bold text-slate-400 mt-0.5">{detailedReview.summary.unattempted_count}</p>
                      </div>
                    </div>
                  </div>

                  {/* Paginated Questions Sheet */}
                  <div className="bg-slate-800/40 border border-slate-700/60 rounded-3xl overflow-hidden shadow-xl">
                    {/* Sheet Header & Page Controls */}
                    <div className="p-4 px-6 border-b border-slate-700/60 flex items-center justify-between gap-4 flex-wrap bg-slate-800/60">
                      <div>
                        <h4 className="font-bold text-white text-sm">Exam Response Sheet</h4>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Showing questions {(reviewPage - 1) * questionsPerPage + 1}–{Math.min(reviewPage * questionsPerPage, detailedReview.questions.length)} of {detailedReview.questions.length}
                        </p>
                      </div>

                      {/* Pagination Controls */}
                      {detailedReview.questions.length > questionsPerPage && (
                        <div className="flex items-center gap-2">
                          <button
                            disabled={reviewPage === 1}
                            onClick={() => setReviewPage(p => Math.max(1, p - 1))}
                            className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 disabled:opacity-40 text-slate-300 transition-colors"
                            title="Previous page"
                          >
                            <ChevronLeft className="w-4 h-4" />
                          </button>
                          <span className="text-xs text-slate-300 font-mono px-2">
                            Page {reviewPage} of {Math.ceil(detailedReview.questions.length / questionsPerPage)}
                          </span>
                          <button
                            disabled={reviewPage === Math.ceil(detailedReview.questions.length / questionsPerPage)}
                            onClick={() => setReviewPage(p => Math.min(Math.ceil(detailedReview.questions.length / questionsPerPage), p + 1))}
                            className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 disabled:opacity-40 text-slate-300 transition-colors"
                            title="Next page"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Quick Question Number Jump Bar */}
                    <div className="px-6 py-2.5 border-b border-slate-700/40 bg-slate-900/40 flex items-center gap-1.5 overflow-x-auto">
                      <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider shrink-0 mr-1">Jump to:</span>
                      {detailedReview.questions.map((q, idx) => {
                        const targetPage = Math.floor(idx / questionsPerPage) + 1;
                        let bgClass = 'bg-slate-800 text-slate-400 border-slate-700';
                        if (q.status === 'correct') bgClass = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
                        else if (q.status === 'incorrect') bgClass = 'bg-rose-500/20 text-rose-300 border-rose-500/30';
                        else bgClass = 'bg-slate-800 text-slate-500 border-slate-700';

                        return (
                          <button
                            key={q.id}
                            onClick={() => setReviewPage(targetPage)}
                            className={`w-7 h-7 rounded-lg text-xs font-mono font-bold border transition-all shrink-0 ${bgClass} ${reviewPage === targetPage ? 'ring-2 ring-indigo-500' : 'hover:opacity-80'}`}
                            title={`Q${idx + 1}: ${q.status}`}
                          >
                            {idx + 1}
                          </button>
                        );
                      })}
                    </div>

                    {/* Question Cards List */}
                    <div className="p-6 space-y-6">
                      {detailedReview.questions
                        .slice((reviewPage - 1) * questionsPerPage, reviewPage * questionsPerPage)
                        .map(q => {
                          const options = [
                            { key: 'A', text: q.option_a },
                            { key: 'B', text: q.option_b },
                            { key: 'C', text: q.option_c },
                            { key: 'D', text: q.option_d },
                          ].filter(o => o.text && o.text.trim() !== '');

                          return (
                            <div key={q.id} className="p-5 rounded-2xl bg-slate-900/60 border border-slate-700/80 space-y-4 shadow-sm">
                              {/* Question Meta Bar */}
                              <div className="flex items-center justify-between gap-3 flex-wrap">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-white text-sm">Question #{q.index}</span>
                                  <DiffBadge d={q.difficulty} />
                                </div>
                                <div className="flex items-center gap-2">
                                  {q.status === 'correct' && (
                                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                                      ✅ Correct (+{q.marks_awarded} mark)
                                    </span>
                                  )}
                                  {q.status === 'incorrect' && (
                                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-500/10 border border-rose-500/30 text-rose-400">
                                      ❌ Incorrect (0 marks)
                                    </span>
                                  )}
                                  {q.status === 'unattempted' && (
                                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-700 border border-slate-600 text-slate-400">
                                      ⬜ Unattempted (0 marks)
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Question Text */}
                              <p className="text-sm font-medium text-slate-100 leading-relaxed">
                                {q.question_text}
                              </p>

                              {/* Options Matrix */}
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                                {options.map(opt => {
                                  const isCorrectOpt = opt.key === q.correct_option;
                                  const isStudentChoice = opt.key === q.selected_option;

                                  let style = 'bg-slate-800/40 border-slate-700/60 text-slate-300';
                                  if (isCorrectOpt) {
                                    style = 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200 font-semibold ring-1 ring-emerald-500/30';
                                  } else if (isStudentChoice && !isCorrectOpt) {
                                    style = 'bg-rose-500/15 border-rose-500/40 text-rose-200 ring-1 ring-rose-500/30';
                                  }

                                  return (
                                    <div key={opt.key} className={`p-3 rounded-xl border flex items-center justify-between gap-3 transition-colors ${style}`}>
                                      <div className="flex items-center gap-3 min-w-0">
                                        <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${isCorrectOpt ? 'bg-emerald-500 text-slate-950' : (isStudentChoice ? 'bg-rose-500 text-white' : 'bg-slate-700 text-slate-400')}`}>
                                          {opt.key}
                                        </span>
                                        <span className="text-xs break-words">{opt.text}</span>
                                      </div>
                                      <div className="shrink-0 flex items-center gap-1.5">
                                        {isStudentChoice && (
                                          <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${isCorrectOpt ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'}`}>
                                            Student Pick
                                          </span>
                                        )}
                                        {isCorrectOpt && (
                                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                            Correct
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              )}

              {/* Empty state prompt when no student selected */}
              {!selectedCandidate && !reviewLoading && !showScoreboard && (
                <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center space-y-2">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto border border-indigo-500/20">
                    <Search className="w-5 h-5" />
                  </div>
                  <h3 className="text-white font-semibold text-sm">Search Candidate for Detailed Performance</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                    Select a candidate from the search bar above to inspect their complete question-by-question responses, correct answers, and unattempted questions.
                  </p>
                </div>
              )}

              {/* Collapsible Scoreboard */}
              {showScoreboard && (
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden mt-4">
                  <div className="px-4 py-3 border-b border-slate-700/60 flex items-center justify-between">
                    <h3 className="font-semibold text-white text-sm">Full Scoreboard</h3>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-400">{result.summary.passed} passed · {result.summary.failed} failed</span>
                      <button onClick={() => setShowScoreboard(false)} className="text-xs text-slate-400 hover:text-white">Hide</button>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-[11px] text-slate-500 uppercase border-b border-slate-700/60">
                          <th className="text-left px-4 py-2">#</th>
                          <th className="text-left px-4 py-2">Student</th>
                          <th className="text-left px-4 py-2">Arm</th>
                          <th className="text-left px-4 py-2">Score</th>
                          <th className="text-left px-4 py-2">%</th>
                          <th className="text-left px-4 py-2">Result</th>
                          <th className="text-left px-4 py-2">Tab Switches</th>
                          <th className="text-right px-4 py-2">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {result.students.map((s, i) => {
                          const pct = Math.round((s.score || 0) / result.summary.max_score * 100);
                          const passed = s.score >= result.summary.pass_mark;
                          return (
                            <tr key={s.id} className="hover:bg-slate-800/60 transition-colors">
                              <td className="px-4 py-2.5 text-slate-500 text-xs">{i + 1}</td>
                              <td className="px-4 py-2.5 text-white font-medium">{s.student_name}</td>
                              <td className="px-4 py-2.5 text-slate-400 text-xs">{s.class_arm}</td>
                              <td className="px-4 py-2.5 font-bold text-white">{s.score}</td>
                              <td className="px-4 py-2.5 text-slate-300">{pct}%</td>
                              <td className="px-4 py-2.5">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${passed ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400'}`}>
                                  {passed ? 'PASS' : 'FAIL'}
                                </span>
                              </td>
                              <td className="px-4 py-2.5">{s.tab_switches > 0 ? <span className="text-amber-400">⚠ {s.tab_switches}</span> : <span className="text-slate-600">—</span>}</td>
                              <td className="px-4 py-2.5 text-right">
                                <button
                                  onClick={() => loadDetailedReview({ id: s.id, student_name: s.student_name, class_name: '', class_arm: s.class_arm, admission_no: s.admission_no, token: '', status: 'submitted', score: s.score, started_at: null, submitted_at: s.submitted_at, tab_switches: s.tab_switches })}
                                  className="px-2.5 py-1 rounded-lg bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-600/50 text-xs font-medium transition-colors"
                                >
                                  View Sheet
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Question Analytics */}
              {result.question_analytics.length > 0 && (
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-700/60">
                    <h3 className="font-semibold text-white text-sm">Question Difficulty Analysis</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Sorted by hardest (fewest correct answers) first</p>
                  </div>
                  <div className="divide-y divide-slate-800">
                    {result.question_analytics.slice(0, 10).map((qa, i) => {
                      const pct = qa.attempts > 0 ? Math.round(qa.correct_count / qa.attempts * 100) : 0;
                      return (
                        <div key={qa.id} className="px-4 py-3">
                          <div className="flex items-start gap-3">
                            <span className="text-[11px] text-slate-500 font-bold mt-0.5 w-5 shrink-0">{i + 1}.</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs text-slate-300 line-clamp-2">{qa.question_text}</p>
                              <div className="mt-1.5 flex items-center gap-3">
                                <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                                  <div className={`h-full rounded-full ${pct >= 70 ? 'bg-emerald-500' : pct >= 40 ? 'bg-amber-500' : 'bg-red-500'}`} style={{ width: `${pct}%` }} />
                                </div>
                                <span className="text-[11px] text-slate-400 shrink-0">{qa.correct_count}/{qa.attempts} correct ({pct}%)</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {confirmRelease && (
        <ConfirmDialog
          title="Push Scores to Grades"
          message={`Push ${result?.summary.total_students || 0} scores into student records? This will overwrite existing records for the same assessment and subject.`}
          onConfirm={handleRelease}
          onCancel={() => setConfirmRelease(false)}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN CbtPage
// ═══════════════════════════════════════════════════════════════════════════════
const TABS = [
  { id: 'banks', label: 'Question Banks', icon: BookOpen },
  { id: 'exams', label: 'Exams', icon: PlayCircle },
  { id: 'monitor', label: 'Live Monitor', icon: MonitorCheck },
  { id: 'results', label: 'Results', icon: BarChart3 },
] as const;

type TabId = typeof TABS[number]['id'];

export default function CbtPage() {
  const [activeTab, setActiveTab] = useState<TabId>('banks');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type });
  }, []);

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="CBT Exam Center" subtitle="Computer-based testing · Question banks · Live monitoring · Auto-grading" />

      <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
        {/* Tab bar */}
        <div className="flex gap-1 p-1 bg-slate-800/60 rounded-2xl border border-slate-700/60 w-fit">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'}`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {activeTab === 'banks' && <QuestionBanksTab toast={showToast} />}
        {activeTab === 'exams' && <ExamsTab toast={showToast} />}
        {activeTab === 'monitor' && <LiveMonitorTab toast={showToast} />}
        {activeTab === 'results' && <ResultsTab toast={showToast} />}
      </div>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
