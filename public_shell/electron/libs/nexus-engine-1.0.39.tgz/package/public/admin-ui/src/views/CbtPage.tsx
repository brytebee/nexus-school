import React, { useState, useEffect, useCallback, useRef } from 'react';
import Header from '../components/Header';
import {
  MonitorCheck, BookOpen, PlayCircle, BarChart3, Plus, Trash2, Eye,
  ChevronDown, ChevronRight, RefreshCw, X, Check, AlertCircle,
  Users, Clock, Award, TrendingUp, Zap, Shield, FileText,
  CheckCircle2, AlertTriangle, Upload, Download
} from 'lucide-react';

// ─── Auth helper ─────────────────────────────────────────────────────────────
function authHeaders(): Record<string, string> {
  const token = localStorage.getItem('nexus_admin_token');
  return token ? { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
}

// ─── Types ────────────────────────────────────────────────────────────────────
interface QuestionBank {
  id: number;
  name: string;
  subject: string;
  class_category: string;
  description: string;
  question_count: number;
  created_at: string;
}

interface Question {
  id: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: 'A' | 'B' | 'C' | 'D';
  marks: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

interface CbtExam {
  id: number;
  title: string;
  class_name: string;
  bank_name: string;
  bank_subject: string;
  academic_session: string;
  term: string;
  question_count: number;
  duration_minutes: number;
  status: 'draft' | 'active' | 'completed';
  pass_mark_percentage: number;
  exam_date: string | null;
  start_time: string | null;
  end_time: string | null;
  shuffle_questions: number;
  shuffle_options: number;
  assessment_mapping: string | null;
  result_release_policy: string;
  token_count: number;
  submitted_count: number;
  active_count: number;
  created_at: string;
}

interface CbtToken {
  id: number;
  token: string;
  status: 'unused' | 'active' | 'submitted';
  score: number | null;
  started_at: string | null;
  submitted_at: string | null;
  tab_switches: number;
  student_name: string;
  class_name: string;
  class_arm: string;
  admission_no: string;
}

interface ExamResult {
  summary: {
    total_students: number;
    passed: number;
    failed: number;
    pass_rate: number;
    avg_score: number;
    max_score: number;
    pass_mark: number;
  };
  students: Array<{ id: number; student_name: string; score: number; submitted_at: string; tab_switches: number; class_arm: string; admission_no: string }>;
  question_analytics: Array<{ id: number; question_text: string; correct_option: string; attempts: number; correct_count: number }>;
}

// ─── Toast ───────────────────────────────────────────────────────────────────
function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error' | 'info'; onClose: () => void }) {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, [onClose]);
  const colours = { success: 'bg-emerald-900/90 border-emerald-500/40 text-emerald-300', error: 'bg-red-900/90 border-red-500/40 text-red-300', info: 'bg-indigo-900/90 border-indigo-500/40 text-indigo-300' };
  const Icon = type === 'success' ? CheckCircle2 : type === 'error' ? AlertTriangle : AlertCircle;
  return (
    <div className={`fixed bottom-6 right-6 z-[9999] flex items-center gap-3 px-4 py-3 rounded-2xl border shadow-2xl backdrop-blur-sm ${colours[type]}`}>
      <Icon className="w-4 h-4 shrink-0" />
      <span className="text-sm font-medium">{message}</span>
      <button onClick={onClose} className="ml-2 opacity-60 hover:opacity-100"><X className="w-3.5 h-3.5" /></button>
    </div>
  );
}

// ─── ConfirmDialog ────────────────────────────────────────────────────────────
function ConfirmDialog({ title, message, onConfirm, onCancel, danger = false }: {
  title: string; message: string; onConfirm: () => void; onCancel: () => void; danger?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-xl ${danger ? 'bg-red-500/10 border border-red-500/20' : 'bg-amber-500/10 border border-amber-500/20'}`}>
            <AlertTriangle className={`w-5 h-5 ${danger ? 'text-red-400' : 'text-amber-400'}`} />
          </div>
          <div>
            <h3 className="font-bold text-white">{title}</h3>
            <p className="text-sm text-slate-400 mt-1">{message}</p>
          </div>
        </div>
        <div className="flex gap-3 justify-end">
          <button onClick={onCancel} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
          <button onClick={onConfirm} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${danger ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-amber-600 hover:bg-amber-500 text-white'}`}>Confirm</button>
        </div>
      </div>
    </div>
  );
}

// ─── Difficulty badge ─────────────────────────────────────────────────────────
function DiffBadge({ d }: { d: string }) {
  const map: Record<string, string> = { easy: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20', hard: 'bg-red-500/10 text-red-400 border-red-500/20' };
  return <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase ${map[d] || map.medium}`}>{d}</span>;
}

// ─── Status badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    draft: 'bg-slate-700 text-slate-300 border-slate-600',
    active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    completed: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
    unused: 'bg-slate-700 text-slate-400 border-slate-600',
    submitted: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  };
  return <span className={`px-2.5 py-0.5 rounded-full border text-[11px] font-semibold capitalize ${map[status] || map.draft}`}>{status}</span>;
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 1: QUESTION BANKS
// ═══════════════════════════════════════════════════════════════════════════════
function QuestionBanksTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBank, setSelectedBank] = useState<QuestionBank | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [qPage, setQPage] = useState(1);
  const [qTotal, setQTotal] = useState(0);
  const [qLoading, setQLoading] = useState(false);
  const [showNewBank, setShowNewBank] = useState(false);
  const [showAddQuestion, setShowAddQuestion] = useState(false);
  const [confirmDeleteBank, setConfirmDeleteBank] = useState<QuestionBank | null>(null);
  const [confirmDeleteQ, setConfirmDeleteQ] = useState<Question | null>(null);
  const [newBank, setNewBank] = useState({ name: '', subject: '', class_category: 'General', description: '' });
  const [newQ, setNewQ] = useState({ question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'A', marks: '1', difficulty: 'medium' });

  const fetchBanks = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/admin/cbt/banks', { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setBanks(d.banks);
    } catch { toast('Failed to load question banks', 'error'); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { fetchBanks(); }, [fetchBanks]);

  const fetchQuestions = useCallback(async (bankId: number, page: number) => {
    setQLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/banks/${bankId}/questions?page=${page}&limit=50`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { setQuestions(d.questions); setQTotal(d.total); }
    } catch { toast('Failed to load questions', 'error'); }
    finally { setQLoading(false); }
  }, [toast]);

  useEffect(() => {
    if (selectedBank) fetchQuestions(selectedBank.id, qPage);
  }, [selectedBank, qPage, fetchQuestions]);

  const handleCreateBank = async () => {
    if (!newBank.name || !newBank.subject) return toast('Name and subject required', 'error');
    try {
      const r = await fetch('/api/admin/cbt/banks', { method: 'POST', headers: authHeaders(), body: JSON.stringify(newBank) });
      const d = await r.json();
      if (d.ok) { toast('Bank created', 'success'); setShowNewBank(false); setNewBank({ name: '', subject: '', class_category: 'General', description: '' }); fetchBanks(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleDeleteBank = async (bank: QuestionBank) => {
    try {
      const r = await fetch(`/api/admin/cbt/banks/${bank.id}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Bank deleted', 'success'); fetchBanks(); if (selectedBank?.id === bank.id) setSelectedBank(null); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmDeleteBank(null);
  };

  const handleAddQuestion = async () => {
    if (!selectedBank) return;
    if (!newQ.question_text || !newQ.option_a || !newQ.option_b || !newQ.option_c || !newQ.option_d) {
      return toast('All fields required', 'error');
    }
    try {
      const r = await fetch(`/api/admin/cbt/banks/${selectedBank.id}/questions`, {
        method: 'POST', headers: authHeaders(), body: JSON.stringify(newQ)
      });
      const d = await r.json();
      if (d.ok) {
        toast(`Question added (${d.total} total)`, 'success');
        setShowAddQuestion(false);
        setNewQ({ question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'A', marks: '1', difficulty: 'medium' });
        fetchQuestions(selectedBank.id, qPage);
        fetchBanks();
      } else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleDeleteQuestion = async (q: Question) => {
    try {
      const r = await fetch(`/api/admin/cbt/questions/${q.id}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Question deleted', 'success'); if (selectedBank) fetchQuestions(selectedBank.id, qPage); fetchBanks(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmDeleteQ(null);
  };

  return (
    <div className="space-y-6">
      {/* Banks grid */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Question Banks</h2>
          <p className="text-xs text-slate-400 mt-0.5">{banks.length} bank{banks.length !== 1 ? 's' : ''} available</p>
        </div>
        <button onClick={() => setShowNewBank(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold transition-colors">
          <Plus className="w-4 h-4" /> New Bank
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading banks…</div>
      ) : banks.length === 0 ? (
        <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
          <BookOpen className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-semibold">No question banks yet</p>
          <p className="text-slate-500 text-sm mt-1">Create your first bank to start adding questions</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {banks.map(bank => (
            <div
              key={bank.id}
              onClick={() => { setSelectedBank(bank); setQPage(1); }}
              className={`p-5 rounded-2xl border cursor-pointer transition-all ${selectedBank?.id === bank.id ? 'bg-indigo-900/30 border-indigo-500/40 ring-1 ring-indigo-500/30' : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                  <BookOpen className="w-4 h-4 text-indigo-400" />
                </div>
                <button onClick={(e) => { e.stopPropagation(); setConfirmDeleteBank(bank); }} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <h3 className="font-bold text-white text-sm leading-tight">{bank.name}</h3>
              <p className="text-xs text-indigo-400 mt-0.5">{bank.subject}</p>
              {bank.description && <p className="text-xs text-slate-500 mt-1 line-clamp-2">{bank.description}</p>}
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs text-slate-400">{bank.class_category}</span>
                <span className="text-xs font-bold text-emerald-400">{bank.question_count} Q</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Question list panel */}
      {selectedBank && (
        <div className="bg-slate-800/40 border border-slate-700/60 rounded-3xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
            <div>
              <h3 className="font-bold text-white">{selectedBank.name}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{qTotal} question{qTotal !== 1 ? 's' : ''} · {selectedBank.subject}</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => { setShowAddQuestion(true); }} className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-semibold hover:bg-emerald-600/30 transition-colors">
                <Plus className="w-3.5 h-3.5" /> Add Question
              </button>
              <button onClick={() => setSelectedBank(null)} className="p-1.5 rounded-lg text-slate-500 hover:text-white transition-colors"><X className="w-4 h-4" /></button>
            </div>
          </div>

          {qLoading ? (
            <div className="flex items-center justify-center h-24 text-slate-500 text-sm">Loading questions…</div>
          ) : questions.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-sm">No questions yet. Add your first question.</div>
          ) : (
            <div className="divide-y divide-slate-700/40">
              {questions.map((q, i) => (
                <div key={q.id} className="px-5 py-4 hover:bg-slate-800/60 transition-colors">
                  <div className="flex items-start gap-3">
                    <span className="text-[11px] font-bold text-slate-500 mt-0.5 w-6 shrink-0">{(qPage - 1) * 50 + i + 1}.</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-200 leading-snug">{q.question_text}</p>
                      <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1">
                        {(['A', 'B', 'C', 'D'] as const).map(opt => (
                          <div key={opt} className={`text-xs flex items-center gap-1.5 ${q.correct_option === opt ? 'text-emerald-400 font-semibold' : 'text-slate-400'}`}>
                            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${q.correct_option === opt ? 'bg-emerald-500/20 border border-emerald-500/30' : 'bg-slate-700 border border-slate-600'}`}>{opt}</span>
                            {q[`option_${opt.toLowerCase()}` as keyof Question] as string}
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <DiffBadge d={q.difficulty} />
                        <span className="text-[10px] text-slate-500">{q.marks} mark{q.marks !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                    <button onClick={() => setConfirmDeleteQ(q)} className="p-1.5 rounded-lg text-slate-600 hover:text-red-400 hover:bg-red-500/10 transition-colors shrink-0">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {qTotal > 50 && (
            <div className="px-5 py-3 border-t border-slate-700/60 flex items-center justify-between">
              <span className="text-xs text-slate-400">Showing {(qPage - 1) * 50 + 1}–{Math.min(qPage * 50, qTotal)} of {qTotal}</span>
              <div className="flex gap-2">
                <button disabled={qPage === 1} onClick={() => setQPage(p => p - 1)} className="px-3 py-1 rounded-lg bg-slate-700 text-slate-300 text-xs disabled:opacity-40">Prev</button>
                <button disabled={qPage * 50 >= qTotal} onClick={() => setQPage(p => p + 1)} className="px-3 py-1 rounded-lg bg-slate-700 text-slate-300 text-xs disabled:opacity-40">Next</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* New Bank Drawer */}
      {showNewBank && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">New Question Bank</h3>
              <button onClick={() => setShowNewBank(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Bank Name *</label>
                <input value={newBank.name} onChange={e => setNewBank(p => ({ ...p, name: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS 2 Mathematics Q3" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Subject *</label>
                <input value={newBank.subject} onChange={e => setNewBank(p => ({ ...p, subject: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. Mathematics" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Class Category</label>
                <input value={newBank.class_category} onChange={e => setNewBank(p => ({ ...p, class_category: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS" />
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Description</label>
                <textarea value={newBank.description} onChange={e => setNewBank(p => ({ ...p, description: e.target.value }))} rows={2} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="Optional description" />
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowNewBank(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleCreateBank} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Create Bank</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Question Modal */}
      {showAddQuestion && selectedBank && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-4 my-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">Add Question — {selectedBank.name}</h3>
              <button onClick={() => setShowAddQuestion(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Question Text *</label>
                <textarea value={newQ.question_text} onChange={e => setNewQ(p => ({ ...p, question_text: e.target.value }))} rows={3} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none" placeholder="Enter the question…" />
              </div>
              {(['a', 'b', 'c', 'd'] as const).map(opt => (
                <div key={opt}>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Option {opt.toUpperCase()} *</label>
                  <input value={newQ[`option_${opt}` as keyof typeof newQ]} onChange={e => setNewQ(p => ({ ...p, [`option_${opt}`]: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              ))}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Correct Answer *</label>
                  <select value={newQ.correct_option} onChange={e => setNewQ(p => ({ ...p, correct_option: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Marks</label>
                  <input type="number" min="1" max="10" value={newQ.marks} onChange={e => setNewQ(p => ({ ...p, marks: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Difficulty</label>
                  <select value={newQ.difficulty} onChange={e => setNewQ(p => ({ ...p, difficulty: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowAddQuestion(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleAddQuestion} className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-colors">Save Question</button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm delete bank */}
      {confirmDeleteBank && (
        <ConfirmDialog
          title="Delete Bank"
          message={`Delete "${confirmDeleteBank.name}" and all its ${confirmDeleteBank.question_count} questions? This cannot be undone.`}
          danger
          onConfirm={() => handleDeleteBank(confirmDeleteBank)}
          onCancel={() => setConfirmDeleteBank(null)}
        />
      )}

      {/* Confirm delete question */}
      {confirmDeleteQ && (
        <ConfirmDialog
          title="Delete Question"
          message="Remove this question from the bank?"
          danger
          onConfirm={() => handleDeleteQuestion(confirmDeleteQ)}
          onCancel={() => setConfirmDeleteQ(null)}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 2: EXAMS
// ═══════════════════════════════════════════════════════════════════════════════
function ExamsTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [exams, setExams] = useState<CbtExam[]>([]);
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [classes, setClasses] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewExam, setShowNewExam] = useState(false);
  const [selectedExam, setSelectedExam] = useState<CbtExam | null>(null);
  const [tokens, setTokens] = useState<CbtToken[]>([]);
  const [tokensLoading, setTokensLoading] = useState(false);
  const [showTokens, setShowTokens] = useState(false);
  const [confirmActivate, setConfirmActivate] = useState<CbtExam | null>(null);
  const [confirmClose, setConfirmClose] = useState<CbtExam | null>(null);
  const [confirmGenTokens, setConfirmGenTokens] = useState<CbtExam | null>(null);
  const [newExam, setNewExam] = useState({
    title: '', bank_id: '', class_name: '', question_count: '20', duration_minutes: '60',
    pass_mark_percentage: '50', shuffle_questions: true, shuffle_options: true,
    exam_date: '', start_time: '', end_time: '',
    assessment_mapping_assessment: '', assessment_mapping_subject: '',
    result_release_policy: 'immediate'
  });

  const fetchExams = useCallback(async () => {
    setLoading(true);
    try {
      const [er, br] = await Promise.all([
        fetch('/api/admin/cbt/exams', { headers: authHeaders() }),
        fetch('/api/admin/cbt/banks', { headers: authHeaders() }),
      ]);
      const [ed, bd] = await Promise.all([er.json(), br.json()]);
      if (ed.ok) setExams(ed.exams);
      if (bd.ok) setBanks(bd.banks);
    } catch { toast('Failed to load exams', 'error'); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { fetchExams(); }, [fetchExams]);

  // Fetch class list for dropdown
  useEffect(() => {
    fetch('/api/admin/classes', { headers: authHeaders() })
      .then(r => r.json())
      .then(d => {
        if (d.ok || Array.isArray(d.classes)) {
          const cls = (d.classes || []).map((c: { class_name?: string; hierarchy_class?: string }) => c.class_name || c.hierarchy_class || '').filter(Boolean);
          setClasses([...new Set(cls)] as string[]);
        }
      })
      .catch(() => {});
  }, []);

  const fetchTokens = useCallback(async (exam: CbtExam) => {
    setTokensLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/tokens`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setTokens(d.tokens);
    } catch { toast('Failed to load tokens', 'error'); }
    finally { setTokensLoading(false); }
  }, [toast]);

  const handleCreateExam = async () => {
    if (!newExam.title || !newExam.bank_id || !newExam.class_name || !newExam.question_count || !newExam.duration_minutes) {
      return toast('Fill all required fields', 'error');
    }
    const payload: Record<string, unknown> = {
      title: newExam.title, bank_id: Number(newExam.bank_id),
      class_name: newExam.class_name, question_count: Number(newExam.question_count),
      duration_minutes: Number(newExam.duration_minutes),
      pass_mark_percentage: Number(newExam.pass_mark_percentage),
      shuffle_questions: newExam.shuffle_questions, shuffle_options: newExam.shuffle_options,
      exam_date: newExam.exam_date || null, start_time: newExam.start_time || null, end_time: newExam.end_time || null,
      result_release_policy: newExam.result_release_policy,
    };
    if (newExam.assessment_mapping_assessment && newExam.assessment_mapping_subject) {
      payload.assessment_mapping = { assessment: newExam.assessment_mapping_assessment, subject: newExam.assessment_mapping_subject };
    }
    try {
      const r = await fetch('/api/admin/cbt/exams', { method: 'POST', headers: authHeaders(), body: JSON.stringify(payload) });
      const d = await r.json();
      if (d.ok) { toast('Exam created', 'success'); setShowNewExam(false); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
  };

  const handleActivate = async (exam: CbtExam) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/activate`, { method: 'PATCH', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Exam activated', 'success'); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmActivate(null);
  };

  const handleClose = async (exam: CbtExam) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/close`, { method: 'PATCH', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast('Exam closed', 'success'); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmClose(null);
  };

  const handleGenTokens = async (exam: CbtExam) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/tokens`, { method: 'POST', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) { toast(`${d.generated} token${d.generated !== 1 ? 's' : ''} generated (${d.total} students in class)`, 'success'); fetchExams(); }
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmGenTokens(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Exams</h2>
          <p className="text-xs text-slate-400 mt-0.5">{exams.length} exam{exams.length !== 1 ? 's' : ''} configured</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchExams} className="p-2 rounded-xl bg-slate-700 text-slate-400 hover:text-white transition-colors"><RefreshCw className="w-4 h-4" /></button>
          <button onClick={() => setShowNewExam(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold transition-colors">
            <Plus className="w-4 h-4" /> New Exam
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading…</div>
      ) : exams.length === 0 ? (
        <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
          <PlayCircle className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-semibold">No exams created yet</p>
          <p className="text-slate-500 text-sm mt-1">Create an exam and link it to a question bank</p>
        </div>
      ) : (
        <div className="space-y-3">
          {exams.map(exam => (
            <div key={exam.id} className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden">
              <div className="p-5">
                <div className="flex items-start gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-white">{exam.title}</h3>
                      <StatusBadge status={exam.status} />
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-slate-400">
                      <span>📚 {exam.bank_name} ({exam.bank_subject})</span>
                      <span>🏫 {exam.class_name}</span>
                      <span>❓ {exam.question_count} Q</span>
                      <span>⏱ {exam.duration_minutes} min</span>
                      <span>✅ Pass: {exam.pass_mark_percentage}%</span>
                      {exam.exam_date && <span>📅 {exam.exam_date}</span>}
                    </div>
                    <div className="mt-2 flex items-center gap-3 text-xs">
                      <span className="text-slate-400">{exam.token_count} tokens</span>
                      <span className="text-emerald-400">{exam.submitted_count} submitted</span>
                      {exam.active_count > 0 && <span className="text-amber-400 animate-pulse">{exam.active_count} live now</span>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-2 shrink-0">
                    {exam.status === 'draft' && (
                      <button onClick={() => setConfirmActivate(exam)} className="px-3 py-1.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-semibold hover:bg-emerald-600/30 transition-colors flex items-center gap-1">
                        <Zap className="w-3 h-3" /> Activate
                      </button>
                    )}
                    {exam.status === 'active' && (
                      <button onClick={() => setConfirmClose(exam)} className="px-3 py-1.5 bg-red-600/20 border border-red-500/30 text-red-400 rounded-xl text-xs font-semibold hover:bg-red-600/30 transition-colors">
                        Close Exam
                      </button>
                    )}
                    <button onClick={() => setConfirmGenTokens(exam)} className="px-3 py-1.5 bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 rounded-xl text-xs font-semibold hover:bg-indigo-600/30 transition-colors flex items-center gap-1">
                      <Users className="w-3 h-3" /> Gen Tokens
                    </button>
                    <button onClick={() => { setSelectedExam(exam); setShowTokens(true); fetchTokens(exam); }} className="px-3 py-1.5 bg-slate-700 border border-slate-600 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-600 transition-colors flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Tokens
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tokens slide-over */}
      {showTokens && selectedExam && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-sm">
          <div className="bg-slate-900 border-l border-slate-700 w-full max-w-lg flex flex-col h-full shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
              <div>
                <h3 className="font-bold text-white">Tokens — {selectedExam.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{tokens.length} candidate{tokens.length !== 1 ? 's' : ''}</p>
              </div>
              <button onClick={() => setShowTokens(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {tokensLoading ? (
                <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading…</div>
              ) : tokens.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-sm">No tokens generated yet.</div>
              ) : (
                <div className="divide-y divide-slate-800">
                  {tokens.map(tk => (
                    <div key={tk.id} className="px-5 py-3 hover:bg-slate-800/40 transition-colors">
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-white truncate">{tk.student_name || '—'}</p>
                          <p className="text-xs text-slate-400">{tk.class_name} {tk.class_arm}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-mono text-xs text-indigo-400 font-bold tracking-widest">{tk.token}</p>
                          <div className="flex items-center justify-end gap-2 mt-0.5">
                            <StatusBadge status={tk.status} />
                            {tk.score !== null && <span className="text-xs text-emerald-400 font-bold">{tk.score} pts</span>}
                          </div>
                        </div>
                      </div>
                      {tk.tab_switches > 0 && (
                        <p className="text-[10px] text-amber-400 mt-1">⚠ {tk.tab_switches} tab switch{tk.tab_switches !== 1 ? 'es' : ''}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Exam Modal */}
      {showNewExam && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-4 my-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white">New Exam</h3>
              <button onClick={() => setShowNewExam(false)} className="text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Title *</label>
                <input value={newExam.title} onChange={e => setNewExam(p => ({ ...p, title: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS 2 Mid-Term Mathematics" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Question Bank *</label>
                  <select value={newExam.bank_id} onChange={e => setNewExam(p => ({ ...p, bank_id: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                    <option value="">Select bank…</option>
                    {banks.map(b => <option key={b.id} value={b.id}>{b.name} ({b.question_count}Q)</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Target Class *</label>
                  {classes.length > 0 ? (
                    <select value={newExam.class_name} onChange={e => setNewExam(p => ({ ...p, class_name: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                      <option value="">Select class…</option>
                      {classes.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  ) : (
                    <input value={newExam.class_name} onChange={e => setNewExam(p => ({ ...p, class_name: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" placeholder="e.g. JSS 2" />
                  )}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">No. of Questions *</label>
                  <input type="number" min="1" value={newExam.question_count} onChange={e => setNewExam(p => ({ ...p, question_count: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Duration (min) *</label>
                  <input type="number" min="5" value={newExam.duration_minutes} onChange={e => setNewExam(p => ({ ...p, duration_minutes: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Pass Mark %</label>
                  <input type="number" min="0" max="100" value={newExam.pass_mark_percentage} onChange={e => setNewExam(p => ({ ...p, pass_mark_percentage: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Exam Date</label>
                  <input type="date" value={newExam.exam_date} onChange={e => setNewExam(p => ({ ...p, exam_date: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">Start Time</label>
                  <input type="time" value={newExam.start_time} onChange={e => setNewExam(p => ({ ...p, start_time: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 font-semibold mb-1 block">End Time</label>
                  <input type="time" value={newExam.end_time} onChange={e => setNewExam(p => ({ ...p, end_time: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500" />
                </div>
              </div>
              <div className="flex gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={newExam.shuffle_questions} onChange={e => setNewExam(p => ({ ...p, shuffle_questions: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Shuffle Questions</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={newExam.shuffle_options} onChange={e => setNewExam(p => ({ ...p, shuffle_options: e.target.checked }))} className="w-4 h-4 rounded accent-indigo-500" />
                  <span className="text-xs text-slate-300">Shuffle Options</span>
                </label>
              </div>
              <div>
                <label className="text-xs text-slate-400 font-semibold mb-1 block">Result Release</label>
                <select value={newExam.result_release_policy} onChange={e => setNewExam(p => ({ ...p, result_release_policy: e.target.value }))} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500">
                  <option value="immediate">Immediate</option>
                  <option value="delayed_30m">After 30 min</option>
                  <option value="delayed_1h">After 1 hour</option>
                  <option value="delayed_12h">After 12 hours</option>
                  <option value="delayed_24h">After 24 hours</option>
                  <option value="manual">Manual (Push to Grades)</option>
                </select>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 space-y-2">
                <p className="text-xs text-slate-400 font-semibold">Grade Push Mapping (optional)</p>
                <div className="grid grid-cols-2 gap-2">
                  <input value={newExam.assessment_mapping_assessment} onChange={e => setNewExam(p => ({ ...p, assessment_mapping_assessment: e.target.value }))} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" placeholder="Assessment (e.g. Exam)" />
                  <input value={newExam.assessment_mapping_subject} onChange={e => setNewExam(p => ({ ...p, assessment_mapping_subject: e.target.value }))} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" placeholder="Subject (e.g. Mathematics)" />
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button onClick={() => setShowNewExam(false)} className="px-4 py-2 rounded-xl bg-slate-700 text-slate-300 text-sm hover:bg-slate-600 transition-colors">Cancel</button>
              <button onClick={handleCreateExam} className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-colors">Create Exam</button>
            </div>
          </div>
        </div>
      )}

      {confirmActivate && <ConfirmDialog title="Activate Exam" message={`Activate "${confirmActivate.title}"? Students with tokens will be able to start immediately.`} onConfirm={() => handleActivate(confirmActivate)} onCancel={() => setConfirmActivate(null)} />}
      {confirmClose && <ConfirmDialog title="Close Exam" message={`Close "${confirmClose.title}"? Active sessions will be forcibly ended.`} danger onConfirm={() => handleClose(confirmClose)} onCancel={() => setConfirmClose(null)} />}
      {confirmGenTokens && <ConfirmDialog title="Generate Tokens" message={`Generate exam tokens for all active students in ${confirmGenTokens.class_name}? Existing tokens will not be duplicated.`} onConfirm={() => handleGenTokens(confirmGenTokens)} onCancel={() => setConfirmGenTokens(null)} />}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 3: LIVE MONITOR
// ═══════════════════════════════════════════════════════════════════════════════
function LiveMonitorTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [exams, setExams] = useState<CbtExam[]>([]);
  const [selectedExam, setSelectedExam] = useState<CbtExam | null>(null);
  const [tokens, setTokens] = useState<CbtToken[]>([]);
  const [loading, setLoading] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchActive = useCallback(async () => {
    try {
      const r = await fetch('/api/admin/cbt/exams', { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) {
        const active = d.exams.filter((e: CbtExam) => e.status === 'active');
        setExams(active);
        if (active.length > 0 && !selectedExam) setSelectedExam(active[0]);
      }
    } catch {}
    finally { setLoading(false); }
  }, [selectedExam]);

  const fetchTokens = useCallback(async (examId: number) => {
    try {
      const r = await fetch(`/api/admin/cbt/exams/${examId}/tokens`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setTokens(d.tokens);
    } catch {}
  }, []);

  useEffect(() => {
    fetchActive();
    intervalRef.current = setInterval(fetchActive, 10000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [fetchActive]);

  useEffect(() => {
    if (!selectedExam) return;
    fetchTokens(selectedExam.id);
    const t = setInterval(() => fetchTokens(selectedExam.id), 5000);
    return () => clearInterval(t);
  }, [selectedExam, fetchTokens]);

  const submitted = tokens.filter(t => t.status === 'submitted');
  const active = tokens.filter(t => t.status === 'active');
  const unused = tokens.filter(t => t.status === 'unused');

  if (loading) return <div className="flex items-center justify-center h-48 text-slate-500 text-sm">Loading…</div>;

  if (exams.length === 0) {
    return (
      <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
        <Shield className="w-10 h-10 text-slate-600 mx-auto mb-3" />
        <p className="text-slate-400 font-semibold">No active exams right now</p>
        <p className="text-slate-500 text-sm mt-1">Activate an exam from the Exams tab to see live monitoring here</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Live Monitor</h2>
          <p className="text-xs text-slate-400 mt-0.5">Auto-refreshes every 5 seconds</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Live
          </span>
        </div>
      </div>

      {/* Exam selector */}
      {exams.length > 1 && (
        <div className="flex gap-2 flex-wrap">
          {exams.map(e => (
            <button key={e.id} onClick={() => setSelectedExam(e)} className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${selectedExam?.id === e.id ? 'bg-indigo-600/30 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:border-slate-600'}`}>
              {e.title}
            </button>
          ))}
        </div>
      )}

      {selectedExam && (
        <>
          {/* KPIs */}
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: 'Total', value: tokens.length, colour: 'text-white' },
              { label: 'Live', value: active.length, colour: 'text-amber-400' },
              { label: 'Submitted', value: submitted.length, colour: 'text-emerald-400' },
              { label: 'Not Started', value: unused.length, colour: 'text-slate-400' },
            ].map(kpi => (
              <div key={kpi.label} className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 text-center">
                <p className={`text-2xl font-bold ${kpi.colour}`}>{kpi.value}</p>
                <p className="text-xs text-slate-400 mt-0.5">{kpi.label}</p>
              </div>
            ))}
          </div>

          {/* Token table */}
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-700/60">
              <h3 className="font-semibold text-white text-sm">{selectedExam.title} — Candidate Status</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-[11px] text-slate-500 uppercase border-b border-slate-700/60">
                    <th className="text-left px-4 py-2">Student</th>
                    <th className="text-left px-4 py-2">Class</th>
                    <th className="text-left px-4 py-2">Token</th>
                    <th className="text-left px-4 py-2">Status</th>
                    <th className="text-left px-4 py-2">Started</th>
                    <th className="text-left px-4 py-2">Tab Switches</th>
                    <th className="text-left px-4 py-2">Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {tokens.map(tk => (
                    <tr key={tk.id} className={`hover:bg-slate-800/60 transition-colors ${tk.status === 'active' ? 'bg-amber-500/5' : ''}`}>
                      <td className="px-4 py-2.5 text-white font-medium">{tk.student_name || '—'}</td>
                      <td className="px-4 py-2.5 text-slate-400">{tk.class_name} {tk.class_arm}</td>
                      <td className="px-4 py-2.5 font-mono text-indigo-400 text-xs tracking-widest">{tk.token}</td>
                      <td className="px-4 py-2.5"><StatusBadge status={tk.status} /></td>
                      <td className="px-4 py-2.5 text-slate-400 text-xs">{tk.started_at ? new Date(tk.started_at).toLocaleTimeString() : '—'}</td>
                      <td className="px-4 py-2.5">
                        {tk.tab_switches > 0 ? <span className="text-amber-400 font-semibold">⚠ {tk.tab_switches}</span> : <span className="text-slate-600">0</span>}
                      </td>
                      <td className="px-4 py-2.5">
                        {tk.score !== null ? <span className="text-emerald-400 font-bold">{tk.score}</span> : <span className="text-slate-600">—</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB 4: RESULTS
// ═══════════════════════════════════════════════════════════════════════════════
function ResultsTab({ toast }: { toast: (m: string, t: 'success' | 'error' | 'info') => void }) {
  const [exams, setExams] = useState<CbtExam[]>([]);
  const [selectedExam, setSelectedExam] = useState<CbtExam | null>(null);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [resultLoading, setResultLoading] = useState(false);
  const [confirmRelease, setConfirmRelease] = useState(false);

  useEffect(() => {
    fetch('/api/admin/cbt/exams', { headers: authHeaders() })
      .then(r => r.json())
      .then(d => { if (d.ok) setExams(d.exams.filter((e: CbtExam) => e.submitted_count > 0)); })
      .catch(() => toast('Failed to load exams', 'error'))
      .finally(() => setLoading(false));
  }, [toast]);

  const fetchResult = useCallback(async (exam: CbtExam) => {
    setResultLoading(true);
    try {
      const r = await fetch(`/api/admin/cbt/exams/${exam.id}/results`, { headers: authHeaders() });
      const d = await r.json();
      if (d.ok) setResult(d);
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    finally { setResultLoading(false); }
  }, [toast]);

  const handleRelease = async () => {
    if (!selectedExam) return;
    try {
      const r = await fetch(`/api/admin/cbt/exams/${selectedExam.id}/release`, { method: 'POST', headers: authHeaders() });
      const d = await r.json();
      if (d.ok) toast(`${d.released} score${d.released !== 1 ? 's' : ''} pushed to student records`, 'success');
      else toast(d.error || 'Failed', 'error');
    } catch { toast('Network error', 'error'); }
    setConfirmRelease(false);
  };

  if (loading) return <div className="flex items-center justify-center h-48 text-slate-500 text-sm">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Results</h2>
          <p className="text-xs text-slate-400 mt-0.5">{exams.length} exam{exams.length !== 1 ? 's' : ''} with submissions</p>
        </div>
      </div>

      {exams.length === 0 ? (
        <div className="p-10 rounded-3xl bg-slate-800/40 border border-slate-700/60 text-center">
          <BarChart3 className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 font-semibold">No results yet</p>
          <p className="text-slate-500 text-sm mt-1">Results appear here once students have submitted an exam</p>
        </div>
      ) : (
        <>
          {/* Exam selector */}
          <div className="flex gap-2 flex-wrap">
            {exams.map(e => (
              <button key={e.id} onClick={() => { setSelectedExam(e); fetchResult(e); }} className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${selectedExam?.id === e.id ? 'bg-indigo-600/30 border-indigo-500/40 text-indigo-300' : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:border-slate-600'}`}>
                {e.title} <span className="opacity-60">({e.submitted_count})</span>
              </button>
            ))}
          </div>

          {selectedExam && resultLoading && (
            <div className="flex items-center justify-center h-32 text-slate-500 text-sm">Loading results…</div>
          )}

          {selectedExam && result && !resultLoading && (
            <div className="space-y-5">
              {/* Summary KPIs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: 'Submissions', value: result.summary.total_students, colour: 'text-white', icon: Users },
                  { label: 'Pass Rate', value: `${result.summary.pass_rate}%`, colour: result.summary.pass_rate >= 50 ? 'text-emerald-400' : 'text-red-400', icon: TrendingUp },
                  { label: 'Avg Score', value: `${result.summary.avg_score}/${result.summary.max_score}`, colour: 'text-indigo-400', icon: Award },
                  { label: 'Pass Mark', value: `${result.summary.pass_mark}`, colour: 'text-amber-400', icon: CheckCircle2 },
                ].map(kpi => (
                  <div key={kpi.label} className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60">
                    <kpi.icon className={`w-5 h-5 ${kpi.colour} mb-2`} />
                    <p className={`text-2xl font-bold ${kpi.colour}`}>{kpi.value}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{kpi.label}</p>
                  </div>
                ))}
              </div>

              {/* Push to Grades */}
              {selectedExam.assessment_mapping && (
                <div className="p-4 rounded-2xl bg-indigo-900/20 border border-indigo-500/20 flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-indigo-300">Push Scores to Grade Book</p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {(() => { try { const m = JSON.parse(selectedExam.assessment_mapping!); return `${m.assessment} · ${m.subject}`; } catch { return selectedExam.assessment_mapping; } })()}
                    </p>
                  </div>
                  <button onClick={() => setConfirmRelease(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center gap-2">
                    <Upload className="w-4 h-4" /> Push to Grades
                  </button>
                </div>
              )}

              {/* Scoreboard */}
              <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-700/60 flex items-center justify-between">
                  <h3 className="font-semibold text-white text-sm">Scoreboard</h3>
                  <span className="text-xs text-slate-400">{result.summary.passed} passed · {result.summary.failed} failed</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-[11px] text-slate-500 uppercase border-b border-slate-700/60">
                        <th className="text-left px-4 py-2">#</th>
                        <th className="text-left px-4 py-2">Student</th>
                        <th className="text-left px-4 py-2">Arm</th>
                        <th className="text-left px-4 py-2">Score</th>
                        <th className="text-left px-4 py-2">%</th>
                        <th className="text-left px-4 py-2">Result</th>
                        <th className="text-left px-4 py-2">Tab Switches</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {result.students.map((s, i) => {
                        const pct = Math.round((s.score || 0) / result.summary.max_score * 100);
                        const passed = s.score >= result.summary.pass_mark;
                        return (
                          <tr key={s.id} className="hover:bg-slate-800/60 transition-colors">
                            <td className="px-4 py-2.5 text-slate-500 text-xs">{i + 1}</td>
                            <td className="px-4 py-2.5 text-white font-medium">{s.student_name}</td>
                            <td className="px-4 py-2.5 text-slate-400 text-xs">{s.class_arm}</td>
                            <td className="px-4 py-2.5 font-bold text-white">{s.score}</td>
                            <td className="px-4 py-2.5 text-slate-300">{pct}%</td>
                            <td className="px-4 py-2.5">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${passed ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400'}`}>
                                {passed ? 'PASS' : 'FAIL'}
                              </span>
                            </td>
                            <td className="px-4 py-2.5">{s.tab_switches > 0 ? <span className="text-amber-400">⚠ {s.tab_switches}</span> : <span className="text-slate-600">—</span>}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Question Analytics */}
              {result.question_analytics.length > 0 && (
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-700/60">
                    <h3 className="font-semibold text-white text-sm">Question Difficulty Analysis</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Sorted by hardest (fewest correct answers) first</p>
                  </div>
                  <div className="divide-y divide-slate-800">
                    {result.question_analytics.slice(0, 10).map((qa, i) => {
                      const pct = qa.attempts > 0 ? Math.round(qa.correct_count / qa.attempts * 100) : 0;
                      return (
                        <div key={qa.id} className="px-4 py-3">
                          <div className="flex items-start gap-3">
                            <span className="text-[11px] text-slate-500 font-bold mt-0.5 w-5 shrink-0">{i + 1}.</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs text-slate-300 line-clamp-2">{qa.question_text}</p>
                              <div className="mt-1.5 flex items-center gap-3">
                                <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                                  <div className={`h-full rounded-full ${pct >= 70 ? 'bg-emerald-500' : pct >= 40 ? 'bg-amber-500' : 'bg-red-500'}`} style={{ width: `${pct}%` }} />
                                </div>
                                <span className="text-[11px] text-slate-400 shrink-0">{qa.correct_count}/{qa.attempts} correct ({pct}%)</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {confirmRelease && (
        <ConfirmDialog
          title="Push Scores to Grades"
          message={`Push ${result?.summary.total_students || 0} scores into student records? This will overwrite existing records for the same assessment and subject.`}
          onConfirm={handleRelease}
          onCancel={() => setConfirmRelease(false)}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN CbtPage
// ═══════════════════════════════════════════════════════════════════════════════
const TABS = [
  { id: 'banks', label: 'Question Banks', icon: BookOpen },
  { id: 'exams', label: 'Exams', icon: PlayCircle },
  { id: 'monitor', label: 'Live Monitor', icon: MonitorCheck },
  { id: 'results', label: 'Results', icon: BarChart3 },
] as const;

type TabId = typeof TABS[number]['id'];

export default function CbtPage() {
  const [activeTab, setActiveTab] = useState<TabId>('banks');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type });
  }, []);

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="CBT Exam Center" subtitle="Computer-based testing · Question banks · Live monitoring · Auto-grading" />

      <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
        {/* Tab bar */}
        <div className="flex gap-1 p-1 bg-slate-800/60 rounded-2xl border border-slate-700/60 w-fit">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/60'}`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {activeTab === 'banks' && <QuestionBanksTab toast={showToast} />}
        {activeTab === 'exams' && <ExamsTab toast={showToast} />}
        {activeTab === 'monitor' && <LiveMonitorTab toast={showToast} />}
        {activeTab === 'results' && <ResultsTab toast={showToast} />}
      </div>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
