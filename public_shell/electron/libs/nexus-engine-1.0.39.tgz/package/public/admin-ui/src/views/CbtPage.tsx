import React from 'react';
import Header from '../components/Header';
import { MonitorCheck, Play, Award, CheckCircle2 } from 'lucide-react';

export default function CbtPage() {
  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-900 overflow-y-auto">
      <Header title="CBT Exam Center" subtitle="Computer-based testing, sittings, tokens & auto-grading (Phase 7f)" />
      <div className="p-8 max-w-7xl mx-auto w-full space-y-6">
        <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/60 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <MonitorCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Local Exam Room &amp; CBT Controller</h3>
              <p className="text-xs text-slate-400">Schedule timed exams, monitor active LAN computer banks, and generate candidate tokens</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The local CBT engine operates completely without internet on the campus LAN (<code className="text-indigo-400 font-mono">/cbt</code>), supporting high-concurrency exam submissions, automatic grading, and instant score reconciliation into student records.
          </p>
          <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Phase 7f Component Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
