const database          = require('./src/database');
const server            = require('./src/server');
const reports           = require('./src/report-compiler');
const classArmValidator = require('./src/classArmValidator');
const reportAssembler   = require('./src/report-assembler');

module.exports = {
  database,
  server,
  reports,
  classArmValidator,
  reportAssembler,
};
