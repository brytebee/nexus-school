const database = require('./src/database');
const server = require('./src/server');
const reports = require('./src/report-compiler');
const classArmValidator = require('./src/classArmValidator');

module.exports = {
  database,
  server,
  reports,
  classArmValidator
};

