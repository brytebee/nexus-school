/**
 * report-assembler.js
 *
 * Canonical student data assembly for report card generation.
 * Used by result-dispatcher.js (WA / Email dispatch) and
 * compileBatchAndUpload (parent portal publish).
 *
 * The assembly logic deliberately mirrors the main.js `query-results`
 * IPC handler so that a dispatched PDF is identical to a manually
 * generated one — one code change propagates to all three paths.
 *
 * Exported API:
 *   assembleStudentsForReport(db, studentIds, term, session) → { students, termConfig }
 *   fetchTermConfig(db, overrides?)                          → termConfig object
 */

'use strict';

const database = require('./database');

// ─────────────────────────────────────────────────────────────────────────────
// fetchTermConfig
// Loads the full term configuration row and merges any caller overrides.
// Includes every field the report-compiler template contract depends on.
// ─────────────────────────────────────────────────────────────────────────────
function fetchTermConfig(db, overrides = {}) {
  let base = {};
  try {
    base = db.prepare(`
      SELECT academic_session, term,
             grading_scale, show_position, show_domains, show_attendance,
             include_attendance_in_grades, attendance_score_weight,
             exclude_unregistered_from_totals,
             resumption_date, term_start_date, term_end_date
      FROM school_term_config WHERE id = 1
    `).get() || {};
  } catch (_) { /* schema may not have all columns yet */ }

  return { ...base, ...overrides };
}

// ─────────────────────────────────────────────────────────────────────────────
// assembleStudentsForReport
//
// Builds a generate-reports-compatible student array for the given IDs.
// Returns the same object shape that the `query-results` IPC handler returns
// per student, so any template change in report-compiler.js is automatically
// picked up by the dispatcher without requiring a parallel update.
//
// Priority order (mirrors query-results):
//   1. student_attendance  (manually entered totals, most authoritative)
//   2. daily_attendance    (aggregated from daily roll calls)
// ─────────────────────────────────────────────────────────────────────────────
function assembleStudentsForReport(db, studentIds, term, session) {
  if (!Array.isArray(studentIds) || !studentIds.length) {
    return { students: [], termConfig: fetchTermConfig(db) };
  }

  // ── Config ────────────────────────────────────────────────────────────────
  let excludeUnregisteredFromTotals = false;
  try {
    const r = db.prepare(
      'SELECT exclude_unregistered_from_totals FROM school_term_config WHERE id = 1'
    ).get() || {};
    excludeUnregisteredFromTotals = r.exclude_unregistered_from_totals === 1;
  } catch (_) {}

  // ── Hoist prepared statements (avoid re-preparing inside the student loop) ─
  const getRecords = db.prepare(
    'SELECT subject, score, breakdown FROM student_records WHERE student_id = ? AND academic_session = ? AND term = ?'
  );
  const getExplicitSubjects = db.prepare(
    'SELECT subject FROM student_subjects WHERE student_id = ?'
  );
  const getDomains = db.prepare(
    'SELECT domain_type, trait, grade FROM student_domains WHERE student_id = ? AND academic_session = ? AND term = ?'
  );
  const getRemark = db.prepare(
    'SELECT remark, principal_remark FROM teacher_remarks WHERE student_id = ? AND academic_session = ? AND term = ?'
  );
  const getTermAttendance = db.prepare(
    'SELECT total_days, days_attended FROM student_attendance WHERE student_id = ? AND academic_session = ? AND term = ?'
  );

  let getStudentAttendanceCount = null;
  try {
    getStudentAttendanceCount = db.prepare(`
      SELECT count(*) as days_attended
      FROM daily_attendance
      WHERE student_id = ? AND status IN ('Present', 'Late') AND academic_session = ? AND term = ?
    `);
  } catch (_) { /* daily_attendance table may not exist in older schemas */ }

  // ── Pre-load form teacher map (O(1) lookup per class) ────────────────────
  const formTeacherMap = new Map();
  try {
    db.prepare(`
      SELECT f.class_name, t.name, t.signature
      FROM form_teachers f
      JOIN teachers t ON f.teacher_id = t.id
    `).all().forEach(ft => formTeacherMap.set(ft.class_name, ft));
  } catch (_) {}

  // ── Pre-load class-level attendance totals from daily_attendance ──────────
  const classDaysMap = new Map();
  try {
    db.prepare(`
      SELECT class_name, count(DISTINCT date) as total_days
      FROM daily_attendance
      WHERE academic_session = ? AND term = ?
      GROUP BY class_name
    `).all(session, term).forEach(r => classDaysMap.set(r.class_name, r.total_days));
  } catch (_) { /* daily_attendance may not exist */ }

  // ── Fee gate setting ──────────────────────────────────────────────────────
  let feeGateEnabled = false;
  const getFeeStatus = (() => {
    try {
      const settings = JSON.parse(
        db.prepare("SELECT value FROM app_settings WHERE key = 'fee_settings'").get()?.value || '{}'
      );
      feeGateEnabled = settings.fee_gate_enabled !== false;
      // Compute dynamically from balance (total_billed - total_paid) — NOT from stale status column
      return feeGateEnabled
        ? db.prepare('SELECT COALESCE(total_billed, 0) - COALESCE(total_paid, 0) AS balance FROM student_fees WHERE student_id = ? AND academic_session = ? AND term = ? LIMIT 1')
        : null;
    } catch (_) {
      return null;
    }
  })();

  // ── ILS prepared statements ────────────────────────────────────────────────
  const getIlsRecords = (() => {
    try {
      return db.prepare(`
        SELECT subject, pack_number, score, passed
        FROM ils_records
        WHERE student_id = ? AND academic_session = ? AND term = ?
        ORDER BY subject, pack_number
      `);
    } catch (_) { return null; }
  })();

  const getIlsVerse = (() => {
    try {
      return db.prepare(`SELECT verse_count FROM ils_verse_memory WHERE student_id = ? AND academic_session = ? AND term = ?`);
    } catch (_) { return null; }
  })();

  const getClassTypeStmt = (() => {
    try {
      return db.prepare(`SELECT curriculum_type, pac_count, pac_labels FROM class_configs WHERE hierarchy_class = ? OR hierarchy_class = ?`);
    } catch (_) { return null; }
  })();

  // ── Fetch base student rows ───────────────────────────────────────────────
  const placeholders = studentIds.map(() => '?').join(', ');
  const baseStudents = db.prepare(
    `SELECT * FROM students WHERE id IN (${placeholders})`
  ).all(...studentIds);

  // ── Assemble each student ─────────────────────────────────────────────────
  const students = baseStudents.map(stu => {
    // Subject resolution: registered subjects first, merged with score records
    const records       = getRecords.all(stu.id, session, term);
    const explicitSubjs = getExplicitSubjects.all(stu.id).map(r => r.subject);
    const explicitSet   = new Set(explicitSubjs);

    const resolvedSubjects = new Map();
    explicitSubjs.forEach(name =>
      resolvedSubjects.set(name, { name, score: null, breakdown: {}, isRegistered: true })
    );
    records.forEach(r =>
      resolvedSubjects.set(r.subject, {
        name:         r.subject,
        score:        r.score,
        breakdown:    parseBreakdown(r.breakdown),
        isRegistered: explicitSet.has(r.subject),
      })
    );
    const subjects = Array.from(resolvedSubjects.values());

    // Merge arm into class_name if stored separately
    const fullClassName = (stu.class_arm && !stu.class_name.includes(stu.class_arm))
      ? `${stu.class_name} ${stu.class_arm}`
      : stu.class_name;

    // Check ILS curriculum type
    const baseClassName = fullClassName.split(' ').slice(0, -1).join(' ') || fullClassName;
    let curriculumType = 'STANDARD_NIGERIAN';
    let pacCount = 12;
    let pacLabels = null;
    if (getClassTypeStmt) {
      try {
        const ctRow = getClassTypeStmt.get(fullClassName, baseClassName);
        curriculumType = ctRow?.curriculum_type || 'STANDARD_NIGERIAN';
        pacCount = ctRow?.pac_count || 12;
        try { if (ctRow?.pac_labels) pacLabels = JSON.parse(ctRow.pac_labels); } catch (_) {}
      } catch (_) {}
    }

    let il_subjects = [];
    let verseCount = 0;
    if (curriculumType === 'ILS' && getIlsRecords) {
      try {
        const ilsRows = getIlsRecords.all(stu.id, session, term);
        const bySubject = {};
        for (const r of ilsRows) {
          if (!bySubject[r.subject]) bySubject[r.subject] = [];
          bySubject[r.subject].push(r);
        }
        il_subjects = Object.entries(bySubject).map(([subject, packs]) => {
          const packsMap = {};
          let hundredsCount = 0;
          packs.forEach(p => {
            packsMap[p.pack_number] = p.score;
            if (p.score === 100) hundredsCount++;
          });
          const passed  = packs.filter(p => p.passed === 1);
          const total   = packs.reduce((sum, p) => sum + p.score, 0);
          const avg     = packs.length > 0 ? Math.round((total / packs.length) * 10) / 10 : 0;
          return {
            subject,
            packs: packsMap,
            packs_completed: passed.length,
            hundreds_count: hundredsCount,
            total_score: total,
            average: avg
          };
        });

        if (getIlsVerse) {
          const vRow = getIlsVerse.get(stu.id, session, term);
          verseCount = vRow?.verse_count || 0;
        }
      } catch (_) {}
    }

    // Domains & remarks
    const domains = getDomains.all(stu.id, session, term);
    const remark  = getRemark.get(stu.id, session, term) || {};

    // Form teacher lookup
    const ft = formTeacherMap.get(fullClassName) || {};

    // Attendance (priority: student_attendance → daily_attendance → zeroes)
    const termAtt = getTermAttendance.get(stu.id, session, term);
    let classTotalDays = 0;
    let daysAttended   = 0;
    if (termAtt) {
      classTotalDays = termAtt.total_days;
      daysAttended   = termAtt.days_attended;
    } else if (getStudentAttendanceCount) {
      classTotalDays = classDaysMap.get(fullClassName) || 0;
      daysAttended   = (getStudentAttendanceCount.get(stu.id, session, term) || { days_attended: 0 }).days_attended;
    }

    // Fee status — dynamically computed from balance (total_billed - total_paid)
    let feeStatus = 'cleared';
    if (getFeeStatus) {
      try {
        const fRow = getFeeStatus.get(stu.id, session, term);
        // fRow is null when no fee record exists for this term; treat as cleared
        feeStatus = (fRow && fRow.balance > 0) ? 'owing' : 'cleared';
      } catch (_) {}
    }

    return {
      ...stu,
      class_name:             fullClassName,
      curriculum_type:        curriculumType,
      il_subjects,
      pac_count:              pacCount,
      pac_labels:             pacLabels,
      verse_count:            verseCount,
      academic_session:       session,
      term,
      subjects,
      domains,
      remark:                 remark.remark          || '',
      principal_remark:       remark.principal_remark || '',
      // ── IMPORTANT: attendance MUST be a nested object —
      //    clean_slate.hbs reads {{student.attendance.days_attended}}
      //    and {{student.attendance.total_days}}. Flat scalars produce " / ".
      attendance: {
        total_days:    classTotalDays,
        days_attended: daysAttended,
      },
      form_teacher_name:      ft.name      || '',
      form_teacher_signature: ft.signature || null,
      feeStatus,
    };
  });

  return {
    students,
    termConfig: fetchTermConfig(db),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// parseBreakdown — safely parses a JSON string into a plain object
// ─────────────────────────────────────────────────────────────────────────────
function parseBreakdown(raw) {
  try {
    const p = JSON.parse(raw);
    return (p && typeof p === 'object' && !Array.isArray(p)) ? p : {};
  } catch {
    return {};
  }
}

module.exports = {
  assembleStudentsForReport,
  fetchTermConfig,
  // Export for unit testing
  _parseBreakdown: parseBreakdown,
};
