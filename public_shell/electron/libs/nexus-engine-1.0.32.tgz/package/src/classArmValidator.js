/**
 * Pure Class & Arm Validation Utility
 * Validates raw class strings against pre-fetched Class Manager data.
 *
 * @param {string} raw - Raw input string (e.g., "JSS 1 Gold", "JSS 1", "All Classes")
 * @param {Array<string|Object>} classConfigs - Array of hierarchy_class strings or objects [{hierarchy_class}]
 * @param {Array<Object>} classArms - Array of [{hierarchy_class, arm}] objects
 * @param {Object} [options] - Options object
 * @param {'strict'|'fee_target'} [options.mode='strict'] - Validation mode
 * @returns {{ ok: boolean, error?: string, resolved?: { class_name: string|null, class_arm: string|null } }}
 */
function validateClassArmRef(raw, classConfigs = [], classArms = [], options = {}) {
    const mode = options.mode || 'strict';
    const trimmed = (raw || '').trim();

    if (!trimmed) {
        return { ok: false, error: 'Class selection is required.' };
    }

    // Special wildcard handling for fee structure targets
    if (mode === 'fee_target' && trimmed.toLowerCase() === 'all classes') {
        return {
            ok: true,
            resolved: { class_name: null, class_arm: null }
        };
    }

    // Normalize input arrays to standard canonical structures
    const normalizedConfigs = classConfigs.map(c => {
        if (typeof c === 'string') return { canonical: c.trim(), lower: c.trim().toLowerCase() };
        const name = (c.hierarchy_class || c.name || '').trim();
        return { canonical: name, lower: name.toLowerCase() };
    }).filter(c => Boolean(c.canonical));

    const normalizedArms = classArms.map(a => {
        const cls = (a.hierarchy_class || '').trim();
        const arm = (a.arm || '').trim();
        return {
            canonicalClass: cls,
            canonicalArm: arm,
            lowerClass: cls.toLowerCase(),
            lowerArm: arm.toLowerCase(),
            lowerFull: `${cls.toLowerCase()} ${arm.toLowerCase()}`
        };
    }).filter(a => Boolean(a.canonicalClass) && Boolean(a.canonicalArm));

    // Sort configs by length descending so multi-word classes (e.g. "SSS 1") take precedence over short prefixes
    const sortedConfigs = [...normalizedConfigs].sort((a, b) => b.lower.length - a.lower.length);

    let matchedConfig = null;
    let rawArm = '';

    const inputLower = trimmed.toLowerCase();

    for (const conf of sortedConfigs) {
        if (inputLower === conf.lower) {
            matchedConfig = conf;
            rawArm = '';
            break;
        }
        if (inputLower.startsWith(conf.lower + ' ')) {
            matchedConfig = conf;
            rawArm = trimmed.substring(conf.lower.length + 1).trim();
            break;
        }
    }

    if (!matchedConfig) {
        return { ok: false, error: `Class "${trimmed}" is not registered in Class Manager.` };
    }

    const canonicalClassName = matchedConfig.canonical;
    const lowerClassName = matchedConfig.lower;

    // Find all registered arms for this class
    const armsForClass = normalizedArms.filter(a => a.lowerClass === lowerClassName);

    if (armsForClass.length > 0) {
        // Class HAS registered arms
        if (!rawArm) {
            if (mode === 'fee_target') {
                // Level-wide billing allowed for fee structure
                return {
                    ok: true,
                    resolved: { class_name: canonicalClassName, class_arm: '' }
                };
            } else {
                // Roster mode (student / teacher) requires an arm
                return {
                    ok: false,
                    error: `Class "${canonicalClassName}" requires a designated arm (e.g. ${armsForClass.map(a => a.canonicalArm).join(', ')}).`
                };
            }
        }

        const matchedArmObj = armsForClass.find(a => a.lowerArm === rawArm.toLowerCase());
        if (!matchedArmObj) {
            return {
                ok: false,
                error: `Arm "${rawArm}" is not registered for class "${canonicalClassName}".`
            };
        }

        return {
            ok: true,
            resolved: { class_name: canonicalClassName, class_arm: matchedArmObj.canonicalArm }
        };
    } else {
        // Class HAS NO registered arms
        if (rawArm) {
            return {
                ok: false,
                error: `Class "${canonicalClassName}" has no registered arms, but arm "${rawArm}" was specified.`
            };
        }

        return {
            ok: true,
            resolved: { class_name: canonicalClassName, class_arm: '' }
        };
    }
}

module.exports = {
    validateClassArmRef
};
