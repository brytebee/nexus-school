'use strict';

/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: 'node',
  // Route better-sqlite3 to a copy compiled for the local Node.js / arm64
  // runtime so tests don't fail with the Electron-compiled x86_64 binary.
  moduleNameMapper: {
    '^better-sqlite3$': '<rootDir>/src/__tests__/test-deps/node_modules/better-sqlite3'
  }
};
