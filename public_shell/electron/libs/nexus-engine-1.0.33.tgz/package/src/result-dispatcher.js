/**
 * result-dispatcher.js
 *
 * WA / Email result dispatch and parent-portal publish pipeline.
 *
 * PDF generation uses report-assembler.js + report-compiler.js, which are
 * the same modules used by the main.js `generate-reports` IPC handler.
 * This guarantees a dispatched PDF is byte-identical to a manually generated one.
 * Any change to the Handlebars template or report-compiler is automatically
 * picked up here — no parallel update needed.
 */

'use strict';

const nodemailer = require('nodemailer');
const fs         = require('fs');
const path       = require('path');
const crypto     = require('crypto');
const { app, BrowserWindow } = require('electron');

const database = require('./database');
const reports  = require('./report-compiler');
const { assembleStudentsForReport, fetchTermConfig } = require('./report-assembler');

// ─────────────────────────────────────────────────────────────────────────────
// SMTP password encryption helpers (AES-256-GCM)
// ─────────────────────────────────────────────────────────────────────────────
function getEncryptionKey() {
  const fingerprint =
    process.versions.node +
    process.platform +
    (process.env.COMPUTERNAME || process.env.HOSTNAME || 'nexus-key-seed');
  return crypto.createHash('sha256').update(fingerprint).digest();
}

function encrypt(text) {
  if (!text) return '';
  try {
    const key    = getEncryptionKey();
    const iv     = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    let enc      = cipher.update(text, 'utf8', 'hex');
    enc         += cipher.final('hex');
    return `${iv.toString('hex')}:${cipher.getAuthTag().toString('hex')}:${enc}`;
  } catch (_) { return ''; }
}

function decrypt(text) {
  if (!text) return '';
  try {
    const key     = getEncryptionKey();
    const parts   = text.split(':');
    if (parts.length !== 3) return '';
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(parts[0], 'hex'));
    decipher.setAuthTag(Buffer.from(parts[1], 'hex'));
    let dec  = decipher.update(parts[2], 'hex', 'utf8');
    dec     += decipher.final('utf8');
    return dec;
  } catch (_) { return ''; }
}

// ─────────────────────────────────────────────────────────────────────────────
// loadIdentity — loads school identity & enriches tier + principal signature
// ─────────────────────────────────────────────────────────────────────────────
function loadIdentity(db) {
  let identity = null;
  try {
    const row = db.prepare("SELECT value FROM app_settings WHERE key = 'school_identity'").get();
    if (row?.value) identity = JSON.parse(row.value);
  } catch (_) {}

  identity = identity || {};

  if (!identity.tier) {
    try {
      const ls = db.prepare("SELECT value FROM app_settings WHERE key = 'license_payload'").get();
      if (ls?.value) identity.tier = JSON.parse(ls.value).tier || 'Gold';
    } catch (_) {}
  }
  if (!identity.tier) identity.tier = 'Gold';

  if (!identity.principalSignBase64) {
    identity.principalSignBase64 = identity.signature || identity.principal_signature || null;
  }
  return identity;
}

// ─────────────────────────────────────────────────────────────────────────────
// compileStudentPdf
//
// Renders a single student's report card to a PDF Buffer using the same
// generateHTMLPages + printToPDF pipeline as the main.js `generate-reports`
// IPC handler.
//
// @param {object}   student   — fully assembled student object (from report-assembler)
// @param {object}   termConfig — complete term config (includes resumption_date etc.)
// @param {string}   baseDir   — engine root with /assets/templates
// @param {string}   tempDir   — scratch directory for HTML + images
// @param {string}   templateId
// @param {object}   identity  — school identity (logo, signatures, colours)
// @returns {Promise<Buffer>}
// ─────────────────────────────────────────────────────────────────────────────
const activePdfWindows = new Set();

async function compileStudentPdf(student, termConfig, baseDir, tempDir, templateId = 'clean_slate', identity = null) {
  const isActivated = app.locals.activation_status?.is_activated ?? false;
  const isStandalone = (app.locals.license_limit?.payload ? JSON.parse(app.locals.license_limit.payload).tier : '') === 'standalone';
  if (!isActivated && !isStandalone) {
    throw new Error('NOT_ACTIVATED: Results locked until school is activated.');
  }

  if (!app.isReady()) await app.whenReady();

  let deptMgrs = [];
  let db = null;
  try {
    db = database.getDb();
    deptMgrs = db.prepare("SELECT * FROM department_managers ORDER BY id ASC").all() || [];
  } catch (_) {}

  // Detect ILS class type
  const cn = student.class_name || '';
  const baseClassName = cn.split(' ').slice(0, -1).join(' ') || cn;
  let classType = student.curriculum_type || 'STANDARD_NIGERIAN';
  let classPacCount = student.pac_count || 12;
  let classPacLabels = student.pac_labels || null;

  if (db) {
    try {
      const ctRow = db.prepare("SELECT curriculum_type, pac_count, pac_labels FROM class_configs WHERE hierarchy_class = ? OR hierarchy_class = ?")
                      .get(cn, baseClassName);
      if (ctRow?.curriculum_type) classType = ctRow.curriculum_type;
      if (ctRow?.pac_count) classPacCount = ctRow.pac_count;
      try { if (ctRow?.pac_labels) classPacLabels = JSON.parse(ctRow.pac_labels); } catch (_) {}
    } catch (_) {}
  }

  // Ensure ILS records are populated if ILS class
  if (classType === 'ILS' && db && (!student.il_subjects || student.il_subjects.length === 0)) {
    const ilsSession = termConfig?.academic_session || student.academic_session;
    const ilsTerm    = termConfig?.term || student.term;
    try {
      const rows = db.prepare(`
        SELECT subject, pack_number, score, passed
        FROM ils_records
        WHERE student_id = ? AND academic_session = ? AND term = ?
        ORDER BY subject, pack_number
      `).all(student.id, ilsSession, ilsTerm);

      const bySubject = {};
      for (const r of rows) {
        if (!bySubject[r.subject]) bySubject[r.subject] = [];
        bySubject[r.subject].push(r);
      }
      const il_subjects = Object.entries(bySubject).map(([subject, packs]) => {
        const packsMap = {};
        let hundredsCount = 0;
        packs.forEach(p => {
          packsMap[p.pack_number] = p.score;
          if (p.score === 100) hundredsCount++;
        });
        const passed  = packs.filter(p => p.passed === 1);
        const total   = packs.reduce((sum, p) => sum + p.score, 0);
        const avg     = packs.length > 0 ? Math.round((total / packs.length) * 10) / 10 : 0;
        return {
          subject,
          packs: packsMap,
          packs_completed: passed.length,
          hundreds_count: hundredsCount,
          total_score: total,
          average: avg
        };
      });

      const verseRow = db.prepare(`
        SELECT verse_count FROM ils_verse_memory
        WHERE student_id = ? AND academic_session = ? AND term = ?
      `).get(student.id, ilsSession, ilsTerm);

      student = {
        ...student,
        il_subjects,
        pac_count: classPacCount,
        verse_count: verseRow?.verse_count || 0,
        academic_session: ilsSession,
        term: ilsTerm
      };
    } catch (_) {}
  }

  const payload = {
    identity,
    termConfig,
    departmentManagers: deptMgrs,
    students:        [student],
    reportType:      'terminal',
    templateId:      templateId || 'clean_slate',
    format:          'pdf',
    useSchoolColors: true,
  };

  let html = '';
  if (classType === 'ILS') {
    payload.pac_labels = classPacLabels;
    html = reports.generateILSHTMLPages(payload, baseDir, tempDir);
  } else {
    html = reports.generateHTMLPages(payload, baseDir, tempDir);
  }

  const safeName  = (student.name || 'student').replace(/[^a-zA-Z0-9]/g, '_');
  const htmlPath  = path.join(tempDir, `result_${safeName}_${Date.now()}.html`);
  fs.writeFileSync(htmlPath, html, 'utf8');

  return new Promise((resolve, reject) => {
    let hw = new BrowserWindow({
      show: false,
      width: classType === 'ILS' ? 1123 : 794,
      height: classType === 'ILS' ? 794 : 1123,
      webPreferences: { offscreen: true, webSecurity: false },
    });

    activePdfWindows.add(hw);
    let resolved = false;

    const cleanup = () => {
      clearTimeout(timeoutTimer);
      if (hw) {
        activePdfWindows.delete(hw);
        try { hw.close(); } catch (_) {}
        hw = null;
      }
    };

    const doPrint = async () => {
      if (resolved || !hw) return;
      resolved = true;
      try {
        await new Promise(r => setTimeout(r, 200));
        const rawBuf = await hw.webContents.printToPDF({
          printBackground: true,
          pageSize: 'A4',
          landscape: classType === 'ILS'
        });
        const buf    = Buffer.isBuffer(rawBuf) ? rawBuf : Buffer.from(rawBuf);
        cleanup();
        try { fs.unlinkSync(htmlPath); } catch (_) {}
        resolve(buf);
      } catch (e) {
        cleanup();
        reject(e);
      }
    };

    // Safety valve: if a remote font stalls loading, print with local fonts
    const timeoutTimer = setTimeout(() => {
      console.warn('[Dispatcher] Remote resource load stalled — printing with local fallback fonts');
      doPrint();
    }, 3500);

    hw.webContents.on('did-fail-load', doPrint);
    hw.webContents.on('dom-ready',     () => setTimeout(doPrint, 500));
    hw.webContents.on('did-finish-load', doPrint);
    hw.loadFile(htmlPath);
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// sendMailDirect — SMTP send helper
// ─────────────────────────────────────────────────────────────────────────────
async function sendMailDirect(smtpConfig, toEmail, subject, bodyHtml, pdfBuffer, pdfFilename) {
  const transporter = nodemailer.createTransport({
    host:   smtpConfig.host,
    port:   Number(smtpConfig.port) || 587,
    secure: Number(smtpConfig.port) === 465,
    auth:   { user: smtpConfig.user, pass: decrypt(smtpConfig.pass) },
  });

  return transporter.sendMail({
    from:        smtpConfig.from,
    to:          toEmail,
    subject,
    html:        bodyHtml,
    attachments: pdfBuffer ? [{ filename: pdfFilename, content: pdfBuffer }] : [],
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// processEmailQueue — drain pending_emails for previously offline SMTP
// ─────────────────────────────────────────────────────────────────────────────
async function processEmailQueue() {
  const db = database.getDb();
  let smtpConfig = null;
  try {
    const row = db.prepare("SELECT value FROM app_settings WHERE key = 'smtp_config'").get();
    if (row?.value) smtpConfig = JSON.parse(row.value);
  } catch (_) {}

  if (!smtpConfig?.host || !smtpConfig?.user) return;

  const pending = db.prepare(
    "SELECT * FROM pending_emails WHERE status = 'pending' AND attempts < 3 LIMIT 5"
  ).all();

  for (const mail of pending) {
    try {
      const buf = mail.attachment_b64 ? Buffer.from(mail.attachment_b64, 'base64') : null;
      await sendMailDirect(smtpConfig, mail.to_email, mail.subject, mail.body_html, buf, mail.attachment_name);
      db.prepare("UPDATE pending_emails SET status = 'sent', sent_at = datetime('now') WHERE id = ?").run(mail.id);
      console.log(`[Email Dispatcher] ✓ Sent queued email to ${mail.to_email}`);
    } catch (err) {
      console.error(`[Email Dispatcher] ✗ Failed for ${mail.to_email}:`, err.message);
      db.prepare('UPDATE pending_emails SET attempts = attempts + 1 WHERE id = ?').run(mail.id);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// resolveTargetIds — converts scope/className/studentIds to a concrete ID list
// ─────────────────────────────────────────────────────────────────────────────
function resolveTargetIds(db, { scope, studentIds, studentId, className }) {
  const activeClause = "COALESCE(is_active, 1) = 1 AND COALESCE(status, 'active') != 'overflow' AND COALESCE(enrollment_status, 'active') != 'inactive'";
  if (Array.isArray(studentIds) && studentIds.length > 0) return studentIds;
  if (scope === 'student' && studentId) return [studentId];
  if (scope === 'class' && className) {
    const norm = className.replace(/\s+/g, '').toUpperCase();
    return db.prepare(`
      SELECT id FROM students
      WHERE (UPPER(replace(class_name, ' ', '')) = ?
         OR UPPER(replace(class_name || COALESCE(' ' || NULLIF(class_arm, ''), ''), ' ', '')) = ?)
        AND ${activeClause}
    `).all(norm, norm).map(r => r.id);
  }
  // default: all active students
  return db.prepare(`SELECT id FROM students WHERE ${activeClause}`).all().map(r => r.id);
}

// ─────────────────────────────────────────────────────────────────────────────
// dispatchResults — core dispatcher IPC function
// ─────────────────────────────────────────────────────────────────────────────
async function dispatchResults({
  scope, studentIds, studentId, className,
  term, academicSession,
  templateId, channels,
  pulseBot: pulseBotArg,
}) {
  const isActivated = app.locals.activation_status?.is_activated ?? false;
  if (!isActivated) {
    throw new Error('NOT_ACTIVATED: Result dispatch is locked until school is activated.');
  }
  console.log(
    `[Dispatcher] dispatchResults CALLED — scope=${scope}, ` +
    `studentIds=${JSON.stringify(studentIds)}, channels=${JSON.stringify(channels)}`
  );

  const db = database.getDb();

  // ── Identity ───────────────────────────────────────────────────────────────
  const identity = loadIdentity(db);
  let schoolName = identity?.name || 'Nexus School';
  try {
    if (!schoolName || schoolName === 'Nexus School') {
      const r = db.prepare("SELECT value FROM app_settings WHERE key = 'school_name'").get();
      if (r?.value) schoolName = r.value;
    }
  } catch (_) {}

  // ── termConfig — full row so templates get grading_scale, resumption_date etc. ─
  const termConfig = fetchTermConfig(db, {
    term,
    academic_session: academicSession,
    template:         templateId || 'clean_slate',
  });

  // ── baseDir: engine root with /assets/templates ────────────────────────────
  let baseDir = path.join(__dirname, '..');
  if (!fs.existsSync(path.join(baseDir, 'assets', 'templates'))) {
    try { baseDir = path.dirname(require.resolve('@nexus/engine')); } catch (_) {}
  }

  const tempDir = fs.mkdtempSync(path.join(require('os').tmpdir(), 'nexus-results-'));

  // ── Resolve student IDs ────────────────────────────────────────────────────
  const targetStudentIds = resolveTargetIds(db, { scope, studentIds, studentId, className });
  if (!targetStudentIds.length) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}
    return { ok: true, dispatched: 0, skipped: 0, queued: 0, warnings: [] };
  }

  // ── Assemble ALL student data in one pass (mirrors query-results handler) ──
  const { students: assembled } = assembleStudentsForReport(db, targetStudentIds, term, academicSession);

  // ── Pre-flight checks ──────────────────────────────────────────────────────
  let smtpConfig = null;
  try {
    const row = db.prepare("SELECT value FROM app_settings WHERE key = 'smtp_config'").get();
    if (row?.value) smtpConfig = JSON.parse(row.value);
  } catch (_) {}
  const smtpReady = !!(smtpConfig?.host && smtpConfig?.user);

  let pulseBot = pulseBotArg;
  if (!pulseBot) {
    try      { pulseBot = require('./pulse-bot'); }
    catch(_) { try { pulseBot = require('../../public_shell/electron/pulse-bot'); } catch (_) {} }
  }
  const botReady = pulseBot?.getPulseStatus?.()?.status === 'ready';

  const warnings = [];
  if (!channels || channels.length === 0) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}
    return { ok: false, error: 'No delivery channel selected.' };
  }
  if (channels.includes('whatsapp') && !botReady) {
    warnings.push('WhatsApp bot is offline — connect Nexus Pulse first');
  }
  if (channels.includes('email') && !smtpReady) {
    warnings.push('Email (SMTP) is not configured — emails will be queued until you set it up in Settings → Notifications');
  }
  // Hard-block only when WhatsApp is the sole channel and bot is offline
  const waOnlyAndOffline = channels.includes('whatsapp') && !botReady && channels.length === 1;
  if (waOnlyAndOffline) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}
    return { ok: false, error: warnings.join('. ') };
  }

  let feeSettings = {};
  try {
    const fsRow = db.prepare("SELECT value FROM app_settings WHERE key = 'fee_settings'").get();
    if (fsRow?.value) feeSettings = JSON.parse(fsRow.value);
  } catch (_) {}
  // fee_shield is Diamond-only; treat undefined as disabled (strict opt-in)
  const shieldEnabled = feeSettings.fee_shield_enabled === true;
  const shieldMode = feeSettings.fee_shield_mode || 'block';

  // ── Dispatch loop ──────────────────────────────────────────────────────────
  let dispatched = 0;
  let skipped    = 0;
  let queued     = 0;

  for (const profile of assembled) {
    const isOwing = (profile.fee_status !== 'cleared' && profile.feeStatus !== 'cleared');
    if (shieldEnabled && shieldMode === 'block' && isOwing) {
      console.warn(`[Dispatcher] Fee Shield BLOCKED ${profile.name} (${profile.id}) — feeStatus=${profile.feeStatus} fee_status=${profile.fee_status}`);
      skipped++;
      continue;
    }

    const parentPhone = profile.parent_phone || '';
    const parentEmail = profile.parent_email || '';

    if (!parentPhone && !parentEmail) {
      console.warn(`[Dispatcher] ${profile.name}: no parent contact on record (phone=${JSON.stringify(profile.parent_phone)}, email=${JSON.stringify(profile.parent_email)}) — skipping`);
      skipped++;
      continue;
    }

    try {
      console.log(`[Dispatcher] Compiling PDF for ${profile.name} (${profile.id}), class=${profile.class_name}, curriculum=${profile.curriculum_type}…`);
      const rawBuf    = await compileStudentPdf(profile, termConfig, baseDir, tempDir, templateId || 'clean_slate', identity);
      if (!rawBuf || rawBuf.length === 0) {
        console.error(`[Dispatcher] ✗ PDF compiled to empty buffer for ${profile.name} — skipping`);
        skipped++;
        continue;
      }
      const pdfBuffer = Buffer.isBuffer(rawBuf) ? rawBuf : Buffer.from(rawBuf);
      const pdfFile   = `${profile.name.replace(/\s/g, '_')}_${term.replace(/\s/g, '_')}_Report_Card.pdf`;
      console.log(`[Dispatcher] PDF compiled for ${profile.name} — ${pdfBuffer.length} bytes (curriculum=${profile.curriculum_type || 'STANDARD_NIGERIAN'})`);

      // ── WhatsApp ──────────────────────────────────────────────────────────
      if (channels.includes('whatsapp') && botReady) {
        if (parentPhone) {
          const caption = `🎓 *Results Out*\n\nDear Parent, kindly find attached the ${term} report card for *${profile.name}* (${profile.class_name}).\n\n_${schoolName} · Powered by Nexus Pulse_`;
          try {
            console.log(`[Dispatcher] Sending PDF via WhatsApp → ${parentPhone}`);
            await pulseBot.sendReceiptPdf(parentPhone, pdfFile, pdfBuffer, caption);
            dispatched++;
            console.log(`[Dispatcher] ✓ WhatsApp delivered to ${parentPhone}`);
            await new Promise(r => setTimeout(r, 2000)); // rate-limit
          } catch (waErr) {
            console.error(`[Dispatcher] ✗ WhatsApp send failed for ${profile.name} (${parentPhone}):`, waErr.message || waErr);
            skipped++;
          }
        } else {
          console.warn(`[Dispatcher] ${profile.name}: WA selected but no parent phone — skipping channel`);
          skipped++;
        }
      }

      // ── Email ─────────────────────────────────────────────────────────────
      if (channels.includes('email') && parentEmail) {
        const subject  = `🎓 Report Card: ${profile.name} — ${term}`;
        const bodyHtml = `
          <div style="font-family:sans-serif;padding:20px;line-height:1.6">
            <h3>Academic Report Card</h3>
            <p>Dear Parent,</p>
            <p>Kindly find attached the official report card for <strong>${profile.name}</strong>
               for the <strong>${term} (${academicSession})</strong> academic term.</p>
            <p>For any enquiries or feedback, please contact the school office.</p>
            <br><p>Best regards,</p>
            <p><strong>${schoolName}</strong></p>
          </div>`;

        if (smtpReady) {
          try {
            await sendMailDirect(smtpConfig, parentEmail, subject, bodyHtml, pdfBuffer, pdfFile);
            dispatched++;
            console.log(`[Dispatcher] ✓ Email delivered to ${parentEmail}`);
          } catch (smtpErr) {
            console.warn(`[Dispatcher] SMTP failed for ${parentEmail}, queuing:`, smtpErr.message);
            db.prepare(
              'INSERT INTO pending_emails (to_email, subject, body_html, attachment_b64, attachment_name) VALUES (?,?,?,?,?)'
            ).run(parentEmail, subject, bodyHtml, pdfBuffer.toString('base64'), pdfFile);
            queued++;
          }
        } else {
          db.prepare(
            'INSERT INTO pending_emails (to_email, subject, body_html, attachment_b64, attachment_name) VALUES (?,?,?,?,?)'
          ).run(parentEmail, subject, bodyHtml, pdfBuffer.toString('base64'), pdfFile);
          queued++;
        }
      }

    } catch (pdfErr) {
      console.error(`[Dispatcher] ✗ PDF compilation failed for ${profile.name}:`, pdfErr?.message || pdfErr, pdfErr?.stack || '');
      skipped++;
    }
  }

  try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}

  return {
    ok: true,
    dispatched,
    skipped,
    queued,
    warnings: warnings.length ? warnings : undefined,
    smtpConfigured: smtpReady,
    botOnline:      botReady,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// uploadPdfToCloudinary — signed raw upload
// ─────────────────────────────────────────────────────────────────────────────
async function uploadPdfToCloudinary(pdfBuffer, publicId) {
  const cloudName    = process.env.CLOUDINARY_CLOUD_NAME;
  const uploadPreset = process.env.CLOUDINARY_UPLOAD_PRESET;
  const apiKey       = process.env.CLOUDINARY_API_KEY;
  const apiSecret    = process.env.CLOUDINARY_API_SECRET;

  if (!cloudName || !apiKey || !apiSecret) {
    throw new Error(
      'Cloudinary credentials not configured (CLOUDINARY_CLOUD_NAME / CLOUDINARY_API_KEY / CLOUDINARY_API_SECRET).'
    );
  }

  const timestamp = Math.floor(Date.now() / 1000);
  const toSign    = `public_id=${publicId}&resource_type=raw&timestamp=${timestamp}&upload_preset=${uploadPreset || ''}${apiSecret}`;
  const signature = crypto.createHash('sha1').update(toSign).digest('hex');

  const formData  = new FormData();
  formData.append('file',          new Blob([pdfBuffer], { type: 'application/pdf' }), `${publicId}.pdf`);
  formData.append('public_id',     publicId);
  formData.append('resource_type', 'raw');
  formData.append('timestamp',     String(timestamp));
  formData.append('api_key',       apiKey);
  formData.append('signature',     signature);
  if (uploadPreset) formData.append('upload_preset', uploadPreset);

  const res = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/raw/upload`,
    { method: 'POST', body: formData, signal: AbortSignal.timeout(30_000) }
  );

  if (!res.ok) throw new Error(`Cloudinary upload failed (${res.status}): ${await res.text()}`);
  return (await res.json()).secure_url;
}

// ─────────────────────────────────────────────────────────────────────────────
// compileBatchAndUpload — generates PDFs for all students and uploads to Cloudinary
// Called from the results:publish IPC handler in main.js
// ─────────────────────────────────────────────────────────────────────────────
async function compileBatchAndUpload(db, term, academicSession, baseDir, targetStudentIds = null) {
  const tempDir = path.join(require('os').tmpdir(), `nexus_batch_${Date.now()}`);
  fs.mkdirSync(tempDir, { recursive: true });

  // Fetch students who have scores for this term/session (standard or ILS) AND have a parent phone
  let rows = db.prepare(`
    SELECT DISTINCT s.id, s.parent_phone
    FROM students s
    WHERE s.parent_phone IS NOT NULL AND s.parent_phone != ''
      AND COALESCE(s.is_active, 1) = 1
      AND COALESCE(s.status, 'active') != 'overflow'
      AND COALESCE(s.enrollment_status, 'active') != 'inactive'
      AND (
        EXISTS (SELECT 1 FROM student_records sr WHERE sr.student_id = s.id AND sr.term = ? AND sr.academic_session = ?)
        OR
        EXISTS (SELECT 1 FROM ils_records ir WHERE ir.student_id = s.id AND ir.term = ? AND ir.academic_session = ?)
      )
  `).all(term, academicSession, term, academicSession);

  if (targetStudentIds && Array.isArray(targetStudentIds) && targetStudentIds.length > 0) {
    const idSet = new Set(targetStudentIds.map(String));
    rows = rows.filter(r => idSet.has(String(r.id)));
  }

  if (!rows.length) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}
    return { results: [], parentMap: {}, skipped: 0, total: 0 };
  }

  // Assemble all student data in one pass (same as dispatchResults)
  const studentIds = rows.map(r => r.id);
  const { students: assembled, termConfig } = assembleStudentsForReport(db, studentIds, term, academicSession);

  // Resolve identity + baseDir
  const identity = loadIdentity(db);

  if (!fs.existsSync(path.join(baseDir, 'assets', 'templates'))) {
    try { baseDir = path.dirname(require.resolve('@nexus/engine')); } catch (_) {}
  }

  let feeSettings = {};
  try {
    const fsRow = db.prepare("SELECT value FROM app_settings WHERE key = 'fee_settings'").get();
    if (fsRow?.value) feeSettings = JSON.parse(fsRow.value);
  } catch (_) {}
  // fee_shield is Diamond-only; treat undefined as disabled (strict opt-in)
  const shieldEnabled = feeSettings.fee_shield_enabled === true;
  const shieldMode = feeSettings.fee_shield_mode || 'block';

  const results   = [];
  const parentMap = {};
  let skipped     = 0;

  for (const profile of assembled) {
    const isOwing = (profile.fee_status !== 'cleared' && profile.feeStatus !== 'cleared');
    if (shieldEnabled && shieldMode === 'block' && isOwing) {
      console.warn(`[CloudPublish] Fee Shield BLOCKED ${profile.name} (${profile.id}) — student has outstanding balance`);
      skipped++;
      continue;
    }
    try {
      const pdfBuffer = await compileStudentPdf(profile, termConfig, baseDir, tempDir, 'clean_slate', identity);
      const publicId  = `nexus_results/${profile.id}_${term.replace(/\s+/g, '_')}_${academicSession.replace('/', '-')}`;
      const pdfUrl    = await uploadPdfToCloudinary(pdfBuffer, publicId);
      results.push({ studentId: profile.id, pdfUrl });

      const phone = profile.parent_phone;
      if (phone) {
        if (!parentMap[phone]) parentMap[phone] = [];
        if (!parentMap[phone].includes(profile.id)) parentMap[phone].push(profile.id);
      }
    } catch (err) {
      console.error(`[compileBatchAndUpload] Failed for student ${profile.id}:`, err.message);
      skipped++;
    }
  }

  try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}
  return { results, parentMap, skipped, total: rows.length };
}

// ─────────────────────────────────────────────────────────────────────────────
module.exports = {
  dispatchResults,
  processEmailQueue,
  compileBatchAndUpload,
  encrypt,
  decrypt,
};
