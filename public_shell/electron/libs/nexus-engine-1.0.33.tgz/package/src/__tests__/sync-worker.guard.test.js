'use strict';

/**
 * sync-worker.guard.test.js
 *
 * Guards the belt-and-suspenders pre-query migration in sync-worker.js.
 * Tests the guard pattern directly on an in-memory SQLite DB so we don't
 * need to spin up the full sync-worker (which makes network calls).
 *
 * The guard pattern in pushSchoolDelta() is:
 *   try { db.exec(`ALTER TABLE students ADD COLUMN parent_phone_2 TEXT DEFAULT NULL`); } catch (_) {}
 *
 * This file verifies that exact pattern behaves correctly in all three states:
 *   1. Column already missing  → added silently
 *   2. Column already present  → no error thrown (idempotent)
 *   3. After guard runs        → SELECT on parent_phone_2 works without error
 */

const BetterSqlite3 = require('better-sqlite3');

const GUARD_SQL = `ALTER TABLE students ADD COLUMN parent_phone_2 TEXT DEFAULT NULL`;

function runGuard(db) {
  try { db.exec(GUARD_SQL); } catch (_) {}
}

function columnNames(db, table) {
  return db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
}

describe('sync-worker parent_phone_2 guard', () => {
  test('adds column when it is missing (v1.0.91 upgrade scenario)', () => {
    const db = new BetterSqlite3(':memory:');
    db.exec(`CREATE TABLE students (id TEXT PRIMARY KEY, name TEXT NOT NULL, class_name TEXT NOT NULL)`);

    expect(columnNames(db, 'students')).not.toContain('parent_phone_2');
    runGuard(db);
    expect(columnNames(db, 'students')).toContain('parent_phone_2');
  });

  test('does not throw when column already exists (idempotent)', () => {
    const db = new BetterSqlite3(':memory:');
    db.exec(`
      CREATE TABLE students (
        id             TEXT PRIMARY KEY,
        name           TEXT NOT NULL,
        class_name     TEXT NOT NULL,
        parent_phone_2 TEXT DEFAULT NULL
      )
    `);

    expect(() => runGuard(db)).not.toThrow();
    expect(columnNames(db, 'students')).toContain('parent_phone_2');
  });

  test('SELECT on parent_phone_2 succeeds after guard runs', () => {
    const db = new BetterSqlite3(':memory:');
    db.exec(`CREATE TABLE students (id TEXT PRIMARY KEY, name TEXT NOT NULL, class_name TEXT NOT NULL)`);
    db.exec(`INSERT INTO students (id, name, class_name) VALUES ('x1', 'Test Student', 'JSS1')`);

    runGuard(db);

    // Mirrors the exact SELECT pattern in sync-worker.js pushSchoolDelta()
    expect(() => {
      db.prepare(`
        SELECT id, name, class_name,
               COALESCE(parent_phone_2, NULL) as parent_phone_2
        FROM students
      `).all();
    }).not.toThrow();
  });

  test('NULL default is respected — existing rows have parent_phone_2 = NULL after guard', () => {
    const db = new BetterSqlite3(':memory:');
    db.exec(`CREATE TABLE students (id TEXT PRIMARY KEY, name TEXT NOT NULL, class_name TEXT NOT NULL)`);
    db.exec(`INSERT INTO students (id, name, class_name) VALUES ('x2', 'Existing Student', 'SS3')`);

    runGuard(db);

    const row = db.prepare(`SELECT parent_phone_2 FROM students WHERE id='x2'`).get();
    expect(row.parent_phone_2).toBeNull();
  });
});
