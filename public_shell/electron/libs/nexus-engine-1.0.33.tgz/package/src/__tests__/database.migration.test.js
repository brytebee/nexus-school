'use strict';

/**
 * database.migration.test.js
 *
 * Guards the parent_phone_2 column migration in database.init().
 * Uses in-memory SQLite so no filesystem access is needed.
 */

const BetterSqlite3 = require('better-sqlite3');

function columnNames(db, table) {
  return db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
}

// ─── Fresh-install path ──────────────────────────────────────────────────────

describe('database.init() — fresh install', () => {
  let db;

  beforeAll(() => {
    jest.resetModules();
    const database = require('../database');

    let instance;
    function InMemoryDb(_path, opts) {
      instance = new BetterSqlite3(':memory:', { ...opts, verbose: undefined });
      return instance;
    }

    database.init(':memory:', InMemoryDb);
    db = instance;
  });

  test('students table is created', () => {
    const r = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name='students'`).all();
    expect(r.length).toBe(1);
  });

  test('parent_phone_2 column exists after init()', () => {
    expect(columnNames(db, 'students')).toContain('parent_phone_2');
  });

  test('parent_phone_2 defaults to NULL on new rows', () => {
    db.prepare(`INSERT INTO students (id, name, class_name) VALUES ('s001', 'Ada Obi', 'JSS 1')`).run();
    const row = db.prepare(`SELECT parent_phone_2 FROM students WHERE id='s001'`).get();
    expect(row.parent_phone_2).toBeNull();
  });
});

// ─── Pre-F4 upgrade path ─────────────────────────────────────────────────────

describe('database.init() — pre-F4 school DB (parent_phone_2 missing)', () => {
  let rawDb;

  beforeAll(() => {
    jest.resetModules();
    const database = require('../database');

    // Build a DB that already has students WITHOUT parent_phone_2
    rawDb = new BetterSqlite3(':memory:');
    rawDb.exec(`
      CREATE TABLE students (
        id         TEXT PRIMARY KEY,
        name       TEXT NOT NULL,
        class_name TEXT NOT NULL
      );
    `);
    rawDb.exec(`INSERT INTO students (id, name, class_name) VALUES ('s002', 'Emeka Eze', 'SS2')`);

    // Sanity: column must be absent before init()
    expect(columnNames(rawDb, 'students')).not.toContain('parent_phone_2');

    function ExistingDbCtor(_path, _opts) { return rawDb; }
    database.init(':memory:', ExistingDbCtor);
  });

  test('alterSafe adds parent_phone_2 on upgrade', () => {
    expect(columnNames(rawDb, 'students')).toContain('parent_phone_2');
  });

  test('existing rows get NULL (no data loss)', () => {
    const row = rawDb.prepare(`SELECT parent_phone_2 FROM students WHERE id='s002'`).get();
    expect(row.parent_phone_2).toBeNull();
  });

  test('new rows can store a second phone number', () => {
    rawDb.prepare(
      `INSERT INTO students (id, name, class_name, parent_phone_2)
       VALUES ('s003', 'Ngozi Dike', 'JSS3', '08011223344')`
    ).run();
    const row = rawDb.prepare(`SELECT parent_phone_2 FROM students WHERE id='s003'`).get();
    expect(row.parent_phone_2).toBe('08011223344');
  });
});
