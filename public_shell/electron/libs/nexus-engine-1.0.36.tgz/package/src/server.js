const express = require('express');
const app = express();
const address = require('address');
const fs = require('fs');
const csv = require('csv-parser');
const crypto = require('crypto');

const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

const database = require('./database');
const reports = require('./report-compiler.js');
const { validateClassArmRef } = require('./classArmValidator');

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// ── Scoped LAN Security Middlewares ──────────────────────────────────────────
const handshakeRates = new Map();
function handshakeRateLimiter(req, res, next) {
    const ip = req.ip || req.socket.remoteAddress;
    const now = Date.now();
    let rate = handshakeRates.get(ip);
    if (!rate || now > rate.resetTime) {
        rate = { count: 1, resetTime: now + 60000 };
        handshakeRates.set(ip, rate);
        return next();
    }
    if (rate.count >= 10) {
        return res.status(429).json({ error: "Too many requests. Please try again after a minute." });
    }
    rate.count++;
    next();
}

function requireDeviceAuth(req, res, next) {
    const deviceId = req.headers['x-device-id'] || req.body?.device_id;
    if (!deviceId) {
        return res.status(401).json({ error: "Unauthorized: Missing device identifier" });
    }
    const db = database.getDb();
    const isRevoked = db.prepare("SELECT 1 FROM revoked_devices WHERE device_id = ?").get(deviceId);
    if (isRevoked) {
        return res.status(403).json({ error: "Forbidden: Device is revoked" });
    }
    const device = db.prepare('SELECT 1 FROM connected_devices WHERE device_id = ?').get(deviceId);
    if (!device) {
        // Auto-register connected device if missing (e.g. from prior pairing before table sync)
        try {
            db.prepare('INSERT OR IGNORE INTO connected_devices (device_id, device_model) VALUES (?, ?)')
                .run(deviceId, req.headers['x-device-model'] || 'Android Device');
        } catch (_) {}
    }
    next();
}

// ── Activity Log Helper ───────────────────────────────────────────────────────
// Call this from any handler (desktop or server) to record an auditable action.
// Never throws — logging failures are non-fatal.
function logActivity({ device_id = 'DESKTOP', device_model = 'Desktop App',
                       actor_label = 'Admin', event_type, payload = null }) {
    try {
        const db = database.getDb();
        const hash = payload
            ? crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex').slice(0, 16)
            : null;
        db.prepare(`
            INSERT INTO activity_log (device_id, device_model, actor_label, event_type, payload_hash)
            VALUES (?, ?, ?, ?, ?)
        `).run(device_id, device_model, actor_label, event_type, hash);
    } catch (e) {
        console.warn('[ActivityLog] Failed to write log entry:', e.message);
    }
}

function sortGradingComponents(components) {
    if (!components || !Array.isArray(components)) return [];
    return [...components].sort((a, b) => {
        const aKey = (a.key || a.label || '').toLowerCase();
        const bKey = (b.key || b.label || '').toLowerCase();
        const isACaOrExam = aKey.startsWith('ca') || aKey.includes('exam');
        const isBCaOrExam = bKey.startsWith('ca') || bKey.includes('exam');
        if (isACaOrExam && !isBCaOrExam) return 1;
        if (!isACaOrExam && isBCaOrExam) return -1;
        if (isACaOrExam && isBCaOrExam) {
            const isAExam = aKey.includes('exam');
            const isBExam = bKey.includes('exam');
            if (isAExam && !isBExam) return 1;
            if (!isAExam && isBExam) return -1;
        }
        return aKey.localeCompare(bKey, undefined, { numeric: true, sensitivity: 'base' });
    });
}

function checkLockState(db, type) {
    try {
        const lockRow = db.prepare(`SELECT value FROM app_settings WHERE key = 'mobile_${type}_locked'`).get();
        if (lockRow && lockRow.value === '1') return true;

        const lockAtRow = db.prepare(`SELECT value FROM app_settings WHERE key = 'mobile_${type}_lock_at'`).get();
        if (lockAtRow && lockAtRow.value) {
            const lockAtTime = new Date(lockAtRow.value).getTime();
            if (!isNaN(lockAtTime) && Date.now() >= lockAtTime) {
                return true;
            }
        }
    } catch (e) {
        console.error(`[checkLockState] Failed to evaluate lock for ${type}:`, e.message);
    }
    return false;
}

function getLockAtMillis(db, type) {
    try {
        const lockAtRow = db.prepare(`SELECT value FROM app_settings WHERE key = 'mobile_${type}_lock_at'`).get();
        if (lockAtRow && lockAtRow.value) {
            const lockAtTime = new Date(lockAtRow.value).getTime();
            return isNaN(lockAtTime) ? 0 : lockAtTime;
        }
    } catch (e) {
        console.error(`[getLockAtMillis] Failed to get lock_at time for ${type}:`, e.message);
    }
    return 0;
}
function normalizeTermName(term) {
    if (!term) return 'First Term';
    const clean = term.toString().trim().toLowerCase();
    if (clean.includes('1') || clean.includes('first')) return 'First Term';
    if (clean.includes('2') || clean.includes('second')) return 'Second Term';
    if (clean.includes('3') || clean.includes('third')) return 'Third Term';
    return term.trim();
}

// ─── Prompt 2: The CSV Matrix Parser ─────────────────────────────────────────
function normalizeSubjectName(subject, className) {
    if (!subject) return 'General';
    let norm = subject.trim();

    // ── Mathematics: WAEC uses 'Mathematics' for JSS, 'General Mathematics' for SSS
    const isJSS = className && (className.toUpperCase().startsWith('JS') || className.toUpperCase().startsWith('JSS'));
    const isSSS = className && (className.toUpperCase().startsWith('SS'));

    // Normalise common misspellings / abbreviations first
    const table = {
        'Further Maths':              'Further Mathematics',
        'Further Mathematic':         'Further Mathematics',
        'Add Maths':                  'Further Mathematics',
        'Additional Mathematics':     'Further Mathematics',
        'Lit in English':             'Literature in English',
        'Literature':                 'Literature in English',
        'Lit':                        'Literature in English',
        'Eng Lang':                   'English Language',
        'English':                    'English Language',
        'English Studies':            'English Language',
        'Gen Maths':                  'General Mathematics',
        'General Maths':              'General Mathematics',
        'Maths':                      isSSS ? 'General Mathematics' : 'Mathematics',
        'Math':                       isSSS ? 'General Mathematics' : 'Mathematics',
        'CRS':                        'Christian Religious Studies',
        'CRK':                        'Christian Religious Studies',
        'Christian Religious Knowledge': 'Christian Religious Studies',
        'IRK':                        'Islamic Studies',
        'Islamic Religious Knowledge': 'Islamic Studies',
        'Islamic Religious Studies':  'Islamic Studies',
        'Civic Education':            'Citizenship and Heritage Studies',
        'Civic Ed':                   'Citizenship and Heritage Studies',
        'Govt':                       'Government',
        'Agric':                      'Agriculture',
        'Agric Science':              'Agriculture',
        'Agricultural Science':       'Agriculture',
        'Econs':                      'Economics',
        'Fin Accounting':             'Financial Accounting',
        'Account':                    'Accounting',
        'Accounts':                   'Accounting',
        'Financial Acc':              'Financial Accounting',
        'Commerce':                   'Commerce',
        'Tech Drawing':               'Technical Drawing',
        'PHE':                        'Physical Education',
        'Physical & Health Education': 'Physical Education',
        'Health Edu':                 'Health Education',
        'Food & Nutrition':           'Food and Nutrition',
        'Food Nutrition':             'Food and Nutrition',
        'Home Mgt':                   'Home Management',
        'Catering':                   'Catering Craft',
        'Yoruba Language':            'Yoruba',
        'Igbo Language':              'Igbo',
        'Hausa Language':             'Hausa',
        'French Language':            'French',
        'Digital Tech':               'Digital Technologies',
        'ICT':                        'Digital Technologies',
        'Computer Science':           'Digital Technologies',
        'Basic Science':              'Integrated Science',
        'Intermediate Science':       'Integrated Science',
        'Social Studies':             'Social and Citizenship Studies',
        'Social & Citizenship Studies': 'Social and Citizenship Studies',
        'Nigerian History':           'History',
        'Visual Arts':                'Fine Art',
        'Fine Arts':                  'Fine Art',
    };

    if (table[norm]) norm = table[norm];

    // JSS/SSS Mathematics swap
    if (norm === 'General Mathematics' && isJSS) return 'Mathematics';
    if (norm === 'Mathematics' && isSSS) return 'General Mathematics';

    return norm;
}

// Parses a phase-8 CSV with Teacher_ID, Teacher_Name, Teacher_Phone, and
// pipe-delimited Subjects. Inserts securely into SQLite via prepared statements.
function handleCSVUpload(filePath, callback, newStudentLimit, dry_run = false) {
    const rows = [];

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            if (rows.length === 0) {
                if (callback) callback(0, 'INVALID_TEMPLATE: The uploaded CSV file is empty.');
                return;
            }

            // Helper to extract column values regardless of space/underscore/case variations
            const getCSVCol = (row, ...possibleKeys) => {
                if (!row || typeof row !== 'object') return '';
                for (const key of possibleKeys) {
                    if (row[key] !== undefined && row[key] !== null) {
                        const val = String(row[key]).trim();
                        if (val) return val;
                    }
                }
                const rowKeys = Object.keys(row);
                for (const targetKey of possibleKeys) {
                    const normTarget = targetKey.toLowerCase().replace(/[\s_]+/g, '');
                    for (const rKey of rowKeys) {
                        if (rKey.toLowerCase().replace(/[\s_]+/g, '') === normTarget) {
                            const val = String(row[rKey]).trim();
                            if (val) return val;
                        }
                    }
                }
                return '';
            };

            // Extract and normalize headers
            const normHeaders = Object.keys(rows[0] || {}).map(h => h.trim().toLowerCase().replace(/[\s_]+/g, ''));
            const hasStudentCols = normHeaders.includes('studentid') || normHeaders.includes('firstname') || normHeaders.includes('lastname') || normHeaders.includes('parentphone');
            const hasTeacherCols = normHeaders.includes('teacherid') || normHeaders.includes('teachername') || normHeaders.includes('teacherphone') || normHeaders.includes('staffid') || normHeaders.includes('staffname');

            if (!hasStudentCols && !hasTeacherCols) {
                if (callback) callback(0, 'INVALID_TEMPLATE: CSV headers do not match Student or Teacher templates. Expected columns: Student_ID, First_Name, Last_Name, Class OR Teacher_ID, Teacher_Name, Subjects.');
                return;
            }

            let db;
            try {
                db = database.getDb();
            } catch (e) {
                console.error('[CSV] Database not initialized. Aborting import.', e);
                if (callback) callback(0, 'DB not initialized');
                return;
            }

            const configs = db.prepare("SELECT hierarchy_class FROM class_configs").all();
            const classArms = db.prepare("SELECT hierarchy_class, arm FROM class_arms").all();

            // Validation pass using global classArmValidator
            const blockingErrors = [];
            let rIdx = 1;
            for (const r of rows) {
                rIdx++;
                const sId = getCSVCol(r, 'Student_ID', 'Student ID', 'student_id', 'student id', 'ID', 'id');
                const fName = getCSVCol(r, 'First_Name', 'First Name', 'first_name', 'first name');
                const lName = getCSVCol(r, 'Last_Name', 'Last Name', 'last_name', 'last name');
                const cName = getCSVCol(r, 'Class', 'class', 'Class_Name', 'Class Name');
                const tId = getCSVCol(r, 'Teacher_ID', 'Teacher ID', 'teacher_id', 'teacher id', 'Staff_ID', 'Staff ID');

                if (tId && cName) {
                    const classes = cName.split('|').map(c => c.trim()).filter(Boolean);
                    for (const cls of classes) {
                        const check = validateClassArmRef(cls, configs, classArms, { mode: 'strict' });
                        if (!check.ok) {
                            blockingErrors.push({
                                rowIndex: rIdx,
                                field: 'Class',
                                reason: check.error
                            });
                        }
                    }
                }
                if (sId && (fName || lName) && cName) {
                    const check = validateClassArmRef(cName, configs, classArms, { mode: 'strict' });
                    if (!check.ok) {
                        blockingErrors.push({
                            rowIndex: rIdx,
                            field: 'Class',
                            reason: check.error
                        });
                    }
                }
            }

            if (dry_run) {
                const cleanCount = Math.max(0, rows.length - blockingErrors.length);
                if (callback) callback(cleanCount, null, {
                    dry_run: true,
                    cleanCount,
                    blocking: blockingErrors,
                    normalizable: [],
                    newStudentsInserted: 0
                });
                return;
            }

            if (blockingErrors.length > 0) {
                if (callback) callback(0, 'VAL_ERR: Validation failed. Please fix registered classes.', {
                    dry_run: false,
                    cleanCount: 0,
                    blocking: blockingErrors,
                    normalizable: []
                });
                return;
            }

            // Prepare parameterized statements — no raw interpolation, SQL injection-proof
            const upsertTeacher = db.prepare(`
                INSERT INTO teachers (id, name, phone)
                VALUES (@id, @name, @phone)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name, phone=excluded.phone
            `);

            const upsertAllocation = db.prepare(`
                INSERT OR IGNORE INTO teacher_allocations (teacher_id, class_name, subject)
                VALUES (@teacher_id, @class_name, @subject)
            `);

            const upsertStudentSubject = db.prepare(`
                INSERT OR IGNORE INTO student_subjects (student_id, subject)
                VALUES (@student_id, @subject)
            `);

            const upsertFormTeacher = db.prepare(`
                INSERT INTO form_teachers (class_name, teacher_id)
                VALUES (?, ?)
                ON CONFLICT(class_name) DO UPDATE SET teacher_id = excluded.teacher_id
            `);

            const upsertStudent = db.prepare(`
                INSERT INTO students (id, name, class_name, class_arm, parent_name, parent_email, parent_phone, reg_no, gender, dob, enrollment_status)
                VALUES (@id, @name, @class_name, @class_arm, @parent_name, @parent_email, @parent_phone, @reg_no, @gender, @dob, @enrollment_status)
                ON CONFLICT(id) DO UPDATE SET 
                    name=excluded.name, 
                    class_name=excluded.class_name,
                    class_arm=excluded.class_arm,
                    parent_name=COALESCE(excluded.parent_name, students.parent_name),
                    parent_email=COALESCE(excluded.parent_email, students.parent_email),
                    parent_phone=COALESCE(excluded.parent_phone, students.parent_phone),
                    reg_no=COALESCE(NULLIF(excluded.reg_no, ''), students.reg_no),
                    gender=COALESCE(NULLIF(excluded.gender, ''), students.gender),
                    dob=COALESCE(NULLIF(excluded.dob, ''), students.dob),
                    enrollment_status=COALESCE(students.enrollment_status, excluded.enrollment_status)
            `);

            // Wrap all inserts in a single transaction for speed + atomicity
            const runImport = db.transaction((rows) => {
                let studentCount = 0;
                let teacherIds = new Set();
                let allocationCount = 0;
                let warnings = [];
                let newStudentsInserted = 0;

                // If a cap is provided, query the current count once before the loop
                const hasCap = typeof newStudentLimit === 'number' && isFinite(newStudentLimit) && newStudentLimit < 999999;
                let currentCount = hasCap ? db.prepare('SELECT COUNT(id) AS c FROM students').get().c : 0;
                const availableSlots = hasCap ? Math.max(0, newStudentLimit - currentCount) : Infinity;

                for (const row of rows) {
                    const studentId    = getCSVCol(row, 'Student_ID', 'Student ID', 'student_id', 'student id', 'ID', 'id');
                    const firstName    = getCSVCol(row, 'First_Name', 'First Name', 'first_name', 'first name');
                    const lastName     = getCSVCol(row, 'Last_Name', 'Last Name', 'last_name', 'last name');
                    const className    = getCSVCol(row, 'Class', 'class', 'Class_Name', 'Class Name');
                    const teacherId    = getCSVCol(row, 'Teacher_ID', 'Teacher ID', 'teacher_id', 'teacher id', 'Staff_ID', 'Staff ID');
                    const teacherName  = getCSVCol(row, 'Teacher_Name', 'Teacher Name', 'teacher_name', 'teacher name', 'Staff_Name', 'Staff Name', 'Name');
                    const teacherPhone = getCSVCol(row, 'Teacher_Phone', 'Teacher Phone', 'teacher_phone', 'teacher phone', 'Phone', 'phone');
                    const subjectsRaw  = getCSVCol(row, 'Subjects', 'subjects', 'Subject', 'subject');
                    
                    const parentName   = getCSVCol(row, 'Parent_Name', 'Parent Name', 'parent_name', 'parent name');
                    const parentEmail  = getCSVCol(row, 'Parent_Email', 'Parent Email', 'parent_email', 'parent email', 'Email', 'email');
                    const parentPhone  = getCSVCol(row, 'Parent_Phone', 'Parent Phone', 'parent_phone', 'parent phone');
                    const gender       = getCSVCol(row, 'Gender', 'gender');
                    const dob          = getCSVCol(row, 'DOB', 'dob', 'Date_of_Birth', 'Date of Birth');
                    const regNo        = getCSVCol(row, 'Registration_Number', 'Reg_No', 'Reg No', 'Registration_No');
                    const classHostValRaw = getCSVCol(row, 'Class_Host', 'Class Host', 'class_host', 'class host');
                    const classHostValUpper = classHostValRaw.toUpperCase();

                    // 1. If row defines a Teacher, process teacher logic
                    if (teacherId) {
                        if (!teacherIds.has(teacherId)) {
                            upsertTeacher.run({ id: teacherId, name: teacherName || teacherId, phone: teacherPhone });
                            teacherIds.add(teacherId);
                        }
                        // Upsert allocation if class and subjects exist
                        if (className) {
                            const classes = className.split('|').map(c => c.trim()).filter(Boolean);
                            const subjects = subjectsRaw
                                ? subjectsRaw.split('|').map(s => s.trim()).filter(Boolean)
                                : ['General'];
                            for (const cls of classes) {
                                for (const subject of subjects) {
                                    upsertAllocation.run({ teacher_id: teacherId, class_name: cls, subject: normalizeSubjectName(subject, cls) });
                                    allocationCount++;
                                }
                            }
                            
                            // Resolve Form Teacher (Class Host)
                            let hostClassName = null;
                            if (classHostValUpper === 'TRUE' || classHostValUpper === '1' || classHostValUpper === 'YES') {
                                hostClassName = classes[0]; // First class in the list
                            } else if (classHostValRaw && classHostValUpper !== 'FALSE' && classHostValUpper !== '0' && classHostValUpper !== 'NO') {
                                hostClassName = classHostValRaw; // Explicit class name
                            }

                            if (hostClassName) {
                                try {
                                    // Expand bare hierarchy class name to arm-expanded name so it
                                    // matches the fullList used by the Class Hosts modal.
                                    // e.g. "JSS 1" → "JSS 1 Gold" (first configured arm).
                                    // If hostClassName already includes an arm (e.g. "JSS 1 Gold"),
                                    // the query below returns nothing and the name is kept as-is.
                                    const allArms = db.prepare(
                                        `SELECT arm FROM class_arms WHERE hierarchy_class = ? ORDER BY rowid`
                                    ).all(hostClassName);
                                    const resolvedHostClass = allArms.length > 0
                                        ? `${hostClassName} ${allArms[0].arm}`
                                        : hostClassName;

                                    // Warn when boolean TRUE was used and multiple arms exist —
                                    // the admin should use an explicit arm name instead so the
                                    // assignment is unambiguous.
                                    const usedBoolean = (classHostValUpper === 'TRUE' || classHostValUpper === '1' || classHostValUpper === 'YES');
                                    if (usedBoolean && allArms.length > 1) {
                                        const armList = allArms.map(a => `${hostClassName} ${a.arm}`).join(', ');
                                        warnings.push(
                                            `Teacher "${teacherName || teacherId}": Class_Host=TRUE is ambiguous — ` +
                                            `"${resolvedHostClass}" was assumed (first arm). ` +
                                            `Use an explicit arm name to be precise (e.g. ${armList}).`
                                        );
                                    }

                                    upsertFormTeacher.run(resolvedHostClass, teacherId);
                                } catch (ftErr) {
                                    console.error(`[CSV] Failed to assign form teacher for ${hostClassName}:`, ftErr.message);
                                }
                            }
                        }
                    }

                    // 2. If row defines a Student, process student logic
                    if (studentId && (firstName || lastName) && className) {
                        // ── Seat cap enforcement ───────────────────────────────────
                        // Determine if this student already exists (update vs new insert)
                        const isExisting = hasCap
                            ? db.prepare('SELECT 1 FROM students WHERE id = ? LIMIT 1').get(studentId) !== undefined
                            : false;

                        let status = 'active';
                        if (!isExisting && hasCap && newStudentsInserted >= availableSlots) {
                            status = 'overflow';
                            warnings.push(`Seat cap reached: student '${studentId}' (${firstName} ${lastName}) was imported as overflow.`);
                        }

                        const classCheck = validateClassArmRef(className, configs, classArms, { mode: 'strict' });
                        const classNameVal = classCheck.ok ? classCheck.resolved.class_name : className;
                        const classArmVal = classCheck.ok ? classCheck.resolved.class_arm : '';

                        upsertStudent.run({
                            id: studentId,
                            name: `${firstName} ${lastName}`.trim(),
                            class_name: classNameVal,
                            class_arm: classArmVal,
                            parent_name: parentName || null,
                            parent_email: parentEmail || null,
                            parent_phone: parentPhone || null,
                            reg_no: regNo || '',
                            gender: gender || '',
                            dob: dob || '',
                            enrollment_status: status
                        });

                        if (!isExisting && status === 'active') newStudentsInserted++;

                        // Bug #2 fix: also write the student's subject enrollment so
                        // the handshake and Print Hub can filter correctly per subject.
                        if (subjectsRaw) {
                            const stuSubjects = subjectsRaw
                                .split('|')
                                .map(s => s.trim())
                                .filter(Boolean);
                            for (const subj of stuSubjects) {
                                upsertStudentSubject.run({ student_id: studentId, subject: normalizeSubjectName(subj, className) });
                            }
                        }

                        studentCount++;
                    }
                }

                return { studentCount, teacherCount: teacherIds.size, allocationCount, warnings, newStudentsInserted };
            });

            try {
                const result = runImport(rows);
                console.log(`[CSV] ✅ Import complete — ${result.studentCount} students, ${result.teacherCount} teachers, ${result.allocationCount} allocations.`);
                logActivity({
                    event_type: 'ROSTER_CSV_IMPORTED',
                    payload: { students: result.studentCount, teachers: result.teacherCount, allocations: result.allocationCount }
                });
                if (result.warnings && result.warnings.length > 0) {
                    result.warnings.forEach(w => console.warn(`[CSV] ⚠️  ${w}`));
                }
                // Report the count that corresponds to the dominant import type.
                // A pure teachers CSV has studentCount=0; use teacherCount so the
                // UI does not incorrectly show "Zero rows were processed".
                const reportedCount = result.teacherCount > 0 && result.studentCount === 0
                    ? result.teacherCount
                    : result.studentCount;
                if (callback) callback(reportedCount, null, result);
            } catch (err) {
                console.error('[CSV] ❌ Transaction failed:', err.message);
                if (callback) callback(0, err.message);
            }
        });
}
// ─────────────────────────────────────────────────────────────────────────────
// ─── CBT ENGINE LOCAL SERVING & API ──────────────────────────────────────────

const path = require('path');
// Serve the local student client
app.use('/cbt', express.static(path.join(__dirname, '../public/cbt')));

app.post('/api/cbt/auth', (req, res) => {
    const { token, dob_day, dob_month, dob_year } = req.body;
    if (!token) return res.status(400).json({ error: "Token required" });
    
    let db;
    try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT * FROM cbt_tokens WHERE token = ?").get(token.toUpperCase());
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    if (tk.status === 'submitted') return res.status(403).json({ error: "Exam already submitted" });
    
    // Validate Batch Window
    if (tk.batch_id) {
        const batch = db.prepare("SELECT status FROM cbt_batches WHERE id = ?").get(tk.batch_id);
        if (!batch || batch.status !== 'active') {
            return res.status(403).json({ error: "Your exam batch is not currently active." });
        }
    }
    
    // External 2FA Validation
    let candidateName = "";
    if (tk.external_candidate_id) {
        if (!dob_day || !dob_month || !dob_year) return res.status(401).json({ error: "Date of Birth required for external candidates." });
        const ext = db.prepare("SELECT * FROM cbt_external_candidates WHERE id = ?").get(tk.external_candidate_id);
        if (!ext || ext.dob_day !== dob_day || ext.dob_month !== dob_month || ext.dob_year !== dob_year) {
            return res.status(401).json({ error: "Authentication failed. Token and DOB do not match." });
        }
        candidateName = ext.name;
    } else {
        const stu = db.prepare("SELECT name FROM students WHERE id = ? AND (enrollment_status = 'active' OR enrollment_status IS NULL OR enrollment_status = '')").get(tk.student_id);
        if (!stu) return res.status(403).json({ error: "Access Denied: Student is not active or is in overflow status." });
        candidateName = stu.name;
    }

    const exam = db.prepare("SELECT * FROM cbt_exams WHERE id = ?").get(tk.exam_id);
    if (!exam || exam.status !== 'active') return res.status(403).json({ error: "Exam is closed or inactive." });

    // Mark active if not already
    if (tk.status === 'unused') {
        db.prepare("UPDATE cbt_tokens SET status = 'active', started_at = ? WHERE id = ?").run(new Date().toISOString(), tk.id);
    }

    res.json({ success: true, token_id: tk.id, candidate_name: candidateName, exam });
});

app.post('/api/cbt/paper', (req, res) => {
    const { token_id } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT exam_id, question_seed FROM cbt_tokens WHERE id = ?").get(token_id);
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    
    const exam = db.prepare("SELECT * FROM cbt_exams WHERE id = ?").get(tk.exam_id);
    if (!exam) return res.status(404).json({ error: "Exam Not Found" });
    
    // --- Seeded Fisher-Yates shuffle ---
    // Uses the token's question_seed to deterministically shuffle for this candidate.
    // This means every candidate gets a unique order while the server can always
    // reproduce it — no snapshot storage required (~8 bytes per student).
    function seededRandom(seed) {
        // Simple mulberry32 PRNG from a string seed
        let h = 0;
        for (let i = 0; i < seed.length; i++) {
            h = Math.imul(31, h) + seed.charCodeAt(i) | 0;
        }
        return function() {
            h |= 0; h = h + 0x6D2B79F5 | 0;
            let t = Math.imul(h ^ h >>> 15, 1 | h);
            t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }

    function fisherYates(arr, rng) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(rng() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }

    const seed = tk.question_seed || 'DEFAULTSEED';
    const rng  = seededRandom(seed);

    let subjectQuotas = [];
    if (exam.subject_quotas) {
        try {
            subjectQuotas = typeof exam.subject_quotas === 'string'
                ? JSON.parse(exam.subject_quotas)
                : exam.subject_quotas;
        } catch (e) {
            subjectQuotas = [];
        }
    }

    let qs = [];
    if (Array.isArray(subjectQuotas) && subjectQuotas.length > 0) {
        // Multi-Bank Composite Examination: pull quota per subject bank
        for (const sq of subjectQuotas) {
            const bId = Number(sq.bank_id || sq.bankId);
            const quota = Number(sq.question_count || sq.questionCount || sq.count || 0);
            if (!bId || quota <= 0) continue;

            let bankQs = db.prepare(
                "SELECT id, question_text, option_a, option_b, option_c, option_d FROM cbt_questions WHERE bank_id = ?"
            ).all(bId);

            if (exam.shuffle_questions) {
                const bankRng = seededRandom(`${seed}_bank_${bId}`);
                bankQs = fisherYates(bankQs, bankRng);
            }

            bankQs = bankQs.slice(0, quota);
            qs.push(...bankQs);
        }

        // Shuffle combined questions across subjects if shuffle_questions is enabled
        if (exam.shuffle_questions) {
            qs = fisherYates(qs, rng);
        }
    } else {
        // Single Bank Draw (Legacy / Standard)
        qs = db.prepare("SELECT id, question_text, option_a, option_b, option_c, option_d FROM cbt_questions WHERE bank_id = ?").all(exam.bank_id);

        if (exam.shuffle_questions) {
            qs = fisherYates(qs, rng);
        }

        // Slice to exam question count
        qs = qs.slice(0, exam.question_count || qs.length);
    }

    if (exam.shuffle_options) {
        // Each question gets its own seeded option shuffle derived from seed + question id
        qs = qs.map(q => {
            const optRng = seededRandom(seed + String(q.id));
            const opts = [
                { key: 'option_a', val: q.option_a },
                { key: 'option_b', val: q.option_b },
                { key: 'option_c', val: q.option_c },
                { key: 'option_d', val: q.option_d },
            ].filter(o => o.val);
            fisherYates(opts, optRng);
            return {
                id: q.id,
                question_text: q.question_text,
                option_a: opts[0]?.val || '',
                option_b: opts[1]?.val || '',
                option_c: opts[2]?.val || '',
                option_d: opts[3]?.val || '',
            };
        });
    }

    // Note: correct_option is never sent to the client.
    res.json({ success: true, questions: qs, config: exam });
});

app.post('/api/cbt/heartbeat', (req, res) => {
    const { token_id, tab_switches } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    if (tab_switches > 0) {
        db.prepare("UPDATE cbt_tokens SET tab_switches = tab_switches + ? WHERE id = ?").run(tab_switches, token_id);
    }
    res.json({ ok: true });
});

app.post('/api/cbt/submit', (req, res) => {
    const { token_id, answers } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT exam_id, status FROM cbt_tokens WHERE id = ?").get(token_id);
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    // Prevent double-submission
    if (tk.status === 'submitted') return res.status(403).json({ error: "Exam already submitted. Results are final." });
    
    // Auto Grade
    let score = 0;
    const insertAnswer = db.prepare("INSERT OR IGNORE INTO cbt_answers (token_id, question_id, selected_option, is_correct) VALUES (?, ?, ?, ?)");
    const getCorrect = db.prepare("SELECT correct_option, marks FROM cbt_questions WHERE id = ?");
    
    const tx = db.transaction(() => {
        for (const ans of answers) {
            const q = getCorrect.get(ans.question_id);
            if (!q) continue;
            const isCorrect = q.correct_option === ans.selected_option ? 1 : 0;
            score += isCorrect * (q.marks || 1);
            insertAnswer.run(token_id, ans.question_id, ans.selected_option, isCorrect);
        }
        db.prepare("UPDATE cbt_tokens SET status = 'submitted', score = ?, submitted_at = ? WHERE id = ?")
          .run(score, new Date().toISOString(), token_id);
    });
    
    try {
        tx();
        // Fetch result_release_policy to decide what to return
        const exam = db.prepare("SELECT result_release_policy FROM cbt_exams WHERE id = ?").get(tk.exam_id);
        const policy = exam?.result_release_policy || 'immediate';
        if (policy === 'immediate') {
            res.json({ success: true, score });
        } else {
            // Delayed or manual — score is held; candidate sees acknowledgement only
            res.json({ success: true, score: null, held: true, message: 'Your submission was received. Results will be released by your school.' });
        }
    } catch (e) {
        res.status(500).json({ error: "Failed to grade exam: " + e.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────

// The "Day 1" Handshake Endpoint
// Helper to retrieve license status from app locals
function getLicenseStatus() {
    const VALID_TIERS = ['Standalone', 'Silver', 'Gold', 'Diamond'];
    try {
        if (app.locals.license_limit?.payload) {
            const parsed = JSON.parse(app.locals.license_limit.payload);
            // Security: reject any tier not on the canonical allowlist
            if (!VALID_TIERS.includes(parsed.tier)) {
                console.warn(`[Security] getLicenseStatus: unrecognised tier '${parsed.tier}' — clamping to Silver.`);
                return { tier: 'Silver' };
            }
            return parsed;
        }
    } catch (_) {}
    return { tier: 'Silver' }; // default fallback
}

// The "Day 1" Handshake Endpoint
const handleHandshake = (req, res) => {
    const { device_id, teacher_id, teacher_name, public_key, thermal_status, device_model } = req.body;

    console.log(`[Handshake] Received identity from ${teacher_name} [${teacher_id || 'NO_ID'}] (${device_id})`);

    let db;
    try {
        db = database.getDb();
    } catch (e) {
        return res.status(500).json({ error: "Database not initialized" });
    }

    // Identity check: require teacher_id to be present in the QR payload
    if (!teacher_id) {
        return res.status(400).json({ error: "Missing teacher_id in handshake payload." });
    }

    const isStandalone = getLicenseStatus().tier === 'Standalone';
    let teacher;
    let role = 'teacher';

    if (isStandalone) {
        // Standalone mode: ALL device pairings are admin-level regardless of what
        // teacher_id the QR contains. A device may carry a stale teacher QR from
        // a previous session — we normalise it to STANDALONE_ADMIN instead of
        // hard-failing with a 404. The 2-device slot limit is enforced below.
        if (teacher_id !== 'STANDALONE_ADMIN') {
            console.log(`[Handshake] Standalone mode — normalising stale QR identity '${teacher_id}' → STANDALONE_ADMIN`);
        }
        teacher = { id: 'STANDALONE_ADMIN', name: 'Admin' };
        role = 'super_admin';
    } else if (teacher_id === 'STANDALONE_ADMIN') {
        // STANDALONE_ADMIN identity on a non-Standalone license is rejected
        return res.status(403).json({ error: "STANDALONE_ADMIN identity is only valid for Standalone licenses." });
    } else if (teacher_id.startsWith('admin_')) {
        // ── Admin companion pairing (subscription tiers) ──────────────────────
        // QR teacher_id for admins is encoded as 'admin_<id>' by the desktop app.
        const rawAdminId = teacher_id.replace(/^admin_/, '');
        const adminRow = db.prepare('SELECT id, username, role_level FROM admin_users WHERE id = ? LIMIT 1').get(rawAdminId);
        if (!adminRow) {
            console.warn(`[Handshake] Admin ID not found in admin_users: ${rawAdminId}`);
            return res.status(404).json({ error: "Admin account not found in the vault." });
        }
        teacher = { id: String(adminRow.id), name: String(adminRow.username) };
        // Map role_level → Android role string consumed by AppLaunchActivity
        if (adminRow.role_level >= 9)      role = 'it_admin';
        else if (adminRow.role_level >= 7) role = 'principal';
        else if (adminRow.role_level >= 5) role = 'bursar';
        else                               role = 'result_clerk';
        console.log(`[Handshake] Admin '${adminRow.username}' (level ${adminRow.role_level}) → role '${role}' (id: '${teacher.id}')`);
    } else {
        // First check if this exists in staff_roles
        const staff = db.prepare('SELECT id, name, role FROM staff_roles WHERE id = ? LIMIT 1').get(teacher_id);
        if (staff) {
            teacher = { id: staff.id, name: staff.name };
            role = staff.role;
        } else {
            // Subscription path: look up by teacher ID (from QR)
            teacher = db.prepare('SELECT id, name, sync_revoked FROM teachers WHERE id = ? LIMIT 1').get(teacher_id);
            if (!teacher) {
                console.warn(`[Handshake] Teacher ID not found in teachers or staff_roles: ${teacher_id}`);
                return res.status(404).json({ error: "Teacher ID not found in the vault." });
            }
            if (teacher.sync_revoked === 1) {
                return res.status(403).json({ error: "TEACHER_REVOKED", message: "This teacher's sync access has been revoked." });
            }
            role = 'teacher';
        }
    }

    // Connect device limit checks for Standalone
    if (isStandalone) {
        const existingDevice = db.prepare('SELECT device_id FROM connected_devices WHERE device_id = ?').get(device_id);
        if (!existingDevice) {
            const count = db.prepare('SELECT COUNT(*) as c FROM connected_devices').get().c;
            if (count >= 2) {
                return res.status(403).json({
                    error: "DEVICE_LIMIT_REACHED",
                    message: "Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."
                });
            }
        }
    }

    // Register connected device across all plans so requireDeviceAuth succeeds for mobile APIs
    try {
        db.prepare(`
            INSERT OR REPLACE INTO connected_devices (device_id, device_model, label, tier, paired_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        `).run(
            device_id,
            device_model || 'Android Device',
            teacher.name || 'Staff Member',
            isStandalone ? 'Standalone' : (planTier || 'Subscription')
        );
    } catch (devErr) {
        console.warn('[Handshake] Failed to register connected device:', devErr.message);
    }

    // Notify Main Process
    eventEmitter.emit('handshake-success', req.body);

    // Resolve form/homeroom class for this teacher (null if they are not a form teacher)
    let formClass = null;
    if (teacher.id !== 'STANDALONE_ADMIN' && role === 'teacher') {
        const formTeacherRow = db.prepare(
            'SELECT class_name FROM form_teachers WHERE teacher_id = ? LIMIT 1'
        ).get(teacher.id);
        formClass = formTeacherRow?.class_name || null;
    }

    // Bug #1 fix: fetch students filtered by BOTH class AND subject enrollment.
    // A student only appears in a subject tab if they are explicitly enrolled in
    // that subject (student_subjects row exists).
    // PLUS: We union ALL students in the teacher's form_class under the 'General' subject 
    // so they are available on-device for Attendance taking.
    let students;
    if (role === 'it_admin' || role === 'principal' || role === 'bursar') {
        // Management companion roles (IT Admin, Principal, Bursar) use dedicated
        // monitoring dashboards (/api/devices, /api/dashboard-summary, /api/fees/summary).
        // They do not grade students. Omit student grading matrix so handshake payload
        // remains lightweight (<5KB) and completes in milliseconds instead of timing out.
        students = [];
        console.log(`[Handshake] Management role '${role}' paired — student grading matrix omitted for optimal performance.`);
    } else if (isStandalone || role === 'result_clerk') {
        // Standalone or admin staff roles: return every student with every subject they are enrolled in.
        // The UNION 'General' row is kept in the raw query so students with no
        // subject rows are not silently dropped — but ALL 'General' rows are
        // stripped from the payload below before sending to the device.
        const rawStudents = db.prepare(`
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, ss.subject
            FROM students s
            JOIN student_subjects ss ON ss.student_id = s.id
            UNION
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, 'General' AS subject
            FROM students s
        `).all();

        // Remove 'General' sentinel rows — they exist only for attendance tracking.
        // Students whose ONLY row is 'General' (not yet enrolled in any subject)
        // are excluded from the grading payload; they appear in Attendance-only view.
        const realSubjectIds = new Set(
            rawStudents.filter(r => r.subject !== 'General').map(r => r.id)
        );
        students = rawStudents.filter(r => r.subject !== 'General');

        // For completeness, log how many students have no subject assignment yet
        const noSubjectCount = rawStudents
            .filter(r => r.subject === 'General' && !realSubjectIds.has(r.id)).length;
        if (noSubjectCount > 0) {
            console.log(`[Handshake] ${noSubjectCount} student(s) have no subject assignment yet — excluded from grading roster.`);
        }
    } else {
        // Subscription path: filter by teacher allocation, then strip 'General' sentinel.
        const rawStudents = db.prepare(`
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, a.subject
            FROM students s
            JOIN teacher_allocations a
              ON (UPPER(replace(s.class_name, ' ', '')) = UPPER(replace(a.class_name, ' ', ''))
               OR UPPER(replace(s.class_name || COALESCE(s.class_arm, ''), ' ', '')) = UPPER(replace(a.class_name, ' ', '')))
            WHERE a.teacher_id = ?
              AND (
                EXISTS (
                  SELECT 1 FROM student_subjects ss
                  WHERE ss.student_id = s.id AND ss.subject = a.subject
                )
                OR NOT EXISTS (
                  SELECT 1 FROM student_subjects ss2
                  WHERE ss2.student_id = s.id
                )
              )
            UNION
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, 'General' as subject
            FROM students s
            WHERE UPPER(TRIM(replace(s.class_name, ' ', ''))) = ? 
               OR UPPER(TRIM(replace(s.class_name || COALESCE(s.class_arm, ''), ' ', ''))) = ?
               OR (s.class_arm IS NOT NULL AND s.class_arm != ''
                   AND UPPER(TRIM(replace(s.class_name, ' ', ''))) = SUBSTR(?, 1, LENGTH(UPPER(TRIM(replace(s.class_name, ' ', '')))))
                   AND ? LIKE '%' || UPPER(TRIM(replace(s.class_arm, ' ', ''))))
        `).all(teacher.id,
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS',
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS',
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS',
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS');

        // Strip 'General' sentinel — only keep real subject rows for grading payload.
        students = rawStudents.filter(r => r.subject !== 'General');
    }

    // Read score_components from school_term_config so the tablet knows what fields to collect
    let scoreComponents = null;
    try {
        const termCfg = db.prepare('SELECT grading_scale, attendance_score_weight, include_attendance_in_grades FROM school_term_config WHERE id = 1').get();
        if (termCfg?.grading_scale) {
            const parsed = JSON.parse(termCfg.grading_scale);
            if (parsed && Array.isArray(parsed) && parsed.length > 0) {
                // Bare array format: [{key, label, max}, ...]
                scoreComponents = parsed;
            } else if (parsed && !Array.isArray(parsed) && parsed.components && parsed.components.length > 0) {
                // Object format: { scale: ..., components: [...] }
                scoreComponents = parsed.components;
            }
        }
        // Append Attendance as a scoreable component if the school allocated marks for it
        // AND include_attendance_in_grades is true (1)
        const attWeight = termCfg?.attendance_score_weight || 0;
        const includeAtt = termCfg?.include_attendance_in_grades !== 0; // default to true if not explicit 0
        if (attWeight > 0 && includeAtt) {
            if (!scoreComponents) scoreComponents = [];
            const alreadyHas = scoreComponents.find(c => c.key === 'ATT' || c.key === 'Attendance' ||
                (c.label && c.label.toLowerCase().includes('attend')));
            if (!alreadyHas) {
                scoreComponents.push({ key: 'ATT', label: 'Attendance', max: attWeight });
            }
        }
    } catch(e) { /* use default if config unreadable */ }
    if (!scoreComponents || scoreComponents.length === 0) {
        scoreComponents = [
            { key: "CA1",  label: "C.A. 1", max: 10 },
            { key: "CA2",  label: "C.A. 2", max: 10 },
            { key: "Exam", label: "Exam",   max: 80 },
        ];
    }
    scoreComponents = sortGradingComponents(scoreComponents);

    // ── WAEC/NECO-aligned master subject lists ──────────────────────────────────
    // These cover ALL streams (Science, Arts, Commercial) so the phone always
    // has a complete picker. Class-level split keeps JSS students from seeing SS
    // subjects and vice versa.  School-specific subjects from the DB are merged in.
    const MASTER_JSS = [
        'English Language', 'Mathematics', 'Integrated Science',
        'Social and Citizenship Studies', 'Agricultural Science',
        'Christian Religious Studies', 'Islamic Studies',
        'Physical and Health Education', 'French', 'Arabic',
        'Yoruba', 'Igbo', 'Hausa',
        'Home Economics', 'Business Studies', 'Digital Technologies',
        'Fine Art', 'Music', 'Technical Drawing',
        'Cultural and Creative Arts', 'Civic Education',
        'History', 'Geography'
    ];

    const MASTER_SS = [
        // Core
        'English Language', 'General Mathematics', 'Further Mathematics',
        // Sciences
        'Physics', 'Chemistry', 'Biology', 'Agricultural Science',
        'Technical Drawing', 'Food and Nutrition',
        // Commercial
        'Commerce', 'Financial Accounting', 'Economics',
        'Office Practice', 'Shorthand', 'Marketing',
        // Arts / Social
        'Government', 'History', 'Geography',
        'Literature in English', 'Christian Religious Studies',
        'Islamic Studies', 'Arabic', 'French',
        'Yoruba', 'Igbo', 'Hausa',
        // Technical / Creative
        'Fine Art', 'Music', 'Physical and Health Education',
        'Digital Technologies', 'Data Processing',
        'Catering Craft', 'Home Management',
        'Clothing and Textiles',
        // General / Civic
        'Civic Education', 'Insurance'
    ];

    // Helper: is this class name a JSS-level class?
    const isJSSClass = (cn) => {
        const u = (cn || '').toUpperCase();
        return u.startsWith('JS') || u.startsWith('JSS') || u.startsWith('JHS');
    };

    // Pull school-specific subjects (DB) and normalize them
    const rawSubjectRows = db.prepare(`
        SELECT subject FROM teacher_allocations WHERE subject != 'General'
        UNION
        SELECT subject FROM student_subjects WHERE subject != 'General'
    `).all();
    const dbSubjectsNorm = rawSubjectRows.map(row => normalizeSubjectName(row.subject, null));

    // Master all_subjects = union of JSS + SS master lists + DB subjects, sorted
    const allSubjects = [...new Set([
        ...MASTER_JSS, ...MASTER_SS, ...dbSubjectsNorm
    ])].sort();

    // Per-class subjects: start from class's master list, add DB subjects for that class
    const classRows = db.prepare(`
        SELECT DISTINCT a.class_name, a.subject
        FROM teacher_allocations a
        WHERE a.subject != 'General'
        UNION
        SELECT DISTINCT s.class_name, ss.subject
        FROM students s
        JOIN student_subjects ss ON ss.student_id = s.id
        WHERE ss.subject != 'General'
    `).all();

    // Collect distinct class names from DB
    const allClassNames = [...new Set(classRows.map(r => r.class_name).filter(Boolean))];

    // Build classSubjectsMap: master list for level + school-specific DB additions
    const classSubjectsMap = {};
    allClassNames.forEach(className => {
        const base = isJSSClass(className) ? [...MASTER_JSS] : [...MASTER_SS];
        classSubjectsMap[className] = [...new Set([...base])].sort();
    });

    // Merge DB subjects into their respective class
    classRows.forEach(row => {
        const normSubject = normalizeSubjectName(row.subject, row.class_name);
        if (!classSubjectsMap[row.class_name]) classSubjectsMap[row.class_name] = [];
        if (!classSubjectsMap[row.class_name].includes(normSubject)) {
            classSubjectsMap[row.class_name].push(normSubject);
            classSubjectsMap[row.class_name].sort();
        }
    });


    // Form class was resolved above to support the new union query.

    // Merge saved school_config with guaranteed defaults so Android always
    // receives a valid modules array and primary_color regardless of what
    // fields the identity.json was saved with.
    const baseConfig = app.locals.school_config || {};
    const modules = Array.isArray(baseConfig.modules)
                     ? [...baseConfig.modules]
                     : ["grading", "attendance"];
    
    // Ensure student_photo is present in modules list for all plans
    if (!modules.includes("student_photo")) {
        modules.push("student_photo");
    }

    // Derive the plan tier to display on the device Settings screen.
    // Priority: explicit planTier field → premiumPlan flag → module inference.
    let planTier = baseConfig.planTier || baseConfig.plan_tier || null;
    if (!planTier) {
        if (modules.some(m => m === 'custom_result'))  planTier = 'Diamond';
        else if (modules.some(m => m === 'parent_contact')) planTier = 'Gold';
        else if (baseConfig.premiumPlan === true || baseConfig.premiumPlan === 'true') planTier = 'Silver';
        else planTier = 'Standalone';
    }

    const registrationLocked = checkLockState(db, 'registration');
    const gradesLocked       = checkLockState(db, 'grades');
    const attendanceLocked   = checkLockState(db, 'attendance');
    const registrationLockAt = getLockAtMillis(db, 'registration');
    const gradesLockAt       = getLockAtMillis(db, 'grades');
    const attendanceLockAt   = getLockAtMillis(db, 'attendance');

    const termCfgForScores = db.prepare('SELECT academic_session, term FROM school_term_config WHERE id = 1').get() || {};

    const schoolConfig = {
        name:          baseConfig.name          || baseConfig.school_name || "Nexus School",
        primary_color: baseConfig.themePrimary  || baseConfig.primary_color || "#1A237E",
        logoBase64:    baseConfig.logoBase64    || null,
        modules:       modules,
        plan_tier:     planTier,
        active_session: termCfgForScores.academic_session || "2024/2025",
        active_term:    termCfgForScores.term             || "First Term",
        registration_locked: registrationLocked,
        grades_locked:       gradesLocked,
        attendance_locked:   attendanceLocked,
        registration_lock_at: registrationLockAt,
        grades_lock_at:       gradesLockAt,
        attendance_lock_at:   attendanceLockAt
    };

    // ── Sync existing Hub scores to device on handshake ─────────────────────
    // Expands each student_records breakdown into individual component rows
    // matching the Android StudentScore Room entity (student_id, subject, component_key, score).
    let existingScores = [];
    try {
        if (termCfgForScores.academic_session && students.length > 0) {
            const uniqueIds = [...new Set(students.map(s => s.id))];
            const placeholders = uniqueIds.map(() => '?').join(',');
            const scoreRows = db.prepare(`
                SELECT student_id, subject, score, breakdown
                FROM student_records
                WHERE student_id IN (${placeholders})
                  AND academic_session = ?
                  AND term = ?
            `).all(...uniqueIds, termCfgForScores.academic_session, termCfgForScores.term);

            for (const r of scoreRows) {
                let bd = {};
                try { bd = JSON.parse(r.breakdown) || {}; } catch (_) {}
                const entries = Object.entries(bd || {}).filter(([, v]) => v != null);
                if (entries.length > 0) {
                    for (const [key, val] of entries) {
                        // Normalize the key to match active components
                        const normKey = key.toLowerCase().replace(/[^a-z0-9]/g, '');
                        const matchedComp = scoreComponents.find(c =>
                            c.key.toLowerCase().replace(/[^a-z0-9]/g, '') === normKey ||
                            c.label.toLowerCase().replace(/[^a-z0-9]/g, '') === normKey
                        );
                        const finalKey = matchedComp ? matchedComp.key : key;
                        existingScores.push({
                            student_id:    r.student_id,
                            subject:       r.subject,
                            component_key: finalKey,
                            score:         Number(val) || 0,
                        });
                    }
                } else if (r.score != null && r.score > 0) {
                    // Fallback: no breakdown stored (score entered from desktop admin panel).
                    // Map the aggregate to the heaviest score component (usually "Exam") so
                    // the teacher sees the value pre-filled and can adjust components if needed.
                    const heaviest = scoreComponents.reduce(
                        (best, c) => (!best || (c.max || 0) > (best.max || 0) ? c : best),
                        scoreComponents[scoreComponents.length - 1] || null
                    );
                    if (heaviest) {
                        existingScores.push({
                            student_id:    r.student_id,
                            subject:       r.subject,
                            component_key: heaviest.key,
                            score:         Math.min(Number(r.score) || 0, heaviest.max || 100),
                        });
                    }
                }
            }
        }
    } catch (scoreErr) {
        console.warn('[Handshake] Could not fetch existing scores (non-fatal):', scoreErr.message);
    }

    const payloadObj = {
        status: "MARRIED",
        message: `Welcome to the ecosystem, ${teacher.name}.`,
        role: String(role || 'teacher'),
        teacher_id: String(teacher.id),
        teacher_name: String(teacher.name),
        school_config: schoolConfig,
        score_components: scoreComponents,
        students: students,
        all_subjects: allSubjects,
        class_subjects: classSubjectsMap,
        form_class: formClass,
        scores: existingScores,             // pre-existing Hub scores for the matched roster
        server_timestamp: new Date().toISOString()
    };

    const jsonString = JSON.stringify(payloadObj);


    // PM Rule: Gzip if > 500 students to prevent Heat Spikes on the mobile side
    // For testing/QA, let's keep the threshold tight or test dynamically, 
    // but the prompt specifies chunk/gzip if > 500.
    if (students.length > 500) {
        console.log(`[Eco-Mode] Payload > 500 targeted students (${students.length}). Gzipping for ${device_id}...`);
        const zlib = require('zlib');
        zlib.gzip(jsonString, (err, buffer) => {
            if (!err) {
                res.setHeader('Content-Encoding', 'gzip');
                res.setHeader('Content-Type', 'application/json');
                res.status(200).send(buffer);
            } else {
                res.status(500).json({ error: "Compression error" });
            }
        });
    } else {
        console.log(`[Handshake] Sending ${students.length} targeted student records to ${device_id}`);
        res.status(200).json(payloadObj);
    }
};

// The "Day 2" Sync Endpoint
const handleSync = (req, res) => {
    const { device_id, teacher_id, teacher_name, signature, events, device_model } = req.body || {};
    const eventsArray = events || [];

    console.log(`[Sync] Received ${eventsArray.length} signed events from device: ${device_id || 'UNKNOWN'}`);
    if (signature) {
        console.log(`[Sync] ECDSA Signature Attached: ${signature.substring(0, 30)}...`);
    }

    let db;
    try {
        db = database.getDb();
    } catch (e) {
        console.error("[Sync] DB not ready.");
        return res.status(500).json({ error: "Database not initialized" });
    }

    let assertSetupChain;
    try {
        assertSetupChain = require('../../public_shell/electron/lib/setupChain').assertSetupChain;
    } catch (_) {}
    const termSetupCheck = (db && assertSetupChain) ? assertSetupChain(db, 'term') : { ok: true };

    const registrationLocked = checkLockState(db, 'registration');
    const gradesLocked       = checkLockState(db, 'grades');
    const attendanceLocked   = checkLockState(db, 'attendance');
    const registrationLockAt = getLockAtMillis(db, 'registration');
    const gradesLockAt       = getLockAtMillis(db, 'grades');
    const attendanceLockAt   = getLockAtMillis(db, 'attendance');

    const isStandalone = getLicenseStatus().tier === 'Standalone';
    const isStandaloneDevice = db.prepare('SELECT 1 FROM connected_devices WHERE device_id = ?').get(device_id) ? true : false;

    if (isStandalone && !isStandaloneDevice) {
        console.warn(`[Sync] Blocked sync request from unregistered/revoked device: ${device_id}`);
        return res.status(403).json({
            error: "DEVICE_REVOKED_OR_NOT_PAIRED",
            message: "Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."
        });
    }

    let teacherId = "UNKNOWN_TEACHER";
    let role = "teacher";
    if (isStandaloneDevice || teacher_id === 'STANDALONE_ADMIN') {
        teacherId = 'STANDALONE_ADMIN';
        role = "super_admin";
    } else if (teacher_id && teacher_id.startsWith('admin_')) {
        // ── Admin companion sync (subscription tiers) ────────────────────────
        const rawAdminId = teacher_id.replace(/^admin_/, '');
        const adminRow = db.prepare('SELECT id, username, role_level FROM admin_users WHERE id = ? LIMIT 1').get(rawAdminId);
        if (adminRow) {
            teacherId = adminRow.id;
            if (adminRow.role_level >= 9)      role = 'it_admin';
            else if (adminRow.role_level >= 7) role = 'principal';
            else if (adminRow.role_level >= 5) role = 'bursar';
            else                               role = 'result_clerk';
        }
    } else if (teacher_id) {
        // First check if this exists in staff_roles
        const staff = db.prepare('SELECT id, role FROM staff_roles WHERE id = ? LIMIT 1').get(teacher_id);
        if (staff) {
            teacherId = staff.id;
            role = staff.role;
        } else {
            const teacher = db.prepare('SELECT id, sync_revoked FROM teachers WHERE id = ? LIMIT 1').get(teacher_id);
            if (teacher) {
                if (teacher.sync_revoked === 1) {
                    return res.status(403).json({ error: "TEACHER_REVOKED", message: "This teacher's sync access has been revoked." });
                }
                teacherId = teacher.id;
                role = "teacher";
            }
        }
    } else if (teacher_name) {
        // Fallback for older tablet app versions
        const teacher = db.prepare('SELECT id, sync_revoked FROM teachers WHERE name = ? COLLATE NOCASE LIMIT 1').get(teacher_name);
        if (teacher) {
            if (teacher.sync_revoked === 1) {
                return res.status(403).json({ error: "TEACHER_REVOKED", message: "This teacher's sync access has been revoked." });
            }
            teacherId = teacher.id;
            role = "teacher";
        }
    }

    let actorLabel = teacher_name || "Teacher";
    if (teacherId === 'STANDALONE_ADMIN') {
        actorLabel = "Admin";
    } else if (teacherId !== 'UNKNOWN_TEACHER') {
        if (role !== "teacher") {
            const staff = db.prepare('SELECT name FROM staff_roles WHERE id = ?').get(teacherId);
            if (staff) actorLabel = staff.name;
        } else {
            const dbTeacher = db.prepare('SELECT name FROM teachers WHERE id = ?').get(teacherId);
            if (dbTeacher) actorLabel = dbTeacher.name;
        }
    }

    // Read current active session/term so every grade record is queryable by session+term.
    // This fixes the root cause of scores showing "—" in generated reports.
    const termRow      = db.prepare('SELECT academic_session, term FROM school_term_config WHERE id = 1').get() || {};
    const activeSession = termRow.academic_session || '2024/2025';
    const activeTerm    = termRow.term             || 'First Term';

    // Process Ledger insertions in a single atomic transaction.
    // Using INSERT OR IGNORE for the audit log so that idempotent re-syncs
    // (same deterministic event_id GRADE_<student>_<subject>) don't throw a
    // PRIMARY KEY conflict and silently abort the grade upsert that follows.
    const insertLog    = db.prepare('INSERT OR IGNORE INTO sync_logs (event_id, device_id, teacher_id, payload) VALUES (?, ?, ?, ?)');
    const upsertRecord = db.prepare(`
        INSERT OR REPLACE INTO student_records 
        (student_id, subject, academic_session, term, assessment, score, breakdown, teacher_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertStudent = db.prepare('INSERT OR IGNORE INTO students (id, name, class_name) VALUES (?, ?, ?)');
    const insertStudentSubject = db.prepare('INSERT OR IGNORE INTO student_subjects (student_id, subject) VALUES (?, ?)');
    const upsertStudent = db.prepare(`
        INSERT INTO students (id, name, class_name, class_arm, reg_no, admission_no, gender, dob, photo, parent_name, parent_email, parent_phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET 
            name = excluded.name, 
            class_name = excluded.class_name,
            class_arm = COALESCE(nullif(excluded.class_arm, ''), class_arm),
            reg_no = COALESCE(nullif(excluded.reg_no, ''), reg_no),
            admission_no = COALESCE(nullif(excluded.admission_no, ''), admission_no),
            gender = COALESCE(nullif(excluded.gender, ''), gender),
            dob = COALESCE(nullif(excluded.dob, ''), dob),
            photo = COALESCE(excluded.photo, photo),
            parent_name = COALESCE(nullif(excluded.parent_name, ''), parent_name),
            parent_email = COALESCE(nullif(excluded.parent_email, ''), parent_email),
            parent_phone = COALESCE(nullif(excluded.parent_phone, ''), parent_phone)
    `);
    const insertActivityLog = db.prepare(`
        INSERT INTO activity_log (device_id, device_model, actor_label, event_type, payload_hash)
        VALUES (?, ?, ?, ?, ?)
    `);

    let successfullyInserted = 0;
    const failedEvents = [];
    
    // Check if device is explicitly revoked
    const isRevoked = db.prepare("SELECT 1 FROM revoked_devices WHERE device_id = ?").get(device_id);
    if (isRevoked) {
        return res.status(403).json({ error: "REVOKED" });
    }

    // License Check State
    let currentStudentCount = db.prepare('SELECT COUNT(id) AS c FROM students').get().c;
    const maxStudents = app.locals.license_limit?.payload ? JSON.parse(app.locals.license_limit.payload).student_count || 999999 : 999999;

    const processSyncTransaction = db.transaction(() => {
        for (const evt of eventsArray) {
            // 1. Audit Trail (INSERT OR IGNORE — safe on re-sync)
            try {
                insertLog.run(evt.event_id, device_id || 'UNKNOWN', teacherId, JSON.stringify(evt));
            } catch (auditErr) {
                console.warn(`[Sync] Audit log skipped for ${evt.event_id}:`, auditErr.message);
            }

            // 2. Add Student Interceptor (The Hawk)
            if (evt.event_type === "ADD_STUDENT") {
                try {
                    // ── Mobile registration lock check ────────────────────────────
                    if (registrationLocked) {
                        console.log(`[Sync] ADD_STUDENT blocked — mobile registration is disabled by admin.`);
                        failedEvents.push(evt.event_id);
                        continue;
                    }
                    // ─────────────────────────────────────────────────────────────
                    if (currentStudentCount >= maxStudents) {
                        failedEvents.push(evt.event_id);
                        continue; // Skip this insertion
                    }
                    const p = JSON.parse(evt.payload);
                    upsertStudent.run(
                        p.student_id,
                        p.name,
                        p.class_name,
                        p.class_arm || '',
                        p.reg_no || '',
                        p.admission_no || '',
                        p.gender || '',
                        p.dob || '',
                        p.photo_base64 || null,
                        p.parent_name || '',
                        p.parent_email || '',
                        p.parent_phone || ''
                    );
                    insertStudentSubject.run(p.student_id, p.subject || 'General');
                    currentStudentCount++;
                } catch (e) {
                    console.error("Failed to add student:", e);
                }
            }

            // 3. Ledger Upsert — runs independently so audit errors never block grade writes
            if (evt.event_type === "UPDATE_GRADE") {
                if (!termSetupCheck.ok) {
                    console.log(`[Sync] UPDATE_GRADE blocked — term setup incomplete: ${termSetupCheck.message}`);
                    failedEvents.push(evt.event_id);
                    continue;
                }
                if (gradesLocked) {
                    console.log(`[Sync] UPDATE_GRADE blocked — mobile grades entry is locked by admin.`);
                    failedEvents.push(evt.event_id);
                    continue;
                }
                try {
                    const p = JSON.parse(evt.payload);
                    const breakdownStr = p.breakdown ? JSON.stringify(p.breakdown) : "{}";
                    const incomingSubject = p.subject || 'General';

                    // --- SUBJECT CONSISTENCY & CURRICULUM TYPE ENGINE ---
                    // 1. Get the student's canonical class + arm to check allocations & curriculum mode
                    const studentRow = db.prepare("SELECT class_name, COALESCE(class_arm, '') as class_arm, is_active, status, enrollment_status FROM students WHERE id = ?").get(p.student_id);
                    if (!studentRow || studentRow.is_active === 0 || studentRow.status === 'overflow' || studentRow.enrollment_status === 'inactive') {
                        console.warn(`[Sync] Grade/PAC score update blocked — student ${p.student_id} is inactive or in overflow status.`);
                        failedEvents.push(evt.event_id);
                        continue;
                    }
                    if (studentRow && teacherId && teacherId !== 'STANDALONE_ADMIN' && incomingSubject !== 'General') {
                        const fullClass = studentRow.class_name + studentRow.class_arm;
                        // 2. Check allocation against both bare class_name and composite (e.g. 'JSS1' AND 'JSS1A')
                        const allocationCheck = db.prepare(
                            "SELECT 1 FROM teacher_allocations WHERE teacher_id = ? AND (UPPER(replace(class_name, ' ', '')) = ? OR UPPER(replace(class_name, ' ', '')) = ?) AND subject = ?"
                        ).get(teacherId, 
                              (studentRow.class_name || '').replace(/\s+/g, '').toUpperCase(), 
                              (fullClass || '').replace(/\s+/g, '').toUpperCase(), 
                              incomingSubject);
                        
                        if (!allocationCheck) {
                            // 3. Mismatch detected! Log warning, but DO NOT drop the data (per requirements)
                            try {
                                db.prepare('INSERT INTO sync_warnings (device_id, teacher_id, student_id, mismatched_subject) VALUES (?, ?, ?, ?)').run(device_id, teacherId, p.student_id, incomingSubject);
                            } catch (warnErr) {
                                console.error("[Sync] Failed to log sync_warning:", warnErr.message);
                            }
                        }
                    }

                    // Check if student's class is in ILS curriculum mode or payload is a PAC score
                    const classRow = studentRow?.class_name
                        ? db.prepare("SELECT curriculum_type FROM class_configs WHERE hierarchy_class = ?").get(studentRow.class_name)
                        : null;
                    const isILS = classRow?.curriculum_type === 'ILS' || p.pack_number !== undefined || evt.event_type === 'UPDATE_PAC_SCORE';

                    if (isILS && (p.pack_number !== undefined || evt.event_type === 'UPDATE_PAC_SCORE')) {
                        const packNum = parseInt(p.pack_number);
                        const scoreNum = Math.round((Number(p.score) || 0) * 100) / 100;
                        if (isNaN(packNum) || packNum < 1 || packNum > 12 || isNaN(scoreNum) || scoreNum < 80 || scoreNum > 100) {
                            console.warn(`[Sync] UPDATE_PAC_SCORE blocked — invalid score (${p.score}) or pack_number (${p.pack_number}) for event ${evt.event_id}`);
                            failedEvents.push(evt.event_id);
                            continue;
                        }
                        const passed = scoreNum >= 85 ? 1 : 0;

                        db.prepare(`
                            INSERT INTO ils_records (student_id, academic_session, term, subject, pack_number, score, passed)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(student_id, academic_session, term, subject, pack_number)
                            DO UPDATE SET score = excluded.score, passed = excluded.passed
                        `).run(p.student_id, activeSession, activeTerm, incomingSubject, packNum, scoreNum, passed);
                        successfullyInserted++;
                    } else {
                        upsertRecord.run(
                            p.student_id,
                            incomingSubject,
                            activeSession,
                            activeTerm,
                            p.assessment || 'CA1',
                            p.score,
                            breakdownStr,
                            teacherId
                        );
                        successfullyInserted++;
                    }
                } catch (gradeErr) {
                    console.error(`[Sync] Grade upsert failed for ${evt.event_id}:`, gradeErr.message);
                }
            }

            // 4. Attendance Interceptor
            if (evt.event_type === "ATTENDANCE_UPDATE") {
                if (!termSetupCheck.ok) {
                    console.log(`[Sync] ATTENDANCE_UPDATE blocked — term setup incomplete: ${termSetupCheck.message}`);
                    failedEvents.push(evt.event_id);
                    continue;
                }
                if (attendanceLocked) {
                    console.log(`[Sync] ATTENDANCE_UPDATE blocked — mobile attendance entry is locked by admin.`);
                    failedEvents.push(evt.event_id);
                    continue;
                }
                try {
                    const p = JSON.parse(evt.payload);
                    const source = p.source || 'teacher';

                    // Reject future-dated attendance
                    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
                    if (p.date && p.date > today) {
                        console.warn(`[Sync] ATTENDANCE_UPDATE rejected — future date ${p.date} (today is ${today})`);
                        failedEvents.push(evt.event_id);
                        continue;
                    }

                    const upsertAttendance = db.prepare(`
                        INSERT INTO daily_attendance
                        (student_id, class_name, date, status, academic_session, term, recorded_by_teacher_id, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(student_id, date) DO UPDATE SET 
                        status=excluded.status, 
                        recorded_by_teacher_id=excluded.recorded_by_teacher_id,
                        source=excluded.source
                        WHERE daily_attendance.source != 'admin' OR excluded.source = 'admin'
                    `);
                    upsertAttendance.run(
                        p.student_id,
                        p.class_name,
                        p.date,
                        p.status,
                        activeSession,
                        activeTerm,
                        teacherId,
                        source
                    );
                    successfullyInserted++;

                    // Guardian Shield: Emit alert event if absent
                    if (p.status === 'Absent') {
                        eventEmitter.emit('attendance-alert', {
                            student_id: p.student_id,
                            date: p.date
                        });
                    }
                } catch (attErr) {
                    console.error(`[Sync] Attendance upsert failed for ${evt.event_id}:`, attErr.message);
                }
            }

            // 5. Activity Log write (all tiers)
            try {
                const crypto = require('crypto');
                const hash = crypto.createHash('sha256').update(evt.payload || '').digest('hex');
                insertActivityLog.run(
                    device_id || 'UNKNOWN',
                    device_model || null,
                    actorLabel,
                    evt.event_type,
                    hash
                );
            } catch (actErr) {
                console.warn(`[Sync] Activity log failed for ${evt.event_id}:`, actErr.message);
            }
        }
    });



    try {
        processSyncTransaction();
        console.log(`[Sync] Successfully upserted ${successfullyInserted} grade records into Ledger.`);
    } catch (err) {
        console.error("[Sync] Transaction failed:", err);
    }

    // Forward enriched events to main.js via EventEmitter
    eventEmitter.emit('sync-events', { teacher_name: teacher_name || "A Teacher", events: eventsArray, count: successfullyInserted });

    // Inform Main App if limit was breached!
    if (failedEvents.length > 0) {
        eventEmitter.emit('capacity-alert', { totalFailed: failedEvents.length });
    }

    // Resolve license expiry so phone can show a countdown warning
    let expiresAt = 0;
    try {
        if (app.locals.license_limit?.payload) {
            expiresAt = JSON.parse(app.locals.license_limit.payload).expires_at || 0;
        }
    } catch (_) {}

    // --- SUBJECT CONSISTENCY ENGINE ---
    // Push the canonical list of subjects back to the Android app so it can fix stale lists
    let canonicalSubjects = [];
    try {
        if (teacherId) {
            canonicalSubjects = db.prepare('SELECT class_name, subject FROM teacher_allocations WHERE teacher_id = ?').all(teacherId);
        }
    } catch (e) {
        console.error("[Sync] Failed to fetch canonical subjects:", e.message);
    }

    // Fetch class curriculum types so Android app knows which mode (Standard vs ILS) to render per class
    let classCurriculumTypes = {};
    try {
        const rows = db.prepare("SELECT hierarchy_class, curriculum_type FROM class_configs").all();
        for (const r of rows) {
            classCurriculumTypes[r.hierarchy_class] = r.curriculum_type || 'STANDARD_NIGERIAN';
        }
    } catch (_) {}

    // Push current score_components so every Sync Now refreshes grading fields on device.
    let syncScoreComponents = null;
    try {
        const termCfg2 = db.prepare('SELECT grading_scale, attendance_score_weight, include_attendance_in_grades FROM school_term_config WHERE id = 1').get();
        if (termCfg2?.grading_scale) {
            const p2 = JSON.parse(termCfg2.grading_scale);
            if (Array.isArray(p2) && p2.length > 0)            syncScoreComponents = p2;
            else if (p2?.components?.length > 0)               syncScoreComponents = p2.components;
        }
        const attW = termCfg2?.attendance_score_weight || 0;
        const includeAtt2 = termCfg2?.include_attendance_in_grades !== 0;
        if (attW > 0 && includeAtt2) {
            if (!syncScoreComponents) syncScoreComponents = [];
            const hasAtt = syncScoreComponents.find(c =>
                c.key === 'ATT' || c.key === 'Attendance' ||
                (c.label && c.label.toLowerCase().includes('attend'))
            );
            if (!hasAtt) syncScoreComponents.push({ key: 'ATT', label: 'Attendance', max: attW });
        }
    } catch (_) {}

    if (syncScoreComponents) {
        syncScoreComponents = sortGradingComponents(syncScoreComponents);
    }

    res.status(200).json({
        status: failedEvents.length > 0 ? 'PARTIAL_LIMIT' : 'ACK',
        failed_events: failedEvents,
        expires_at: expiresAt,
        role: role,
        canonical_subjects: canonicalSubjects,
        class_curriculum_types: classCurriculumTypes,
        score_components: syncScoreComponents || [],
        registration_locked: registrationLocked,
        grades_locked:       gradesLocked,
        attendance_locked:   attendanceLocked,
        registration_lock_at: registrationLockAt,
        grades_lock_at:       gradesLockAt,
        attendance_lock_at:   attendanceLockAt
    });
};

app.post('/handshake', handshakeRateLimiter, (req, res, next) => {
    console.warn('[DEPRECATED] Bare route /handshake used. Clients should update to use /api/handshake.');
    next();
}, handleHandshake);
app.post('/api/handshake', handshakeRateLimiter, handleHandshake);

// ── Camera-Free PIN Pairing & Local Web Bridge (/pair) ─────────────────────────
// PINs are persisted in SQLite (pairing_pins table) so they survive engine restarts.
// Each PIN is: 6-digit, 30-min TTL, single-use, per-teacher rollover.

function _getPinsDb() {
    try { return database.getDb(); } catch (_) { return null; }
}

function generatePairingPin(teacherId, teacherName) {
    const db = _getPinsDb();
    const now = Date.now();
    const expires_at = now + 30 * 60 * 1000;

    if (db) {
        // 1. Purge expired pins
        db.prepare('DELETE FROM pairing_pins WHERE expires_at <= ?').run(now);
        // 2. Rotate: delete any existing PIN for this teacher
        db.prepare('DELETE FROM pairing_pins WHERE teacher_id = ?').run(teacherId);
        // 3. Generate unique 6-digit PIN
        let pin;
        do {
            pin = Math.floor(100000 + Math.random() * 900000).toString();
        } while (db.prepare('SELECT 1 FROM pairing_pins WHERE pin = ?').get(pin));
        // 4. Persist to SQLite
        db.prepare(
            'INSERT INTO pairing_pins (pin, teacher_id, teacher_name, created_at, expires_at) VALUES (?, ?, ?, ?, ?)'
        ).run(pin, teacherId, teacherName || 'Teacher', now, expires_at);
        const formatted_pin = `${pin.slice(0, 3)} ${pin.slice(3)}`;
        console.log(`[PairingPin] Generated SQLite-backed PIN ${formatted_pin} for ${teacherName} (TTL 30m)`);
        return { pin, formatted_pin, expires_at };
    }

    // Fallback: in-memory map (DB not yet initialized)
    if (!generatePairingPin._fallbackStore) generatePairingPin._fallbackStore = new Map();
    const store = generatePairingPin._fallbackStore;
    for (const [p, d] of store.entries()) {
        if (d.expires_at <= now || d.teacher_id === teacherId) store.delete(p);
    }
    let pin;
    do { pin = Math.floor(100000 + Math.random() * 900000).toString(); } while (store.has(pin));
    store.set(pin, { teacher_id: teacherId, teacher_name: teacherName || 'Teacher', created_at: now, expires_at });
    const formatted_pin = `${pin.slice(0, 3)} ${pin.slice(3)}`;
    console.warn(`[PairingPin] DB unavailable — using in-memory fallback PIN ${formatted_pin}`);
    return { pin, formatted_pin, expires_at };
}

function _getPinData(cleanPin) {
    const db = _getPinsDb();
    if (db) return db.prepare('SELECT * FROM pairing_pins WHERE pin = ?').get(cleanPin) || null;
    const store = generatePairingPin._fallbackStore;
    return store ? (store.get(cleanPin) || null) : null;
}

function _deletePin(cleanPin) {
    const db = _getPinsDb();
    if (db) { db.prepare('DELETE FROM pairing_pins WHERE pin = ?').run(cleanPin); return; }
    if (generatePairingPin._fallbackStore) generatePairingPin._fallbackStore.delete(cleanPin);
}

// Generate PIN endpoint (called by desktop UI or local web page)
app.post('/api/generate-pairing-pin', (req, res) => {
    const { teacher_id, teacher_name } = req.body;
    if (!teacher_id) {
        return res.status(400).json({ error: "teacher_id required" });
    }
    const pinInfo = generatePairingPin(teacher_id, teacher_name);
    const host = req.hostname || address.ip();
    const port = req.socket.localPort || 3000;
    return res.json({
        ok: true,
        pin: pinInfo.pin,
        formatted_pin: pinInfo.formatted_pin,
        expires_at: pinInfo.expires_at,
        pairing_url: `http://${host}:${port}/pair`
    });
});

// Handshake by PIN: validates PIN, injects resolved teacher identity, and runs standard handleHandshake
app.post('/api/handshake-pin', handshakeRateLimiter, (req, res) => {
    const { pin, device_id, device_model, public_key, thermal_status } = req.body;
    if (!pin) {
        return res.status(400).json({ error: "PIN_REQUIRED", message: "Pairing PIN is required." });
    }

    const cleanPin = pin.toString().replace(/\s+/g, '');
    const pinData = _getPinData(cleanPin);

    if (!pinData) {
        return res.status(400).json({ error: "INVALID_PIN", message: "Invalid pairing PIN. Ask Admin for a new code." });
    }

    if (pinData.expires_at <= Date.now()) {
        _deletePin(cleanPin);
        return res.status(400).json({ error: "PIN_EXPIRED", message: "Pairing PIN has expired. Ask Admin to regenerate." });
    }

    // Attach resolved teacher identity to request body for handleHandshake
    req.body.teacher_id = pinData.teacher_id;
    req.body.teacher_name = pinData.teacher_name;

    // Wrap res.json to consume PIN on successful handshake
    const originalJson = res.json.bind(res);
    res.json = function(data) {
        if (res.statusCode >= 200 && res.statusCode < 300) {
            _deletePin(cleanPin);
            console.log(`[Handshake] Successfully consumed pairing PIN ${cleanPin} for ${pinData.teacher_name}`);
        }
        return originalJson(data);
    };

    handleHandshake(req, res);
});

// Serve direct APK download from Hub over local Wi-Fi (0 internet data required)
app.get('/pair/apk', (req, res) => {
    const fs = require('fs');
    const path = require('path');
    const candidatePaths = [
        // 1. Production: electron-builder bundles APK via extraResources
        ...(process.resourcesPath ? [path.join(process.resourcesPath, 'Nexus-release.apk')] : []),
        // 2. Dev: Electron CWD is public_shell/electron - APK one level up in android/
        path.join(process.cwd(), '../android/build/outputs/apk/release/Nexus-release.apk'),
        path.join(process.cwd(), '../android/build/outputs/apk/debug/Nexus-debug.apk'),
        // 3. Dev: engine loaded from private_engine/src directly
        path.join(__dirname, '../../public_shell/android/build/outputs/apk/release/Nexus-release.apk'),
        path.join(__dirname, '../../public_shell/android/build/outputs/apk/debug/Nexus-debug.apk'),
        // 4. Dev: engine synced into node_modules/@nexus/engine/src (4 levels up = public_shell)
        path.join(__dirname, '../../../../android/build/outputs/apk/release/Nexus-release.apk'),
        path.join(__dirname, '../../../../android/build/outputs/apk/debug/Nexus-debug.apk'),
        // 5. Fallback: APK manually placed next to the electron entry point
        path.join(process.cwd(), 'Nexus-release.apk'),
        path.join(process.cwd(), 'release/Nexus-release.apk'),
        path.join(process.cwd(), 'resources/Nexus-release.apk'),
    ];

    const existingCandidates = candidatePaths
        .filter(p => fs.existsSync(p))
        .map(p => ({ path: p, mtime: fs.statSync(p).mtimeMs }))
        .sort((a, b) => b.mtime - a.mtime); // newest build wins

    if (existingCandidates.length === 0) {
        console.error('[/pair/apk] APK not found. Searched:\n' + candidatePaths.map(p => '  ' + p).join('\n'));
        return res.status(404).send(
            'APK file not found on the local server.\n\n' +
            'For releases, ensure Nexus-release.apk is listed in extraResources in package.json.\n' +
            'For development, run ./gradlew assembleDebug in the android folder first.'
        );
    }

    const apkPath = existingCandidates[0].path;
    console.log(`[/pair/apk] Serving APK from: ${apkPath}`);

    const stat = fs.statSync(apkPath);
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="Nexus-release.apk"');
    res.setHeader('Content-Length', stat.size);
    fs.createReadStream(apkPath).pipe(res);
});

// Local Web Bridge: Mobile pairing page loaded by teacher's phone browser over Wi-Fi
app.get('/pair', (req, res) => {
    const config = app.locals.school_config || {};
    const schoolName = config.name || "Nexus School";
    const primaryColor = config.primary_color || config.themePrimary || "#00b4d8";
    const hostIp = address.ip();
    const port = req.socket.localPort || 3000;
    const logoBase64 = config.logoBase64 ? (config.logoBase64.includes(',') ? config.logoBase64 : `data:image/png;base64,${config.logoBase64}`) : null;
    const logoHtml = logoBase64 ? `<img src="${logoBase64}" alt="Logo">` : `<span style="font-size: 32px">🏫</span>`;

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Connect to ${schoolName} — Nexus Hub</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: #060914;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px 16px 40px;
    }
    .container { width: 100%; max-width: 440px; }
    .header { text-align: center; margin-bottom: 24px; }
    .logo {
      width: 68px; height: 68px; border-radius: 50%;
      background: rgba(255,255,255,0.06);
      display: inline-flex; align-items: center; justify-content: center;
      margin-bottom: 12px; border: 2px solid rgba(255,255,255,0.12);
      overflow: hidden;
    }
    .logo img { width: 100%; height: 100%; object-fit: cover; }
    .school-title { font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 4px; }
    .hub-badge {
      display: inline-flex; align-items: center; gap: 6px;
      background: rgba(0, 229, 160, 0.12); border: 1px solid rgba(0, 229, 160, 0.25);
      color: #00e5a0; font-size: 11px; font-weight: 700;
      padding: 4px 10px; border-radius: 20px;
    }
    .card {
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 16px;
    }
    .step-tag {
      font-size: 11px; font-weight: 800; text-transform: uppercase;
      letter-spacing: 0.8px; color: ${primaryColor}; margin-bottom: 6px;
    }
    .card-title { font-size: 16px; font-weight: 700; margin-bottom: 6px; color: #fff; }
    .card-desc { font-size: 13px; color: #8892b0; line-height: 1.45; margin-bottom: 16px; }
    .btn {
      display: flex; align-items: center; justify-content: center; gap: 8px;
      width: 100%; padding: 13px 18px; border-radius: 10px;
      font-size: 14px; font-weight: 700; text-decoration: none; cursor: pointer;
      border: none; transition: transform 0.1s, opacity 0.15s;
    }
    .btn:active { transform: scale(0.98); }
    .btn-download {
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.15);
      color: #fff;
    }
    .btn-pair {
      background: ${primaryColor};
      color: #050814;
      font-weight: 800;
    }
    .pin-input {
      width: 100%;
      background: rgba(0,0,0,0.3);
      border: 1.5px solid rgba(255,255,255,0.15);
      border-radius: 10px;
      padding: 12px 16px;
      color: #00e5ff;
      font-family: monospace;
      font-size: 24px;
      font-weight: 800;
      letter-spacing: 6px;
      text-align: center;
      margin-bottom: 14px;
      outline: none;
    }
    .pin-input:focus { border-color: ${primaryColor}; background: rgba(0,0,0,0.5); }
    .fallback-box {
      background: rgba(0,0,0,0.25);
      border: 1px dashed rgba(255,255,255,0.1);
      border-radius: 10px;
      padding: 12px 14px;
      font-size: 12px;
      color: #8892b0;
      line-height: 1.5;
      margin-top: 14px;
      display: none;
    }
    .fallback-box strong { color: #fff; }
    .footer { text-align: center; font-size: 11px; color: #4a5578; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">
        ${logoHtml}
      </div>
      <h1 class="school-title">${schoolName}</h1>
      <span class="hub-badge">● School Hub Local Wi-Fi</span>
    </div>

    <!-- Step 1: Install APK directly over Wi-Fi -->
    <div class="card">
      <div class="step-tag">Step 1 — Get the App</div>
      <h2 class="card-title">Download Nexus Mobile App</h2>
      <p class="card-desc">
        Fast local Wi-Fi download directly from the school PC. 
        <strong>Zero mobile cellular data used.</strong>
      </p>
      <a href="/pair/apk" class="btn btn-download">
        <span>📥</span> Download Nexus App (35 MB)
      </a>
    </div>

    <!-- Step 2: Instant PIN Pair -->
    <div class="card">
      <div class="step-tag">Step 2 — Connect Phone</div>
      <h2 class="card-title">Camera-Free Pairing</h2>
      <p class="card-desc">
        Look at the school PC screen and enter the 6-digit pairing PIN shown for your name.
      </p>
      
      <input 
        type="text" 
        id="pin" 
        class="pin-input" 
        placeholder="••• •••" 
        maxlength="7"
        inputmode="numeric" 
        autocomplete="off"
      />

      <button id="pair-btn" class="btn btn-pair">
        <span>🚀</span> Launch & Pair Nexus App
      </button>

      <div id="fallback" class="fallback-box">
        <a id="direct-open-link" href="#" class="btn btn-pair" style="margin-bottom: 12px; font-size: 13px; text-decoration: none;">
          <span>📱</span> Tap Here to Open Nexus App
        </a>
        If the app did not open automatically:<br>
        1. Open the <strong>Nexus School</strong> app on this phone.<br>
        2. Tap <strong>"Can't Scan? Connect with PIN"</strong>.<br>
        3. Enter Hub IP: <strong id="fb-ip">${hostIp}</strong> and PIN: <strong id="fb-pin"></strong>.
      </div>
    </div>

    <div class="footer">
      Nexus School OS — Sovereign Local Pairing Hub<br>
      IP: ${hostIp}:${port}
    </div>
  </div>

  <script>
    const hostIp = "${hostIp}";
    const hostPort = "${port}";
    const pinInput = document.getElementById("pin");
    const pairBtn = document.getElementById("pair-btn");
    const fallbackBox = document.getElementById("fallback");
    const directOpenLink = document.getElementById("direct-open-link");
    const fbPin = document.getElementById("fb-pin");

    pinInput.addEventListener("input", (e) => {
      let raw = e.target.value.replace(/\\D/g, "");
      if (raw.length > 6) raw = raw.slice(0, 6);
      if (raw.length > 3) {
        e.target.value = raw.slice(0, 3) + " " + raw.slice(3);
      } else {
        e.target.value = raw;
      }
    });

    pairBtn.addEventListener("click", () => {
      const cleanPin = pinInput.value.replace(/\\s+/g, "");
      if (cleanPin.length < 6) {
        alert("Please enter a valid 6-digit pairing PIN.");
        return;
      }

      fbPin.textContent = cleanPin;
      fallbackBox.style.display = "block";

      // 1. Android Chrome Intent URI (Official Android Chrome standard)
      const chromeIntent = "intent://pair?ip=" + encodeURIComponent(hostIp) + "&port=" + encodeURIComponent(hostPort) + "&pin=" + encodeURIComponent(cleanPin) + "#Intent;scheme=nexus;package=com.nexus.school;end";
      // 2. Custom URI scheme fallback
      const customScheme = "nexus://pair?ip=" + encodeURIComponent(hostIp) + "&port=" + encodeURIComponent(hostPort) + "&pin=" + encodeURIComponent(cleanPin);

      directOpenLink.href = chromeIntent;

      // Try Chrome Intent first; if blocked, fall back to custom scheme
      try {
        window.location.href = chromeIntent;
      } catch (err) {
        window.location.href = customScheme;
      }
    });
  </script>
</body>
</html>`;

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
});

app.post('/sync', (req, res, next) => {
    console.warn('[DEPRECATED] Bare route /sync used. Clients should update to use /api/sync.');
    next();
}, handleSync);
app.post('/api/sync', handleSync);

// Helper for rendering PDF using Electron offscreen browser window
async function renderHtmlToPdf(htmlContent) {
    const path = require('path');
    const fs = require('fs');
    const os = require('os');
    let BrowserWindow;
    try {
        BrowserWindow = require('electron').BrowserWindow;
    } catch (e) {
        throw new Error('Electron environment not available for PDF rendering');
    }

    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-mob-reports-'));
    const htmlPath = path.join(tempDir, 'report.html');
    fs.writeFileSync(htmlPath, htmlContent, 'utf8');

    return new Promise((resolve, reject) => {
        let win = new BrowserWindow({
            show: false,
            width: 794,
            height: 1123,
            webPreferences: {
                offscreen: true,
                webSecurity: false
            }
        });
        win.loadFile(htmlPath);
        win.webContents.on('did-finish-load', async () => {
            try {
                await new Promise(r => setTimeout(r, 250));
                const pdfBuffer = await win.webContents.printToPDF({
                    printBackground: true,
                    pageSize: 'A4',
                    landscape: false
                });
                win.close(); win = null;
                try { fs.rmSync(tempDir, { recursive: true }); } catch(_) {}
                resolve(pdfBuffer);
            } catch (err) {
                if (win) { win.close(); win = null; }
                reject(err);
            }
        });
    });
}

// ── Mobile API: Generate Class Reports PDF ───────────────────────────────────
app.post('/api/generate-report', requireDeviceAuth, async (req, res) => {
    const { class_name } = req.body;
    if (!class_name) {
        return res.status(400).json({ error: "Class name is required" });
    }

    try {
        const path = require('path');
        const fs = require('fs');
        const os = require('os');
        const db = database.getDb();
        const termConfig = db.prepare('SELECT * FROM school_term_config WHERE id = 1').get();
        if (!termConfig) {
            return res.status(400).json({ error: "Term configuration not found" });
        }
        const session = termConfig.academic_session;
        const term = termConfig.term;

        const students = db.prepare(`
            SELECT * FROM students 
            WHERE UPPER(replace(class_name || COALESCE(' ' || NULLIF(class_arm, ''), ''), ' ', '')) = ? 
            ORDER BY name ASC
        `).all(class_name.replace(/\s+/g, '').toUpperCase());

        if (students.length === 0) {
            return res.status(404).json({ error: `No students found in class: ${class_name}` });
        }

        const getRecords = db.prepare(
          "SELECT subject, score, breakdown FROM student_records WHERE student_id = ? AND academic_session = ? AND term = ?"
        );
        const getDomains = db.prepare(
          "SELECT domain_type, trait, grade FROM student_domains WHERE student_id = ? AND academic_session = ? AND term = ?"
        );
        const getRemark = db.prepare(
          "SELECT remark, principal_remark FROM teacher_remarks WHERE student_id = ? AND academic_session = ? AND term = ?"
        );
        const getExplicitSubjects = db.prepare("SELECT subject FROM student_subjects WHERE student_id = ?");
        const getTermAttendance = db.prepare(
          "SELECT total_days, days_attended FROM student_attendance WHERE student_id = ? AND academic_session = ? AND term = ?"
        );

        let excludeUnregisteredFromTotals = false;
        try {
          const termCfgForExclude = db.prepare("SELECT exclude_unregistered_from_totals FROM school_term_config WHERE id = 1").get() || {};
          excludeUnregisteredFromTotals = termCfgForExclude.exclude_unregistered_from_totals === 1;
        } catch (_) {}

        const _maxSubjectsMap = {};
        try {
          db.prepare("SELECT hierarchy_class, max_subjects FROM class_configs").all()
            .forEach(c => { _maxSubjectsMap[c.hierarchy_class] = c.max_subjects; });
        } catch (_) {}

        const _resolveMax = (cn) => {
          if (!cn) return null;
          const normCn = cn.replace(/\s+/g, '').toUpperCase();
          for (const key of Object.keys(_maxSubjectsMap)) {
            if (normCn === key.replace(/\s+/g, '').toUpperCase()) return _maxSubjectsMap[key];
          }
          const keys = Object.keys(_maxSubjectsMap).sort((a, b) => b.replace(/\s+/g, '').length - a.replace(/\s+/g, '').length);
          for (const key of keys) {
            const normKey = key.replace(/\s+/g, '').toUpperCase();
            if (normCn.startsWith(normKey)) {
              const v = _maxSubjectsMap[key];
              if (v != null && v > 0) return v;
            }
          }
          return null;
        };

        const formTeacherMap = new Map();
        db.prepare(`
          SELECT f.class_name, t.name, t.signature 
          FROM form_teachers f
          JOIN teachers t ON f.teacher_id = t.id
        `).all().forEach(ft => formTeacherMap.set(ft.class_name, ft));

        const classDaysMap = new Map();
        db.prepare(`
          SELECT class_name, count(DISTINCT date) as total_days 
          FROM daily_attendance 
          WHERE academic_session = ? AND term = ? 
          GROUP BY class_name
        `).all(session, term).forEach(r => classDaysMap.set(r.class_name, r.total_days));

        const getStudentAttendanceCount = db.prepare(`
          SELECT count(*) as days_attended 
          FROM daily_attendance 
          WHERE student_id = ? AND status IN ('Present', 'Late') AND academic_session = ? AND term = ?
        `);

        const identityRow = db.prepare("SELECT value FROM app_settings WHERE key = 'school_identity'").get();
        const identityPacket = identityRow ? JSON.parse(identityRow.value) : {};

        const results = students.map((stu) => {
          const records = getRecords.all(stu.id, session, term);
          const explicitSubjs = getExplicitSubjects.all(stu.id).map(r => r.subject);
          const resolvedSubjects = new Map();
          const explicitSubjsSet = new Set(explicitSubjs);

          explicitSubjs.forEach(sName => {
            resolvedSubjects.set(sName, { name: sName, score: null, breakdown: {}, isRegistered: true });
          });

          records.forEach(r => {
            resolvedSubjects.set(r.subject, {
              name: r.subject,
              score: r.score,
              breakdown: (() => { try { const p = JSON.parse(r.breakdown); return (p && typeof p === 'object') ? p : {}; } catch { return {}; } })(),
              isRegistered: explicitSubjsSet.has(r.subject),
            });
          });

          let allSubjectsArray = Array.from(resolvedSubjects.values());
          const gradedSubjects = allSubjectsArray.filter(s =>
            s.score !== null && (!excludeUnregisteredFromTotals || s.isRegistered)
          );
          const totalScore = gradedSubjects.reduce((sum, s) => sum + s.score, 0);
          const _maxSubs = _resolveMax(stu.class_name);
          const _denom = (_maxSubs && _maxSubs > 0) ? _maxSubs : gradedSubjects.length;
          const avg = gradedSubjects.length ? (totalScore / _denom).toFixed(2) : "—";

          const domains = getDomains.all(stu.id, session, term);
          const remark = getRemark.get(stu.id, session, term) || {};
          const fullClassName = (stu.class_arm && !stu.class_name.includes(stu.class_arm))
            ? `${stu.class_name} ${stu.class_arm}`
            : stu.class_name;

          const ft = formTeacherMap.get(fullClassName) || {};
          const termAtt = getTermAttendance.get(stu.id, session, term);
          let classTotalDays = 0;
          let daysAttended = 0;
          if (termAtt) {
            classTotalDays = termAtt.total_days;
            daysAttended = termAtt.days_attended;
          } else {
            classTotalDays = classDaysMap.get(fullClassName) || 0;
            const attRow = getStudentAttendanceCount.get(stu.id, session, term) || { days_attended: 0 };
            daysAttended = attRow.days_attended;
          }

          return {
            ...stu,
            class_name: fullClassName,
            subjects: allSubjectsArray,
            total_score: totalScore,
            average: avg,
            domains,
            attendance: {
              total_days: classTotalDays,
              days_attended: daysAttended
            },
            remark: remark.remark || "",
            principal_remark: remark.principal_remark || "",
            form_teacher_name: ft.name || "",
            form_teacher_signature: ft.signature || null,
            principal_signature: identityPacket.signature || null,
          };
        });

        const baseDir = path.join(path.dirname(require.resolve('./report-compiler.js')), '..');
        const payload = {
            identity: identityPacket,
            students: results,
            termConfig,
            reportType: "terminal",
            format: "pdf"
        };

        const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-mob-reports-'));
        const html = reports.generateHTMLPages(payload, baseDir, tempDir);
        const pdfBuffer = await renderHtmlToPdf(html);
        try { fs.rmSync(tempDir, { recursive: true }); } catch(_) {}
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=TerminalReport_${class_name.replace(/\s+/g, '_')}.pdf`);
        res.send(pdfBuffer);
    } catch (err) {
        console.error('[Generate Report API] Error:', err);
        res.status(500).json({ error: "Failed to generate class reports: " + err.message });
    }
});

// ── Mobile API: Financial Summary (Bursar) ───────────────────────────────────
app.get('/api/fees/summary', requireDeviceAuth, (req, res) => {
    try {
        const db = database.getDb();
        const termConfig = db.prepare('SELECT * FROM school_term_config WHERE id = 1').get();
        if (!termConfig) {
            return res.status(400).json({ error: "Term configuration not found" });
        }
        const session = termConfig.academic_session;
        const term = termConfig.term;

        const summary = db.prepare(`
            SELECT 
                COALESCE(SUM(total_billed), 0) as total_billed,
                COALESCE(SUM(total_paid), 0) as total_paid,
                COALESCE(SUM(total_billed - total_paid), 0) as total_outstanding
            FROM student_fees
            WHERE academic_session = ? AND term = ?
        `).get(session, term);

        const statusCounts = db.prepare(`
            SELECT status, count(*) as count
            FROM student_fees
            WHERE academic_session = ? AND term = ?
            GROUP BY status
        `).all(session, term);

        const statuses = { cleared: 0, partial: 0, unpaid: 0 };
        statusCounts.forEach(row => {
            if (row.status in statuses) {
                statuses[row.status] = row.count;
            }
        });

        res.json({
            academic_session: session,
            term: term,
            total_billed: summary.total_billed,
            total_paid: summary.total_paid,
            total_outstanding: summary.total_outstanding,
            status_counts: statuses
        });
    } catch (err) {
        console.error('[Fees Summary API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile API: Paired Devices (IT Admin) ────────────────────────────────────
app.get('/api/devices', requireDeviceAuth, (req, res) => {
    try {
        const db = database.getDb();
        const devices = db.prepare("SELECT * FROM connected_devices ORDER BY paired_at DESC").all();
        res.json({ devices });
    } catch (err) {
        console.error('[Devices API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile API: Stats Summary Dashboard (Principal) ──────────────────────────
app.get('/api/dashboard-summary', requireDeviceAuth, (req, res) => {
    try {
        const db = database.getDb();
        const studentsCount = db.prepare("SELECT count(*) as c FROM students").get().c;
        const teachersCount = db.prepare("SELECT count(*) as c FROM teachers").get().c;
        
        let classesCount = 0;
        try {
            classesCount = db.prepare("SELECT count(*) as c FROM class_configs").get().c;
        } catch (_) {
            classesCount = db.prepare("SELECT count(DISTINCT class_name) as c FROM students").get().c;
        }

        let lastSyncTime = 'Never';
        try {
            const row = db.prepare("SELECT received_at FROM activity_log WHERE event_type = 'SYNC_RECEIVED' ORDER BY received_at DESC LIMIT 1").get();
            if (row) lastSyncTime = row.received_at;
        } catch (_) {}

        res.json({
            students_count: studentsCount,
            teachers_count: teachersCount,
            classes_count: classesCount,
            last_sync_time: lastSyncTime
        });
    } catch (err) {
        console.error('[Dashboard Summary API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile API: Revoke Device (IT Admin) ─────────────────────────────────────
app.post('/api/revoke-device', requireDeviceAuth, (req, res) => {
    const { device_id } = req.body;
    if (!device_id) {
        return res.status(400).json({ error: "Device ID is required" });
    }
    try {
        const db = database.getDb();
        db.prepare("DELETE FROM connected_devices WHERE device_id = ?").run(device_id);
        db.prepare("INSERT OR IGNORE INTO revoked_devices (device_id) VALUES (?)").run(device_id);
        
        logActivity({
            device_id: 'DESKTOP',
            actor_label: 'IT Admin',
            event_type: 'DEVICE_REVOKED',
            payload: { device_id }
        });
        
        res.json({ ok: true });
    } catch (err) {
        console.error('[Revoke Device API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile Directory Hub: Search APIs ────────────────────────────────────────

// Search parents by name, phone, email, or child name
app.get('/api/search/parents', requireDeviceAuth, (req, res) => {
    const q = (req.query.q || '').trim().toLowerCase();
    if (!q) return res.json([]);
    try {
        const db = database.getDb();
        const pattern = `%${q}%`;
        const digits = q.replace(/\D/g, '');
        const phonePattern = digits.length >= 7 ? `%${digits.slice(-10)}%` : pattern;

        // Join students ↔ parent fields, return unique parents with their children
        const rows = db.prepare(`
            SELECT DISTINCT
                s.parent_name   AS parentName,
                COALESCE(s.parent_phone, '')  AS parentPhone,
                COALESCE(s.parent_phone_2, '') AS parentPhone2,
                COALESCE(s.parent_email, '')  AS parentEmail,
                json_group_array(json_object(
                    'id',         s.id,
                    'name',       s.name,
                    'class_name', s.class_name,
                    'class_arm',  COALESCE(s.class_arm,''),
                    'photo',      COALESCE(s.photo,''),
                    'admission_no', COALESCE(s.admission_no,'')
                )) AS children
            FROM students s
            WHERE (
                lower(COALESCE(s.parent_name,''))  LIKE ?  OR
                COALESCE(s.parent_phone,'')        LIKE ?  OR
                COALESCE(s.parent_phone,'')        LIKE ?  OR
                COALESCE(s.parent_phone_2,'')      LIKE ?  OR
                COALESCE(s.parent_phone_2,'')      LIKE ?  OR
                COALESCE(s.parent_email,'')        LIKE ?  OR
                lower(s.name)                      LIKE ?
            )
            AND s.is_active = 1
            GROUP BY COALESCE(NULLIF(s.parent_phone, ''), s.parent_phone_2, s.parent_name, s.id)
            LIMIT 30
        `).all(pattern, pattern, phonePattern, pattern, phonePattern, pattern, pattern);

        const result = rows.map(r => ({
            ...r,
            children: JSON.parse(r.children || '[]')
        }));
        res.json(result);
    } catch (err) {
        console.error('[Search Parents]', err);
        res.status(500).json({ error: err.message });
    }
});

// Search staff by name, phone, or email
app.get('/api/search/staff', requireDeviceAuth, (req, res) => {
    const q = (req.query.q || '').trim().toLowerCase();
    if (!q) return res.json([]);
    try {
        const db = database.getDb();
        const pattern = `%${q}%`;
        const digits = q.replace(/\D/g, '');
        const phonePattern = digits.length >= 7 ? `%${digits.slice(-10)}%` : pattern;

        const rows = db.prepare(`
            SELECT t.id, t.name,
                   COALESCE(t.phone, '') AS phone,
                   COALESCE(t.email, '') AS email,
                   COALESCE(sr.role, 'Teacher') AS role,
                   (
                       SELECT json_group_array(json_object('class_name', ta.class_name, 'subject', ta.subject))
                       FROM teacher_allocations ta WHERE ta.teacher_id = t.id
                   ) AS allocations
            FROM teachers t
            LEFT JOIN staff_roles sr ON sr.id = t.id
            WHERE (
                lower(COALESCE(t.name,'')) LIKE ?
                OR COALESCE(t.phone,'') LIKE ?
                OR COALESCE(t.phone,'') LIKE ?
                OR lower(COALESCE(t.email,'')) LIKE ?
            )
            AND t.is_active = 1
            LIMIT 30
        `).all(pattern, pattern, phonePattern, pattern);

        const result = rows.map(r => ({
            ...r,
            allocations: JSON.parse(r.allocations || '[]')
        }));
        res.json(result);
    } catch (err) {
        console.error('[Search Staff]', err);
        res.status(500).json({ error: err.message });
    }
});

// Search students by name, admission_no, class or parent name
app.get('/api/search/students', requireDeviceAuth, (req, res) => {
    const q = (req.query.q || '').trim().toLowerCase();
    if (!q) return res.json([]);
    try {
        const db = database.getDb();
        const pattern = `%${q}%`;
        const digits = q.replace(/\D/g, '');
        const phonePattern = digits.length >= 7 ? `%${digits.slice(-10)}%` : pattern;

        const rows = db.prepare(`
            SELECT s.id, s.name, s.class_name, s.class_arm, s.admission_no,
                   s.reg_no, s.gender, s.dob, s.photo, s.parent_name,
                   COALESCE(s.parent_phone, '') AS parent_phone,
                   COALESCE(s.parent_phone_2, '') AS parent_phone_2,
                   COALESCE(s.parent_email, '') AS parent_email,
                   COALESCE(sf.status, s.fee_status, 'unpaid') AS fee_status,
                   COALESCE(sf.total_billed, 0) AS total_billed,
                   COALESCE(sf.total_paid, 0) AS total_paid,
                   (COALESCE(sf.total_billed, 0) - COALESCE(sf.total_paid, 0)) AS balance,
                   (
                       SELECT json_group_array(ss.subject)
                       FROM student_subjects ss WHERE ss.student_id = s.id
                   ) AS subjects
            FROM students s
            LEFT JOIN student_fees sf ON sf.student_id = s.id
            WHERE (
                lower(s.name) LIKE ?  OR
                lower(COALESCE(s.admission_no,'')) LIKE ? OR
                lower(COALESCE(s.class_name,'')) LIKE ? OR
                lower(COALESCE(s.parent_name,'')) LIKE ? OR
                COALESCE(s.parent_phone,'') LIKE ? OR
                COALESCE(s.parent_phone,'') LIKE ? OR
                COALESCE(s.parent_phone_2,'') LIKE ? OR
                COALESCE(s.parent_phone_2,'') LIKE ?
            )
            AND s.is_active = 1
            LIMIT 30
        `).all(pattern, pattern, pattern, pattern, pattern, phonePattern, pattern, phonePattern);

        const result = rows.map(r => ({
            ...r,
            subjects: JSON.parse(r.subjects || '[]')
        }));
        res.json(result);
    } catch (err) {
        console.error('[Search Students]', err);
        res.status(500).json({ error: err.message });
    }
});

// Update staff profile (email and/or phone) — called after OTP verification on device
app.patch('/api/staff/profile', requireDeviceAuth, (req, res) => {
    const { teacher_id, email, phone } = req.body;
    if (!teacher_id) return res.status(400).json({ error: 'teacher_id required' });
    try {
        const db = database.getDb();
        // Update in teachers table
        if (email !== undefined) {
            db.prepare('UPDATE teachers SET email = ? WHERE id = ?').run(email, teacher_id);
        }
        if (phone !== undefined) {
            db.prepare('UPDATE teachers SET phone = ? WHERE id = ?').run(phone, teacher_id);
        }
        logActivity({
            device_id: req.headers['x-device-id'] || 'mobile',
            actor_label: 'Staff',
            event_type: 'STAFF_PROFILE_UPDATED',
            payload: { teacher_id, email: email ? '***' : undefined, phone: phone ? '***' : undefined }
        });
        res.json({ ok: true });
    } catch (err) {
        console.error('[Staff Profile Update]', err);
        res.status(500).json({ error: err.message });
    }
});

// Update student bio fields
app.patch('/api/update/student-bio', requireDeviceAuth, (req, res) => {
    const { student_id, name, gender, dob, photo, parent_name, parent_phone, parent_email, class_name, class_arm } = req.body;
    if (!student_id) return res.status(400).json({ error: 'student_id required' });
    try {
        const db = database.getDb();
        const fields = [];
        const vals = [];
        if (name        !== undefined) { fields.push('name = ?');         vals.push(name); }
        if (gender      !== undefined) { fields.push('gender = ?');       vals.push(gender); }
        if (dob         !== undefined) { fields.push('dob = ?');          vals.push(dob); }
        if (photo       !== undefined) { fields.push('photo = ?');        vals.push(photo); }
        if (parent_name !== undefined) { fields.push('parent_name = ?');  vals.push(parent_name); }
        if (parent_phone!== undefined) { fields.push('parent_phone = ?'); vals.push(parent_phone); }
        if (parent_email!== undefined) { fields.push('parent_email = ?'); vals.push(parent_email); }
        if (class_name  !== undefined) { fields.push('class_name = ?');   vals.push(class_name); }
        if (class_arm   !== undefined) { fields.push('class_arm = ?');    vals.push(class_arm); }
        if (fields.length === 0) return res.status(400).json({ error: 'No fields to update' });
        vals.push(student_id);
        db.prepare(`UPDATE students SET ${fields.join(', ')} WHERE id = ?`).run(...vals);
        logActivity({
            device_id: req.headers['x-device-id'] || 'mobile',
            actor_label: 'Owner',
            event_type: 'STUDENT_BIO_UPDATED',
            payload: { student_id, fields: fields.map(f => f.split(' ')[0]) }
        });
        res.json({ ok: true });
    } catch (err) {
        console.error('[Student Bio Update]', err);
        res.status(500).json({ error: err.message });
    }
});

// Replace student subjects list
app.patch('/api/update/student-subjects', requireDeviceAuth, (req, res) => {
    const { student_id, subjects } = req.body;
    if (!student_id || !Array.isArray(subjects)) return res.status(400).json({ error: 'student_id and subjects[] required' });
    try {
        const db = database.getDb();
        const replace = db.transaction(() => {
            db.prepare('DELETE FROM student_subjects WHERE student_id = ?').run(student_id);
            const ins = db.prepare('INSERT OR IGNORE INTO student_subjects (student_id, subject) VALUES (?, ?)');
            for (const s of subjects) {
                if (s && s.trim()) ins.run(student_id, s.trim());
            }
        });
        replace();
        res.json({ ok: true });
    } catch (err) {
        console.error('[Student Subjects Update]', err);
        res.status(500).json({ error: err.message });
    }
});

// Update student fee record (manual override / adjustment)
app.patch('/api/update/student-fees', requireDeviceAuth, (req, res) => {
    const { student_id, total_billed, total_paid } = req.body;
    if (!student_id) return res.status(400).json({ error: 'student_id required' });
    try {
        const db = database.getDb();
        const fields = [];
        const vals = [];
        if (total_billed !== undefined) { fields.push('total_billed = ?'); vals.push(Number(total_billed)); }
        if (total_paid   !== undefined) { fields.push('total_paid = ?');   vals.push(Number(total_paid)); }
        if (fields.length === 0) return res.status(400).json({ error: 'No fee fields to update' });
        // Derive balance and status
        const existing = db.prepare('SELECT total_billed, total_paid FROM student_fees WHERE student_id = ?').get(student_id);
        const newBilled = total_billed !== undefined ? Number(total_billed) : (existing?.total_billed || 0);
        const newPaid   = total_paid   !== undefined ? Number(total_paid)   : (existing?.total_paid   || 0);
        const balance   = Math.max(0, newBilled - newPaid);
        const status    = balance === 0 ? 'cleared' : newPaid === 0 ? 'unpaid' : 'partial';
        db.prepare(`
            INSERT INTO student_fees (student_id, total_billed, total_paid, balance, status, updated_at)
            VALUES (?, ?, ?, ?, ?, datetime('now'))
            ON CONFLICT(student_id) DO UPDATE SET
                total_billed = excluded.total_billed,
                total_paid   = excluded.total_paid,
                balance      = excluded.balance,
                status       = excluded.status,
                updated_at   = excluded.updated_at
        `).run(student_id, newBilled, newPaid, balance, status);
        db.prepare(`UPDATE students SET fee_status = ? WHERE id = ?`).run(status, student_id);
        res.json({ ok: true, balance, status });
    } catch (err) {
        console.error('[Student Fees Update]', err);
        res.status(500).json({ error: err.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────

function startServer(port = 3000) {
    app.listen(port, () => {
        const ip = address.ip();
        console.log(`[Nexus Server] Listening at http://${ip}:${port}`);
    });
    return eventEmitter;
}

function setSchoolConfig(config) {
    app.locals.school_config = config;
}

function setSchoolLicense(license) {
    app.locals.license_limit = license;
}

function setActivationStatus(status) {
    app.locals.activation_status = status;
}

function revokeDevice(deviceId) {
    const db = database.getDb();
    db.prepare("INSERT OR IGNORE INTO revoked_devices (device_id) VALUES (?)").run(deviceId);
}

function clearData() {
    const db = database.getDb();

    // PRAGMA must run OUTSIDE a transaction — SQLite silently ignores
    // pragma statements issued inside a transaction (they become no-ops).
    db.pragma('foreign_keys = OFF');

    try {
        db.transaction(() => {
            const tables = db.prepare(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).all();
            for (const table of tables) {
                // Quote names to handle any reserved-word table names safely
                db.prepare(`DELETE FROM "${table.name}"`).run();
            }
            try {
                db.prepare("DELETE FROM sqlite_sequence").run();
            } catch (seqErr) {
                // Ignore if sqlite_sequence does not exist
            }

            // Re-seed minimal defaults
            db.exec(`
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('class_hierarchy', '["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"]');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('pass_mark_threshold', '50');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('current_academic_session', '2025/2026');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_daily_attendance', 'true');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_subject_attendance', 'false');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('truancy_escalation_flow', '[{"step":1,"trigger_after":1,"notify":"form_teacher","channel":"in-app"},{"step":2,"trigger_after":3,"notify":"principal","channel":"in-app"},{"step":3,"trigger_after":5,"notify":"parent","channel":"whatsapp"}]');
                INSERT OR REPLACE INTO system_settings (key, value) VALUES ('roster_seeded', 'true');
            `);

            // Re-seed default class configs
            const defaultClasses = ["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"];
            const insertConfig = db.prepare("INSERT OR IGNORE INTO class_configs (hierarchy_class) VALUES (?)");
            defaultClasses.forEach(cls => insertConfig.run(cls));

            // NOTE: We intentionally do NOT re-seed a default admin here.
            // Zero rows in admin_users is the correct post-reset state.
            // BootGate detects the empty table and routes to <SetupWizard />
            // exactly as it does on a fresh first install.
            // See: private_engine/docs/guides/23-database-backup-restore.md § 5.4 Gap 1

            db.prepare(`
                INSERT INTO audit_logs (admin_id, action, target, details)
                VALUES (NULL, 'SYSTEM_RESET', 'database', 'Database was reset to factory defaults')
            `).run();
        })();

        console.log('[Reset] All tables cleared and defaults re-seeded successfully.');
    logActivity({ event_type: 'APP_RESET', payload: { cleared_by: 'Admin' } });
    } finally {
        // Always re-enable FK enforcement — even if the transaction threw
        db.pragma('foreign_keys = ON');
    }
}


function handleGradesCSVUpload(filePath, callback, dry_run = false) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Grades Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const activeTermCfg = db.prepare('SELECT academic_session, term, grading_scale FROM school_term_config WHERE id = 1').get();
            if (!activeTermCfg || !activeTermCfg.academic_session || !activeTermCfg.term) {
                if (callback) callback(0, 'SETUP_INCOMPLETE', { setupCheck: { step: 'term', message: 'Academic session and term must be configured before importing grades.' } });
                return;
            }
            const activeSession = activeTermCfg.academic_session;
            const activeTerm = activeTermCfg.term;

            let activeComponents = [];
            if (activeTermCfg?.grading_scale) {
                try {
                    const parsed = JSON.parse(activeTermCfg.grading_scale);
                    activeComponents = Array.isArray(parsed) ? parsed : (parsed.components || []);
                } catch (_) {}
            }

            const validStudentIds = new Set(db.prepare("SELECT id FROM students").all().map(s => s.id.trim()));

            const blockingErrors = [];
            const warnings = [];
            let rIdx = 1;
            let hasSessionMismatch = false;

            for (const row of rows) {
                rIdx++;
                const cleanRow = {};
                for (const key of Object.keys(row)) {
                    const normKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
                    cleanRow[normKey] = row[key];
                }

                const studentId = (cleanRow['studentid'] || cleanRow['id'] || '').toString().trim();
                const csvSession = (cleanRow['session'] || '').toString().trim();
                const csvTerm = (cleanRow['term'] || '').toString().trim();

                if (studentId && !validStudentIds.has(studentId)) {
                    blockingErrors.push({
                        rowIndex: rIdx,
                        field: 'Student_ID',
                        reason: `Student ID "${studentId}" does not exist in Student Directory.`
                    });
                }

                if ((csvSession && csvSession !== activeSession) || (csvTerm && normalizeTermName(csvTerm) !== activeTerm)) {
                    hasSessionMismatch = true;
                }
            }

            if (hasSessionMismatch) {
                warnings.push({
                    rowIndex: 0,
                    field: 'Session/Term',
                    from: 'CSV Session/Term',
                    to: `${activeSession} ${activeTerm}`
                });
            }

            if (dry_run) {
                const cleanCount = Math.max(0, rows.length - blockingErrors.length);
                if (callback) callback(cleanCount, null, {
                    dry_run: true,
                    cleanCount,
                    blocking: blockingErrors,
                    normalizable: warnings,
                    activeSession,
                    activeTerm
                });
                return;
            }

            if (blockingErrors.length > 0) {
                if (callback) callback(0, 'VAL_ERR: Validation failed. Unknown student IDs found.', {
                    dry_run: false,
                    cleanCount: 0,
                    blocking: blockingErrors,
                    normalizable: warnings
                });
                return;
            }

            const upsertRecord = db.prepare(`
                INSERT INTO student_records (student_id, subject, assessment, score, breakdown, teacher_id, academic_session, term)
                VALUES (@student_id, @subject, @assessment, @score, @breakdown, 'STANDALONE_ADMIN', @session, @term)
                ON CONFLICT(student_id, subject, assessment, academic_session, term) 
                DO UPDATE SET score = excluded.score, breakdown = excluded.breakdown
            `);

            const runImport = db.transaction((rows) => {
                let count = 0;
                for (const row of rows) {
                    const cleanRow = {};
                    for (const key of Object.keys(row)) {
                        const normKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
                        cleanRow[normKey] = row[key];
                    }

                    const studentId = (cleanRow['studentid'] || cleanRow['id'] || '').toString().trim();
                    const subject   = (cleanRow['subject']   || '').toString().trim();
                    let assessment = (cleanRow['assessment'] || '').toString().trim();
                    if (!assessment) {
                        assessment = 'FULL';
                    }

                    if (!studentId || !subject || !assessment || !validStudentIds.has(studentId)) continue;

                    // Build breakdown from any present *score columns (excluding exactly 'score')
                    const breakdown = {};
                    let totalFromBreakdown = 0;
                    let hasBreakdown = false;
                    for (const key of Object.keys(cleanRow)) {
                        if (key.endsWith('score') && key !== 'score') {
                            const valStr = (cleanRow[key] || '').toString().trim();
                            if (valStr !== '') {
                                const parsedVal = parseFloat(valStr);
                                if (!isNaN(parsedVal)) {
                                    const val = Math.round(parsedVal * 100) / 100;
                                    let originalLabel = key;
                                    for (const origKey of Object.keys(row)) {
                                        if (origKey.trim().toLowerCase().replace(/[^a-z0-9]/g, '') === key) {
                                            originalLabel = origKey.trim();
                                            if (originalLabel.toLowerCase().endsWith('_score')) {
                                                originalLabel = originalLabel.substring(0, originalLabel.length - 6);
                                            } else if (originalLabel.toLowerCase().endsWith(' score')) {
                                                originalLabel = originalLabel.substring(0, originalLabel.length - 6);
                                            }
                                            break;
                                        }
                                    }
                                    
                                    const normLabel = originalLabel.toLowerCase().replace(/[^a-z0-9]/g, '');
                                    const matchedComp = activeComponents.find(c => 
                                        c.key.toLowerCase().replace(/[^a-z0-9]/g, '') === normLabel ||
                                        c.label.toLowerCase().replace(/[^a-z0-9]/g, '') === normLabel
                                    );
                                    const finalKey = matchedComp ? matchedComp.key : originalLabel;
                                    breakdown[finalKey] = val;
                                    totalFromBreakdown += val;
                                    hasBreakdown = true;
                                }
                            }
                        }
                    }

                    let score;
                    if (hasBreakdown) {
                        score = Math.round(totalFromBreakdown * 100) / 100;
                    } else {
                        const scoreVal = (cleanRow['score'] || '').toString().trim();
                        if (scoreVal === '') continue;
                        score = Math.round(parseFloat(scoreVal) * 100) / 100;
                        if (isNaN(score)) continue;
                    }

                    const breakdownStr = hasBreakdown ? JSON.stringify(breakdown) : null;
                    const rowSession = (cleanRow['session'] || '').toString().trim() || activeSession;
                    const rowTermRaw = (cleanRow['term'] || '').toString().trim();
                    const rowTerm = rowTermRaw ? normalizeTermName(rowTermRaw) : activeTerm;

                    upsertRecord.run({
                        student_id: studentId,
                        subject,
                        assessment,
                        score,
                        breakdown: breakdownStr,
                        session: activeSession,
                        term: activeTerm
                    });
                    try {
                        db.prepare("INSERT OR IGNORE INTO student_subjects (student_id, subject) VALUES (?, ?)").run(studentId, subject);
                    } catch (_) {}
                    count++;
                }
                return count;
            });

            try {
                const count = runImport(rows);
                logActivity({
                    event_type: 'GRADES_CSV_IMPORTED',
                    payload: { rows_inserted: count }
                });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}


// Parses a CSV with Student_ID, Total_Days, Days_Attended and inserts into student_attendance.
// Session and Term are always stamped from the active school_term_config — CSV values are ignored.
function handleAttendanceCSVUpload(filePath, callback, dry_run = false) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Attendance Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const activeTermCfg = db.prepare('SELECT academic_session, term FROM school_term_config WHERE id = 1').get();
            if (!activeTermCfg || !activeTermCfg.academic_session || !activeTermCfg.term) {
                if (callback) callback(0, 'SETUP_INCOMPLETE', { setupCheck: { step: 'term', message: 'Academic session and term must be configured before importing attendance.' } });
                return;
            }
            const activeSession = activeTermCfg.academic_session;
            const activeTerm = activeTermCfg.term;

            const validStudentIds = new Set(db.prepare('SELECT id FROM students').all().map(s => s.id.trim()));

            const blockingErrors = [];
            const warnings = [];
            let rIdx = 1;
            let hasSessionMismatch = false;

            for (const row of rows) {
                rIdx++;
                const cleanRow = {};
                for (const key of Object.keys(row)) {
                    cleanRow[key.trim().toLowerCase().replace(/[^a-z0-9]/g, '')] = row[key];
                }
                const studentId = (cleanRow['studentid'] || cleanRow['id'] || '').toString().trim();
                const csvSession = (cleanRow['session'] || '').toString().trim();
                const csvTerm = (cleanRow['term'] || '').toString().trim();

                if (studentId && !validStudentIds.has(studentId)) {
                    blockingErrors.push({ rowIndex: rIdx, field: 'Student_ID', reason: `Student ID "${studentId}" does not exist in Student Directory.` });
                }
                if ((csvSession && csvSession !== activeSession) || (csvTerm && normalizeTermName(csvTerm) !== activeTerm)) {
                    hasSessionMismatch = true;
                }
            }

            if (hasSessionMismatch) {
                warnings.push({ rowIndex: 0, field: 'Session/Term', from: 'CSV Session/Term', to: `${activeSession} / ${activeTerm}` });
            }

            if (dry_run) {
                if (callback) callback(Math.max(0, rows.length - blockingErrors.length), null, {
                    dry_run: true, cleanCount: Math.max(0, rows.length - blockingErrors.length),
                    blocking: blockingErrors, normalizable: warnings, activeSession, activeTerm
                });
                return;
            }

            if (blockingErrors.length > 0) {
                if (callback) callback(0, 'VAL_ERR: Validation failed. Unknown student IDs found.', {
                    dry_run: false, cleanCount: 0, blocking: blockingErrors, normalizable: warnings
                });
                return;
            }

            const upsertAtt = db.prepare(`
                INSERT INTO student_attendance (student_id, academic_session, term, total_days, days_attended)
                VALUES (@student_id, @session, @term, @total_days, @days_attended)
                ON CONFLICT(student_id, academic_session, term)
                DO UPDATE SET total_days = excluded.total_days, days_attended = excluded.days_attended
            `);

            const runImport = db.transaction((rows) => {
                let count = 0;
                for (const row of rows) {
                    const cleanRow = {};
                    for (const key of Object.keys(row)) {
                        cleanRow[key.trim().toLowerCase().replace(/[^a-z0-9]/g, '')] = row[key];
                    }
                    const studentId = (cleanRow['studentid'] || cleanRow['id'] || '').toString().trim();
                    const totVal    = (cleanRow['totaldays']    || '').toString().trim();
                    const attVal    = (cleanRow['daysattended'] || '').toString().trim();

                    if (!studentId || totVal === '' || attVal === '' || !validStudentIds.has(studentId)) continue;
                    const total_days    = parseInt(totVal, 10);
                    const days_attended = parseInt(attVal, 10);
                    if (isNaN(total_days) || isNaN(days_attended)) continue;

                    upsertAtt.run({ student_id: studentId, session: activeSession, term: activeTerm, total_days, days_attended });
                    count++;
                }
                return count;
            });

            try {
                const count = runImport(rows);
                logActivity({ event_type: 'ATTENDANCE_CSV_IMPORTED', payload: { rows_inserted: count } });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// Parses a CSV with Class_Name, Max_Subjects, Pass_Mark_Override, Arms and updates configs/hierarchy/arms.
function handleClassesCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Classes Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            if (rows.length === 0) {
                if (callback) callback(0, 'INVALID_TEMPLATE: The uploaded CSV file is empty.');
                return;
            }

            // Extract and normalize headers
            const headers = Object.keys(rows[0] || {}).map(h => h.trim().toLowerCase());
            const hasClass = headers.includes('class_name') || headers.includes('class');
            const hasArmsOrMax = headers.includes('arms') || headers.includes('max_subjects');

            if (!hasClass || !hasArmsOrMax) {
                if (callback) callback(0, 'INVALID_TEMPLATE: CSV headers do not match Classes template. Expected columns: Class_Name, Arms, Max_Subjects, Pass_Mark_Override.');
                return;
            }

            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const upsertConfig = db.prepare(`
                INSERT INTO class_configs (hierarchy_class, max_subjects, pass_mark_override)
                VALUES (@class_name, @max_subjects, @pass_mark_override)
                ON CONFLICT(hierarchy_class) DO UPDATE SET
                    max_subjects = excluded.max_subjects,
                    pass_mark_override = COALESCE(excluded.pass_mark_override, class_configs.pass_mark_override)
            `);

            const insertArm = db.prepare(`
                INSERT OR IGNORE INTO class_arms (hierarchy_class, arm)
                VALUES (?, ?)
            `);

            const getHierarchy = db.prepare("SELECT value FROM system_settings WHERE key = 'class_hierarchy'");
            const updateHierarchy = db.prepare("INSERT OR REPLACE INTO system_settings (key, value) VALUES ('class_hierarchy', ?)");

            const runImport = db.transaction((rows) => {
                // Reset/overwrite instead of merge: delete existing configurations and arms first.
                // If the transaction fails, these deletions are rolled back automatically.
                db.prepare("DELETE FROM class_arms").run();
                db.prepare("DELETE FROM class_configs").run();
                db.prepare("DELETE FROM system_settings WHERE key = 'class_hierarchy'").run();

                let count = 0;
                let hierarchy = [];
                let hierarchyChanged = false;

                for (const row of rows) {
                    const className = (row['Class_Name'] || row['Class'] || '').trim();
                    const maxSubsVal = (row['Max_Subjects'] || '').trim();
                    const passMarkVal = (row['Pass_Mark_Override'] || '').trim();
                    const armsRaw = (row['Arms'] || '').trim();

                    if (!className) continue;

                    const max_subjects = maxSubsVal !== '' ? parseInt(maxSubsVal, 10) : 0;
                    const pass_mark_override = passMarkVal !== '' ? parseInt(passMarkVal, 10) : null;

                    upsertConfig.run({
                        class_name: className,
                        max_subjects: isNaN(max_subjects) ? 0 : max_subjects,
                        pass_mark_override: isNaN(pass_mark_override) ? null : pass_mark_override
                    });

                    // Add to hierarchy list if not present
                    if (!hierarchy.includes(className)) {
                        hierarchy.push(className);
                        hierarchyChanged = true;
                    }

                    // Process arms
                    if (armsRaw) {
                        const arms = armsRaw.split('|').map(a => a.trim()).filter(Boolean);
                        for (let arm of arms) {
                            // Normalise: if the admin entered the full class name as part
                            // of the arm (e.g. "JSS 1 Emerald" when className="JSS 1"),
                            // strip the prefix so only "Emerald" is stored.  This prevents
                            // getFullList from producing doubled names like "JSS 1 JSS 1 Emerald".
                            if (arm.toLowerCase().startsWith(className.toLowerCase() + ' ')) {
                                arm = arm.slice(className.length + 1).trim();
                            }
                            if (arm) insertArm.run(className, arm);
                        }
                    }


                    count++;
                }

                if (hierarchyChanged) {
                    updateHierarchy.run(JSON.stringify(hierarchy));
                }
                db.prepare("INSERT OR REPLACE INTO system_settings (key, value) VALUES ('classes_initialized', 'true')").run();

                return count;
            });

            try {
                const count = runImport(rows);
                logActivity({
                    event_type: 'CLASSES_CSV_IMPORTED',
                    payload: { rows_inserted: count }
                });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// ── Fee Structure CSV Import ─────────────────────────────────────────────────
// Columns: Class_Name, Item_Name, Amount, Term
function handleFeeStructureCSVUpload(filePath, callback, dry_run = false) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => { if (callback) callback(0, err.message); })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const configs   = db.prepare('SELECT hierarchy_class FROM class_configs').all();
            const classArms = db.prepare('SELECT hierarchy_class, arm FROM class_arms').all();

            const blockingErrors = [];
            let rIdx = 1;
            for (const row of rows) {
                rIdx++;
                const className = (row['Class_Name'] || '').trim();
                if (className) {
                    const check = validateClassArmRef(className, configs, classArms, { mode: 'fee_target' });
                    if (!check.ok) {
                        blockingErrors.push({ rowIndex: rIdx, field: 'Class_Name', reason: check.error });
                    }
                }
            }

            if (dry_run) {
                if (callback) callback(Math.max(0, rows.length - blockingErrors.length), null, {
                    dry_run: true, cleanCount: Math.max(0, rows.length - blockingErrors.length),
                    blocking: blockingErrors, normalizable: []
                });
                return;
            }

            if (blockingErrors.length > 0) {
                if (callback) callback(0, 'VAL_ERR: Validation failed. Unknown classes found.', {
                    dry_run: false, cleanCount: 0, blocking: blockingErrors, normalizable: []
                });
                return;
            }

            const upsert = db.prepare(`
                INSERT INTO fee_structures (class_name, item_name, amount, term)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(class_name, item_name, term)
                DO UPDATE SET amount = excluded.amount
            `);

            try {
                let count = 0;
                db.transaction(() => {
                    for (const row of rows) {
                        const className = (row['Class_Name'] || '').trim();
                        const itemName  = (row['Item_Name']  || '').trim();
                        const amount    = parseFloat(row['Amount'] || '0');
                        const term      = (row['Term'] || 'All Terms').trim();
                        if (!className || !itemName || isNaN(amount)) continue;
                        upsert.run(className, itemName, amount, term);
                        count++;
                    }
                })();
                logActivity({ event_type: 'FEE_STRUCTURE_CSV_IMPORTED', payload: { rows: count } });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}


// ── Fee Payment CSV Import ───────────────────────────────────────────────────
// Columns: Student_ID, Academic_Session, Term, Amount_Paid, Payment_Method,
//          Reference_Number (opt), Payment_Date (opt), Recorded_By (opt)
function handleFeePaymentCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => { if (callback) callback(0, err.message); })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const validMethods = ['cash', 'transfer', 'pos', 'bank_teller'];
            const insertTx = db.prepare(`
                INSERT INTO fee_transactions
                    (student_id, academic_session, term, amount, payment_method, reference_number, recorded_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `);
            const upsertFee = db.prepare(`
                INSERT INTO student_fees (student_id, academic_session, term, total_billed, total_paid, status)
                VALUES (?, ?, ?, 0, ?, 'partial')
                ON CONFLICT(student_id, academic_session, term)
                DO UPDATE SET
                    total_paid = total_paid + excluded.total_paid,
                    status = CASE
                        WHEN (total_paid + excluded.total_paid) >= total_billed AND total_billed > 0 THEN 'cleared'
                        WHEN (total_paid + excluded.total_paid) > 0 THEN 'partial'
                        ELSE 'unpaid'
                    END,
                    updated_at = datetime('now')
            `);

            try {
                let count = 0;
                let errors = [];
                const inserted = [];
                db.transaction(() => {
                    for (const row of rows) {
                        const studentId = (row['Student_ID'] || '').trim();
                        const session   = (row['Academic_Session'] || '').trim();
                        const term      = (row['Term'] || '').trim();
                        const amount    = parseFloat(row['Amount_Paid'] || '0');
                        const method    = (row['Payment_Method'] || 'cash').trim().toLowerCase();
                        const ref       = (row['Reference_Number'] || '').trim();
                        const date      = (row['Payment_Date'] || new Date().toISOString().split('T')[0]).trim();
                        const recordedBy = (row['Recorded_By'] || 'Admin').trim();

                        if (!studentId || !session || !term || isNaN(amount) || amount <= 0) {
                            errors.push(`Invalid row: ${JSON.stringify(row)}`);
                            continue;
                        }
                        const method_safe = validMethods.includes(method) ? method : 'cash';
                        const finalRef = ref || `BULK-${Date.now()}-${count + 1}`;
                        insertTx.run(studentId, session, term, amount, method_safe, finalRef, recordedBy, date);
                        upsertFee.run(studentId, session, term, amount);
                        inserted.push({
                            student_id: studentId,
                            academic_session: session,
                            term,
                            amount,
                            payment_method: method_safe,
                            reference_number: finalRef,
                            note: `Bulk Import (${recordedBy})`,
                        });
                        count++;
                    }
                })();
                if (errors.length) console.warn('[FeePaymentCSV] Skipped rows:', errors);
                logActivity({ event_type: 'FEE_PAYMENT_CSV_IMPORTED', payload: { rows: count, skipped: errors.length } });
                if (callback) callback(count, null, { inserted });
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// ── Fee Adjustment CSV Import ────────────────────────────────────────────────
// Columns: Student_ID, Academic_Session, Term, Adjustment_Type, Amount,
//          Description (opt), Approved_By (opt)
function handleFeeAdjustmentCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => { if (callback) callback(0, err.message); })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const validTypes = ['scholarship', 'waiver', 'owner_grant', 'bursary', 'discount'];
            const insert = db.prepare(`
                INSERT INTO fee_adjustments
                    (student_id, academic_session, term, adjustment_type, description, amount, approved_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `);

            try {
                let count = 0;
                let errors = [];
                db.transaction(() => {
                    for (const row of rows) {
                        const studentId = (row['Student_ID'] || '').trim();
                        const session   = (row['Academic_Session'] || '').trim();
                        const term      = (row['Term'] || '').trim();
                        const adjType   = (row['Adjustment_Type'] || 'discount').trim().toLowerCase();
                        const amount    = parseFloat(row['Amount'] || '0');
                        const desc      = (row['Description'] || '').trim();
                        const approvedBy = (row['Approved_By'] || 'Admin').trim();

                        if (!studentId || !session || !term || isNaN(amount) || amount <= 0) {
                            errors.push(`Invalid row: ${JSON.stringify(row)}`);
                            continue;
                        }
                        const type_safe = validTypes.includes(adjType) ? adjType : 'discount';
                        insert.run(studentId, session, term, type_safe, desc, amount, approvedBy);
                        count++;
                    }
                })();
                if (errors.length) console.warn('[FeeAdjustmentCSV] Skipped rows:', errors);
                logActivity({ event_type: 'FEE_ADJUSTMENT_CSV_IMPORTED', payload: { rows: count, skipped: errors.length } });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

function validateCSVDryRun(filePath, type, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            if (callback) callback(null, err.message);
        })
        .on('end', () => {
            if (rows.length === 0) {
                if (callback) callback({ cleanCount: 0, blocking: [{ rowIndex: 1, field: 'File', reason: 'The uploaded CSV file is empty.' }], normalizable: [] });
                return;
            }
            
            let db;
            try {
                db = database.getDb();
            } catch (e) {
                if (callback) callback(null, 'DB not initialized');
                return;
            }
            
            // Collect metadata for validation
            const classConfigs = db.prepare("SELECT hierarchy_class FROM class_configs").all().map(c => c.hierarchy_class.trim());
            const classArms = db.prepare("SELECT hierarchy_class, arm FROM class_arms").all().map(a => ({
                class_name: a.hierarchy_class.trim(),
                arm: a.arm.trim()
            }));
            
            const studentIds = new Set(db.prepare("SELECT id FROM students").all().map(s => s.id));
            
            // Helper to normalize strings for comparison (lowercase, strip all whitespace)
            const norm = (s) => (s || '').toString().toLowerCase().replace(/\s+/g, '');
            
            // Helper to validate a class + arm combo
            // Returns: { ok: boolean, error: string, normalized: { class_name, class_arm } }
            const validateClassCombo = (rawClassName) => {
                const res = validateClassArmRef(rawClassName, classConfigs, classArms, { mode: 'strict' });
                if (!res.ok) {
                    return { ok: false, error: res.error };
                }
                const exactMatch = rawClassName.trim() === `${res.resolved.class_name}${res.resolved.class_arm ? ' ' + res.resolved.class_arm : ''}`;
                return {
                    ok: true,
                    exactMatch,
                    normalized: res.resolved
                };
            };

            const blocking = [];
            const normalizable = [];
            let cleanCount = 0;
            
            // Check headers to auto-detect roster type if not specified
            const headers = Object.keys(rows[0] || {}).map(h => h.trim().toLowerCase());
            let resolvedType = type;
            if (type === 'roster' || type === 'students' || type === 'teachers') {
                const hasStudentCols = headers.includes('student_id') || headers.includes('first_name') || headers.includes('last_name') || headers.includes('parent_phone');
                const hasTeacherCols = headers.includes('teacher_id') || headers.includes('teacher_name') || headers.includes('teacher_phone');
                if (hasTeacherCols && !hasStudentCols) {
                    resolvedType = 'teachers';
                } else {
                    resolvedType = 'students';
                }
            }
            
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const rowIndex = i + 1;
                let isRowBlocking = false;
                let isRowNormalizable = false;
                const rowNorms = [];
                
                if (resolvedType === 'students') {
                    const studentId = (row['Student_ID'] || row['ID'] || '').trim();
                    const firstName = (row['First_Name'] || '').trim();
                    const lastName = (row['Last_Name'] || '').trim();
                    const className = (row['Class'] || '').trim();
                    
                    if (!studentId || (!firstName && !lastName) || !className) {
                        blocking.push({ rowIndex, field: 'Roster', reason: `Row is missing required student fields (Student_ID, Name, or Class)` });
                        continue;
                    }
                    
                    const classCheck = validateClassCombo(className);
                    if (!classCheck.ok) {
                        blocking.push({ rowIndex, field: 'Class', reason: classCheck.error });
                        isRowBlocking = true;
                    } else if (!classCheck.exactMatch) {
                        rowNorms.push({
                            field: 'Class',
                            from: className,
                            to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                        });
                        isRowNormalizable = true;
                    }

                    const parentPhone = (row['Parent_Phone'] || row['Phone'] || '').trim();
                    if (parentPhone) {
                        const cleanPhone = parentPhone.replace(/[\s\-()]/g, '');
                        const isNig = /^(\+?234|0)[789][01]\d{8}$/.test(cleanPhone);
                        const isIntl = /^\+?[1-9]\d{6,14}$/.test(cleanPhone);
                        if (!isNig && !isIntl) {
                            blocking.push({ rowIndex, field: 'Parent_Phone', reason: `"${parentPhone}" is not a valid phone number` });
                            isRowBlocking = true;
                        }
                    }

                    const parentEmail = (row['Parent_Email'] || row['Email'] || '').trim();
                    if (parentEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parentEmail)) {
                        blocking.push({ rowIndex, field: 'Parent_Email', reason: `"${parentEmail}" is not a valid email address` });
                        isRowBlocking = true;
                    }
                    
                } else if (resolvedType === 'teachers') {
                    const teacherId = (row['Teacher_ID'] || '').trim();
                    const teacherName = (row['Teacher_Name'] || '').trim();
                    const className = (row['Class'] || '').trim();
                    const classHost = (row['Class_Host'] || '').trim();
                    
                    if (!teacherId || !teacherName) {
                        blocking.push({ rowIndex, field: 'Teacher', reason: `Row is missing required teacher fields (Teacher_ID or Teacher_Name)` });
                        continue;
                    }

                    const teacherPhone = (row['Teacher_Phone'] || row['Phone'] || '').trim();
                    if (teacherPhone) {
                        const cleanPhone = teacherPhone.replace(/[\s\-()]/g, '');
                        const isNig = /^(\+?234|0)[789][01]\d{8}$/.test(cleanPhone);
                        const isIntl = /^\+?[1-9]\d{6,14}$/.test(cleanPhone);
                        if (!isNig && !isIntl) {
                            blocking.push({ rowIndex, field: 'Teacher_Phone', reason: `"${teacherPhone}" is not a valid phone number` });
                            isRowBlocking = true;
                        }
                    }
                    
                    // Validate allocated classes
                    if (className) {
                        const classes = className.split('|').map(c => c.trim()).filter(Boolean);
                        for (const cls of classes) {
                            const check = validateClassArmRef(cls, classConfigs, classArms, { mode: 'strict' });
                            if (!check.ok) {
                                blocking.push({ rowIndex, field: 'Class', reason: check.error });
                                isRowBlocking = true;
                            } else {
                                const canonicalFull = `${check.resolved.class_name}${check.resolved.class_arm ? ' ' + check.resolved.class_arm : ''}`;
                                if (cls !== canonicalFull) {
                                    rowNorms.push({
                                        field: 'Class Allocation',
                                        from: cls,
                                        to: canonicalFull
                                    });
                                    isRowNormalizable = true;
                                }
                            }
                        }
                    }
                    
                    // Validate class host (form teacher assignment)
                    if (classHost && classHost.toUpperCase() !== 'FALSE' && classHost.toUpperCase() !== 'NO' && classHost.toUpperCase() !== '0') {
                        let hostClassToValidate = classHost;
                        // If it's a simple boolean flag, retrieve the first class from className
                        if (classHost.toUpperCase() === 'TRUE' || classHost.toUpperCase() === '1' || classHost.toUpperCase() === 'YES') {
                            const classes = className.split('|').map(c => c.trim()).filter(Boolean);
                            hostClassToValidate = classes[0] || '';
                        }
                        
                        if (hostClassToValidate) {
                            // Enforce strict check on hostClassToValidate
                            const classCheck = validateClassCombo(hostClassToValidate);
                            if (!classCheck.ok) {
                                blocking.push({ rowIndex, field: 'Class_Host', reason: classCheck.error });
                                isRowBlocking = true;
                            } else if (!classCheck.exactMatch) {
                                rowNorms.push({
                                    field: 'Class Host',
                                    from: hostClassToValidate,
                                    to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                                });
                                isRowNormalizable = true;
                            }
                        }
                    }
                    
                } else if (resolvedType === 'grades') {
                    const studentId = (row['Student_ID'] || '').trim();
                    const subject = (row['Subject'] || '').trim();
                    
                    if (!studentId || !subject) {
                        blocking.push({ rowIndex, field: 'Grades', reason: `Row is missing required fields (Student_ID or Subject)` });
                        continue;
                    }
                    
                    if (!studentIds.has(studentId)) {
                        blocking.push({ rowIndex, field: 'Student_ID', reason: `Student ID "${studentId}" was not found` });
                        isRowBlocking = true;
                    }
                    
                } else if (resolvedType === 'attendance') {
                    const studentId = (row['Student_ID'] || '').trim();
                    const className = (row['Class'] || '').trim();
                    
                    if (!studentId || !className) {
                        blocking.push({ rowIndex, field: 'Attendance', reason: `Row is missing required fields (Student_ID or Class)` });
                        continue;
                    }
                    
                    if (!studentIds.has(studentId)) {
                        blocking.push({ rowIndex, field: 'Student_ID', reason: `Student ID "${studentId}" was not found` });
                        isRowBlocking = true;
                    }
                    
                    const classCheck = validateClassCombo(className);
                    if (!classCheck.ok) {
                        blocking.push({ rowIndex, field: 'Class', reason: classCheck.error });
                        isRowBlocking = true;
                    } else if (!classCheck.exactMatch) {
                        rowNorms.push({
                            field: 'Class',
                            from: className,
                            to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                        });
                        isRowNormalizable = true;
                    }
                    
                } else if (resolvedType === 'fee-structure') {
                    const className = (row['Class_Name'] || '').trim();
                    const itemName = (row['Item_Name'] || '').trim();
                    const term = (row['Term'] || 'All Terms').trim();
                    
                    if (!className || !itemName) {
                        blocking.push({ rowIndex, field: 'Fee Structure', reason: `Row is missing required fields (Class_Name or Item_Name)` });
                        continue;
                    }
                    
                    const classCheck = validateClassCombo(className);
                    if (!classCheck.ok) {
                        blocking.push({ rowIndex, field: 'Class_Name', reason: classCheck.error });
                        isRowBlocking = true;
                    } else if (!classCheck.exactMatch) {
                        rowNorms.push({
                            field: 'Class Name',
                            from: className,
                            to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                        });
                        isRowNormalizable = true;
                    }
                    
                    // Validate term is one of the four valid values or a casing variant
                    const validTerms = ['All Terms', 'First Term', 'Second Term', 'Third Term'];
                    const matchedTerm = validTerms.find(t => norm(t) === norm(term));
                    if (!matchedTerm) {
                        blocking.push({ rowIndex, field: 'Term', reason: `Term "${term}" must be one of: All Terms, First Term, Second Term, Third Term` });
                        isRowBlocking = true;
                    } else if (term !== matchedTerm) {
                        rowNorms.push({
                            field: 'Term',
                            from: term,
                            to: matchedTerm
                        });
                        isRowNormalizable = true;
                    }
                    
                } else if (resolvedType === 'fee-adjustment') {
                    const studentId = (row['Student_ID'] || '').trim();
                    const amount = (row['Amount'] || '').trim();
                    
                    if (!studentId || !amount) {
                        blocking.push({ rowIndex, field: 'Fee Adjustment', reason: `Row is missing required fields (Student_ID or Amount)` });
                        continue;
                    }
                    
                    if (!studentIds.has(studentId)) {
                        blocking.push({ rowIndex, field: 'Student_ID', reason: `Student ID "${studentId}" was not found` });
                        isRowBlocking = true;
                    }
                }
                
                if (!isRowBlocking) {
                    if (isRowNormalizable) {
                        for (const normVal of rowNorms) {
                            normalizable.push({
                                rowIndex,
                                field: normVal.field,
                                from: normVal.from,
                                to: normVal.to
                            });
                        }
                    }
                    cleanCount++;
                }
            }
            
            if (callback) {
                callback({ cleanCount, blocking, normalizable });
            }
        });
}

module.exports = {
    startServer,
    setSchoolConfig,
    setSchoolLicense,
    setActivationStatus,
    revokeDevice,
    logActivity,
    handleCSVUpload,
    handleGradesCSVUpload,
    handleAttendanceCSVUpload,
    handleClassesCSVUpload,
    handleFeeStructureCSVUpload,
    handleFeePaymentCSVUpload,
    handleFeeAdjustmentCSVUpload,
    validateCSVDryRun,
    clearData,
    generatePairingPin
};
