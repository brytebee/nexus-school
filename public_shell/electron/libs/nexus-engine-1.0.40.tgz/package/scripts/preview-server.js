#!/usr/bin/env node
/**
 * Standalone Authenticated Diagnostic Studio & Template Sandbox Server
 * Nexus School OS - private_engine
 *
 * Provides walled, developer-authenticated diagnostic access for on-site school
 * troubleshooting and live student report card verification with dynamic SQLite querying.
 *
 * Developer Identity:
 *   Email: brytebee@gmail.com
 *   Phone: 07066324306
 *
 * Usage:
 *   node scripts/preview-server.js
 *   npm run template:preview
 *
 * Serves on: http://localhost:3333
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const reportCompiler = require('../src/report-compiler');
const reportAssembler = require('../src/report-assembler');
const database = require('../src/database');
const rankingLib = (() => {
  try { return require('../../public_shell/electron/src/lib/ranking'); }
  catch {
    try { return require('../../../../src/lib/ranking'); }
    catch (_) { return null; }
  }
})();

const app = express();
const PORT = process.env.PORT || 3333;
const BASE_DIR = path.resolve(__dirname, '..');
const TEMPLATES_DIR = path.join(BASE_DIR, 'assets', 'templates');
const TEMP_DIR = path.join(os.tmpdir(), 'nexus-preview-cache');

if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ── Cookie & Body Parser Middleware ──────────────────────────────────────────
app.use((req, res, next) => {
  const cookieHeader = req.headers.cookie;
  req.cookies = {};
  if (cookieHeader) {
    cookieHeader.split(';').forEach(c => {
      const parts = c.split('=');
      const name = parts[0]?.trim();
      const val = parts.slice(1).join('=').trim();
      if (name) req.cookies[name] = decodeURIComponent(val);
    });
  }
  next();
});
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Developer Authentication Vault & Engine ──────────────────────────────────
const DEV_EMAIL = 'brytebee@gmail.com';
const DEV_PHONE = '07066324306';
const AUTH_SALT = 'nexus_dev_diagnostic_salt_2026_x86';
const VAULT_FILE = path.join(TEMP_DIR, 'nexus_dev_vault.json');

function hashSecret(secret) {
  return crypto.createHash('sha256').update(secret + AUTH_SALT).digest('hex');
}

// Initialize Vault if missing (default master password: brytebee@2026!)
function getVault() {
  try {
    if (fs.existsSync(VAULT_FILE)) {
      return JSON.parse(fs.readFileSync(VAULT_FILE, 'utf8'));
    }
  } catch (_) {}

  const defaultVault = {
    email: DEV_EMAIL,
    phone: DEV_PHONE,
    passwordHash: hashSecret('brytebee@2026!'),
    updatedAt: new Date().toISOString()
  };
  try {
    fs.writeFileSync(VAULT_FILE, JSON.stringify(defaultVault, null, 2), 'utf8');
  } catch (_) {}
  return defaultVault;
}

function updateVaultPassword(newPassword) {
  const vault = getVault();
  vault.passwordHash = hashSecret(newPassword);
  vault.updatedAt = new Date().toISOString();
  fs.writeFileSync(VAULT_FILE, JSON.stringify(vault, null, 2), 'utf8');
  return true;
}

// In-Memory Sessions & Verification Codes
const activeSessions = new Map(); // token -> { email, expiresAt }
let activeEmailOtp = null; // { code, expiresAt, email }

function createSession(email = DEV_EMAIL) {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + (24 * 60 * 60 * 1000); // 24 Hours
  activeSessions.set(token, { email, expiresAt });
  return token;
}

function isSessionValid(token) {
  if (!token) return false;
  const session = activeSessions.get(token);
  if (!session) return false;
  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return false;
  }
  return true;
}

function isRequestAuthenticated(req) {
  const token = req.cookies?.nexus_dev_session ||
                req.headers['x-dev-auth'] ||
                (req.headers.authorization && req.headers.authorization.replace('Bearer ', '').trim()) ||
                req.query.devAuth;
  return isSessionValid(token);
}

// Offline 15-Minute Challenge-Response Algorithm
function getCurrentChallenge() {
  const timeSlice = Math.floor(Date.now() / (15 * 60 * 1000));
  const rawHash = crypto.createHmac('sha256', AUTH_SALT).update('challenge_' + timeSlice).digest('hex');
  return rawHash.replace(/\D/g, '').slice(0, 6).padStart(6, '7');
}

function getExpectedChallengeResponse(challengeCode) {
  const respHash = crypto.createHmac('sha256', AUTH_SALT + '_response').update(String(challengeCode)).digest('hex');
  return respHash.replace(/\D/g, '').slice(0, 6).padStart(6, '3');
}

// ── Dynamic SQLite Discovery & Loader ─────────────────────────────────────────
function loadBetterSqlite3() {
  const candidates = [
    path.resolve(__dirname, '../../public_shell/electron/node_modules/better-sqlite3'),
    'better-sqlite3',
    path.resolve(__dirname, '../node_modules/better-sqlite3'),
  ];
  for (const cand of candidates) {
    try {
      const mod = require(cand);
      // Quick test instantiation to verify architecture / ABI compatibility
      const testDb = new mod(':memory:');
      testDb.close();
      return mod;
    } catch (_) {}
  }
  return null;
}

function locateDatabasePath() {
  const candidates = [
    process.env.NEXUS_DB_PATH,
    path.join(os.homedir(), 'Library/Application Support/NexusSchoolOS/nexus_os.db'),
    path.join(process.env.APPDATA || '', 'NexusSchoolOS/nexus_os.db'),
    path.join(os.homedir(), '.config/NexusSchoolOS/nexus_os.db'),
    path.resolve(BASE_DIR, 'nexus.sqlite'),
    path.resolve(BASE_DIR, '../public_shell/electron/nexus_school.db'),
    path.resolve(BASE_DIR, '../public_shell/electron/nexus.sqlite'),
  ].filter(Boolean);

  for (const cand of candidates) {
    if (fs.existsSync(cand)) {
      try {
        const stat = fs.statSync(cand);
        if (stat.size > 0) return cand;
      } catch (_) {}
    }
  }
  return candidates[0] || path.resolve(BASE_DIR, 'nexus.sqlite');
}

let dbInstance = null;
let activeDatabasePath = null;

function getDatabase() {
  if (dbInstance) return dbInstance;
  const DatabaseClass = loadBetterSqlite3();
  if (!DatabaseClass) {
    console.warn('[Preview Server] Warning: better-sqlite3 native driver not found.');
    return null;
  }
  activeDatabasePath = locateDatabasePath();
  try {
    class SafeDatabase extends DatabaseClass {
      constructor(filename, options = {}) {
        super(filename, { ...options, verbose: process.env.DEBUG ? console.log : null });
      }
    }
    dbInstance = database.init(activeDatabasePath, SafeDatabase);
    console.log(`[Preview Server] SQLite Connected: ${activeDatabasePath}`);
    return dbInstance;
  } catch (err) {
    console.error(`[Preview Server] SQLite connection error at ${activeDatabasePath}:`, err.message);
    return null;
  }
}

// ── Sample Assets (SVG Data URIs for Fallback / Mocks) ───────────────────────
const SAMPLE_LOGO_SVG = `data:image/svg+xml;base64,${Buffer.from(`
<svg width="140" height="140" viewBox="0 0 140 140" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="shieldGrad" x1="0" y1="0" x2="140" y2="140" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#1A237E"/>
      <stop offset="100%" stop-color="#0D47A1"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="140" y2="140" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#FFD700"/>
      <stop offset="100%" stop-color="#FFA000"/>
    </linearGradient>
  </defs>
  <path d="M70 10 L125 35 V75 C125 105 70 130 70 130 C70 130 15 105 15 75 V35 L70 10 Z" fill="url(#shieldGrad)" stroke="url(#goldGrad)" stroke-width="4"/>
  <path d="M70 24 L113 43 V75 C113 98 70 118 70 118 C70 118 27 98 27 75 V43 L70 24 Z" fill="none" stroke="#FFFFFF" stroke-opacity="0.3" stroke-width="1.5"/>
  <path d="M70 45 L74 58 L87 58 L76 66 L80 79 L70 71 L60 79 L64 66 L53 58 L66 58 Z" fill="url(#goldGrad)"/>
  <path d="M50 88 C60 84 80 84 90 88 V100 C80 96 60 96 50 100 Z" fill="#FFFFFF"/>
  <line x1="70" y1="86" x2="70" y2="100" stroke="#1A237E" stroke-width="2"/>
</svg>
`).toString('base64')}`;

const SAMPLE_PHOTO_SVG = `data:image/svg+xml;base64,${Buffer.from(`
<svg width="200" height="240" viewBox="0 0 200 240" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="200" height="240" fill="#E2E8F0" rx="8"/>
  <circle cx="100" cy="85" r="42" fill="#94A3B8"/>
  <path d="M35 210 C35 155 65 145 100 145 C135 145 165 155 165 210 Z" fill="#64748B"/>
  <rect x="75" y="170" width="50" height="40" fill="#CBD5E1"/>
  <polygon points="100,175 92,205 108,205" fill="#EF4444"/>
</svg>
`).toString('base64')}`;

const SAMPLE_SIGNATURE_SVG = `data:image/svg+xml;base64,${Buffer.from(`
<svg width="240" height="80" viewBox="0 0 240 80" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M20 50 C 40 20, 60 25, 75 45 C 90 65, 110 30, 130 40 C 150 50, 160 30, 180 50 C 190 60, 210 40, 225 35" stroke="#1A237E" stroke-width="2.5" stroke-linecap="round" fill="none"/>
  <path d="M45 55 C 80 58, 140 54, 215 50" stroke="#1A237E" stroke-width="1.8" stroke-linecap="round" fill="none"/>
</svg>
`).toString('base64')}`;

// ── School Branding Discovery Helper ─────────────────────────────────────────
function getSchoolIdentity(db) {
  if (db) {
    try {
      const raw = db.prepare("SELECT value FROM app_settings WHERE key = 'school_identity'").get()?.value;
      let logoFallback = null;
      try {
        logoFallback = db.prepare("SELECT value FROM app_settings WHERE key = 'school_logo_b64'").get()?.value;
      } catch (_) {}
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          name: parsed.name || 'Dapson Memorial Schools',
          motto: parsed.motto || 'Excellence in Everything',
          address: parsed.address || 'Plot 14, Admiralty Way, Lekki Phase 1, Lagos State',
          phone: parsed.phone || parsed.principalPhone || '+234 803 123 4567',
          email: parsed.email || 'info@dapson.edu.ng',
          themePrimary: parsed.themePrimary || '#0284c7',
          themeSecondary: parsed.themeSecondary || '#f59e0b',
          tier: 'Gold', // Override for diagnostic studio preview so stamps and signatures are never suppressed
          logoBase64: parsed.logoBase64 || logoFallback || SAMPLE_LOGO_SVG,
          signature: parsed.signature || 'Dr. Adamu Okechukwu',
          principalSignBase64: parsed.principalSignBase64 || SAMPLE_SIGNATURE_SVG,
          stamp: parsed.stamp || null,
          stampStyle: parsed.stampStyle || 'classic_round',
          stampCustomColor: parsed.themePrimary || '#0284c7',
        };
      }
    } catch (_) {}
  }
  return {
    name: 'ST. AUGUSTINE INTERNATIONAL COLLEGE',
    motto: 'Knowledge, Character & Excellence',
    address: 'Plot 14, Admiralty Way, Lekki Phase 1, Lagos State',
    phone: '+234 803 123 4567',
    email: 'info@staugustine.edu.ng',
    themePrimary: '#1A237E',
    themeSecondary: '#00E5FF',
    tier: 'Gold',
    logoBase64: SAMPLE_LOGO_SVG,
    signature: 'Dr. E. O. Okonjo (Ph.D)',
    principalSignBase64: SAMPLE_SIGNATURE_SVG,
    stampStyle: 'classic_round',
    stampCustomColor: '#1A237E',
  };
}

// ── Built-in School Presets for Diagnostic Studio ─────────────────────────────
const SCHOOL_PRESETS = {
  live: {
    id: 'live',
    name: 'Dapson Memorial Schools (Live SQLite DB)',
    tier: 'Gold',
    isLive: true,
  },
  apex_demo: {
    id: 'apex_demo',
    name: 'Apex British International Academy',
    motto: 'Striving for Royal Distinction & Character',
    address: 'Plot 24, Diplomatic Zone, Victoria Island, Lagos',
    phone: '+234 802 999 8888',
    email: 'admissions@apexacademy.edu.ng',
    themePrimary: '#1A237E',
    themeSecondary: '#D4AF37',
    tier: 'Gold',
    logoBase64: SAMPLE_LOGO_SVG,
    signature: 'Sir Arthur Bellingham (Ed.D)',
    principalSignBase64: SAMPLE_SIGNATURE_SVG,
    stampStyle: 'classic_round',
    stampCustomColor: '#1A237E',
    isLive: false,
  },
  prestige_demo: {
    id: 'prestige_demo',
    name: 'Prestige Collegiate School',
    motto: 'Excellence, Integrity & Leadership',
    address: '55 Queen Elizabeth Road, GRA, Ikeja, Lagos',
    phone: '+234 803 777 6666',
    email: 'info@prestigecollegiate.sch.ng',
    themePrimary: '#064E3B',
    themeSecondary: '#F59E0B',
    tier: 'Diamond',
    logoBase64: SAMPLE_LOGO_SVG,
    signature: 'Dr. (Mrs) Folashade Alakija',
    principalSignBase64: SAMPLE_SIGNATURE_SVG,
    stampStyle: 'classic_round',
    stampCustomColor: '#064E3B',
    isLive: false,
  },
  royal_demo: {
    id: 'royal_demo',
    name: 'Royal Crown Academy',
    motto: 'Coram Deo — In the Presence of God',
    address: '12 Coronation Crescent, Maitama, Abuja',
    phone: '+234 809 111 2233',
    email: 'contact@royalcrown.edu.ng',
    themePrimary: '#312E81',
    themeSecondary: '#E11D48',
    tier: 'Gold',
    logoBase64: SAMPLE_LOGO_SVG,
    signature: 'Prof. Kingsley Nnamdi',
    principalSignBase64: SAMPLE_SIGNATURE_SVG,
    stampStyle: 'classic_round',
    stampCustomColor: '#312E81',
    isLive: false,
  },
};

const SAMPLE_DEPT_MANAGERS = [
  {
    id: 1,
    section_name: 'Nursery & Early Years',
    class_prefixes: JSON.stringify(['BEGINNERS', 'READING', 'NURSERY', 'KG', 'CRECHE']),
    manager_title: 'Head of Nursery',
    manager_name: 'Mrs. Folashade Adebayo',
    grading_scale: JSON.stringify([
      { grade: 'EXC', min: 85, max: 100, remark: 'Exceeding Expectations' },
      { grade: 'EXP', min: 70, max: 84,  remark: 'Expected Standard' },
      { grade: 'DEV', min: 50, max: 69,  remark: 'Developing Standard' },
      { grade: 'EMG', min: 0,  max: 49,  remark: 'Emerging Skill' },
    ]),
  },
  {
    id: 2,
    section_name: 'Primary School',
    class_prefixes: JSON.stringify(['GRADE', 'PRIMARY', 'BASIC']),
    manager_title: 'Headmaster',
    manager_name: 'Mr. Emmanuel Chukwu',
    grading_scale: JSON.stringify([
      { grade: 'A', min: 80, max: 100, remark: 'Distinction' },
      { grade: 'B', min: 70, max: 79,  remark: 'Very Good' },
      { grade: 'C', min: 60, max: 69,  remark: 'Good' },
      { grade: 'D', min: 50, max: 59,  remark: 'Pass' },
      { grade: 'E', min: 0,  max: 49,  remark: 'Needs Improvement' },
    ]),
  },
  {
    id: 3,
    section_name: 'Junior Secondary (JSS)',
    class_prefixes: JSON.stringify(['JSS', 'JS']),
    manager_title: 'Vice Principal (Junior)',
    manager_name: 'Dr. (Mrs) Ngozi Okonjo',
    grading_scale: null,
  },
  {
    id: 4,
    section_name: 'Senior Secondary (SSS)',
    class_prefixes: JSON.stringify(['SSS', 'SS']),
    manager_title: 'Principal (Senior)',
    manager_name: 'Dr. Lawal Ibe',
    grading_scale: null,
  },
];

// ── Mock Data Generator ──────────────────────────────────────────────────────
function getMockPayload(options = {}) {
  const {
    system = 'standard_secondary',
    templateId = 'royal',
    useSchoolColors = true,
    feeStatus = 'cleared',
    showAttendance = true,
    showPosition = true,
    stampStyle = 'classic_round',
  } = options;

  const identity = {
    name: 'ST. AUGUSTINE INTERNATIONAL COLLEGE',
    motto: 'Knowledge, Character & Excellence',
    address: 'Plot 14, Admiralty Way, Lekki Phase 1, Lagos State',
    phone: '+234 803 123 4567',
    email: 'info@staugustine.edu.ng',
    themePrimary: '#1A237E',
    themeSecondary: '#00E5FF',
    tier: 'Diamond',
    logoBase64: SAMPLE_LOGO_SVG,
    signature: 'Dr. E. O. Okonjo (Ph.D)',
    principalSignBase64: SAMPLE_SIGNATURE_SVG,
    stampStyle: stampStyle,
    stampCustomColor: '#1A237E',
  };

  const termConfig = {
    academic_session: '2025/2026',
    term: 'First Term',
    resumption_date: '12th January, 2026',
    template: templateId,
    show_attendance: showAttendance ? 1 : 0,
    show_position: showPosition ? 1 : 0,
    show_domains: 1,
    attendance_score_weight: 0,
    include_attendance_in_grades: 0,
    exclude_unregistered_from_totals: 0,
  };

  if (system === 'ils') {
    const il_subjects = [
      {
        subject: 'Math',
        packs: { 1: 100, 2: 96, 3: 92, 4: 100, 5: 88, 6: 95, 7: 100, 8: 94, 9: 98, 10: 100, 11: 92, 12: 97 },
        packs_completed: 12,
        hundreds_count: 4,
        total_score: 1152,
        average: 96.0,
      },
      {
        subject: 'English',
        packs: { 1: 94, 2: 98, 3: 100, 4: 92, 5: 96, 6: 100, 7: 95, 8: 91, 9: 100, 10: 97, 11: 94, 12: 98 },
        packs_completed: 12,
        hundreds_count: 3,
        total_score: 1155,
        average: 96.3,
      },
      {
        subject: 'Social Studies',
        packs: { 1: 92, 2: 90, 3: 95, 4: 98, 5: 94, 6: 100, 7: 96, 8: 92, 9: 90, 10: 94, 11: 96, 12: 98 },
        packs_completed: 12,
        hundreds_count: 1,
        total_score: 1135,
        average: 94.6,
      },
      {
        subject: 'Science',
        packs: { 1: 98, 2: 100, 3: 96, 4: 94, 5: 100, 6: 98, 7: 92, 8: 96, 9: 100, 10: 95, 11: 98, 12: 99 },
        packs_completed: 12,
        hundreds_count: 3,
        total_score: 1166,
        average: 97.2,
      },
      {
        subject: 'Word Building',
        packs: { 1: 100, 2: 100, 3: 98, 4: 96, 5: 94, 6: 98, 7: 100, 8: 98, 9: 96, 10: 100, 11: 98, 12: 100 },
        packs_completed: 12,
        hundreds_count: 5,
        total_score: 1178,
        average: 98.2,
      },
      {
        subject: 'Literature & Creative Writing',
        packs: { 1: 90, 2: 92, 3: 95, 4: 91, 5: 94, 6: 96, 7: 98, 8: 92, 9: 95, 10: 90, 11: 94, 12: 96 },
        packs_completed: 12,
        hundreds_count: 0,
        total_score: 1123,
        average: 93.6,
      },
      {
        subject: 'Bible Reading',
        packs: { 1: 100, 2: 100, 3: 100, 4: 98, 5: 100, 6: 96, 7: 100, 8: 98, 9: 100, 10: 100, 11: 98, 12: 100 },
        packs_completed: 12,
        hundreds_count: 8,
        total_score: 1190,
        average: 99.2,
      },
      {
        subject: 'Animal Science',
        packs: { 1: 94, 2: 96, 3: 92, 4: 98, 5: 90, 6: 95, 7: 94, 8: 96, 9: 98, 10: 92, 11: 96, 12: 94 },
        packs_completed: 12,
        hundreds_count: 0,
        total_score: 1135,
        average: 94.6,
      },
    ];

    const student = {
      id: 'ILS-MOCK-001',
      name: 'CHUKWUDI EMMANUEL OKAFOR',
      admission_no: 'STA/2024/0088',
      class_name: 'ACE Learning Center (Grade 6)',
      curriculum_type: 'ILS',
      gender: 'Male',
      dob: '14th May, 2013',
      photo: SAMPLE_PHOTO_SVG,
      il_subjects,
      pac_count: 12,
      pac_labels: null,
      verse_count: 36,
      academic_session: '2025/2026',
      term: 'First Term',
      attendance: { total_days: 65, days_attended: 63 },
      remark: 'Emmanuel has demonstrated exceptional diligence and spiritual devotion throughout this term. He consistently masters his PACs with high distinction.',
      principal_remark: 'An outstanding academic performance. Recommended for promotion with honors.',
      form_teacher_name: 'Mrs. Abigail Henderson',
      form_teacher_signature: SAMPLE_SIGNATURE_SVG,
      feeStatus: feeStatus,
    };

    return {
      identity,
      termConfig,
      departmentManagers: SAMPLE_DEPT_MANAGERS,
      students: [student],
      pac_labels: null,
      reportType: 'terminal',
      templateId,
      useSchoolColors,
      format: 'html',
    };
  }

  // Standard Curriculum Mock
  const subjects = [
    { name: 'Mathematics', score: 94, breakdown: { ca1: 18, ca2: 19, exam: 57 }, grade: 'A1', remark: 'Distinction' },
    { name: 'English Language', score: 88, breakdown: { ca1: 17, ca2: 18, exam: 53 }, grade: 'A1', remark: 'Excellent' },
    { name: 'Basic Science', score: 91, breakdown: { ca1: 19, ca2: 18, exam: 54 }, grade: 'A1', remark: 'Distinction' },
    { name: 'Social Studies', score: 85, breakdown: { ca1: 16, ca2: 17, exam: 52 }, grade: 'B2', remark: 'Very Good' },
    { name: 'Civic Education', score: 89, breakdown: { ca1: 18, ca2: 18, exam: 53 }, grade: 'A1', remark: 'Excellent' },
    { name: 'Business Studies', score: 82, breakdown: { ca1: 15, ca2: 16, exam: 51 }, grade: 'B2', remark: 'Very Good' },
    { name: 'Basic Technology', score: 90, breakdown: { ca1: 18, ca2: 19, exam: 53 }, grade: 'A1', remark: 'Distinction' },
    { name: 'Agricultural Science', score: 86, breakdown: { ca1: 17, ca2: 17, exam: 52 }, grade: 'B2', remark: 'Very Good' },
    { name: 'French Language', score: 79, breakdown: { ca1: 15, ca2: 15, exam: 49 }, grade: 'B3', remark: 'Good' },
    { name: 'Christian Religious Studies', score: 95, breakdown: { ca1: 20, ca2: 19, exam: 56 }, grade: 'A1', remark: 'Distinction' },
    { name: 'Computer Studies / ICT', score: 96, breakdown: { ca1: 20, ca2: 19, exam: 57 }, grade: 'A1', remark: 'Distinction' },
    { name: 'Physical & Health Education', score: 87, breakdown: { ca1: 17, ca2: 18, exam: 52 }, grade: 'B2', remark: 'Very Good' },
    { name: 'Cultural & Creative Arts', score: 88, breakdown: { ca1: 18, ca2: 17, exam: 53 }, grade: 'A1', remark: 'Excellent' },
  ];

  const domains = [
    { domain_type: 'affective', trait: 'Punctuality', grade: '5' },
    { domain_type: 'affective', trait: 'Neatness', grade: '5' },
    { domain_type: 'affective', trait: 'Politeness & Respect', grade: '5' },
    { domain_type: 'affective', trait: 'Attentiveness', grade: '4' },
    { domain_type: 'affective', trait: 'Honesty & Integrity', grade: '5' },
    { domain_type: 'psychomotor', trait: 'Handwriting', grade: '4' },
    { domain_type: 'psychomotor', trait: 'Verbal Fluency', grade: '5' },
    { domain_type: 'psychomotor', trait: 'Sports & Games', grade: '4' },
    { domain_type: 'psychomotor', trait: 'Musical Skills', grade: '4' },
    { domain_type: 'psychomotor', trait: 'Craft & Handling Tools', grade: '5' },
  ];

  const student = {
    id: 'MOCK-STU-001',
    name: 'CHUKWUDI EMMANUEL OKAFOR',
    admission_no: 'STA/2024/0088',
    class_name: 'JSS 2 Gold',
    curriculum_type: 'STANDARD_NIGERIAN',
    gender: 'Male',
    dob: '14th May, 2013',
    photo: SAMPLE_PHOTO_SVG,
    academic_session: '2025/2026',
    term: 'First Term',
    subjects,
    domains,
    total_score: 1146,
    average: 88.15,
    class_average: 74.20,
    class_size: 32,
    position: '1st',
    attendance: { total_days: 65, days_attended: 63 },
    remark: 'An exceptionally brilliant and well-mannered student. He consistently sets an admirable standard for his peers.',
    principal_remark: 'Outstanding terminal performance. Commended for exemplary academic discipline.',
    form_teacher_name: 'Mr. Kenneth C. Adeleke',
    form_teacher_signature: SAMPLE_SIGNATURE_SVG,
    feeStatus: feeStatus,
  };

  return {
    identity,
    termConfig,
    departmentManagers: SAMPLE_DEPT_MANAGERS,
    students: [student],
    templateId,
    useSchoolColors,
    format: 'html',
    reportType: 'terminal',
  };
}

// ── Discover Templates ───────────────────────────────────────────────────────
function getAvailableTemplates() {
  const files = fs.readdirSync(TEMPLATES_DIR);
  const hbsFiles = files.filter(f => f.endsWith('.hbs'));

  return hbsFiles.map(file => {
    const id = file.replace('.hbs', '');
    const content = fs.readFileSync(path.join(TEMPLATES_DIR, file), 'utf8');
    const hasILS = content.includes('isILS');
    return {
      id,
      filename: file,
      hasILS,
      name: id.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
    };
  });
}

// ── Authentication API Routes ────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const vault = getVault();

  // Allow login by master password, registered phone, or default hash
  const isValidEmail = (email && email.trim().toLowerCase() === DEV_EMAIL.toLowerCase());
  const isValidPass = (password && hashSecret(password) === vault.passwordHash);
  const isPhoneOverride = (password && password.trim() === DEV_PHONE);

  if (isValidEmail && (isValidPass || isPhoneOverride)) {
    const token = createSession(DEV_EMAIL);
    res.setHeader('Set-Cookie', `nexus_dev_session=${token}; Path=/; HttpOnly; Max-Age=86400; SameSite=Lax`);
    return res.json({ success: true, token, email: DEV_EMAIL });
  }

  res.status(401).json({ success: false, error: 'Invalid developer credentials. Access denied.' });
});

app.get('/api/auth/challenge', (req, res) => {
  const challenge = getCurrentChallenge();
  const expected = getExpectedChallengeResponse(challenge);
  console.log(`[DEV AUTH GATE] 🔑 Active 15-Min Challenge: [ ${challenge} ] -> Expected Unlock Response: [ ${expected} ]`);
  res.json({ success: true, challenge, validityMinutes: 15 });
});

app.post('/api/auth/challenge-verify', (req, res) => {
  const { challenge, responseCode } = req.body;
  if (!challenge || !responseCode) {
    return res.status(400).json({ success: false, error: 'Challenge and response code required.' });
  }

  const expected = getExpectedChallengeResponse(challenge);
  if (responseCode.trim() === expected || responseCode.trim() === DEV_PHONE) {
    const token = createSession(DEV_EMAIL);
    res.setHeader('Set-Cookie', `nexus_dev_session=${token}; Path=/; HttpOnly; Max-Age=86400; SameSite=Lax`);
    return res.json({ success: true, token, email: DEV_EMAIL });
  }

  res.status(401).json({ success: false, error: 'Invalid challenge response code.' });
});

app.post('/api/auth/request-otp', (req, res) => {
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  activeEmailOtp = {
    code: otp,
    expiresAt: Date.now() + (10 * 60 * 1000), // 10 mins
    email: DEV_EMAIL
  };

  console.log(`\n╔════════════════════════════════════════════════════════════════════╗`);
  console.log(`║ 🔐 [DEV AUTH GATE] ONE-TIME VERIFICATION OTP FOR DIAGNOSTICS       ║`);
  console.log(`║ Developer: ${DEV_EMAIL} (Phone: ${DEV_PHONE})                  ║`);
  console.log(`║ Verification Code: ${otp} (Valid for 10 minutes)                    ║`);
  console.log(`╚════════════════════════════════════════════════════════════════════╝\n`);

  res.json({
    success: true,
    message: `Verification code generated for ${DEV_EMAIL}. (Logged to server console in local offline mode).`
  });
});

app.post('/api/auth/verify-otp', (req, res) => {
  const { otp } = req.body;
  if (!activeEmailOtp || Date.now() > activeEmailOtp.expiresAt) {
    return res.status(400).json({ success: false, error: 'OTP expired or not requested.' });
  }

  if (activeEmailOtp.code === otp?.trim() || otp?.trim() === DEV_PHONE) {
    activeEmailOtp = null;
    const token = createSession(DEV_EMAIL);
    res.setHeader('Set-Cookie', `nexus_dev_session=${token}; Path=/; HttpOnly; Max-Age=86400; SameSite=Lax`);
    return res.json({ success: true, token, email: DEV_EMAIL });
  }

  res.status(401).json({ success: false, error: 'Invalid verification OTP code.' });
});

app.post('/api/auth/update-credentials', (req, res) => {
  const { otp, newPassword } = req.body;
  if (!otp || !newPassword || newPassword.length < 6) {
    return res.status(400).json({ success: false, error: 'Valid OTP and new password (min 6 chars) required.' });
  }

  // Must verify OTP before updating credentials
  if (!activeEmailOtp || Date.now() > activeEmailOtp.expiresAt || activeEmailOtp.code !== otp.trim()) {
    return res.status(401).json({ success: false, error: 'Verification failed: invalid or expired OTP.' });
  }

  activeEmailOtp = null;
  updateVaultPassword(newPassword);
  console.log(`[DEV AUTH GATE] Master password updated successfully for ${DEV_EMAIL}.`);
  const token = createSession(DEV_EMAIL);
  res.setHeader('Set-Cookie', `nexus_dev_session=${token}; Path=/; HttpOnly; Max-Age=86400; SameSite=Lax`);
  res.json({ success: true, message: 'Developer credentials updated successfully.', token });
});

app.get('/api/auth/status', (req, res) => {
  const authenticated = isRequestAuthenticated(req);
  res.json({ authenticated, email: authenticated ? DEV_EMAIL : null });
});

app.post('/api/auth/logout', (req, res) => {
  const token = req.cookies?.nexus_dev_session || req.headers['x-dev-auth'];
  if (token) activeSessions.delete(token);
  res.setHeader('Set-Cookie', 'nexus_dev_session=; Path=/; HttpOnly; Max-Age=0');
  res.json({ success: true, message: 'Logged out successfully.' });
});

// ── Protected Studio API Routes ──────────────────────────────────────────────
app.use('/api/studio', (req, res, next) => {
  if (!isRequestAuthenticated(req)) {
    return res.status(401).json({ success: false, error: 'UNAUTHORIZED_DEV_ACCESS' });
  }
  next();
});

app.get('/api/studio/status', (req, res) => {
  const db = getDatabase();
  let studentCount = 0;
  let classCount = 0;
  let schoolName = 'Nexus School';

  if (db) {
    try {
      studentCount = db.prepare('SELECT count(*) as c FROM students').get()?.c || 0;
      classCount = db.prepare('SELECT count(DISTINCT class_name) as c FROM students').get()?.c || 0;
      const rawIdentity = db.prepare("SELECT value FROM app_settings WHERE key = 'school_identity'").get()?.value;
      if (rawIdentity) {
        schoolName = JSON.parse(rawIdentity).name || schoolName;
      }
    } catch (_) {}
  }

  res.json({
    connected: !!db,
    dbPath: activeDatabasePath || 'None',
    studentCount,
    classCount,
    schoolName,
  });
});

app.get('/api/studio/schools', (req, res) => {
  const list = Object.values(SCHOOL_PRESETS).map(s => ({
    id: s.id,
    name: s.name,
    tier: s.tier,
    isLive: s.isLive,
    primaryColor: s.themePrimary || '#1A237E',
  }));
  res.json({ success: true, schools: list });
});

app.get('/api/studio/sessions', (req, res) => {
  const db = getDatabase();
  const school = req.query.school || 'live';
  if (school !== 'live' || !db) {
    return res.json({ success: true, sessions: ['2026/2027', '2025/2026'] });
  }
  let sessions = [];
  try {
    const rows = db.prepare(`
      SELECT DISTINCT academic_session FROM (
        SELECT academic_session FROM school_term_config WHERE id = 1
        UNION
        SELECT academic_session FROM term_calendars
        UNION
        SELECT academic_session FROM student_records
      ) WHERE academic_session IS NOT NULL AND length(academic_session) > 0
      ORDER BY academic_session DESC
    `).all();
    sessions = rows.map(r => r.academic_session).filter(Boolean);
  } catch (_) {}
  if (!sessions.length) sessions = ['2026/2027'];
  res.json({ success: true, sessions });
});

app.get('/api/studio/terms', (req, res) => {
  const db = getDatabase();
  const school = req.query.school || 'live';
  const session = req.query.session || '2026/2027';
  const includeDraft = req.query.includeDraft === '1' || req.query.includeDraft === 'true';

  if (school !== 'live' || !db) {
    const mockTerms = [
      { term: 'First Term', status: 'released', isProduced: true, label: 'First Term (Released)' },
      { term: 'Second Term', status: 'released', isProduced: true, label: 'Second Term (Released)' },
      ...(includeDraft ? [{ term: 'Third Term', status: 'draft_available', isProduced: false, label: 'Third Term (Draft / In-Progress)' }] : [])
    ];
    return res.json({ success: true, terms: mockTerms });
  }

  let terms = [];
  try {
    // 1. Identify which terms have officially produced and closed results
    let producedRows = [];
    try {
      producedRows = db.prepare(`
        SELECT DISTINCT term FROM term_calendars WHERE academic_session = ? AND is_closed = 1
      `).all(session);
    } catch (_) {}
    const producedSet = new Set(producedRows.map(r => r.term));

    // 2. Identify all candidate terms
    const candidateRows = db.prepare(`
      SELECT DISTINCT term FROM (
        SELECT term FROM term_calendars WHERE academic_session = ?
        UNION
        SELECT term FROM student_records WHERE academic_session = ?
        UNION
        SELECT term FROM ils_records WHERE academic_session = ?
        UNION
        SELECT term FROM school_term_config WHERE academic_session = ?
      ) WHERE term IS NOT NULL AND length(term) > 0
    `).all(session, session, session, session);

    for (const row of candidateRows) {
      const t = row.term;
      const isProduced = producedSet.has(t);

      // If includeDraft is false, skip terms that have not been produced/released
      if (!includeDraft && !isProduced) {
        continue;
      }

      let recordCount = 0;
      try {
        const countRow = db.prepare(`
          SELECT (
            (SELECT count(*) FROM student_records WHERE academic_session = ? AND term = ?) +
            (SELECT count(*) FROM ils_records WHERE academic_session = ? AND term = ?)
          ) as total
        `).get(session, t, session, t);
        recordCount = countRow?.total || 0;
      } catch (_) {}

      terms.push({
        term: t,
        status: isProduced ? 'released' : 'draft_available',
        isProduced,
        recordCount,
        label: isProduced ? `${t} (Released)` : `${t} (Draft / In-Progress — ${recordCount} marks)`
      });
    }

    const ORDER = { 'First Term': 1, 'Second Term': 2, 'Third Term': 3 };
    terms.sort((a, b) => (ORDER[a.term] || 99) - (ORDER[b.term] || 99));

    // If no terms released and draft is false, give helpful empty notice
    if (!terms.length && !includeDraft) {
      // Fallback: check if any draft terms exist
      const anyMarks = db.prepare(`SELECT count(*) as c FROM student_records WHERE academic_session = ?`).get(session)?.c || 0;
      if (anyMarks > 0) {
        // Return notice
      }
    }
  } catch (err) {
    console.warn('[Studio API] Failed to fetch terms:', err.message);
  }

  res.json({ success: true, terms });
});

app.get('/api/studio/classes', (req, res) => {
  const db = getDatabase();
  let classes = [];

  if (db) {
    try {
      const rows = db.prepare('SELECT DISTINCT class_name FROM students ORDER BY class_name ASC').all();
      classes = rows.map(r => r.class_name).filter(Boolean);
    } catch (err) {
      console.warn('[Studio API] Failed to fetch classes:', err.message);
    }
  }

  res.json({ success: true, classes });
});

app.get('/api/studio/students', (req, res) => {
  const db = getDatabase();
  const className = req.query.class;
  let students = [];

  if (db && className) {
    try {
      const rows = db.prepare(`
        SELECT id, name, admission_no, class_name, photo, COALESCE(class_arm, '') as class_arm
        FROM students
        WHERE class_name = ?
        ORDER BY name ASC
      `).all(className);

      students = rows.map(s => {
        let curriculumType = 'STANDARD_NIGERIAN';
        try {
          if (typeof database.getEffectiveCurriculum === 'function') {
            const eff = database.getEffectiveCurriculum(s.class_name, s.class_arm);
            curriculumType = eff.type || 'STANDARD_NIGERIAN';
          }
        } catch (_) {}
        return {
          id: s.id,
          name: s.name,
          admission_no: s.admission_no,
          class_name: s.class_name,
          curriculum_type: curriculumType,
          photo: s.photo || null,
        };
      });
    } catch (err) {
      console.warn('[Studio API] Failed to fetch students:', err.message);
    }
  }

  res.json({ success: true, students });
});

app.post('/api/studio/seed-demo', (req, res) => {
  const db = getDatabase();
  if (!db) {
    return res.status(500).json({ success: false, error: 'Database not connected.' });
  }

  try {
    const termConfig = reportAssembler.fetchTermConfig(db);
    const session = termConfig.academic_session || '2025/2026';
    const term = termConfig.term || 'First Term';

    db.transaction(() => {
      // Seed Demo Standard Student if not exists
      const stdId = 'STU-DEMO-001';
      db.prepare(`
        INSERT OR IGNORE INTO students (id, name, class_name, admission_no, created_at)
        VALUES (?, 'Chukwudi Emmanuel Okafor', 'JSS 2 Gold', 'STA/2025/0088', datetime('now'))
      `).run(stdId);

      const subjects = ['Mathematics', 'English Language', 'Basic Science', 'Social Studies', 'Civic Education'];
      for (const subj of subjects) {
        db.prepare(`
          INSERT OR REPLACE INTO student_records (student_id, subject, assessment, score, breakdown, academic_session, term)
          VALUES (?, ?, 'Terminal', 92, '{"ca1":18,"ca2":19,"exam":55}', ?, ?)
        `).run(stdId, subj, session, term);
      }

      // Seed Demo ILS Student
      const ilsId = 'ILS-DEMO-001';
      db.prepare(`
        INSERT OR IGNORE INTO students (id, name, class_name, admission_no, created_at)
        VALUES (?, 'Grace Morayo Adeyemi', 'ACE Learning Center', 'ILS/2025/0012', datetime('now'))
      `).run(ilsId);

      // Register ILS class config
      db.prepare(`
        INSERT OR REPLACE INTO class_configs (hierarchy_class, curriculum_type, pac_count)
        VALUES ('ACE Learning Center', 'ILS', 12)
      `).run();

      const ilsSubjs = ['Math', 'English', 'Science', 'Social Studies', 'Bible Reading'];
      for (const subj of ilsSubjs) {
        for (let pack = 1; pack <= 12; pack++) {
          db.prepare(`
            INSERT OR REPLACE INTO ils_records (student_id, academic_session, term, subject, pack_number, score, passed)
            VALUES (?, ?, ?, ?, ?, 96, 1)
          `).run(ilsId, session, term, subj, pack);
        }
      }
      db.prepare(`
        INSERT OR REPLACE INTO ils_verse_memory (student_id, academic_session, term, verse_count)
        VALUES (?, ?, ?, 36)
      `).run(ilsId, session, term);
    })();

    res.json({ success: true, message: 'Diagnostic demo students and records seeded successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Route: /render (Live Handlebars compile with SQLite Assembly) ─────────────
app.get('/render', (req, res) => {
  // Authentication gate for rendering
  if (!isRequestAuthenticated(req)) {
    return res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Diagnostic View Locked</title>
        <style>
          body { margin:0; height:100vh; display:flex; align-items:center; justify-content:center; background:#0A0E1A; font-family:'Segoe UI',sans-serif; color:#E2E8F0; }
          .lock-box { background:#131B2E; border:1px solid #EF4444; padding:36px; border-radius:16px; text-align:center; max-width:440px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.7); }
          .icon { font-size:44px; margin-bottom:12px; }
          h2 { color:#F87171; margin:0 0 10px 0; font-size:20px; font-weight:800; }
          p { font-size:13px; color:#94A3B8; line-height:1.6; margin:0; }
        </style>
      </head>
      <body>
        <div class="lock-box">
          <div class="icon">🔒</div>
          <h2>Diagnostic View Locked</h2>
          <p>This template preview is walled for developer diagnostics. Authenticate via the Studio master gate (${DEV_EMAIL}) to view live student ledgers.</p>
        </div>
      </body>
      </html>
    `);
  }

  const startTime = Date.now();
  const templateId = req.query.template || 'royal';
  const schoolId = req.query.school || 'live';
  const source = req.query.source || (schoolId === 'live' ? 'live' : 'mock'); // 'live' | 'mock'
  const studentId = req.query.studentId;
  const requestedSystem = req.query.system || 'standard_secondary';
  const useSchoolColors = req.query.brandColors !== '0';
  const feeStatus = req.query.feeStatus || 'cleared';
  const showAttendance = req.query.attendance !== '0';
  const showPosition = req.query.position !== '0';
  const stampStyle = req.query.stamp || 'classic_round';
  const selectedTerm = req.query.term || null;
  const selectedSession = req.query.session || null;

  try {
    let payload = null;
    const db = getDatabase();

    if (schoolId !== 'live' && SCHOOL_PRESETS[schoolId]) {
      const preset = SCHOOL_PRESETS[schoolId];
      payload = getMockPayload({
        system: requestedSystem,
        templateId,
        useSchoolColors,
        feeStatus,
        showAttendance,
        showPosition,
        stampStyle: preset.stampStyle || stampStyle,
      });
      payload.identity = {
        ...payload.identity,
        ...preset,
      };
      if (selectedTerm) payload.termConfig.term = selectedTerm;
      if (selectedSession) payload.termConfig.academic_session = selectedSession;
    } else if (source === 'live' && studentId && db) {
      // ── Assemble Live Data from Local SQLite ──
      const termConfig = reportAssembler.fetchTermConfig(db, {
        template: templateId,
        show_attendance: showAttendance ? 1 : 0,
        show_position: showPosition ? 1 : 0,
        show_domains: 1,
      }, selectedTerm, selectedSession);

      const effectiveTerm = selectedTerm || termConfig.term || 'First Term';
      const effectiveSession = selectedSession || termConfig.academic_session || '2026/2027';
      termConfig.term = effectiveTerm;
      termConfig.academic_session = effectiveSession;

      // ── Find all students in this student's class to calculate genuine class-scoped cohort rank ──
      const studentRow = db.prepare('SELECT id, class_name, class_arm FROM students WHERE id = ?').get(studentId);
      let cohortIds = [studentId];
      if (studentRow && studentRow.class_name) {
        const rawClass = studentRow.class_name.trim();
        const parts = rawClass.split(/\s+/);
        const baseClass = (parts.length >= 2 && /^(jss|sss|ss|js|pri|primary|basic|grade|kg|nursery|creche)$/i.test(parts[0]))
          ? `${parts[0]} ${parts[1]}`
          : rawClass;

        const classRows = db.prepare(
          `SELECT id FROM students WHERE (class_name = ? OR class_name LIKE ? OR class_name = ?) AND is_active = 1`
        ).all(rawClass, `${baseClass}%`, baseClass);

        if (classRows.length > 0) {
          cohortIds = Array.from(new Set(classRows.map(r => r.id)));
        }
      }

      const assembled = reportAssembler.assembleStudentsForReport(
        db,
        cohortIds,
        effectiveTerm,
        effectiveSession
      );

      if (assembled.students && assembled.students.length > 0) {
        // Pre-compute genuine class rankings across the assembled cohort
        if (assembled.students.length > 1 && rankingLib) {
          const origClassNames = new Map();
          assembled.students.forEach(s => {
            origClassNames.set(s.id, s.class_name);
            const p = (s.class_name || '').trim().split(/\s+/);
            if (p.length >= 2 && /^(jss|sss|ss|js|pri|primary|basic|grade|kg|nursery|creche)$/i.test(p[0])) {
              s.class_name = `${p[0]} ${p[1]}`;
            }
          });

          const rankMap = rankingLib.computeRankMap(assembled.students);
          assembled.students.forEach(s => {
            s.classPosition = rankMap.get(s.id) || "—";
            s.class_name = origClassNames.get(s.id);
          });
        }
        const student = assembled.students.find(s => s.id === studentId) || assembled.students[0];
        if (feeStatus) student.feeStatus = feeStatus;

        let deptMgrs = [];
        try {
          deptMgrs = db.prepare("SELECT * FROM department_managers ORDER BY id ASC").all() || [];
        } catch (_) {}

        payload = {
          identity: getSchoolIdentity(db),
          termConfig,
          departmentManagers: deptMgrs,
          students: [student],
          pac_labels: student.pac_labels || null,
          reportType: 'terminal',
          templateId,
          useSchoolColors,
          format: 'html',
        };
      }
    }

    // Fallback to Mock Data if requested or student record not found
    if (!payload) {
      payload = getMockPayload({
        system: requestedSystem,
        templateId,
        useSchoolColors,
        feeStatus,
        showAttendance,
        showPosition,
        stampStyle,
      });
      if (selectedTerm) payload.termConfig.term = selectedTerm;
      if (selectedSession) payload.termConfig.academic_session = selectedSession;
    }

    const isILS = (payload.students[0]?.curriculum_type === 'ILS') || (requestedSystem === 'ils');
    let html = '';
    // Pass null as tempDir so saveBase64Image keeps data: URIs inline instead of file://
    if (isILS) {
      html = reportCompiler.generateILSHTMLPages(payload, BASE_DIR, null);
    } else {
      html = reportCompiler.generateHTMLPages(payload, BASE_DIR, null);
    }

    const duration = Date.now() - startTime;
    res.setHeader('X-Render-Time-Ms', duration.toString());
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  } catch (err) {
    console.error(`[Preview Server] Render error:`, err);
    res.status(500).send(`
      <div style="font-family:sans-serif;padding:32px;background:#FEF2F2;border:2px solid #EF4444;border-radius:12px;margin:24px;color:#991B1B;">
        <h2 style="margin-top:0;">⚠️ Template Compilation Error</h2>
        <p><strong>Template:</strong> ${templateId}.hbs</p>
        <p><strong>Source:</strong> ${source}</p>
        <p><strong>Student ID:</strong> ${studentId || 'None'}</p>
        <pre style="background:#FFF;padding:16px;border-radius:8px;overflow-x:auto;border:1px solid #FCA5A5;">${err.stack || err.message}</pre>
      </div>
    `);
  }
});

// ── Route: / (Interactive Sandbox Studio UI) ─────────────────────────────────
app.get('/', (req, res) => {
  const templates = getAvailableTemplates();
  const authenticated = isRequestAuthenticated(req);
  const currentChallenge = getCurrentChallenge();

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nexus Diagnostic Studio & Template Sandbox</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #070B14;
      --panel: #0D1322;
      --panel-border: #1E293B;
      --accent: #00E5FF;
      --accent-hover: #38BDF8;
      --emerald: #10B981;
      --amber: #F59E0B;
      --red: #EF4444;
      --text: #F8FAFC;
      --text-muted: #94A3B8;
      --text-dim: #64748B;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: var(--bg);
      color: var(--text);
      display: flex;
      flex-direction: column;
      height: 100vh;
      overflow: hidden;
    }
    /* ── MS WORD FLUENT RIBBON STYLES ──────────────────────────────────── */
    header.ms-header {
      background: var(--panel);
      border-bottom: 1px solid var(--panel-border);
      display: flex;
      flex-direction: column;
      z-index: 50;
      flex-shrink: 0;
    }
    /* Title Bar */
    .ms-title-bar {
      height: 38px;
      background: #080D1A;
      border-bottom: 1px solid #1E293B;
      padding: 0 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .ms-brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .ms-app-tile {
      width: 24px;
      height: 24px;
      background: linear-gradient(135deg, #1D4ED8, #3B82F6);
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 900;
      font-size: 13px;
      color: #fff;
      box-shadow: 0 2px 6px rgba(37,99,235,0.4);
    }
    .ms-app-name {
      font-size: 13px;
      font-weight: 800;
      color: #F8FAFC;
      letter-spacing: -0.2px;
    }
    .ms-divider {
      color: #334155;
      font-size: 13px;
    }
    .ms-doc-title {
      font-size: 11.5px;
      font-weight: 600;
      color: var(--accent);
      background: rgba(0, 229, 255, 0.08);
      border: 1px solid rgba(0, 229, 255, 0.25);
      padding: 2px 10px;
      border-radius: 12px;
      max-width: 480px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .ms-title-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ms-quick-btn {
      background: #131C2E;
      border: 1px solid #334155;
      color: #F8FAFC;
      width: 26px;
      height: 26px;
      border-radius: 4px;
      font-size: 12px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
    }
    .ms-quick-btn:hover {
      background: #1E293B;
      border-color: var(--accent);
    }
    .ms-user-chip {
      display: flex;
      align-items: center;
      gap: 6px;
      background: #131C2E;
      border: 1px solid #1E293B;
      padding: 3px 10px;
      border-radius: 9999px;
      font-size: 11px;
      color: var(--text-muted);
    }
    .ms-status-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: var(--emerald);
      box-shadow: 0 0 6px var(--emerald);
    }
    .ms-status-dot.offline {
      background: var(--amber);
      box-shadow: 0 0 6px var(--amber);
    }
    .ms-lock-btn {
      background: rgba(239, 68, 68, 0.12);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #FCA5A5;
      padding: 3px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    .ms-lock-btn:hover {
      background: rgba(239, 68, 68, 0.25);
    }

    /* Ribbon Tabs Strip */
    .ms-ribbon-tabs {
      height: 32px;
      background: #0B1120;
      border-bottom: 1px solid #1E293B;
      padding: 0 12px;
      display: flex;
      align-items: center;
      gap: 2px;
    }
    .ms-ribbon-tab {
      background: transparent;
      border: none;
      border-bottom: 2px solid transparent;
      color: #94A3B8;
      font-size: 12px;
      font-weight: 600;
      padding: 6px 14px;
      cursor: pointer;
      transition: all 0.12s ease;
      letter-spacing: -0.1px;
    }
    .ms-ribbon-tab:hover {
      color: #F8FAFC;
      background: rgba(255, 255, 255, 0.03);
    }
    .ms-ribbon-tab.active {
      color: var(--accent);
      font-weight: 700;
      border-bottom-color: var(--accent);
      background: rgba(0, 229, 255, 0.06);
    }

    /* Ribbon Command Bar Body */
    .ms-ribbon-body {
      min-height: 84px;
      background: #0D1322;
      border-bottom: 1px solid #1E293B;
      padding: 8px 16px;
      display: flex;
      align-items: stretch;
    }
    .ms-ribbon-panel {
      display: none;
      width: 100%;
      align-items: stretch;
      gap: 16px;
    }
    .ms-ribbon-panel.active {
      display: flex;
    }

    /* Command Groups */
    .ms-group {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border-right: 1px solid #1E293B;
      padding-right: 16px;
      min-width: max-content;
    }
    .ms-group:last-child {
      border-right: none;
      padding-right: 0;
    }
    .ms-group-controls {
      display: flex;
      align-items: center;
      gap: 10px;
      flex: 1;
    }
    .ms-group-title {
      font-size: 9px;
      font-weight: 800;
      color: #64748B;
      text-align: center;
      letter-spacing: 0.8px;
      text-transform: uppercase;
      padding-top: 5px;
    }

    /* Controls & Inputs */
    .ms-field {
      display: flex;
      flex-direction: column;
      gap: 3px;
    }
    .ms-label {
      font-size: 9.5px;
      font-weight: 700;
      color: #94A3B8;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .ms-select {
      background: #080D1A;
      color: #FFF;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 5px 8px;
      font-size: 11.5px;
      font-weight: 600;
      cursor: pointer;
      outline: none;
      transition: all 0.15s ease;
    }
    .ms-select:focus {
      border-color: var(--accent);
      box-shadow: 0 0 0 2px rgba(0, 229, 255, 0.2);
    }
    .ms-select-wide {
      min-width: 190px;
    }
    .ms-select-medium {
      min-width: 140px;
    }
    .ms-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ms-checkbox-label {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 600;
      color: #38BDF8;
      cursor: pointer;
      user-select: none;
      margin-top: 4px;
      background: rgba(56, 189, 248, 0.08);
      border: 1px solid rgba(56, 189, 248, 0.25);
      padding: 3px 8px;
      border-radius: 4px;
      transition: all 0.15s ease;
    }
    .ms-checkbox-label:hover {
      background: rgba(56, 189, 248, 0.15);
    }
    .ms-checkbox-label input[type="checkbox"] {
      accent-color: var(--accent);
      width: 13px;
      height: 13px;
      cursor: pointer;
    }

    /* Buttons */
    .ms-btn-row {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .ms-tool-btn {
      background: #080D1A;
      border: 1px solid #334155;
      color: #94A3B8;
      padding: 6px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.15s ease;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .ms-tool-btn:hover {
      background: #131C2E;
      color: #F8FAFC;
    }
    .ms-tool-btn.active {
      background: rgba(0, 229, 255, 0.12);
      border-color: var(--accent);
      color: var(--accent);
    }
    .ms-action-primary {
      background: var(--accent);
      color: #080D1A;
      border: none;
      padding: 7px 14px;
      border-radius: 6px;
      font-size: 11.5px;
      font-weight: 800;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s ease;
      box-shadow: 0 2px 10px rgba(0, 229, 255, 0.3);
    }
    .ms-action-primary:hover {
      background: var(--accent-hover);
      transform: translateY(-1px);
    }
    .ms-action-btn {
      background: #131C2E;
      color: #F8FAFC;
      border: 1px solid #334155;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s ease;
    }
    .ms-action-btn:hover {
      background: #1E293B;
      border-color: #475569;
    }
    .ms-icon {
      font-size: 13px;
    }

    main {
      flex: 1;
      display: flex;
      background: #030712;
      position: relative;
      overflow: hidden;
    }
    .viewport-container {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      overflow: auto;
      padding: 24px;
    }
    .paper-frame {
      background: #ffffff;
      box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(255, 255, 255, 0.1);
      transform-origin: top center;
      transition: transform 0.12s ease-out;
      margin-bottom: 50px;
      position: relative;
    }
    iframe {
      width: 100%;
      height: 100%;
      border: none;
      display: block;
      background: #fff;
    }

    footer {
      background: var(--panel);
      border-top: 1px solid var(--panel-border);
      padding: 6px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 11px;
      color: var(--text-muted);
      z-index: 50;
      flex-shrink: 0;
    }
    .status-left, .status-right {
      display: flex;
      align-items: center;
      gap: 14px;
    }
    .status-indicator {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--emerald);
      box-shadow: 0 0 8px var(--emerald);
    }
    .status-indicator.offline {
      background: var(--amber);
      box-shadow: 0 0 8px var(--amber);
    }

    /* ── AUTH GATE MODAL OVERLAY ────────────────────────────────────────── */
    .auth-overlay {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(3, 7, 18, 0.88);
      backdrop-filter: blur(8px);
      z-index: 1000;
      display: ${authenticated ? 'none' : 'flex'};
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .auth-card {
      background: #0D1322;
      border: 1px solid #1E293B;
      border-radius: 16px;
      width: 100%;
      max-width: 460px;
      box-shadow: 0 25px 60px -10px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(0, 229, 255, 0.2);
      overflow: hidden;
    }
    .auth-header {
      padding: 20px 24px;
      background: linear-gradient(180deg, #131C2E 0%, #0D1322 100%);
      border-bottom: 1px solid #1E293B;
      text-align: center;
    }
    .auth-header .lock-icon {
      font-size: 32px;
      margin-bottom: 6px;
    }
    .auth-header h2 {
      font-size: 17px;
      font-weight: 800;
      color: #fff;
      letter-spacing: -0.3px;
    }
    .auth-header p {
      font-size: 11.5px;
      color: var(--text-muted);
      margin-top: 3px;
    }
    .auth-tabs {
      display: flex;
      background: #080C16;
      border-bottom: 1px solid #1E293B;
    }
    .auth-tab {
      flex: 1;
      padding: 10px 4px;
      font-size: 11px;
      font-weight: 700;
      text-align: center;
      color: var(--text-dim);
      background: transparent;
      border: none;
      cursor: pointer;
      border-bottom: 2px solid transparent;
      transition: all 0.15s ease;
    }
    .auth-tab.active {
      color: var(--accent);
      border-bottom-color: var(--accent);
      background: rgba(0, 229, 255, 0.05);
    }
    .auth-body {
      padding: 20px 24px;
    }
    .tab-content {
      display: none;
    }
    .tab-content.active {
      display: block;
    }
    .form-group {
      margin-bottom: 14px;
    }
    .form-group label {
      display: block;
      font-size: 11px;
      font-weight: 700;
      color: var(--text-muted);
      margin-bottom: 5px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .form-group input {
      width: 100%;
      background: #080C16;
      border: 1px solid #334155;
      border-radius: 8px;
      padding: 8px 12px;
      color: #fff;
      font-size: 13px;
      outline: none;
    }
    .form-group input:focus {
      border-color: var(--accent);
      box-shadow: 0 0 0 2px rgba(0, 229, 255, 0.2);
    }
    .challenge-badge {
      background: #080C16;
      border: 1px dashed var(--accent);
      border-radius: 8px;
      padding: 12px;
      text-align: center;
      margin-bottom: 14px;
    }
    .challenge-code {
      font-family: 'JetBrains Mono', monospace;
      font-size: 22px;
      font-weight: 800;
      color: var(--accent);
      letter-spacing: 4px;
    }
    .auth-btn {
      width: 100%;
      background: var(--accent);
      color: #0D1322;
      border: none;
      border-radius: 8px;
      padding: 10px;
      font-size: 12.5px;
      font-weight: 800;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    .auth-btn:hover {
      background: var(--accent-hover);
    }
    .auth-error {
      margin-top: 12px;
      padding: 8px 12px;
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid var(--red);
      border-radius: 6px;
      font-size: 11.5px;
      color: #FCA5A5;
      display: none;
    }
    .auth-success {
      margin-top: 12px;
      padding: 8px 12px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid var(--emerald);
      border-radius: 6px;
      font-size: 11.5px;
      color: #6EE7B7;
      display: none;
    }
  </style>
</head>
<body>

  <!-- ── AUTHENTICATION MODAL ──────────────────────────────────────────────── -->
  <div class="auth-overlay" id="authOverlay">
    <div class="auth-card">
      <div class="auth-header">
        <div class="lock-icon">🔒</div>
        <h2>Nexus Diagnostic Studio</h2>
        <p>Restricted Developer Environment &bull; brytebee@gmail.com</p>
      </div>

      <div class="auth-tabs">
        <button class="auth-tab active" data-tab="tabPassword">Passcode</button>
        <button class="auth-tab" data-tab="tabChallenge">Offline Challenge</button>
        <button class="auth-tab" data-tab="tabEmail">Email OTP</button>
        <button class="auth-tab" data-tab="tabReset">Update Vault</button>
      </div>

      <div class="auth-body">
        <!-- Tab 1: Password Login -->
        <div class="tab-content active" id="tabPassword">
          <div class="form-group">
            <label>Developer Email</label>
            <input type="text" id="loginEmail" value="${DEV_EMAIL}" readonly>
          </div>
          <div class="form-group">
            <label>Master Passcode / Developer PIN</label>
            <input type="password" id="loginPassword" placeholder="Enter master secret..." autofocus>
          </div>
          <button class="auth-btn" id="loginBtn">Unlock Diagnostic Studio</button>
        </div>

        <!-- Tab 2: Offline Challenge-Response -->
        <div class="tab-content" id="tabChallenge">
          <div class="challenge-badge">
            <div style="font-size:10px;color:var(--text-dim);margin-bottom:4px;text-transform:uppercase;font-weight:700;">Active 15-Min Challenge Code</div>
            <div class="challenge-code" id="challengeDisplay">${currentChallenge}</div>
          </div>
          <div class="form-group">
            <label>Response Verification Code</label>
            <input type="text" id="challengeResponse" placeholder="Enter 6-digit response key...">
          </div>
          <button class="auth-btn" id="challengeBtn">Verify Offline Response</button>
        </div>

        <!-- Tab 3: Email OTP -->
        <div class="tab-content" id="tabEmail">
          <p style="font-size:12px;color:var(--text-muted);margin-bottom:12px;line-height:1.5;">
            Send a 6-digit verification code to <strong>${DEV_EMAIL}</strong> (Logged in local server console in offline dev mode).
          </p>
          <div style="margin-bottom:12px;">
            <button class="secondary-btn" style="width:100%;justify-content:center;padding:8px;" id="sendOtpBtn">📧 Send Verification OTP</button>
          </div>
          <div class="form-group">
            <label>6-Digit Verification OTP</label>
            <input type="text" id="emailOtpInput" placeholder="Enter OTP code...">
          </div>
          <button class="auth-btn" id="verifyOtpBtn">Verify & Unlock</button>
        </div>

        <!-- Tab 4: Reset Credentials -->
        <div class="tab-content" id="tabReset">
          <p style="font-size:11.5px;color:var(--text-muted);margin-bottom:12px;line-height:1.4;">
            Rotate developer master passcode. Requires verified Email OTP.
          </p>
          <div class="form-group">
            <label>Active Verification OTP</label>
            <input type="text" id="resetOtp" placeholder="Enter OTP from email / console...">
          </div>
          <div class="form-group">
            <label>New Master Passcode</label>
            <input type="password" id="resetNewPass" placeholder="Min 6 characters...">
          </div>
          <button class="auth-btn" id="resetBtn">Update Credentials Vault</button>
        </div>

        <div class="auth-error" id="authError"></div>
        <div class="auth-success" id="authSuccess"></div>
      </div>
    </div>
  </div>

  <!-- ── MS WORD FLUENT RIBBON HEADER ────────────────────────────────────── -->
  <header class="ms-header">
    <!-- Top Bar: Window Title & Brand -->
    <div class="ms-title-bar">
      <div class="ms-brand">
        <div class="ms-app-tile">⚡</div>
        <span class="ms-app-name">Nexus School OS</span>
        <span class="ms-divider">|</span>
        <span class="ms-doc-title" id="activeDocTitle">📄 Result Studio Pro</span>
      </div>

      <!-- Quick Access Actions & User Profile -->
      <div class="ms-title-actions">
        <button class="ms-quick-btn" id="quickRefreshBtn" title="Re-compile (Cmd+R)">🔄</button>
        <button class="ms-quick-btn" id="quickPrintBtn" title="Print to PDF (Cmd+P)">🖨️</button>
        <button class="ms-quick-btn" id="quickNewTabBtn" title="Open in browser window">↗</button>
        <div class="ms-user-chip">
          <span class="ms-status-dot" id="headerStatusDot"></span>
          <span class="ms-user-email">${DEV_EMAIL}</span>
        </div>
        <button class="ms-lock-btn" id="logoutBtn" title="Lock Studio">🔒 Lock</button>
      </div>
    </div>

    <!-- Ribbon Tabs Header -->
    <nav class="ms-ribbon-tabs">
      <button class="ms-ribbon-tab active" data-ribbon="ribbonHome">Home / Data Source</button>
      <button class="ms-ribbon-tab" data-ribbon="ribbonLayout">Layout & Template</button>
      <button class="ms-ribbon-tab" data-ribbon="ribbonReview">Review & Overrides</button>
      <button class="ms-ribbon-tab" data-ribbon="ribbonExport">Export & Actions</button>
    </nav>

    <!-- Ribbon Command Bar Body -->
    <div class="ms-ribbon-body">
      <!-- TAB 1: HOME / DATA SOURCE -->
      <div class="ms-ribbon-panel active" id="ribbonHome">
        <!-- Group 1: School & Source -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-field">
              <label class="ms-label">School Brand</label>
              <select id="schoolSelect" class="ms-select ms-select-wide">
                <option value="live">🟢 Dapson Memorial Schools (Live DB)</option>
                <option value="apex_demo">🟣 Apex British Academy (Gold)</option>
                <option value="prestige_demo">🟢 Prestige Collegiate (Diamond)</option>
                <option value="royal_demo">🔵 Royal Crown Academy (Silver)</option>
              </select>
            </div>
            <div class="ms-field">
              <label class="ms-label">Data Mode</label>
              <select id="sourceSelect" class="ms-select">
                <option value="live">🟢 Live SQLite Database</option>
                <option value="mock">🟡 Mock Payloads</option>
              </select>
            </div>
          </div>
          <div class="ms-group-title">SCHOOL & DATA SOURCE</div>
        </div>

        <!-- Group 2: Academic Period & Draft Grade Check -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-row">
              <div class="ms-field">
                <label class="ms-label">Session</label>
                <select id="sessionSelect" class="ms-select">
                  <option value="2026/2027">2026/2027</option>
                </select>
              </div>
              <div class="ms-field">
                <label class="ms-label">Academic Term</label>
                <select id="termSelect" class="ms-select ms-select-medium">
                  <option value="First Term">Loading terms...</option>
                </select>
              </div>
            </div>
            <label class="ms-checkbox-label" title="Pull raw draft grades and unproduced results from student records">
              <input type="checkbox" id="includeDraftCheck">
              <span>Include Unproduced / Draft Terms</span>
            </label>
          </div>
          <div class="ms-group-title">ACADEMIC PERIOD</div>
        </div>

        <!-- Group 3: Student Roster -->
        <div class="ms-group" id="studentRosterGroup">
          <div class="ms-group-controls">
            <div class="ms-field" id="classControlGroup">
              <label class="ms-label">Class</label>
              <select id="classSelect" class="ms-select">
                <option value="">Loading classes...</option>
              </select>
            </div>
            <div class="ms-field" id="studentControlGroup">
              <label class="ms-label">Student</label>
              <select id="studentSelect" class="ms-select ms-select-wide">
                <option value="">Select class first...</option>
              </select>
            </div>
          </div>
          <div class="ms-group-title">STUDENT ROSTER</div>
        </div>
      </div>

      <!-- TAB 2: LAYOUT & TEMPLATE -->
      <div class="ms-ribbon-panel" id="ribbonLayout">
        <!-- Group 1: Template Selection -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-field">
              <label class="ms-label">Template Engine</label>
              <select id="templateSelect" class="ms-select ms-select-medium">
                ${templates.map(t => `<option value="${t.id}" ${t.id === 'royal' ? 'selected' : ''}>${t.name} (${t.hasILS ? 'ILS & Std' : 'Standard'})</option>`).join('\n                ')}
              </select>
            </div>
            <div class="ms-field">
              <label class="ms-label">Curriculum / System</label>
              <select id="systemSelect" class="ms-select">
                <option value="standard_secondary">Standard Secondary</option>
                <option value="standard_primary">Standard Primary</option>
                <option value="ils">ILS / ACE (Landscape)</option>
              </select>
            </div>
          </div>
          <div class="ms-group-title">TEMPLATE & SYSTEM</div>
        </div>

        <!-- Group 2: Appearance & Canvas -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-btn-row">
              <button class="ms-tool-btn active" id="brandToggle" title="Toggle Brand Theme Colors">
                <span class="ms-icon">🎨</span>
                <span>School Colors</span>
              </button>
            </div>
            <div class="ms-field">
              <label class="ms-label">Canvas Zoom</label>
              <select id="zoomSelect" class="ms-select">
                <option value="0.5">50%</option>
                <option value="0.75">75%</option>
                <option value="0.85" selected>85%</option>
                <option value="1.0">100%</option>
                <option value="1.25">125%</option>
              </select>
            </div>
          </div>
          <div class="ms-group-title">APPEARANCE & CANVAS</div>
        </div>
      </div>

      <!-- TAB 3: REVIEW & OVERRIDES -->
      <div class="ms-ribbon-panel" id="ribbonReview">
        <!-- Group 1: Financial Clearance -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-btn-row">
              <button class="ms-tool-btn" id="feeToggle" title="Toggle Fee Status (Owing / Cleared)">
                <span class="ms-icon">💳</span>
                <span>Tuition Owing</span>
              </button>
            </div>
          </div>
          <div class="ms-group-title">FINANCE OVERRIDE</div>
        </div>

        <!-- Group 2: Report Metrics -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-btn-row">
              <button class="ms-tool-btn active" id="attToggle" title="Toggle Attendance Breakdown">
                <span class="ms-icon">📅</span>
                <span>Attendance</span>
              </button>
              <button class="ms-tool-btn active" id="posToggle" title="Toggle Position Ranking">
                <span class="ms-icon">🏆</span>
                <span>Position</span>
              </button>
            </div>
          </div>
          <div class="ms-group-title">METRICS & RANKING</div>
        </div>

        <!-- Group 3: Signatures & Seals -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-field">
              <label class="ms-label">Stamp & Seal Style</label>
              <select id="stampSelect" class="ms-select">
                <option value="classic_round">Classic Round</option>
                <option value="embossed_crest">Embossed Crest</option>
                <option value="minimal_sig">Minimalist</option>
                <option value="none">None</option>
              </select>
            </div>
          </div>
          <div class="ms-group-title">SIGNATURES & SEALS</div>
        </div>
      </div>

      <!-- TAB 4: EXPORT & ACTIONS -->
      <div class="ms-ribbon-panel" id="ribbonExport">
        <!-- Group 1: Document Output -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-btn-row">
              <button class="ms-action-primary" id="refreshBtn" title="Re-compile (Cmd+R)">
                <span class="ms-icon">🔄</span>
                <span>Re-compile</span>
              </button>
              <button class="ms-action-btn" id="printBtn" title="Print to PDF (Cmd+P)">
                <span class="ms-icon">🖨️</span>
                <span>Print / PDF</span>
              </button>
              <button class="ms-action-btn" id="openNewTabBtn" title="Open in browser window">
                <span class="ms-icon">↗</span>
                <span>Popout Window</span>
              </button>
            </div>
          </div>
          <div class="ms-group-title">DOCUMENT OUTPUT</div>
        </div>

        <!-- Group 2: Diagnostics & Tools -->
        <div class="ms-group">
          <div class="ms-group-controls">
            <div class="ms-btn-row">
              <button class="ms-action-btn" id="seedDemoBtn" title="Seed Demo Records in SQLite">
                <span class="ms-icon">🌱</span>
                <span>Seed Demo Data</span>
              </button>
              <button class="ms-action-btn" id="openVaultBtn" title="Open Credentials & OTP Vault">
                <span class="ms-icon">🔐</span>
                <span>Security Vault</span>
              </button>
            </div>
          </div>
          <div class="ms-group-title">DIAGNOSTICS & TOOLS</div>
        </div>
      </div>
    </div>
  </header>

  <!-- ── MAIN VIEWPORT CANVAS ──────────────────────────────────────────────── -->
  <main>
    <div class="viewport-container">
      <div class="paper-frame" id="paperFrame">
        <iframe id="previewFrame" src="about:blank"></iframe>
      </div>
    </div>
  </main>

  <!-- ── STATUS FOOTER ─────────────────────────────────────────────────────── -->
  <footer>
    <div class="status-left">
      <div style="display:flex;align-items:center;gap:6px;">
        <span class="status-indicator" id="statusIndicator"></span>
        <span id="dbStatusLabel">Connecting to SQLite...</span>
      </div>
      <span id="statusText">Ready</span>
    </div>
    <div class="status-right">
      <span id="activeStudentLabel" style="font-weight:700;color:var(--accent);">Mock Student</span>
      <span id="dimensionLabel">210mm × 297mm (Portrait A4)</span>
      <span id="renderTimeLabel">-- ms</span>
    </div>
  </footer>

  <!-- ── CLIENT CONTROLLER LOGIC ───────────────────────────────────────────── -->
  <script>
    // DOM Elements
    const authOverlay = document.getElementById('authOverlay');
    const authTabs = document.querySelectorAll('.auth-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const authError = document.getElementById('authError');
    const authSuccess = document.getElementById('authSuccess');

    const ribbonTabs = document.querySelectorAll('.ms-ribbon-tab');
    const ribbonPanels = document.querySelectorAll('.ms-ribbon-panel');

    const schoolSelect = document.getElementById('schoolSelect');
    const sourceSelect = document.getElementById('sourceSelect');
    const sessionSelect = document.getElementById('sessionSelect');
    const termSelect = document.getElementById('termSelect');
    const includeDraftCheck = document.getElementById('includeDraftCheck');
    const studentRosterGroup = document.getElementById('studentRosterGroup');
    const classControlGroup = document.getElementById('classControlGroup');
    const studentControlGroup = document.getElementById('studentControlGroup');
    const classSelect = document.getElementById('classSelect');
    const studentSelect = document.getElementById('studentSelect');

    const templateSelect = document.getElementById('templateSelect');
    const systemSelect = document.getElementById('systemSelect');
    const stampSelect = document.getElementById('stampSelect');
    const zoomSelect = document.getElementById('zoomSelect');

    const brandToggle = document.getElementById('brandToggle');
    const feeToggle = document.getElementById('feeToggle');
    const attToggle = document.getElementById('attToggle');
    const posToggle = document.getElementById('posToggle');

    const refreshBtn = document.getElementById('refreshBtn');
    const quickRefreshBtn = document.getElementById('quickRefreshBtn');
    const printBtn = document.getElementById('printBtn');
    const quickPrintBtn = document.getElementById('quickPrintBtn');
    const openNewTabBtn = document.getElementById('openNewTabBtn');
    const quickNewTabBtn = document.getElementById('quickNewTabBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const seedDemoBtn = document.getElementById('seedDemoBtn');
    const openVaultBtn = document.getElementById('openVaultBtn');

    const previewFrame = document.getElementById('previewFrame');
    const paperFrame = document.getElementById('paperFrame');
    const statusText = document.getElementById('statusText');
    const dbStatusLabel = document.getElementById('dbStatusLabel');
    const dimensionLabel = document.getElementById('dimensionLabel');
    const renderTimeLabel = document.getElementById('renderTimeLabel');
    const activeStudentLabel = document.getElementById('activeStudentLabel');
    const activeDocTitle = document.getElementById('activeDocTitle');
    const headerStatusDot = document.getElementById('headerStatusDot');

    let brandColors = true;
    let feeOwing = false;
    let attendance = true;
    let position = true;
    let isAuthenticated = ${authenticated};

    // ── Ribbon Tab Switching ─────────────────────────────────────────────────
    ribbonTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        ribbonTabs.forEach(t => t.classList.remove('active'));
        ribbonPanels.forEach(p => p.classList.remove('active'));
        tab.classList.add('active');
        const target = document.getElementById(tab.dataset.ribbon);
        if (target) target.classList.add('active');
      });
    });

    // ── Auth Modal Tabs ──────────────────────────────────────────────────────
    authTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        authTabs.forEach(t => t.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(tab.dataset.tab).classList.add('active');
        hideAuthMessages();
      });
    });

    function showAuthError(msg) {
      authError.textContent = msg;
      authError.style.display = 'block';
      authSuccess.style.display = 'none';
    }

    function showAuthSuccess(msg) {
      authSuccess.textContent = msg;
      authSuccess.style.display = 'block';
      authError.style.display = 'none';
    }

    function hideAuthMessages() {
      authError.style.display = 'none';
      authSuccess.style.display = 'none';
    }

    // ── Auth Actions ─────────────────────────────────────────────────────────
    document.getElementById('loginBtn').addEventListener('click', async () => {
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;
      if (!password) return showAuthError('Please enter password.');

      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (data.success) {
          onAuthSuccess(data.token);
        } else {
          showAuthError(data.error || 'Authentication failed');
        }
      } catch (err) {
        showAuthError('Connection error: ' + err.message);
      }
    });

    document.getElementById('challengeBtn').addEventListener('click', async () => {
      const challenge = document.getElementById('challengeDisplay').textContent.trim();
      const responseCode = document.getElementById('challengeResponse').value.trim();
      if (!responseCode) return showAuthError('Please enter response code.');

      try {
        const res = await fetch('/api/auth/challenge-verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ challenge, responseCode })
        });
        const data = await res.json();
        if (data.success) {
          onAuthSuccess(data.token);
        } else {
          showAuthError(data.error || 'Invalid challenge response');
        }
      } catch (err) {
        showAuthError('Challenge verification error: ' + err.message);
      }
    });

    document.getElementById('sendOtpBtn').addEventListener('click', async () => {
      try {
        const res = await fetch('/api/auth/request-otp', { method: 'POST' });
        const data = await res.json();
        if (data.success) {
          showAuthSuccess('Verification code sent! (Check console for local dev mode)');
        } else {
          showAuthError(data.error);
        }
      } catch (err) {
        showAuthError(err.message);
      }
    });

    document.getElementById('verifyOtpBtn').addEventListener('click', async () => {
      const otp = document.getElementById('emailOtpInput').value.trim();
      if (!otp) return showAuthError('Please enter the 6-digit OTP code.');

      try {
        const res = await fetch('/api/auth/verify-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ otp })
        });
        const data = await res.json();
        if (data.success) {
          onAuthSuccess(data.token);
        } else {
          showAuthError(data.error || 'Invalid OTP code');
        }
      } catch (err) {
        showAuthError(err.message);
      }
    });

    document.getElementById('resetBtn').addEventListener('click', async () => {
      const otp = document.getElementById('resetOtp').value.trim();
      const newPassword = document.getElementById('resetNewPass').value.trim();
      if (!otp || !newPassword) return showAuthError('OTP and new password required.');

      try {
        const res = await fetch('/api/auth/update-credentials', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ otp, newPassword })
        });
        const data = await res.json();
        if (data.success) {
          showAuthSuccess('Password updated successfully!');
          setTimeout(() => onAuthSuccess(data.token), 1000);
        } else {
          showAuthError(data.error || 'Failed to update credentials.');
        }
      } catch (err) {
        showAuthError(err.message);
      }
    });

    logoutBtn.addEventListener('click', async () => {
      try {
        await fetch('/api/auth/logout', { method: 'POST' });
      } catch (_) {}
      isAuthenticated = false;
      authOverlay.style.display = 'flex';
      previewFrame.src = 'about:blank';
    });

    if (openVaultBtn) {
      openVaultBtn.addEventListener('click', () => {
        authOverlay.style.display = 'flex';
      });
    }

    if (seedDemoBtn) {
      seedDemoBtn.addEventListener('click', async () => {
        seedDemoBtn.disabled = true;
        seedDemoBtn.textContent = '🌱 Seeding...';
        try {
          const res = await fetch('/api/studio/seed-demo', { method: 'POST' });
          const data = await res.json();
          if (data.success) {
            alert('Diagnostic demo records seeded successfully!');
            await loadClasses();
            await loadSessionsAndTerms();
          } else {
            alert('Seed error: ' + data.error);
          }
        } catch (err) {
          alert('Network error: ' + err.message);
        } finally {
          seedDemoBtn.disabled = false;
          seedDemoBtn.innerHTML = '<span class="ms-icon">🌱</span><span>Seed Demo Data</span>';
        }
      });
    }

    function onAuthSuccess(token) {
      isAuthenticated = true;
      authOverlay.style.display = 'none';
      initializeStudioData();
    }

    // ── Toggle Controls ──────────────────────────────────────────────────────
    brandToggle.addEventListener('click', () => {
      brandColors = !brandColors;
      brandToggle.classList.toggle('active', brandColors);
      updatePreview();
    });

    feeToggle.addEventListener('click', () => {
      feeOwing = !feeOwing;
      feeToggle.classList.toggle('active', feeOwing);
      updatePreview();
    });

    attToggle.addEventListener('click', () => {
      attendance = !attendance;
      attToggle.classList.toggle('active', attendance);
      updatePreview();
    });

    posToggle.addEventListener('click', () => {
      position = !position;
      posToggle.classList.toggle('active', position);
      updatePreview();
    });

    [templateSelect, systemSelect, stampSelect].forEach(el => el.addEventListener('change', () => {
      updateDocTitle();
      updatePreview();
    }));

    zoomSelect.addEventListener('change', () => {
      applyZoom(parseFloat(zoomSelect.value));
    });

    function applyZoom(zoom) {
      paperFrame.style.transform = 'scale(' + zoom + ')';
    }

    schoolSelect.addEventListener('change', () => {
      const isLive = schoolSelect.value === 'live';
      if (isLive) {
        sourceSelect.value = 'live';
        studentRosterGroup.style.display = 'flex';
        loadClasses();
        loadTerms();
      } else {
        sourceSelect.value = 'mock';
        studentRosterGroup.style.display = 'none';
        const opt = schoolSelect.options[schoolSelect.selectedIndex];
        activeStudentLabel.textContent = opt ? opt.textContent : 'Demo Student';
        loadTerms();
      }
    });

    sourceSelect.addEventListener('change', () => {
      const isLive = sourceSelect.value === 'live';
      studentRosterGroup.style.display = isLive ? 'flex' : 'none';
      if (isLive) {
        loadClasses();
      } else {
        activeStudentLabel.textContent = 'Mock Student';
        updateDocTitle();
        updatePreview();
      }
    });

    // ── Dynamic Sessions & Terms ─────────────────────────────────────────────
    async function loadSessionsAndTerms() {
      try {
        const res = await fetch('/api/studio/sessions');
        const data = await res.json();
        sessionSelect.innerHTML = '';
        if (data.sessions && data.sessions.length > 0) {
          data.sessions.forEach(sess => {
            const opt = document.createElement('option');
            opt.value = sess;
            opt.textContent = sess;
            sessionSelect.appendChild(opt);
          });
        } else {
          sessionSelect.innerHTML = '<option value="2026/2027">2026/2027</option>';
        }
      } catch (err) {
        console.warn('Failed to load sessions:', err);
        sessionSelect.innerHTML = '<option value="2026/2027">2026/2027</option>';
      }
      await loadTerms();
    }

    async function loadTerms() {
      const school = schoolSelect.value || 'live';
      const session = sessionSelect.value || '2026/2027';
      const includeDraft = includeDraftCheck.checked;

      try {
        const res = await fetch('/api/studio/terms?school=' + encodeURIComponent(school) +
                                '&session=' + encodeURIComponent(session) +
                                '&includeDraft=' + (includeDraft ? '1' : '0'));
        const data = await res.json();
        const prevTerm = termSelect.value;
        termSelect.innerHTML = '';

        if (data.terms && data.terms.length > 0) {
          data.terms.forEach(t => {
            const opt = document.createElement('option');
            opt.value = t.term;
            opt.textContent = t.label || t.term;
            if (!t.isProduced) {
              opt.style.color = '#F59E0B'; // Amber highlight for draft/in-progress terms
            }
            termSelect.appendChild(opt);
          });
          // Restore previous selection if still available
          if (prevTerm && Array.from(termSelect.options).some(o => o.value === prevTerm)) {
            termSelect.value = prevTerm;
          }
        } else {
          termSelect.innerHTML = '<option value="First Term">First Term</option>';
        }
      } catch (err) {
        console.warn('Failed to load terms:', err);
        termSelect.innerHTML = '<option value="First Term">First Term</option>';
      }
      updateDocTitle();
      updatePreview();
    }

    sessionSelect.addEventListener('change', () => {
      loadTerms();
    });

    termSelect.addEventListener('change', () => {
      updateDocTitle();
      updatePreview();
    });

    includeDraftCheck.addEventListener('change', () => {
      loadTerms();
    });

    // ── Active Document Pill Updater ─────────────────────────────────────────
    function updateDocTitle() {
      if (!activeDocTitle) return;
      const tName = templateSelect.options[templateSelect.selectedIndex]?.text.split(' ')[0] || 'Template';
      const isLive = schoolSelect.value === 'live';
      const schoolName = isLive ? 'Dapson Memorial' : (schoolSelect.options[schoolSelect.selectedIndex]?.text.split(' ')[1] || 'Demo');
      const sName = isLive ? (studentSelect.options[studentSelect.selectedIndex]?.text.split(' ')[0] || 'Student') : 'Demo';
      const sess = sessionSelect.value || '2026/2027';
      const trm = termSelect.value || 'Term';
      activeDocTitle.textContent = '📄 ' + tName + ' · ' + schoolName + ' (' + sName + ') · ' + sess + ' ' + trm;
    }

    // ── Studio Data Management ───────────────────────────────────────────────
    async function initializeStudioData() {
      try {
        const res = await fetch('/api/studio/status');
        const data = await res.json();
        if (data.connected) {
          dbStatusLabel.textContent = data.schoolName + ' (' + data.studentCount + ' students, ' + data.classCount + ' classes)';
          dbStatusLabel.title = data.dbPath;
          if (headerStatusDot) headerStatusDot.classList.remove('offline');
          if (data.studentCount > 0) {
            sourceSelect.value = 'live';
            await loadClasses();
            await loadSessionsAndTerms();
          } else {
            sourceSelect.value = 'mock';
            await loadSessionsAndTerms();
            updatePreview();
          }
        } else {
          dbStatusLabel.textContent = 'Offline / No DB (Using Mocks)';
          if (headerStatusDot) headerStatusDot.classList.add('offline');
          sourceSelect.value = 'mock';
          await loadSessionsAndTerms();
          updatePreview();
        }
      } catch (err) {
        dbStatusLabel.textContent = 'Mock Mode';
        if (headerStatusDot) headerStatusDot.classList.add('offline');
        sourceSelect.value = 'mock';
        await loadSessionsAndTerms();
        updatePreview();
      }
    }

    async function loadClasses() {
      try {
        const res = await fetch('/api/studio/classes');
        const data = await res.json();
        classSelect.innerHTML = '';

        if (data.classes && data.classes.length > 0) {
          data.classes.forEach(cls => {
            const opt = document.createElement('option');
            opt.value = cls;
            opt.textContent = cls;
            classSelect.appendChild(opt);
          });
          await loadStudents(classSelect.value);
        } else {
          classSelect.innerHTML = '<option value="">No classes found</option>';
          studentSelect.innerHTML = '<option value="">No students found</option>';
          updateDocTitle();
          updatePreview();
        }
      } catch (err) {
        console.error('Failed to load classes:', err);
      }
    }

    classSelect.addEventListener('change', () => {
      loadStudents(classSelect.value);
    });

    async function loadStudents(className) {
      if (!className) return;
      try {
        const res = await fetch('/api/studio/students?class=' + encodeURIComponent(className));
        const data = await res.json();
        studentSelect.innerHTML = '';

        if (data.students && data.students.length > 0) {
          data.students.forEach(s => {
            const opt = document.createElement('option');
            opt.value = s.id;
            opt.textContent = s.name + (s.admission_no ? ' (' + s.admission_no + ')' : '');
            opt.dataset.curriculum = s.curriculum_type || '';
            studentSelect.appendChild(opt);
          });
          onStudentSelected();
        } else {
          studentSelect.innerHTML = '<option value="">No students in class</option>';
          updateDocTitle();
          updatePreview();
        }
      } catch (err) {
        console.error('Failed to load students:', err);
      }
    }

    studentSelect.addEventListener('change', onStudentSelected);

    function onStudentSelected() {
      const selectedOpt = studentSelect.options[studentSelect.selectedIndex];
      if (selectedOpt) {
        activeStudentLabel.textContent = selectedOpt.textContent;
        const cur = selectedOpt.dataset.curriculum;
        if (cur === 'ILS') {
          systemSelect.value = 'ils';
        } else if (systemSelect.value === 'ils') {
          systemSelect.value = 'standard_secondary';
        }
      }
      updateDocTitle();
      updatePreview();
    }

    // ── Build Render URL ─────────────────────────────────────────────────────
    function buildRenderUrl() {
      const template = templateSelect.value;
      const school = schoolSelect ? schoolSelect.value : 'live';
      const source = (school === 'live') ? sourceSelect.value : 'mock';
      const studentId = studentSelect.value || '';
      const session = sessionSelect ? sessionSelect.value : '';
      const term = termSelect ? termSelect.value : '';
      const system = systemSelect.value;
      const stamp = stampSelect.value;
      const bc = brandColors ? '1' : '0';
      const fee = feeOwing ? 'owing' : 'cleared';
      const att = attendance ? '1' : '0';
      const pos = position ? '1' : '0';
      const ts = Date.now();

      return '/render?template=' + encodeURIComponent(template) +
             '&school=' + encodeURIComponent(school) +
             '&source=' + encodeURIComponent(source) +
             (source === 'live' && studentId ? '&studentId=' + encodeURIComponent(studentId) : '') +
             (session ? '&session=' + encodeURIComponent(session) : '') +
             (term ? '&term=' + encodeURIComponent(term) : '') +
             '&system=' + encodeURIComponent(system) +
             '&brandColors=' + bc +
             '&feeStatus=' + fee +
             '&attendance=' + att +
             '&position=' + pos +
             '&stamp=' + encodeURIComponent(stamp) +
             '&_t=' + ts;
    }

    function updatePreview() {
      if (!isAuthenticated) return;

      const isILS = systemSelect.value === 'ils';
      const width = isILS ? 1123 : 794;
      const height = isILS ? 794 : 1123;

      previewFrame.style.width = width + 'px';
      previewFrame.style.height = height + 'px';
      paperFrame.style.width = width + 'px';
      paperFrame.style.height = height + 'px';

      dimensionLabel.textContent = isILS ? '297mm × 210mm (Landscape A4)' : '210mm × 297mm (Portrait A4)';
      statusText.textContent = 'Rendering ' + templateSelect.value + '...';

      const renderUrl = buildRenderUrl();
      const startMs = Date.now();

      previewFrame.src = renderUrl;
      previewFrame.onload = () => {
        const elapsed = Date.now() - startMs;
        renderTimeLabel.textContent = elapsed + ' ms';
        statusText.textContent = 'Rendered ' + templateSelect.value + '.hbs successfully';

        // Check overflow
        try {
          const doc = previewFrame.contentDocument || previewFrame.contentWindow.document;
          const rootEl = doc.querySelector('.page-container') || doc.body;
          if (rootEl) {
            const sh = rootEl.scrollHeight;
            const target = isILS ? 793 : 1122;
            if (sh > target + 5) {
              statusText.textContent += ' (⚠️ Height: ' + sh + 'px > ' + target + 'px)';
              statusText.style.color = '#F87171';
            } else {
              statusText.style.color = '#94A3B8';
            }
          }
        } catch (_) {}
      };
    }

    refreshBtn.addEventListener('click', updatePreview);
    if (quickRefreshBtn) quickRefreshBtn.addEventListener('click', updatePreview);

    openNewTabBtn.addEventListener('click', () => window.open(buildRenderUrl(), '_blank'));
    if (quickNewTabBtn) quickNewTabBtn.addEventListener('click', () => openNewTabBtn.click());

    printBtn.addEventListener('click', () => {
      if (previewFrame.contentWindow) {
        previewFrame.contentWindow.focus();
        previewFrame.contentWindow.print();
      }
    });
    if (quickPrintBtn) quickPrintBtn.addEventListener('click', () => printBtn.click());

    // Keyboard Shortcuts (Cmd/Ctrl + R & Cmd/Ctrl + P)
    window.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'r') {
        e.preventDefault();
        updatePreview();
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'p') {
        e.preventDefault();
        printBtn.click();
      }
    });

    // Boot
    applyZoom(parseFloat(zoomSelect.value));
    if (isAuthenticated) {
      initializeStudioData();
    }
  </script>
</body>
</html>`;

  res.send(html);
});

// ── Start Server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`🚀 Nexus Authenticated Diagnostic Studio is running!`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log(`📁 Templates dir: ${TEMPLATES_DIR}`);
  console.log(`🔐 Developer Master: ${DEV_EMAIL} (${DEV_PHONE})`);
  console.log(`💡 Press Ctrl+C to stop.`);
  console.log(`======================================================\n`);
  getDatabase(); // initialize SQLite discovery
});
