'use strict';

/**
 * fee-structure-priority-fallback.test.js (private_engine)
 *
 * Verifies resolveStudentFeeStructures() and recalculateStudentFeeRecord()
 * in database.js never double-count bare + armed schedules and always preserve
 * fee_adjustments (scholarships) and student_extra_selections during batch apply.
 */

const BetterSqlite3 = require('better-sqlite3');

describe('fee_structures priority fallback & scholarship-safe batch billing', () => {
  let db;
  let database;

  beforeAll(() => {
    jest.resetModules();
    database = require('../database');

    let instance;
    function InMemoryDb(_path, opts) {
      instance = new BetterSqlite3(':memory:', { ...opts, verbose: undefined });
      return instance;
    }

    database.init(':memory:', InMemoryDb);
    db = instance;

    // Seed bare + armed duplicate fee structures
    const ins = db.prepare(`INSERT INTO fee_structures (class_name, item_name, amount, term, is_optional) VALUES (?, ?, ?, 'All Terms', ?)`);
    for (const cls of ['Learning to Read', 'Learning to Read ACE']) {
      ins.run(cls, 'Tuition', 45000, 0);
      ins.run(cls, 'Flags', 2000, 0);
      ins.run(cls, 'Medical Fee', 1000, 0);
      ins.run(cls, 'PTF Levy', 1000, 0);
    }
    for (const cls of ['Reading Readiness 2', 'Reading Readiness 2 B']) {
      ins.run(cls, 'Tuition', 30000, 0);
      ins.run(cls, 'Text books', 6000, 0);
      ins.run(cls, 'Working Materials', 3000, 0);
      ins.run(cls, 'Medical Fee', 1000, 0);
      ins.run(cls, 'PTF Levy', 1000, 0);
    }
    ins.run('JSS 2', 'Tuition', 58000, 0);

    // Seed students
    const insStu = db.prepare(`INSERT INTO students (id, name, class_name, class_arm, is_active) VALUES (?, ?, ?, ?, 1)`);
    insStu.run('STU-061', 'CLAIRE Zamani', 'Learning to Read', 'ACE');
    insStu.run('STU-031', 'Erica Jonathan', 'Reading Readiness 2', 'B');
    insStu.run('STU-033', 'Eunice Yakubu', 'Reading Readiness 2', '');
    insStu.run('STU-MIL', 'Millicent Emmanuel', 'JSS 2', '');
    insStu.run('STU-UNCFG', 'Unconfigured Student', 'SS 3', '');

    // Seed scholarships
    const insAdj = db.prepare(`INSERT INTO fee_adjustments (student_id, academic_session, term, adjustment_type, description, amount) VALUES (?, '2026/2027', 'First Term', 'scholarship', 'Staff Scholarship', ?)`);
    insAdj.run('STU-061', 17000);
    insAdj.run('STU-031', 17000);
    insAdj.run('STU-MIL', 58000);

    // Seed optional extra for Erica
    const ex = db.prepare(`INSERT INTO fee_extras (class_name, item_name, amount, term, is_active) VALUES ('Reading Readiness 2', 'Jersey', 4000, 'All Terms', 1)`).run();
    db.prepare(`INSERT INTO student_extra_selections (student_id, extra_id, academic_session, term) VALUES ('STU-031', ?, '2026/2027', 'First Term')`).run(ex.lastInsertRowid);
  });

  test('resolveStudentFeeStructures stops at armed class and never concatenates bare rows', () => {
    const rows = database.resolveStudentFeeStructures(db, 'Learning to Read', 'ACE', 'First Term');
    expect(rows).toHaveLength(4);
    expect(rows.reduce((s, r) => s + r.amount, 0)).toBe(49000);
  });

  test('resolveStudentFeeStructures falls back cleanly for un-armed students', () => {
    const rows = database.resolveStudentFeeStructures(db, 'Reading Readiness 2', '', 'First Term');
    expect(rows).toHaveLength(5);
    expect(rows.reduce((s, r) => s + r.amount, 0)).toBe(41000);
  });

  test('recalculateStudentFeeRecord factors extras & scholarships without wiping full scholarships or unconfigured classes', () => {
    // Manual bill on an unconfigured class must NOT be zeroed out
    db.prepare(`INSERT INTO student_fees (student_id, academic_session, term, total_billed, total_paid, status) VALUES ('STU-UNCFG', '2026/2027', 'First Term', 50000, 0, 'unpaid')`).run();

    const claire = database.recalculateStudentFeeRecord(db, 'STU-061', '2026/2027', 'First Term');
    const erica = database.recalculateStudentFeeRecord(db, 'STU-031', '2026/2027', 'First Term');
    const eunice = database.recalculateStudentFeeRecord(db, 'STU-033', '2026/2027', 'First Term');
    const millicent = database.recalculateStudentFeeRecord(db, 'STU-MIL', '2026/2027', 'First Term');
    const uncfg = database.recalculateStudentFeeRecord(db, 'STU-UNCFG', '2026/2027', 'First Term');

    expect(claire).toMatchObject({ applied: true, baseFee: 49000, extrasFee: 0, adjFee: 17000, totalBilled: 32000, status: 'unpaid' });
    expect(erica).toMatchObject({ applied: true, baseFee: 41000, extrasFee: 4000, adjFee: 17000, totalBilled: 28000, status: 'unpaid' });
    expect(eunice).toMatchObject({ applied: true, baseFee: 41000, extrasFee: 0, adjFee: 0, totalBilled: 41000, status: 'unpaid' });
    expect(millicent).toMatchObject({ applied: true, baseFee: 58000, extrasFee: 0, adjFee: 58000, totalBilled: 0, status: 'cleared' });
    expect(uncfg.applied).toBe(false);

    // Check persisted rows
    const getFee = (id) => db.prepare(`SELECT total_billed, status FROM student_fees WHERE student_id = ?`).get(id);
    expect(getFee('STU-061')).toEqual({ total_billed: 32000, status: 'unpaid' });
    expect(getFee('STU-031')).toEqual({ total_billed: 28000, status: 'unpaid' });
    expect(getFee('STU-033')).toEqual({ total_billed: 41000, status: 'unpaid' });
    expect(getFee('STU-MIL')).toEqual({ total_billed: 0, status: 'cleared' });
    expect(getFee('STU-UNCFG')).toEqual({ total_billed: 50000, status: 'unpaid' });
  });
});
