'use strict';

const { generatePairingPin } = require('../server');

describe('Camera-Free PIN Pairing', () => {
    test('generates valid 6-digit PIN and formatted PIN', () => {
        const pinInfo = generatePairingPin('teacher_1', 'Mr. Smith');
        expect(pinInfo).toBeDefined();
        expect(pinInfo.pin).toMatch(/^\d{6}$/);
        expect(pinInfo.formatted_pin).toMatch(/^\d{3} \d{3}$/);
        expect(pinInfo.expires_at).toBeGreaterThan(Date.now());
    });

    test('replaces/recycles existing PIN when generated again for the same teacher', () => {
        const pin1 = generatePairingPin('teacher_2', 'Mrs. Davis');
        const pin2 = generatePairingPin('teacher_2', 'Mrs. Davis');
        
        expect(pin1.pin).toBeDefined();
        expect(pin2.pin).toBeDefined();
        // Since random, pin2 is generated fresh and replaces pin1 in memory
    });

    test('generates unique PINs for different teachers concurrently', () => {
        const teacherA = generatePairingPin('teacher_a', 'Teacher A');
        const teacherB = generatePairingPin('teacher_b', 'Teacher B');

        expect(teacherA.pin).not.toBe(teacherB.pin);
    });
});
