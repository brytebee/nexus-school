const fs = require('fs');
const path = require('path');

let db;
let Database;

function init(dbPath, DatabaseConstructor) {
    if (db) return db;
    Database = DatabaseConstructor || require('better-sqlite3');

    // Ensure directory exists
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    // Initialize better-sqlite3
    try {
        db = new Database(dbPath, { verbose: console.log });
    } catch (err) {
        console.error(`[Database] FATAL: Failed to open SQLite at ${dbPath}`);
        console.error(`[Database] Error detail: ${err.message}`);
        if (err.message.includes('NODE_MODULE_VERSION')) {
             console.error("[Database] This is likely a Node/Electron version mismatch. Run 'npm install better-sqlite3' on this machine.");
        }
        throw err;
    }

    // Enable Write-Ahead Logging for better concurrency handling during sync
    db.pragma('journal_mode = WAL');

    // Enable foreign key enforcement (SQLite disables it by default).
    // This activates all ON DELETE CASCADE / RESTRICT rules in the schema.
    db.pragma('foreign_keys = ON');

    console.log(`[Database] SQLite connected at ${dbPath}`);

    // Architect and execute schema migration
    db.exec(`
        -- Table 1: Teachers
        CREATE TABLE IF NOT EXISTS teachers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            sync_revoked INTEGER DEFAULT 0
        );

        -- Table 2: Teacher Allocations (Many-to-Many junction)
        CREATE TABLE IF NOT EXISTS teacher_allocations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id TEXT NOT NULL,
            class_name TEXT NOT NULL,
            subject TEXT NOT NULL,
            UNIQUE(teacher_id, class_name, subject),
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE
        );

        -- Table 3: Students
        CREATE TABLE IF NOT EXISTS students (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            class_name TEXT NOT NULL,
            admission_no TEXT DEFAULT ''
        );

        -- Table 3b: Student Subjects (Explicit Enrollment)
        CREATE TABLE IF NOT EXISTS student_subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            UNIQUE(student_id, subject),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 4: Sync Logs (for offline queue resolution and auditing)
        CREATE TABLE IF NOT EXISTS sync_logs (
            event_id TEXT PRIMARY KEY,
            device_id TEXT NOT NULL,
            teacher_id TEXT NOT NULL,
            payload TEXT NOT NULL,
            synced_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Table 4b: Sync Warnings (Subject Consistency Engine)
        CREATE TABLE IF NOT EXISTS sync_warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT,
            teacher_id TEXT,
            student_id TEXT,
            mismatched_subject TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Table 5: Student Records (The Ledger)
        CREATE TABLE IF NOT EXISTS student_records (
            student_id TEXT,
            subject TEXT,
            assessment TEXT,
            score INTEGER,
            breakdown TEXT,
            teacher_id TEXT,
            academic_session TEXT DEFAULT '2024/2025',
            term TEXT DEFAULT 'First Term',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, subject, assessment, academic_session, term)
        );

        -- Table 6: School Term Configuration (V2)
        CREATE TABLE IF NOT EXISTS school_term_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            academic_session TEXT NOT NULL DEFAULT '2024/2025',
            term TEXT NOT NULL DEFAULT 'First Term',
            resumption_date TEXT DEFAULT '',
            grading_scale TEXT DEFAULT '[]',
            show_position INTEGER DEFAULT 1,
            show_domains INTEGER DEFAULT 1
        );

        -- Table 7: Student Domain Scores – Affective & Psychomotor (V2)
        CREATE TABLE IF NOT EXISTS student_domains (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            domain_type TEXT NOT NULL,
            trait TEXT NOT NULL,
            grade TEXT NOT NULL,
            UNIQUE(student_id, academic_session, term, domain_type, trait)
        );

        -- Table 8: Teacher Remarks per Student per Term (V2)
        CREATE TABLE IF NOT EXISTS teacher_remarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            teacher_id TEXT,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            remark TEXT DEFAULT '',
            principal_remark TEXT DEFAULT '',
            UNIQUE(student_id, academic_session, term)
        );
    `);

    // ── V2 Safe Migrations: add columns/tables if they don't already exist ──────
    const alterSafe = (sql) => { try { db.exec(sql); } catch(e) { /* already exists */ } };

    // student_records historical columns
    alterSafe(`ALTER TABLE student_records ADD COLUMN academic_session TEXT DEFAULT '2024/2025'`);
    alterSafe(`ALTER TABLE student_records ADD COLUMN term TEXT DEFAULT 'First Term'`);
    alterSafe(`ALTER TABLE teachers ADD COLUMN sync_revoked INTEGER DEFAULT 0`);

    // V2.1: Extended student profile
    alterSafe(`ALTER TABLE students ADD COLUMN reg_no TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN admission_no TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN gender TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN dob TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE students ADD COLUMN photo TEXT DEFAULT NULL`);         // Diamond plan
    alterSafe(`ALTER TABLE students ADD COLUMN parent_email TEXT DEFAULT ''`);    // Gold+
    alterSafe(`ALTER TABLE students ADD COLUMN parent_phone TEXT DEFAULT ''`);    // Gold+
    alterSafe(`ALTER TABLE students ADD COLUMN fee_status TEXT DEFAULT 'cleared'`); // Gold+
    alterSafe(`ALTER TABLE students ADD COLUMN parent_name TEXT DEFAULT NULL`);      // Gold+ receipt matching

    // V2.2: Class Progression & CBT Engine Additions
    alterSafe(`ALTER TABLE students ADD COLUMN session_history TEXT DEFAULT '[]'`); // JSON array of past classes
    alterSafe(`ALTER TABLE cbt_exams ADD COLUMN is_promotional INTEGER DEFAULT 0`);

    // V2.5: Class Arms & CBT Security Hardening
    alterSafe(`ALTER TABLE students ADD COLUMN class_arm TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE cbt_tokens ADD COLUMN question_seed TEXT`);

    // V2.6: Exam Scheduling & PC-Aware Token Batching
    alterSafe(`ALTER TABLE cbt_exams ADD COLUMN exam_date TEXT`);
    alterSafe(`ALTER TABLE cbt_exams ADD COLUMN start_time TEXT`);
    alterSafe(`ALTER TABLE cbt_exams ADD COLUMN end_time TEXT`);
    alterSafe(`ALTER TABLE cbt_exams ADD COLUMN pc_count INTEGER NOT NULL DEFAULT 30`);
    alterSafe(`ALTER TABLE cbt_batches ADD COLUMN exam_date TEXT`);

    // V3.0: The Vault — Admin Users Schema Migration
    // Existing installations may have admin_users with old columns (name, pin_hash, role).
    // We add the new columns safely; existing rows will have NULL values which the seeder handles.
    alterSafe(`ALTER TABLE admin_users ADD COLUMN username TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN secret_hash TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN auth_type TEXT DEFAULT 'pin'`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN role_level INTEGER DEFAULT 1`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN avatar TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP`);

    // V3.2: Admin Profile Recovery Migration
    alterSafe(`ALTER TABLE admin_users ADD COLUMN phone TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN recovery_question TEXT`);
    alterSafe(`ALTER TABLE admin_users ADD COLUMN recovery_answer_hash TEXT`);

    // Back-fill: if old rows exist with 'name' but no 'username', copy name → username
    try {
        db.exec(`UPDATE admin_users SET username = name WHERE username IS NULL AND name IS NOT NULL`);
        // Back-fill secret_hash from pin_hash if present
        db.exec(`UPDATE admin_users SET secret_hash = pin_hash WHERE secret_hash IS NULL AND pin_hash IS NOT NULL`);
        // Promote old 'super_admin' role to level 9
        db.exec(`UPDATE admin_users SET role_level = 9 WHERE role_level IS NULL OR role_level = 1`);

        // V3.1: Normalize hash format — old installs used bcrypt ($2b$...) which is ~60 chars.
        // The current Vault uses base64(pin) — "0000" → "MDAwMA==".
        // Any bcrypt hash will never match, so we reset those admins to the default PIN.
        // Admins are notified to change their PIN on first login.
        const defaultPinHash = Buffer.from('0000').toString('base64');
        const legacyAdmins = db.prepare(
            `SELECT id, username FROM admin_users WHERE secret_hash LIKE '$2b$%' OR length(secret_hash) > 30`
        ).all();
        if (legacyAdmins.length > 0) {
            const stmt = db.prepare(`UPDATE admin_users SET secret_hash = ? WHERE id = ?`);
            legacyAdmins.forEach(a => {
                stmt.run(defaultPinHash, a.id);
                console.log(`[DB Migration] Reset PIN for legacy admin '${a.username}' → default 0000`);
            });
        }

        // Back-fill default security question for existing admin account if not configured
        db.prepare(`
            UPDATE admin_users 
            SET recovery_question = 'What is the default recovery code?',
                recovery_answer_hash = ?
            WHERE username = 'admin' AND recovery_question IS NULL
        `).run(defaultPinHash);
    } catch(e) { /* columns may not exist on fresh installs — that's fine */ }


    // Settings Table for flexible configuration (Hierarchy, Thresholds)
    db.exec(`
        CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('class_hierarchy', '["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"]');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('pass_mark_threshold', '50');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('current_academic_session', '2025/2026');
        -- V2.3: Dual-Layer Attendance & Truancy Detection defaults
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_daily_attendance', 'true');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_subject_attendance', 'false');
        INSERT OR IGNORE INTO system_settings (key, value) VALUES ('truancy_escalation_flow', '[{"step":1,"trigger_after":1,"notify":"form_teacher","channel":"in-app"},{"step":2,"trigger_after":3,"notify":"principal","channel":"in-app"},{"step":3,"trigger_after":5,"notify":"parent","channel":"whatsapp"}]');
    `);

    // V2.3: Subject-Level Attendance & Truancy Flagging (Diamond)
    db.exec(`
        -- Raw per-class roll call (mirrors daily_attendance at subject level)
        CREATE TABLE IF NOT EXISTS subject_attendance (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id   TEXT    NOT NULL,
            subject_name TEXT    NOT NULL,
            class_name   TEXT    NOT NULL,
            date         TEXT    NOT NULL,
            status       TEXT    NOT NULL CHECK(status IN ('present','absent','late')),
            marked_by    TEXT,
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, subject_name, date),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Fast aggregate for report compilation (mirrors student_attendance)
        CREATE TABLE IF NOT EXISTS subject_attendance_agg (
            student_id       TEXT NOT NULL,
            subject_name     TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term             TEXT NOT NULL,
            total_classes    INTEGER DEFAULT 0,
            classes_attended INTEGER DEFAULT 0,
            PRIMARY KEY (student_id, subject_name, academic_session, term),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Truancy flag counter — drives the Guardian Shield escalation ladder
        CREATE TABLE IF NOT EXISTS truancy_flags (
            student_id      TEXT    NOT NULL,
            flag_count      INTEGER DEFAULT 0,
            last_flagged    TEXT,
            escalation_step INTEGER DEFAULT 0,
            PRIMARY KEY (student_id),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );
    `);

    // V2.1: Attendance tracking table
    db.exec(`
        CREATE TABLE IF NOT EXISTS student_attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            total_days INTEGER DEFAULT 0,
            days_attended INTEGER DEFAULT 0,
            UNIQUE(student_id, academic_session, term),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 9: Form Teachers (V2.1)
        CREATE TABLE IF NOT EXISTS form_teachers (
            class_name TEXT PRIMARY KEY,
            teacher_id TEXT NOT NULL,
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE
        );

        -- Table 10: Daily Attendance (Gold Phase A)
        CREATE TABLE IF NOT EXISTS daily_attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            class_name TEXT NOT NULL,
            date TEXT NOT NULL,
            status TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            recorded_by_teacher_id TEXT,
            UNIQUE(student_id, date),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 11: App Settings (Gold Phase B — school identity for Pulse Bot etc.)
        CREATE TABLE IF NOT EXISTS app_settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );

        -- ── Phase 5: Fee Management (Gold Lightweight + Diamond Full Ledger) ──────

        -- Table 12: student_fees — Aggregated fee state per student per term (Gold+)
        --   'balance' is NOT stored; always computed as (total_billed - total_paid) at query time.
        CREATE TABLE IF NOT EXISTS student_fees (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            academic_session TEXT    NOT NULL,
            term             TEXT    NOT NULL,
            total_billed     REAL    NOT NULL DEFAULT 0,
            total_paid       REAL    NOT NULL DEFAULT 0,
            next_due_date    TEXT    DEFAULT '',
            status           TEXT    NOT NULL DEFAULT 'unpaid'
                             CHECK(status IN ('cleared','partial','unpaid')),
            updated_at       TEXT    NOT NULL DEFAULT (datetime('now')),
            UNIQUE(student_id, academic_session, term),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 13: fee_transactions — Full payment ledger (Diamond only)
        CREATE TABLE IF NOT EXISTS fee_transactions (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            academic_session TEXT    NOT NULL,
            term             TEXT    NOT NULL,
            amount           REAL    NOT NULL,
            payment_method   TEXT    NOT NULL DEFAULT 'cash'
                             CHECK(payment_method IN ('cash','transfer','pos','bank_teller')),
            reference_number TEXT    DEFAULT '',
            recorded_by      TEXT    NOT NULL DEFAULT 'Admin',
            note             TEXT    DEFAULT '',
            created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );

        -- Table 14: fee_structures — Itemised fee breakdown definitions (Diamond only)
        --   Rows describe what makes up total_billed for a given class.
        CREATE TABLE IF NOT EXISTS fee_structures (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT    NOT NULL,
            item_name  TEXT    NOT NULL,
            amount     REAL    NOT NULL DEFAULT 0,
            term       TEXT    NOT NULL DEFAULT 'All Terms',
            UNIQUE(class_name, item_name, term)
        );

        -- ── Phase 7: Full Production CBT Engine (Diamond) ──────

        -- Table 15: cbt_question_banks — Groups of questions
        CREATE TABLE IF NOT EXISTS cbt_question_banks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            subject TEXT NOT NULL,
            class_category TEXT NOT NULL DEFAULT 'General',
            is_premium BOOLEAN DEFAULT 0,
            pack_id TEXT DEFAULT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        -- Table 16: cbt_questions — Individual questions
        CREATE TABLE IF NOT EXISTS cbt_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bank_id INTEGER NOT NULL,
            question_text TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_option TEXT NOT NULL CHECK(correct_option IN ('A','B','C','D')),
            marks INTEGER NOT NULL DEFAULT 1,
            difficulty TEXT NOT NULL DEFAULT 'medium' CHECK(difficulty IN ('easy','medium','hard')),
            question_hash TEXT DEFAULT NULL,
            FOREIGN KEY (bank_id) REFERENCES cbt_question_banks(id) ON DELETE CASCADE
        );

        -- Table 17: cbt_exams — Scheduled exams
        CREATE TABLE IF NOT EXISTS cbt_exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            bank_id INTEGER NOT NULL,
            class_name TEXT NOT NULL,
            academic_session TEXT NOT NULL,
            term TEXT NOT NULL,
            question_count INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','active','completed')),
            pass_mark_percentage INTEGER NOT NULL DEFAULT 50,
            shuffle_questions INTEGER NOT NULL DEFAULT 1,
            shuffle_options INTEGER NOT NULL DEFAULT 1,
            exam_type TEXT NOT NULL DEFAULT 'internal' CHECK(exam_type IN ('internal','external')),
            assessment_mapping TEXT DEFAULT NULL,
            security_profile TEXT DEFAULT '{}',
            result_release_policy TEXT NOT NULL DEFAULT 'immediate' CHECK(result_release_policy IN ('immediate','delayed_30m','delayed_1h','delayed_12h','delayed_24h','delayed_48h','manual')),
            exam_date TEXT,
            start_time TEXT,
            end_time TEXT,
            pc_count INTEGER NOT NULL DEFAULT 30,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (bank_id) REFERENCES cbt_question_banks(id) ON DELETE RESTRICT
        );

        -- Table 17b: cbt_batches — Time slots for exams
        CREATE TABLE IF NOT EXISTS cbt_batches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            exam_date TEXT,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','closed')),
            FOREIGN KEY (exam_id) REFERENCES cbt_exams(id) ON DELETE CASCADE
        );

        -- Table 17c: cbt_external_candidates — Non-student examinees
        CREATE TABLE IF NOT EXISTS cbt_external_candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            guardian_phone TEXT NOT NULL,
            dob_year TEXT NOT NULL,
            dob_month TEXT NOT NULL,
            dob_day TEXT NOT NULL,
            exam_year TEXT NOT NULL,
            exam_month TEXT NOT NULL,
            exam_day TEXT NOT NULL,
            target_class TEXT NOT NULL,
            subjects TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        -- Table 17d: used_expansion_keys — Token Pack Monetization tracking
        CREATE TABLE IF NOT EXISTS used_expansion_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_hash TEXT NOT NULL UNIQUE,
            tokens_added INTEGER NOT NULL,
            used_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        -- Table 18: cbt_tokens — Access tokens for students taking exams
        CREATE TABLE IF NOT EXISTS cbt_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER NOT NULL,
            student_id TEXT DEFAULT NULL,
            external_candidate_id INTEGER DEFAULT NULL,
            batch_id INTEGER DEFAULT NULL,
            token TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL DEFAULT 'unused' CHECK(status IN ('unused','active','submitted')),
            score INTEGER DEFAULT NULL,
            started_at TEXT DEFAULT NULL,
            submitted_at TEXT DEFAULT NULL,
            tab_switches INTEGER NOT NULL DEFAULT 0,
            whatsapp_dispatches INTEGER NOT NULL DEFAULT 0,
            portal_checks INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (exam_id) REFERENCES cbt_exams(id) ON DELETE CASCADE,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (external_candidate_id) REFERENCES cbt_external_candidates(id) ON DELETE CASCADE,
            FOREIGN KEY (batch_id) REFERENCES cbt_batches(id) ON DELETE CASCADE,
            UNIQUE(exam_id, student_id),
            UNIQUE(exam_id, external_candidate_id)
        );

        -- Table 19: cbt_answers — Student answers for auto-grading
        CREATE TABLE IF NOT EXISTS cbt_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            selected_option TEXT NOT NULL CHECK(selected_option IN ('A','B','C','D','NONE')),
            is_correct INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (token_id) REFERENCES cbt_tokens(id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES cbt_questions(id) ON DELETE CASCADE,
            UNIQUE(token_id, question_id)
        );

    `);

    // Seed default school name if not already set
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('school_name', 'Nexus School')`).run();
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('mobile_registration_locked', '0')`).run();
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('mobile_grades_locked', '0')`).run();
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('mobile_attendance_locked', '0')`).run();
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('mobile_registration_lock_at', NULL)`).run();
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('mobile_grades_lock_at', NULL)`).run();
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('mobile_attendance_lock_at', NULL)`).run();

    // ── Admin Users & System Auth (The Vault) ─────────────────────────────────
    db.exec(`
        CREATE TABLE IF NOT EXISTS admin_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            secret_hash TEXT NOT NULL,
            auth_type TEXT DEFAULT 'pin',
            role_level INTEGER DEFAULT 1,
            avatar TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER,
            action TEXT NOT NULL,
            target TEXT,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(admin_id) REFERENCES admin_users(id)
        );
    `);

    // ── System Auth Seeder ─────────────────────────────────────────
    const adminCount = db.prepare("SELECT COUNT(*) as count FROM admin_users").get().count;
    if (adminCount === 0) {
        // Default PIN: "0000" stored in base64 as placeholder hash
        const defaultHash = Buffer.from("0000").toString('base64');
        db.prepare(`
            INSERT INTO admin_users (username, secret_hash, auth_type, role_level, recovery_question, recovery_answer_hash) 
            VALUES ('admin', ?, 'pin', 9, 'What is the default recovery code?', ?)
        `).run(defaultHash, defaultHash);
        
        db.prepare(`
            INSERT INTO audit_logs (admin_id, action, target, details)
            VALUES (1, 'SYSTEM_INIT', 'admin_users', 'Default superadmin created with default SQA recovery')
        `).run();
    }

    db.exec(`
        -- Table: pending_pulse_messages — WhatsApp Message Queue (Gold Phase B)
        -- Prevents UI freeze during bulk sends (900+ parents).
        -- A 3-second setInterval worker drains this queue one message at a time.
        CREATE TABLE IF NOT EXISTS pending_pulse_messages (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            phone       TEXT    NOT NULL,
            message     TEXT    NOT NULL,
            type        TEXT    NOT NULL DEFAULT 'fee_reminder'
                        CHECK(type IN ('fee_reminder','guardian_alert','otp','digest','general')),
            status      TEXT    NOT NULL DEFAULT 'pending'
                        CHECK(status IN ('pending','sending','sent','failed')),
            attempts    INTEGER NOT NULL DEFAULT 0,
            student_id  TEXT    DEFAULT NULL,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            sent_at     TEXT    DEFAULT NULL,
            error_msg   TEXT    DEFAULT NULL
        );

        -- Table: pulse_inbox — WhatsApp parent query inbox (Gold+ manual responses)
        CREATE TABLE IF NOT EXISTS pulse_inbox (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_name   TEXT NOT NULL,
            sender_phone  TEXT NOT NULL,
            content       TEXT NOT NULL,
            received_at   TEXT NOT NULL DEFAULT (datetime('now')),
            status        TEXT NOT NULL DEFAULT 'unread' CHECK(status IN ('unread','read','replied','bot_handled')),
            ai_confidence INTEGER,
            direction     TEXT NOT NULL DEFAULT 'incoming' CHECK(direction IN ('incoming','outgoing'))
        );

        -- Table: fee_adjustments — Scholarships, Waivers, Grants (Gold+)
        CREATE TABLE IF NOT EXISTS fee_adjustments (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id       TEXT    NOT NULL,
            academic_session TEXT    NOT NULL,
            term             TEXT    NOT NULL,
            adjustment_type  TEXT    NOT NULL DEFAULT 'discount'
                             CHECK(adjustment_type IN ('scholarship','waiver','owner_grant','bursary','discount')),
            description      TEXT    NOT NULL DEFAULT '',
            amount           REAL    NOT NULL DEFAULT 0,
            approved_by      TEXT    NOT NULL DEFAULT 'Admin',
            created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        );
    `);

    // Seed default fee settings (shared by Gold & Diamond — reminder dates + Fee Shield config)
    db.prepare(`INSERT OR IGNORE INTO app_settings (key, value) VALUES ('fee_settings', ?)`).run(JSON.stringify({
        reminder_date_1: '',          // ISO date string (YYYY-MM-DD)
        reminder_date_2: '',          // ISO date string (YYYY-MM-DD)
        fee_shield_enabled: false,    // Diamond only
        fee_shield_mode: 'warn'       // 'warn' | 'watermark' | 'block'
    }));

    // V2.1: Teacher signature
    alterSafe(`ALTER TABLE teachers ADD COLUMN signature TEXT DEFAULT NULL`);

    // V2.1: Remark signatures
    alterSafe(`ALTER TABLE teacher_remarks ADD COLUMN teacher_signature TEXT DEFAULT NULL`);
    alterSafe(`ALTER TABLE teacher_remarks ADD COLUMN principal_signature TEXT DEFAULT NULL`);

    // V2.1: Term config — template + optional display toggles
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN template TEXT DEFAULT 'clean_slate'`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_subject_position INTEGER DEFAULT 0`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_attendance INTEGER DEFAULT 1`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_fee_status INTEGER DEFAULT 0`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_highest_lowest INTEGER DEFAULT 0`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN show_class_average INTEGER DEFAULT 1`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN attendance_score_weight INTEGER DEFAULT 0`);

    // Gold Phase B: Attendance conflict authority
    alterSafe(`ALTER TABLE daily_attendance ADD COLUMN source TEXT DEFAULT 'teacher'`);

    // Gold Phase C: Term calendar boundaries — enables attendance date validation
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN term_start_date TEXT DEFAULT ''`);
    alterSafe(`ALTER TABLE school_term_config ADD COLUMN term_end_date   TEXT DEFAULT ''`);

    // Seed default term config if empty
    db.prepare(`INSERT OR IGNORE INTO school_term_config (id, academic_session, term) VALUES (1, '2024/2025', 'First Term')`).run();

    // Diamond CBT: add description + subject columns to cbt_question_banks
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN description TEXT NOT NULL DEFAULT ''`);
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN subject TEXT NOT NULL DEFAULT ''`);
    
    // NexPack Updates
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN is_premium BOOLEAN DEFAULT 0`);
    alterSafe(`ALTER TABLE cbt_question_banks ADD COLUMN pack_id TEXT DEFAULT NULL`);
    alterSafe(`ALTER TABLE cbt_questions ADD COLUMN question_hash TEXT DEFAULT NULL`);
    // Back-fill: if subject is empty, copy class_category so existing banks are not blank
    try { db.exec(`UPDATE cbt_question_banks SET subject = class_category WHERE subject = '' AND class_category != ''`); } catch(_){}

    // V2.4: Subject Name Standardization — rename legacy "English Studies" → "English Language"
    // Safe to run on every startup (idempotent — no-ops when no matching rows exist).
    // This fixes cross-level subject bleed caused by JSS using a different string than SSS
    // for the same subject, causing both to appear as separate entries in tablet dropdowns.
    try {
        db.exec(`UPDATE student_subjects    SET subject = 'English Language' WHERE subject = 'English Studies'`);
        db.exec(`UPDATE teacher_allocations SET subject = 'English Language' WHERE subject = 'English Studies'`);
        db.exec(`UPDATE student_records     SET subject = 'English Language' WHERE subject = 'English Studies'`);
        console.log('[Database] V2.4: Subject name standardization applied.');
    } catch(e) { console.warn('[Database] V2.4 subject migration warning:', e.message); }

    // V2.7: Migrate pulse_inbox table to support 'bot_handled' status and 'direction' column
    try {
        const tableSql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='pulse_inbox'").get()?.sql || '';
        if (tableSql && !tableSql.includes('bot_handled')) {
            console.log("[Database Migration] Migrating pulse_inbox table to support 'bot_handled' status...");
            db.exec(`
                PRAGMA foreign_keys=OFF;
                BEGIN TRANSACTION;
                ALTER TABLE pulse_inbox RENAME TO old_pulse_inbox;
                CREATE TABLE pulse_inbox (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender_name   TEXT NOT NULL,
                    sender_phone  TEXT NOT NULL,
                    content       TEXT NOT NULL,
                    received_at   TEXT NOT NULL DEFAULT (datetime('now')),
                    status        TEXT NOT NULL DEFAULT 'unread' CHECK(status IN ('unread','read','replied','bot_handled')),
                    ai_confidence INTEGER,
                    direction     TEXT NOT NULL DEFAULT 'incoming' CHECK(direction IN ('incoming','outgoing'))
                );
                INSERT INTO pulse_inbox (id, sender_name, sender_phone, content, received_at, status, ai_confidence, direction)
                SELECT id, sender_name, sender_phone, content, received_at, 
                       (CASE WHEN status NOT IN ('unread','read','replied','bot_handled') THEN 'unread' ELSE status END), 
                       ai_confidence, 'incoming' FROM old_pulse_inbox;
                DROP TABLE old_pulse_inbox;
                COMMIT;
                PRAGMA foreign_keys=ON;
            `);
            console.log("[Database Migration] pulse_inbox table migration completed successfully.");
        }
    } catch (migErr) {
        console.error("[Database Migration] Failed to migrate pulse_inbox:", migErr.message);
    }

    // Ensure the direction column exists for cases where table existed with bot_handled but no direction
    alterSafe(`ALTER TABLE pulse_inbox ADD COLUMN direction TEXT NOT NULL DEFAULT 'incoming'`);

    // V2.6: Standalone Pack & Activity Log tables
    db.exec(`
        CREATE TABLE IF NOT EXISTS connected_devices (
            device_id    TEXT PRIMARY KEY,
            device_model TEXT,
            label        TEXT DEFAULT 'Admin Extension',
            tier         TEXT DEFAULT 'Standalone',
            paired_at    DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS activity_log (
            log_id       TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(8)))),
            device_id    TEXT NOT NULL,
            device_model TEXT,
            actor_label  TEXT NOT NULL,
            event_type   TEXT NOT NULL,
            payload_hash TEXT,
            received_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    // V4.0 Class management tables
    db.exec(`
        CREATE TABLE IF NOT EXISTS class_configs (
            hierarchy_class    TEXT PRIMARY KEY,
            max_subjects       INTEGER DEFAULT 0,
            pass_mark_override INTEGER DEFAULT NULL
        );

        CREATE TABLE IF NOT EXISTS class_arms (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            hierarchy_class TEXT NOT NULL,
            arm             TEXT NOT NULL,
            UNIQUE(hierarchy_class, arm),
            FOREIGN KEY (hierarchy_class) REFERENCES class_configs(hierarchy_class) ON DELETE CASCADE
        );
    `);

    // V4.0 auto-seeding migration
    try {
        const hierarchyRow = db.prepare("SELECT value FROM system_settings WHERE key = 'class_hierarchy'").get();
        if (hierarchyRow) {
            const classes = JSON.parse(hierarchyRow.value);
            const insertConfig = db.prepare("INSERT OR IGNORE INTO class_configs (hierarchy_class) VALUES (?)");
            db.transaction(() => {
                classes.forEach(cls => insertConfig.run(cls));
            })();
        }

        const studentsWithArms = db.prepare("SELECT DISTINCT class_name, class_arm FROM students WHERE class_arm IS NOT NULL AND class_arm != ''").all();
        if (studentsWithArms.length > 0) {
            const insertArm = db.prepare("INSERT OR IGNORE INTO class_arms (hierarchy_class, arm) VALUES (?, ?)");
            db.transaction(() => {
                studentsWithArms.forEach(row => {
                    insertArm.run(row.class_name, row.class_arm);
                });
            })();
        }
    } catch (e) {
        console.error("[Database Migration] Failed to run V4.0 class configs/arms seeding:", e.message);
    }

    console.log(`[Database] V2.1 + Phase 5 Fee Management schema verified and migrated.`);



    // [Demo seeders removed — production build does not auto-populate teachers, students, or grades]



    // Class Arm normalizer (one-time migration for existing composite data)
    try {
        const checkSetting = db.prepare("SELECT value FROM system_settings WHERE key = 'class_arms_normalized'").get();
        if (!checkSetting || checkSetting.value !== 'true') {
            const students = db.prepare("SELECT id, class_name FROM students").all();
            const updateStmt = db.prepare("UPDATE students SET class_name = ?, class_arm = ? WHERE id = ?");
            
            // Regex matches class levels that end with a single uppercase letter (e.g. "SS1A", "JSS 2B", "SS 1 A")
            const matchRegex = /^([A-Z\s]+[0-9]+)\s*([A-Z])$/;
            let updatedCount = 0;
            const armsSet = new Set();

            db.transaction(() => {
                students.forEach(student => {
                    const match = student.class_name.match(matchRegex);
                    if (match) {
                        const level = match[1].trim();
                        const arm = match[2];
                        updateStmt.run(level, arm, student.id);
                        armsSet.add(arm);
                        updatedCount++;
                    }
                });
            })();

            if (updatedCount > 0) {
                console.log(`[Database Migration] Normalised ${updatedCount} composite student class names.`);
                // If we found any arms, insert them into system_settings under class_arms if not present
                const existingArmsRow = db.prepare("SELECT value FROM system_settings WHERE key = 'class_arms'").get();
                if (!existingArmsRow) {
                    const sortedArms = Array.from(armsSet).sort();
                    if (sortedArms.length > 0) {
                        db.prepare("INSERT OR IGNORE INTO system_settings (key, value) VALUES ('class_arms', ?)")
                          .run(JSON.stringify(sortedArms));
                        console.log(`[Database Migration] Initialised system_settings.class_arms with: ${JSON.stringify(sortedArms)}`);
                    }
                }
            }
        }
    } catch (err) {
        console.warn("[Database Migration] Class arm normalizer failed:", err.message);
    }

    // Unconditional normalisation — self-healing on every launch, aligned with server.js normalizeSubjectName
    try {
        const TABLES = ['teacher_allocations', 'student_subjects', 'student_records', 'subject_attendance', 'subject_attendance_agg'];

        // Map of bad value → canonical value (class-independent renames)
        const simpleRenames = {
            'Further Maths':              'Further Mathematics',
            'Further Mathematic':         'Further Mathematics',
            'Add Maths':                  'Further Mathematics',
            'Additional Mathematics':     'Further Mathematics',
            'Literature':                 'Literature in English',
            'Lit in English':             'Literature in English',
            'Lit':                        'Literature in English',
            'English':                    'English Language',
            'English Studies':            'English Language',
            'Eng Lang':                   'English Language',
            'Gen Maths':                  'General Mathematics',
            'General Maths':              'General Mathematics',
            'Maths':                      'Mathematics',   // class-level swap below handles JSS/SS
            'Math':                       'Mathematics',
            'CRS':                        'Christian Religious Studies',
            'CRK':                        'Christian Religious Studies',
            'Christian Religious Knowledge': 'Christian Religious Studies',
            'IRK':                        'Islamic Studies',
            'Islamic Religious Knowledge': 'Islamic Studies',
            'Islamic Religious Studies':  'Islamic Studies',
            'Civic Education':            'Civic Education',   // canonical — no rename needed
            'Civic Ed':                   'Civic Education',
            'Citizenship and Heritage Studies': 'Civic Education',
            'Govt':                       'Government',
            'Agric':                      'Agriculture',
            'Agric Science':              'Agriculture',
            'Agricultural Science':       'Agriculture',
            'Econs':                      'Economics',
            'Account':                    'Financial Accounting',
            'Accounts':                   'Financial Accounting',
            'Accounting':                 'Financial Accounting',
            'Fin Accounting':             'Financial Accounting',
            'Financial Acc':              'Financial Accounting',
            'Tech Drawing':               'Technical Drawing',
            'PHE':                        'Physical Education',
            'Physical & Health Education': 'Physical Education',
            'Health Edu':                 'Health Education',
            'Food & Nutrition':           'Food and Nutrition',
            'Food Nutrition':             'Food and Nutrition',
            'Home Mgt':                   'Home Management',
            'Catering':                   'Catering Craft',
            'Yoruba Language':            'Yoruba',
            'Igbo Language':              'Igbo',
            'Hausa Language':             'Hausa',
            'French Language':            'French',
            'Digital Tech':               'Digital Technologies',
            'ICT':                        'Digital Technologies',
            'Computer Science':           'Digital Technologies',
            'Basic Science':              'Integrated Science',
            'Intermediate Science':       'Integrated Science',
            'Social Studies':             'Social and Citizenship Studies',
            'Social & Citizenship Studies': 'Social and Citizenship Studies',
            'Nigerian History':           'History',
            'Visual Arts':                'Fine Art',
            'Fine Arts':                  'Fine Art',
        };

        for (const [bad, good] of Object.entries(simpleRenames)) {
            if (bad === good) continue;
            for (const tbl of TABLES) {
                try { db.exec(`UPDATE ${tbl} SET subject = '${good}' WHERE subject = '${bad}'`); } catch(_) {}
            }
        }

        // JSS: 'General Mathematics' → 'Mathematics'
        db.exec(`
            UPDATE teacher_allocations SET subject = 'Mathematics' WHERE subject = 'General Mathematics' AND (class_name LIKE 'JS%' OR class_name LIKE 'JSS%');
            UPDATE student_subjects SET subject = 'Mathematics' WHERE subject = 'General Mathematics' AND EXISTS (SELECT 1 FROM students WHERE students.id = student_subjects.student_id AND (students.class_name LIKE 'JS%' OR students.class_name LIKE 'JSS%'));
            UPDATE student_records SET subject = 'Mathematics' WHERE subject = 'General Mathematics' AND EXISTS (SELECT 1 FROM students WHERE students.id = student_records.student_id AND (students.class_name LIKE 'JS%' OR students.class_name LIKE 'JSS%'));
        `);
        try { db.exec(`UPDATE subject_attendance SET subject = 'Mathematics' WHERE subject = 'General Mathematics' AND (class_name LIKE 'JS%' OR class_name LIKE 'JSS%')`); } catch(_) {}
        try { db.exec(`UPDATE subject_attendance_agg SET subject = 'Mathematics' WHERE subject = 'General Mathematics' AND (class_name LIKE 'JS%' OR class_name LIKE 'JSS%')`); } catch(_) {}

        // SSS: 'Mathematics' → 'General Mathematics'
        db.exec(`
            UPDATE teacher_allocations SET subject = 'General Mathematics' WHERE subject = 'Mathematics' AND class_name LIKE 'SS%';
            UPDATE student_subjects SET subject = 'General Mathematics' WHERE subject = 'Mathematics' AND EXISTS (SELECT 1 FROM students WHERE students.id = student_subjects.student_id AND students.class_name LIKE 'SS%');
            UPDATE student_records SET subject = 'General Mathematics' WHERE subject = 'Mathematics' AND EXISTS (SELECT 1 FROM students WHERE students.id = student_records.student_id AND students.class_name LIKE 'SS%');
        `);
        try { db.exec(`UPDATE subject_attendance SET subject = 'General Mathematics' WHERE subject = 'Mathematics' AND class_name LIKE 'SS%'`); } catch(_) {}
        try { db.exec(`UPDATE subject_attendance_agg SET subject = 'General Mathematics' WHERE subject = 'Mathematics' AND class_name LIKE 'SS%'`); } catch(_) {}

        console.log(`[Database] Subject names normalised to WAEC guidelines successfully.`);
    } catch (err) {
        console.error(`[Database] Failed to normalise subject names:`, err.message);
    }

    return db;

}


function getDb() {
    if (!db) {
        throw new Error(
            "[Database] Not initialized. Call database.init(dbPath, DatabaseConstructor) before using getDb()."
        );
    }
    return db;
}

module.exports = { init, getDb };
