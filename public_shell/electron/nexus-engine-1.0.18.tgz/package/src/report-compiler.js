const fs   = require('fs');
const path = require('path');
const Handlebars = require('handlebars');

// Lib modules are located in public_shell/electron/src/lib/.
// Path differs depending on whether the engine is installed (as .tgz node_module)
// or run directly from source in private_engine/src/.
const gradingLib = (() => {
  try    { return require('../../../../src/lib/grading');                      }  // installed
  catch  { return require('../../public_shell/electron/src/lib/grading');      }  // from source
})();

const rankingLib = (() => {
  try    { return require('../../../../src/lib/ranking');                      }  // installed
  catch  { return require('../../public_shell/electron/src/lib/ranking');      }  // from source
})();

const scoringLib = (() => {
  try    { return require('../../../../src/lib/scoring');                      }  // installed
  catch  { return require('../../public_shell/electron/src/lib/scoring');      }  // from source
})();

const attendanceLib = (() => {
  try    { return require('../../../../src/lib/attendance');                   }  // installed
  catch  { return require('../../public_shell/electron/src/lib/attendance');   }  // from source
})();


// ─────────────────────────────────────────────────────────────────────────────
// buildContext — assembles the shared template rendering context
// ─────────────────────────────────────────────────────────────────────────────
function buildContext(payload) {
  const {
    identity, students, termConfig,
    reportType = "terminal", templateId,
    format = "pdf", useSchoolColors = false,
  } = payload || {};

  const primary   = identity?.themePrimary  || "#1A237E";
  const secondary = identity?.themeSecondary || "#00E5FF";
  const dateStr   = new Date().toLocaleDateString("en-NG", {
    year: "numeric", month: "long", day: "numeric",
  });

  // Per-template default colour palettes (active when school brand colours are off)
  const TEMPLATE_PALETTES = {
    clean_slate: { tp: "#1a2d5a", ts: "#4a7fd4" },
    class_photo: { tp: "#1a2d5a", ts: "#4a7fd4" },
    prestige:    { tp: "#0a192f", ts: "#14532d" },
    azure:       { tp: "#1a2d5a", ts: "#4a7fd4" },
    royal:       { tp: "#0d1f4e", ts: "#b8960c" },
    monarch:     { tp: "#1b3a4b", ts: "#4ecdc4" },
    sovereign:   { tp: "#0d1f4e", ts: "#b8960c" },
    sterling:    { tp: "#0d1f4e", ts: "#b8960c" },
    apex:        { tp: "#2d1060", ts: "#b8960c" },
  };

  const resolvedTemplateId = templateId || termConfig?.template || "clean_slate";
  const FREE_TEMPLATES     = ["clean_slate", "class_photo"];
  const palette            = TEMPLATE_PALETTES[resolvedTemplateId] || TEMPLATE_PALETTES.clean_slate;
  const canUseBrandColors  = !FREE_TEMPLATES.includes(resolvedTemplateId) && useSchoolColors;
  const tp = canUseBrandColors ? primary   : palette.tp;
  const ts = canUseBrandColors ? secondary : palette.ts;

  // ── Grading scale + score components ────────────────────────────────────────
  let scoreComponents = null;
  const gradingScale = (() => {
    try {
      const raw = JSON.parse(termConfig?.grading_scale || "[]");
      if (raw && !Array.isArray(raw) && raw.components) {
        scoreComponents = raw.components;
        return raw.scale || [];
      }
      return Array.isArray(raw) ? raw : [];
    } catch { return []; }
  })();

  if (!scoreComponents || !scoreComponents.length) {
    scoreComponents = [
      { key: "CA1",  label: "C.A. 1", max: 10 },
      { key: "CA2",  label: "C.A. 2", max: 10 },
      { key: "Exam", label: "Exam",   max: 80 },
    ];
  }

  // Gold Phase A: Implicit Attendance Component
  const attWeight = Number(termConfig?.attendance_score_weight) || 0;
  if (attWeight > 0 && termConfig?.show_attendance !== 0) {
    scoreComponents.push({ key: "Attendance", label: "Att.", max: attWeight });
  }

  // Sort scoreComponents so CAs and Exam are last
  scoreComponents = [...scoreComponents].sort((a, b) => {
    const aKey = (a.key || a.label || "").toLowerCase();
    const bKey = (b.key || b.label || "").toLowerCase();
    const isACaOrExam = aKey.startsWith("ca") || aKey.includes("exam");
    const isBCaOrExam = bKey.startsWith("ca") || bKey.includes("exam");
    if (isACaOrExam && !isBCaOrExam) return 1;
    if (!isACaOrExam && isBCaOrExam) return -1;
    if (isACaOrExam && isBCaOrExam) {
      const isAExam = aKey.includes("exam");
      const isBExam = bKey.includes("exam");
      if (isAExam && !isBExam) return 1;
      if (!isAExam && isBExam) return -1;
    }
    return aKey.localeCompare(bKey, undefined, { numeric: true, sensitivity: "base" });
  });

  const totalMaxScore = scoreComponents.reduce((s, c) => s + (Number(c.max) || 0), 0);

  const scale = gradingScale.length ? gradingScale : gradingLib.defaultScale;

  function getGradeInfo(score) {
    return gradingLib.getGradeInfo(score, scale);
  }

  const logoHtml = identity?.logoBase64
    ? `<img src="${identity.logoBase64}" class="school-logo" alt="logo"/>`
    : `<div class="logo-placeholder">${(identity?.name || "N")[0].toUpperCase()}</div>`;

  const resumption = termConfig?.resumption_date
    ? `<div class="resumption">Next Term Resumes: <strong>${termConfig.resumption_date}</strong></div>` : "";

  const showDomains    = termConfig?.show_domains  !== 0;
  const showPosition   = termConfig?.show_position !== 0;
  const showAttendance = termConfig?.show_attendance !== 0;

  const maxSubjectsMap = {};
  try {
    const database = require('./database');
    const dbInstance = database.getDb();
    const configs = dbInstance.prepare("SELECT hierarchy_class, max_subjects FROM class_configs").all();
    configs.forEach(c => {
      maxSubjectsMap[c.hierarchy_class] = c.max_subjects;
    });
  } catch (e) {
    console.warn("[Report Compiler] Could not load class_configs mapping:", e.message);
  }

  // ── resolveMaxSubjects ───────────────────────────────────────────────────────
  // maxSubjectsMap is keyed by hierarchy_class (e.g. "SS1"), but a student's
  // class_name may include the arm (e.g. "SS1 Gold" or "SS1A"). This helper
  // resolves the correct max_subjects value using longest-prefix matching.
  function resolveMaxSubjects(className) {
    if (!className) return null;
    const normClassName = className.replace(/\s+/g, '').toUpperCase();
    // 1. Exact normalized match
    for (const key of Object.keys(maxSubjectsMap)) {
      if (normClassName === key.replace(/\s+/g, '').toUpperCase()) {
        return maxSubjectsMap[key];
      }
    }
    // 2. Longest-prefix match (sort descending by key length to match most specific first)
    const keys = Object.keys(maxSubjectsMap).sort((a, b) => {
      return b.replace(/\s+/g, '').length - a.replace(/\s+/g, '').length;
    });
    for (const key of keys) {
      const normKey = key.replace(/\s+/g, '').toUpperCase();
      if (normClassName.startsWith(normKey)) {
        const val = maxSubjectsMap[key];
        if (val != null && val > 0) return val;
      }
    }
    return null;
  }

  return {
    identity, students, termConfig, reportType,
    templateId: resolvedTemplateId,
    format,
    primary, secondary,
    tp, ts,
    dateStr,
    scoreComponents, totalMaxScore, scale,
    getGradeInfo, logoHtml, resumption,
    showDomains, showPosition, showAttendance,
    maxSubjectsMap,
    resolveMaxSubjects,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// buildSharedCSS — injects brand colours into the wrapping document stylesheet
// ─────────────────────────────────────────────────────────────────────────────
function buildSharedCSS(primary, secondary) {
  return `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&family=Playfair+Display:wght@700;800&display=swap');
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Inter',sans-serif;background:#fff;}
    .report-page{width:210mm;min-height:297mm;page-break-after:always;display:flex;flex-direction:column;overflow:hidden;position:relative}
    .report-page:last-child{page-break-after:auto}
    .rh{display:flex;align-items:center;gap:16px;padding-bottom:12px;border-bottom:3px solid ${primary}}
    .school-logo{width:64px;height:64px;border-radius:10px;object-fit:contain}
    .fee-shield{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-45deg);font-size:80px;font-weight:900;color:rgba(255,0,0,0.15);pointer-events:none;z-index:9999;white-space:nowrap;border:8px solid rgba(255,0,0,0.15);padding:20px 40px;border-radius:20px}
  `;
}

// ─────────────────────────────────────────────────────────────────────────────
// computeRankMap — O(n log n) dense class ranking helper
//
// Dense ranking: ties share the same rank number; the next distinct score gets
// the next sequential rank (e.g. 1st, 1st, 3rd — not 1st, 1st, 2nd).
// Returns Map<studentId, ordinalString> keyed to student IDs.
// ─────────────────────────────────────────────────────────────────────────────
function computeRankMap(studentList, maxSubjectsMap) {
  return rankingLib.computeRankMap(studentList, maxSubjectsMap);
}

// ─────────────────────────────────────────────────────────────────────────────
// computeSubjectRankMap — Computes subject-specific rankings per class
// ─────────────────────────────────────────────────────────────────────────────
function computeSubjectRankMap(studentList) {
  return rankingLib.computeSubjectRankMap(studentList);
}

// ─────────────────────────────────────────────────────────────────────────────
// generateHTMLPages — renders one Handlebars page per student
// ─────────────────────────────────────────────────────────────────────────────
function generateHTMLPages(payload, __baseDir, tempDir) {
  const { students, termConfig, reportType = "terminal" } = payload || {};
  const ctx = buildContext(payload);
  const { primary, secondary } = ctx;
  let pages = "";

  if (reportType !== "broadsheet") {
    const hbsPath = path.join(__baseDir, "assets", "templates", `${ctx.templateId}.hbs`);
    if (fs.existsSync(hbsPath)) {
      console.log(`[@nexus/engine] Using Handlebars template: ${ctx.templateId}`);
      const template = Handlebars.compile(fs.readFileSync(hbsPath, "utf8"));

      // Gold Phase A: Calculate and inject attendance component score for every student
      const attWeight = Number(ctx.termConfig?.attendance_score_weight) || 0;
      if (attWeight > 0 && ctx.termConfig?.show_attendance !== 0) {
        students.forEach(s => {
          const tDays = s.attendance?.total_days || 0;
          const aDays = s.attendance?.days_attended || 0;
          const attScore = attendanceLib.computeAttendanceScore(aDays, tDays, attWeight);
          const rawSubs = s.subjects || s.Records || [];
          rawSubs.forEach(sub => {
            if (sub.score !== null && sub.score !== undefined && sub.score !== "") {
              sub.score = Number(sub.score) + attScore;
              if (sub.breakdowns) sub.breakdowns["Attendance"] = attScore;
              if (sub.breakdown) sub.breakdown["Attendance"] = attScore;
            }
          });
          // Also recalculate total_score and average for the student
          const maxSubjectsForStudent = ctx.resolveMaxSubjects(s.class_name);
          const { totalScore, avgScore } = scoringLib.aggregateScores(rawSubs, ctx.totalMaxScore, maxSubjectsForStudent);
          if (rawSubs.filter(sub => sub.score !== null && sub.score !== undefined && sub.score !== "").length > 0) {
            s.total_score = totalScore;
            s.average = avgScore;
          }
        });
      }

      // Pre-compute class rankings once for the whole batch (not per student)
      const rankMap = computeRankMap(students, ctx.maxSubjectsMap);
      const subjectRankMap = computeSubjectRankMap(students);

      // ── Fee-shield flags — constant for the whole batch, hoist out of loop ──
      const _tier = ctx.identity?.tier || 'Standalone';
      const _feeGated = _tier === 'Gold' || _tier === 'Diamond';

      // ── Setup temp folder image saving ──────────────────────────────────────
      let imgDir = null;
      const imgCache = new Map();
      if (tempDir && typeof tempDir === 'string') {
        imgDir = path.join(tempDir, "images");
        if (!fs.existsSync(imgDir)) {
          fs.mkdirSync(imgDir, { recursive: true });
        }
      }

      const saveBase64Image = (base64Str, prefix) => {
        if (!base64Str || typeof base64Str !== "string") return null;
        // If not base64 or data URI, return as-is
        if (!base64Str.startsWith("data:") && !base64Str.match(/^[a-zA-Z0-9+/=]+$/)) {
          return base64Str;
        }
        if (imgCache.has(base64Str)) {
          return imgCache.get(base64Str);
        }
        if (!imgDir) return base64Str; // fallback to inline if no tempDir configured

        try {
          let data = base64Str;
          let ext = "png";
          const matches = base64Str.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
          if (matches) {
            ext = matches[1];
            data = matches[2];
          } else if (base64Str.startsWith("data:")) {
            const commaIdx = base64Str.indexOf(",");
            if (commaIdx !== -1) {
              data = base64Str.substring(commaIdx + 1);
            }
          }
          const buffer = Buffer.from(data, "base64");
          const filename = `${prefix}_${Math.random().toString(36).substring(2, 9)}.${ext}`;
          const filepath = path.join(imgDir, filename);
          fs.writeFileSync(filepath, buffer);
          // Return file:/// absolute path (replacing backslashes on Windows)
          const fileUrl = `file:///${filepath.replace(/\\/g, "/")}`;
          imgCache.set(base64Str, fileUrl);
          return fileUrl;
        } catch (e) {
          console.error(`[@nexus/engine] Failed to save image to temp file:`, e);
          return base64Str;
        }
      };

      pages = students.map(s => {
        // ── Subject normalisation ──────────────────────────────────────────
        const rawSubs = s.subjects || s.Records || [];
        const stuSubjRanks = subjectRankMap.get(s.id) || new Map();
        
        const subs = rawSubs.map(sub => {
          const score = sub.score ?? sub.Total ?? null;
          let subjName = sub.name || sub.subject || "Subject";
          const bd    = sub.breakdown || sub.breakdowns || {};
          
          // Diamond: Inject subject-level attendance percentage
          if (s.subject_attendance_agg) {
              const sa = s.subject_attendance_agg.find(x => x.subject_name === (sub.name || sub.subject));
              if (sa && sa.total_classes > 0) {
                  const attPct = Math.round((sa.classes_attended / sa.total_classes) * 100);
                  subjName = `${subjName} <span style="font-size:0.85em; color:var(--text-dim, #888); font-weight:normal;">(Att: ${attPct}%)</span>`;
              }
          }

          return {
            ...sub,
            name:       subjName,
            score,
            gradeInfo:  ctx.getGradeInfo(score),
            breakdowns: bd,
            position:   ctx.showSubjectPosition ? (stuSubjRanks.get(sub.name || sub.subject) || "—") : null,
            percent:    ctx.totalMaxScore > 0
              ? Math.round((Number(score) || 0) / ctx.totalMaxScore * 100) : 0,
          };
        });

        if (!subs.length) {
          console.warn(`[@nexus/engine] Student "${s.name}" has 0 subjects — check sync.`);
        }

        // ── Score aggregation ──────────────────────────────────────────────
        const maxSubjectsForStudent = ctx.resolveMaxSubjects(s.class_name);
        const { totalScore, numGraded, avgScore, avgPercent } = scoringLib.aggregateScores(subs, ctx.totalMaxScore, maxSubjectsForStudent);
        const overallGrade = ctx.getGradeInfo(avgScore).grade || "—";

        // ── Position — null when toggled off; templates guard with {{#if}} ──
        const classPosition = ctx.showPosition ? (rankMap.get(s.id) || "—") : null;

        // ── Padding rows (fill score table to 13 rows minimum) ────────────
        const paddingRows = [];
        for (let i = subs.length; i < 13; i++) paddingRows.push({});

        // ── Domains ───────────────────────────────────────────────────────
        const defaultDomains = [
          { trait: "Punctuality",          grade: "Excellent" },
          { trait: "Neatness",             grade: "Good"      },
          { trait: "Leadership",           grade: "Good"      },
          { trait: "Honesty",              grade: "Excellent" },
          { trait: "Physical Development", grade: "Good"      },
          { trait: "Drawing & Art",        grade: "Good"      },
        ];
        const domains = (s.domains && s.domains.length) ? s.domains : defaultDomains;

        // Save student photo
        const photoSrc = s.photo 
          ? (s.photo.startsWith('data:') ? s.photo : `data:image/jpeg;base64,${s.photo}`)
          : null;
        const photoFileUrl = photoSrc ? saveBase64Image(photoSrc, `student_${s.id}_photo`) : null;

        // Save common brand assets or signatures
        const logoUrl = ctx.identity?.logoBase64 ? saveBase64Image(ctx.identity.logoBase64, 'logo') : null;

        const principalSig = (
          ctx.identity?.tier === 'Standalone' || ctx.identity?.tier === 'Silver'
            ? null
            : ctx.identity?.principalSignBase64 || null
        );
        const principalSigUrl = principalSig ? saveBase64Image(principalSig, 'principal_sig') : null;

        const teacherSig = (
          ctx.identity?.tier === 'Standalone'
            ? null
            : s.form_teacher_signature || null
        );
        const teacherSigUrl = teacherSig ? saveBase64Image(teacherSig, `teacher_${s.id}_sig`) : null;

        const principalStamp = (ctx.identity?.tier === 'Standalone' ? null : s.principal_stamp) || null;
        const principalStampUrl = principalStamp ? saveBase64Image(principalStamp, `stamp_${s.id}`) : null;

        const hbsCtx = {
          ...ctx,
          student: {
            ...s,
            photo: photoFileUrl,
            subjects: subs,
            totalScore, avgScore, avgPercent,
            average: avgScore,
            total_score: totalScore,
            overallGrade, classPosition, domains,
          },
          showAttendance: ctx.showAttendance,
          paddingRows,
          logoBase64:       logoUrl,
          schoolName:       ctx.identity?.name || "NIGERIAN SCHOOL",
          motto:            ctx.identity?.motto || "",
          schoolAddress:    ctx.identity?.address || "",
          term:             ctx.termConfig?.term || "",
          academic_session: ctx.termConfig?.academic_session || "",
          resumptionDate:   ctx.termConfig?.resumption_date || "",
          identity: {
            ...(ctx.identity || {}),
            principalSignatureBase64: principalSigUrl,
            teacherSignatureBase64: teacherSigUrl,
            stampBase64: principalStampUrl,
          },
          suppressTeacherBlock:   ctx.identity?.tier === 'Standalone',
          suppressPrincipalBlock: ctx.identity?.tier === 'Standalone' || ctx.identity?.tier === 'Silver',
          formTeacherName:     s.form_teacher_name   || null,
          principalName:       s.principal_signature || null,
          principalStamp:      principalStampUrl,
        };

        const htmlContent = template(hbsCtx);
        // Fee Shield Watermark — only for Gold/Diamond plans that have the finance module
        let pageHtml = htmlContent;
        if (_feeGated && (s.feeStatus === 'unpaid' || s.feeStatus === 'partial')) {
          pageHtml = `<div class="report-page"><div class="fee-shield">OUTSTANDING DEBT<br><span style="font-size:30px">Contact Bursary</span></div>${htmlContent.replace(/<div class="report-page">/g, '<div>')}</div>`;
        }

        return pageHtml;
      }).join('\n');

    } else {
      pages = `<div style="padding:20px;color:red;font-family:monospace">
        Missing Handlebars template: <strong>${ctx.templateId}</strong>
      </div>`;
    }

    const css = buildSharedCSS(primary, secondary);
    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Report Cards</title><style>${css}</style></head><body>${pages}</body></html>`;
  }
  return "";
}

// ─────────────────────────────────────────────────────────────────────────────
// generateBroadsheetHTML — single-subject class performance table
// ─────────────────────────────────────────────────────────────────────────────
function generateBroadsheetHTML(payload) {
  const { students, termConfig, subject } = payload;
  const ctx = buildContext(payload);
  const { identity, primary, scoreComponents, getGradeInfo, dateStr, totalMaxScore } = ctx;
  const class_name = students[0]?.class_name || "Class";

  const bsCompHeaders = scoreComponents.map(c => `<th>${c.label}/${c.max}</th>`).join("");
  const bsRows = students.map((stu, i) => {
    const rec       = stu.subjects?.find(s => s.name === subject) || {};
    const bd        = rec.breakdown || {};
    const gi        = getGradeInfo(rec.score);
    const compCells = scoreComponents.map(c => `<td>${bd[c.key] ?? "—"}</td>`).join("");
    return `<tr>
      <td>${i + 1}</td><td>${stu.name}</td>${compCells}
      <td><b>${rec.score ?? "—"}</b></td>
      <td><span style="background:${gi.bg};color:${gi.color};padding:2px 8px;border-radius:10px;font-weight:700">${gi.grade}</span></td>
      <td>${gi.remark}</td>
    </tr>`;
  }).join("");

  const logoHtml2 = identity?.logoBase64
    ? `<img src="${identity.logoBase64}" style="width:52px;height:52px;border-radius:8px;object-fit:contain" alt="logo"/>`
    : `<div style="width:52px;height:52px;border-radius:8px;background:${primary};color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;flex-shrink:0">${(identity?.name || "N")[0]}</div>`;

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Broadsheet — ${subject}</title><style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    *{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',sans-serif;padding:14mm;background:#fff;font-size:11px}
    .rh{display:flex;align-items:center;gap:14px;padding-bottom:12px;border-bottom:3px solid ${primary};margin-bottom:16px}
    .rn{font-size:14px;font-weight:700;color:${primary};text-transform:uppercase}
    .ra{font-size:10px;color:#888;margin-top:2px}
    .badge{background:${primary};color:#fff;padding:5px 14px;border-radius:6px;font-size:11px;font-weight:700;margin-left:auto}
    table{width:100%;border-collapse:collapse}
    th{background:${primary};color:#fff;padding:8px 10px;text-align:left;font-size:10px;text-transform:uppercase}
    td{padding:7px 10px;border-bottom:1px solid #eee}tr:nth-child(even){background:#f9f9ff}
    .ft{margin-top:20px;display:flex;justify-content:space-between;font-size:10px;color:#aaa}
    @media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
  </style></head><body>
    <div class="rh">${logoHtml2}<div><div class="rn">${identity?.name || "Nexus Academy"}</div><div class="ra">${termConfig?.term || ""} · ${termConfig?.academic_session || ""}</div></div><div class="badge">📋 ${subject} — ${class_name}</div></div>
    <table><thead><tr><th>#</th><th>Student Name</th>${bsCompHeaders}<th>Total/${totalMaxScore}</th><th>Grade</th><th>Remark</th></tr></thead><tbody>${bsRows}</tbody></table>
    <div class="ft"><span>Total Students: ${students.length}</span><span>Generated by Nexus School OS · ${dateStr}</span></div>
  </body></html>`;
}

function generatePortalCards(payload) {
  const { students, identity } = payload;
  const ctx = buildContext(payload);
  const { primary, secondary } = ctx;
  const schoolName = identity?.name || "Nexus Academy";
  
  const cards = students.map(s => {
    const namePart = schoolName.split(' ')[0].toLowerCase();
    const portalUrl = `${namePart}.edu.nexus`;
    return `
      <div class="card">
        <div class="card-header">
           <div class="card-logo">${schoolName.substring(0,2).toUpperCase()}</div>
           <div class="card-school">${schoolName}</div>
        </div>
        <div class="card-body">
          <div class="qr-side">
            <div class="qr-box">
              <div class="qr-inner"></div>
            </div>
          </div>
          <div class="card-instr">
            Scan to access <strong>Sovereign Portal</strong><br>
            or visit <span>${portalUrl}</span>
          </div>
        </div>
        <div class="card-footer">
          Student ID: ${s.id} &nbsp;·&nbsp; ${s.name}<br>
          Official Parent Access Card
        </div>
      </div>
    `;
  }).join("");

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Portal Access Cards</title><style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap');
    body{font-family:'Inter',sans-serif;padding:10mm;background:#f8f9fa;color:#1a1a1a}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:8mm}
    .card{background:#fff;border:1px solid #e0e0e0;border-left:4px solid ${primary};border-radius:12px;padding:16px;height:52mm;display:flex;flex-direction:column;position:relative;overflow:hidden;box-shadow:0 2px 4px rgba(0,0,0,0.05)}
    .card-header{display:flex;align-items:center;gap:10px;margin-bottom:12px}
    .card-logo{background:${primary};color:#fff;width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800}
    .card-school{font-size:11px;font-weight:800;color:${primary};text-transform:uppercase;letter-spacing:0.5px}
    .card-body{flex:1;display:flex;align-items:center;gap:16px}
    .qr-box{width:64px;height:64px;border:2px solid #000;padding:2px;border-radius:4px}
    .qr-inner{width:100%;height:100%;background:repeating-conic-gradient(#000 0% 25%, #fff 0% 50%) 50% / 8px 8px;}
    .card-instr{font-size:11px;color:#444;line-height:1.5}
    .card-instr strong{color:#000}
    .card-instr span{color:${secondary};font-weight:800;text-decoration:underline}
    .card-footer{font-size:9px;color:#999;margin-top:12px;border-top:1px solid #f0f0f0;padding-top:8px;font-weight:600}
    @media print{
      body{background:#fff;padding:0}
      .grid{gap:5mm}
      .card{break-inside:avoid;border:1px solid #ddd;border-left:4px solid ${primary}}
    }
  </style></head><body><div class="grid">${cards}</div></body></html>`;
}

module.exports = { generateHTMLPages, generateBroadsheetHTML, generatePortalCards, buildContext };
