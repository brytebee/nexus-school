# Technical Architecture: Financial Hub and Fee Shield

This document outlines the engineering architecture of the Nexus School OS Financial Hub, ledger structure, and the Fee Shield execution gate.

---

## 1. Database Schema

The financial system uses a robust triple-entry ledger design inside SQLite to track billings, payments, and adjustments.

```sql
-- Tracks invoices issued to students based on Applied Fee Schedules
CREATE TABLE student_invoices (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    fee_schedule_id VARCHAR(64) NOT NULL,
    term VARCHAR(16) NOT NULL,
    academic_session VARCHAR(16) NOT NULL,
    amount_billed REAL NOT NULL,          -- Base billed amount (e.g. 50000.0)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(64) NOT NULL,      -- Username of the admin who billed
    FOREIGN KEY(student_id) REFERENCES students(id)
);

-- Tracks adjustments applied to standard bills (Scholarships, waivers, levies)
CREATE TABLE fee_adjustments (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    invoice_id VARCHAR(64),
    type VARCHAR(16) NOT NULL,            -- "WAIVER", "ADDITIONAL_CHARGE"
    amount REAL NOT NULL,                 -- Discount (negative) or charge (positive)
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(64) NOT NULL,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(invoice_id) REFERENCES student_invoices(id)
);

-- Tracks payments received from parents
CREATE TABLE payments (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    amount_paid REAL NOT NULL,            -- Amount received (e.g. 20000.0)
    payment_method VARCHAR(32) NOT NULL,  -- "BANK_TRANSFER", "CASH", "CARD"
    transaction_ref VARCHAR(128),         -- External banking transaction ID
    term VARCHAR(16) NOT NULL,
    academic_session VARCHAR(16) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by VARCHAR(64) NOT NULL,     -- Admin who entered the payment (Audit Log)
    FOREIGN KEY(student_id) REFERENCES students(id)
);
```

---

## 2. The Fee Shield Compilation Gate

During results compilation, `report-compiler.js` runs a financial query to evaluate the student's debt ratio before rendering the report.

### Arithmetic Logic for Debt Ratios
1. **Total Billed**: Sum of standard invoices + positive adjustments.
2. **Total Deductions**: Sum of negative adjustments (waivers/scholarships).
3. **Total Paid**: Sum of all payments.
4. **Real Balance**: `(Total Billed - Total Deductions) - Total Paid`.

### The Code-Level Compilation Gate

Inside `report-compiler.js`, the gate processes this balance:

```javascript
async function evaluateFeeShield(studentId, term, session, config) {
  // If licensing is not Diamond, Fee Shield is bypassed
  if (global.licenseTier !== 'Diamond') {
    return { status: 'CLEARED', balance: 0 };
  }

  const financialSummary = await db.get(`
    SELECT 
      (COALESCE((SELECT SUM(amount_billed) FROM student_invoices WHERE student_id = ? AND term = ? AND academic_session = ?), 0) +
       COALESCE((SELECT SUM(amount) FROM fee_adjustments WHERE student_id = ? AND type = 'ADDITIONAL_CHARGE'), 0)) AS total_billed,
      ABS(COALESCE((SELECT SUM(amount) FROM fee_adjustments WHERE student_id = ? AND type = 'WAIVER'), 0)) AS total_waiver,
      COALESCE((SELECT SUM(amount_paid) FROM payments WHERE student_id = ? AND term = ? AND academic_session = ?), 0) AS total_paid
  `, [studentId, term, session, studentId, studentId, studentId, term, session]);

  const netBilled = financialSummary.total_billed - financialSummary.total_waiver;
  const outstandingBalance = netBilled - financialSummary.total_paid;

  if (outstandingBalance <= config.fee_shield_tolerance_limit) {
    return { status: 'CLEARED', balance: outstandingBalance };
  }

  // Trigger Action Gating depending on term settings
  if (config.fee_shield_mode === 'HARD_LOCK') {
    return { status: 'LOCKED', balance: outstandingBalance };
  } else {
    return { status: 'WATERMARKED', balance: outstandingBalance };
  }
}
```

### Flow Outcome:
* If the status is **`LOCKED`**, the compiler throws a custom exception, which routes the builder to compile the fallback debt warning sheet.
* If the status is **`WATERMARKED`**, the compiler injects a boolean `watermark: true` to the Handlebars compilation context. The CSS layer then overlays a skewed base64 background SVG text:
  ```css
  .watermarked-report::before {
      content: "OUTSTANDING FEES - UNRELEASED REPORT";
      position: absolute;
      transform: rotate(-45deg);
      opacity: 0.12;
      font-size: 4rem;
      /* ... positioning layouts ... */
  }
  ```

---

## 3. Tier Capabilities Comparison

| Architectural Attribute | Gold Capability | Diamond Capability |
| :--- | :--- | :--- |
| **Active DB Ledger** | Writes to `student_invoices` and `payments` tables. | Fully locks database, tracking actions via `recorded_by` indices. |
| **Simultaneous Sync** | Locked to single-device write access. | Multi-admin SQLite WAL mode enabled, permitting concurrent desktop/tablet writes. |
| **Fee Shield Enforcer** | Bypassed. Reports print without financial validation checks. | Active. Bypasses only if explicit exemption flag exists in `student_exemption` table. |
| **Exam QR Gate** | Bypassed. | Generates cryptographic QR string: `encrypt(studentId + ":" + balance)`. |
