# Nexus School OS: Financial Hub Guide

Welcome to the Nexus Financial Hub! This guide will explain how to set up termly fee schedules, invoice parents in bulk, record single or multi-admin payments, and leverage the automated **Fee Shield** to accelerate fee collections.

---

## Overview

The Financial Hub in Nexus is designed to solve a school's most critical challenge: **securing tuition payments and eliminating manual debtor tracking**. By combining an offline transaction ledger with an automated results blocker, Nexus helps schools recover millions of Naira in outstanding fees in their first term.

---

## 1. Bulk Invoicing and Fee Schedules

Instead of manually typing an invoice for every single student, Nexus uses **Fee Structures** to bill entire classrooms simultaneously.

### How to set up and apply bulk billing:
1. Navigate to the **Financial Hub** and click **Fee Schedules**.
2. Create a new fee schedule for each class category (e.g. *Tuition + Dev Levy + PTA* for JSS students = ₦50,000; *Tuition + Lab Fee + PTA* for SSS students = ₦60,000).
3. Select the class category and click **Apply Invoice Schedule**.
4. **What happens next**: Nexus will instantly generate customized ledger invoices for *every student* enrolled in those classes.

### Adjustments and Scholarships:
If a student has a scholarship or discount (e.g. staff child waiver or sibling discount):
* Open the student's billing record.
* Click **Add Adjustment**.
* Enter the discount amount and reason (e.g. *Staff Child: 50% Tuition Waiver = ₦25,000*).
* Nexus adjusts their outstanding balance instantly while preserving the general class schedule data.

---

## 2. Managing Payments and Ledgers

Nexus tracks every payment to keep your accounts accurate and audited.

### A. Recording Payments:
* When a parent pays via cash, bank transfer, or card, go to their profile in the **Financial Hub**.
* Click **Record Payment**.
* Enter the amount, payment method (e.g., Bank Transfer), transaction reference (e.g., bank receipt code), and date.
* The system instantly updates the student's ledger and generates a printable payment receipt.

### B. Multi-Admin Audits:
For larger school admin teams, Nexus tracks **which administrator recorded which payment**. Every single receipt is stamped with the recording admin's initials and username, creating an unalterable audit trail for the school owner to review.

---

## 3. The "Fee Shield" (Debtor Results Lock)

The **Fee Shield** is the ultimate tool for accelerating fee collection. When parents know their child's academic reports will be locked until outstanding balances are paid, they pay on time.

### How the Fee Shield operates:
When you generate report cards in the **Print Hub**, Nexus checks each student's real-time financial ledger against the **Fee Shield threshold** set by the school owner.

Depending on your settings, report cards for students with outstanding balances are:
1. **Watermarked**: The report card is compiled, but a highly visible **"OUTSTANDING BALANCE - OFFICIALLY UNRELEASED"** watermark is stamped diagonally across every page.
2. **Hard Locked**: The compiler refuses to compile the report card altogether. In its place, it generates a single sheet stating: **"Results Locked: Please contact the bursary to clear outstanding fees (Balance: ₦25,000)."**

> [!TIP]
> **Commercial ROI**: Automated Fee Shield alerts combined with early invoice distribution have been shown to recover up to **₦3.6M to ₦4.2M** in previously uncollectable outstanding fees in a single term for a standard 300-student school.

---

## 4. Tier Availability

* **Silver Tier**: Basic payment tracking (manually logs whether a student has "Paid" or "Unpaid" in a single column).
* **Gold Tier**: Class fee structures, bulk billing schedule applicator, individual scholarship adjustments/waivers, and printable payment receipts.
* **Diamond Tier**: Full unlocks! Multi-admin Simultaneous Ledgers, audit logs tracking admin signatures, the **Fee Shield** (automatic watermarking and results locking), and Exam Clearance QR Codes (which admins can scan at the exam hall door to instantly verify payment clearance).
