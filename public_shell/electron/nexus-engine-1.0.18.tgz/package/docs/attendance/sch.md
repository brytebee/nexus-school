# Nexus School OS: Attendance Management Guide

Welcome to the Nexus Attendance Module! This guide will explain how to track, manage, and report student attendance using your Nexus School OS platform.

## Overview
Attendance in Nexus is designed to be effortless. Instead of manually calculating how many days a student was present at the end of the term, Nexus calculates it automatically and places it directly onto their report card.

## 1. How Attendance is Recorded
*(Note: Full mobile entry is rolling out to Gold and Diamond schools soon).*
Teachers will use the **Nexus Android App** in the classroom. With a single tap, a teacher can mark a student as "Absent" or "Late". If no action is taken, the student is assumed "Present". When the teacher's phone syncs with the Admin's laptop, the attendance records are automatically saved to the school's master database.

## 2. Displaying Attendance on Report Cards
When it is time to generate results, the Admin has full control over whether attendance is shown to parents.

**How to show attendance:**
1. Open the **Print Hub** on the desktop app.
2. At the top of the screen, locate the **Show Attendance** toggle and turn it on.
3. When you generate the report cards, a new section will appear (e.g., "Days Present: 40 / 45").

*If you turn this off, all attendance information is completely hidden from the report card.*

## 3. Grading Attendance (The "Att. Score Weight")
Some schools award marks for good attendance (e.g., Attendance is worth 10 marks out of the overall 100). Nexus can do this automatically!

**How to grade attendance:**
1. In the **Print Hub**, make sure **Show Attendance** is toggled ON.
2. Next to it, you will see a box labeled **Att. Score Weight**. 
3. Enter the maximum score a student can get for attendance (e.g., `10`).
4. **What happens next:** Nexus will automatically calculate the student's attendance percentage and award them a score. (For example, if they attended 90% of the term, they get 9 out of 10 points). This score is injected into *every subject* and counts towards their cumulative average.

## 4. Tier Availability
- **Silver Tier**: Can view and print attendance summaries on report cards if the data exists.
- **Gold Tier**: Unlocks the ability for teachers to log daily attendance via the mobile app.
- **Diamond Tier**: Unlocks advanced "Subject-Level" attendance tracking (Truancy detection).
