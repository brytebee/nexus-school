# Nexus Pulse: Office Hours Bot (Gold Tier)

Welcome to Nexus Pulse! This guide explains how to use the local WhatsApp bot to automate parent communication during school hours.

## Overview
Nexus Pulse acts as a 24/7 (during school hours) receptionist for your school. Parents can message the school's WhatsApp number to get instant, private updates on their child's results and attendance without calling the school office.

## 1. Setting Up the Bot
The Office Hours bot runs directly on your school's main laptop.
1. Open the **Nexus Pulse** tab in the desktop app.
2. Click **Start Bot**.
3. A QR code will appear. Open WhatsApp on your school's official phone, go to **Linked Devices**, and scan the code.
4. Once "Ready", the bot is active!

## 2. How Parents Interact
Parents simply send a message to your school's number.
- The bot greets them and presents a simple menu:
  - **1. Results**
  - **2. Attendance**
  - **3. Fees**
- Parents reply with **1, 2, or 3** to navigate.
- The bot automatically identifies the parent based on the phone number registered in the Student Directory.

## 3. Important: The "Office Hours" Limitation
Since this bot runs on your local laptop:
- **Laptop Must Be On**: The bot only works when the Nexus desktop app is running and the laptop is connected to the internet.
- **Connection**: If the laptop is closed or loses internet, the bot will stop responding until it is back online.

*Tip: For 24/7 availability even when the school is closed, consider upgrading to the **Diamond Plan**.*

## 4. Tier Availability
- **Gold Tier**: Full access to the Office Hours bot.
- **Diamond Tier**: Includes the "Always-On" Cloud Bridge (24/7 service).
