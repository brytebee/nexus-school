# Technical Architecture: Office Hours Bot (Local)

This document outlines the implementation of the local WhatsApp bot using `whatsapp-web.js` within the Electron environment.

## 1. Architecture Overview
The Office Hours bot is a local service running in the Electron main process. 
- **Library**: `whatsapp-web.js` (Puppeteer-based).
- **Authentication**: `LocalAuth` strategy persists session data in `~/.nexus_pulse_auth`.
- **UI Bridge**: Communicates state (Starting, QR, Ready) to the renderer via IPC (`pulse-status`).

## 2. Conversation State Machine
To provide a professional experience, the bot uses a stateful `Map` to track parent sessions:
- **Key**: Last 10 digits of the parent's phone number.
- **Value**: Session object containing current state (MENU, SCOPE, TERM_SELECT) and linked student data.
- **TTL**: Sessions automatically expire after 5 minutes of inactivity to free memory and reset the flow.

## 3. Phone Resolution & LID Handling
WhatsApp's multi-device architecture often masks phone numbers with internal Linked IDs (LIDs). The bot implements a multi-strategy resolution:
1. `contact.number` extraction.
2. `contact.id._serialized` parsing (stripping device suffixes).
3. `client.getNumberId(lid)` lookup for hard-to-resolve IDs.

## 4. Security & Privacy
- **Local Data**: All queries are performed against the local `nexus.sqlite` database. 
- **Privacy**: Only numbers registered in the `parent_phone` column of the `students` table can access data. If a number is not found, the bot gracefully declines the request.
- **Gating**: The `pulse:start` IPC channel is only activated if the license tier is `Gold` or higher.
