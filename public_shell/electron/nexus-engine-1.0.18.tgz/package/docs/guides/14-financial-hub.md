# Nexus School OS: Managing Fees in the Financial Hub

This guide explains how to set up fee billing schedules, invoice students in bulk, record payments, and use the Fee Shield to enforce payment compliance across your school.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **Financial Hub** is where all school billing, payment records, and debt management happen. Instead of spreadsheets, paper ledgers, or WhatsApp messages asking *"Has Obi paid?"*, Nexus gives you a live, real-time financial dashboard for every student — with automated invoicing and enforcement built in.

---

## 1. Setting Up a Fee Structure

A Fee Structure defines what items make up the total term bill.

1. Open Nexus School OS → click **Financial Hub** in the left sidebar → go to the **Fee Structure** tab.
2. Select your class from the searchable **Class** Combobox (e.g. `JSS 1 Gold`).
3. Add billing items individually (e.g. *Tuition: ₦35,000*, *PTA: ₦5,000*, *Dev Levy: ₦5,000*).
4. If you have multiple arms for the same class level (e.g. *JSS 1 Gold*, *JSS 1 Silver*, *JSS 1 Blue*), click the **📋 Copy to all arms of JSS 1** button to copy all configured fee items to the other arms in a single click.
5. Once the structure is ready, select the target term and click **⚡ Apply to Class** to instantly bill all students enrolled in those classes.

---

## 2. Recording a Student Payment

When a parent pays:

1. In the **Financial Hub**, search for the student by name or registration number.
2. Click **Record Payment**.
3. Enter:
   - **Amount Paid**: e.g. ₦25,000
   - **Payment Method**: Cash / Bank Transfer / Card
   - **Transaction Reference**: e.g. bank teller number
   - **Payment Date**
4. Click **Save Payment**.

The student's ledger instantly updates — showing the new balance, payment history, and current status (Unpaid / Partial / Cleared).

---

## 3. Adding Adjustments & Scholarships

For students on scholarships, staff waivers, or sibling discounts:

1. Open the **Adjustments** tab in the Financial Hub.
2. Under **New Fee Adjustment**, select the class using the searchable **Class Filter** Combobox to filter the student list.
3. Search and select the student in the **Student (Search)** field.
4. Fill in the adjustment details:
   - **Adjustment Type**: Discount / Waiver / Credit
   - **Amount**: e.g. ₦15,000
   - **Reason**: *"Staff Child — 50% Tuition Waiver"*
5. Click **Save**. The student's net balance is instantly recalculated.

---

## 4. Activating the Fee Shield (Debtor Results Lock)

The **Fee Shield** prevents report cards from being issued to students with outstanding balances.

1. In the Financial Hub, click **Fee Shield Settings**.
2. Configure the threshold:
   - **Mode**: Fixed amount (e.g. any balance over ₦0) or Percentage (e.g. outstanding > 30% of total bill).
   - **Enforcement**: Watermark only (card shows "BALANCE OUTSTANDING") or Hard Lock (no card generated).
3. Toggle **Enable Fee Shield** to ON.

> [!TIP]
> **Commercial ROI**: Schools using the Fee Shield report recovering an average of **₦3.6M – ₦4.2M** in outstanding fees per term for a school of 300 students.

---

## 5. Generating Financial Reports

1. In the Financial Hub, click **Reports**.
2. Choose scope: **By Class**, **Entire School**, or **Debtors Only**.
3. Click **Export PDF** to generate a clean financial summary for the school owner.

---

## 6. Bulk Import via CSV

The **📥 Bulk Import** tab in Financial Hub allows you to load large volumes of fee data from spreadsheet files instead of entering each record manually.

> [!NOTE]
> 🎥 Video guide: *How to use the Bulk Fee Import templates*

### 6.1 Fee Structure CSV

Defines billing line items for each class and term. Upserts existing rows — re-importing the same file is safe.

| Column | Required | Notes |
|---|---|---|
| `Class_Name` | ✅ | Must match a class configured in the Classes screen (e.g. `JSS 1 Gold`) |
| `Item_Name` | ✅ | Label for the fee item (e.g. `Tuition`, `PTA Levy`) |
| `Amount` | ✅ | Numeric amount in Naira — no commas (e.g. `35000`) |
| `Term` | ✅ | `First Term`, `Second Term`, `Third Term`, or `All Terms` |

**Example row:**
```
JSS 1 Gold,Tuition,35000,First Term
```

### 6.2 Fee Payment CSV

Bulk-records payments against student accounts. Updates both the transaction ledger and student balance.

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ | Must exist in the Students database |
| `Academic_Session` | ✅ | e.g. `2025/2026` |
| `Term` | ✅ | e.g. `First Term` |
| `Amount_Paid` | ✅ | Numeric amount in Naira |
| `Payment_Method` | ✅ | `cash`, `transfer`, `pos`, or `bank_teller` |
| `Reference_Number` | ❖ | Bank teller or transfer reference |
| `Payment_Date` | ❖ | ISO format `YYYY-MM-DD` — defaults to today |
| `Recorded_By` | ❖ | Staff name — defaults to `Admin` |

> [!IMPORTANT]
> Invalid rows (missing required fields, zero amount) are skipped and logged to the console. The rest of the file still imports.

### 6.3 Fee Adjustment CSV

Bulk-applies scholarships, waivers, and discounts.

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ | Must exist in the Students database |
| `Academic_Session` | ✅ | e.g. `2025/2026` |
| `Term` | ✅ | e.g. `First Term` |
| `Adjustment_Type` | ✅ | `scholarship`, `waiver`, `owner_grant`, `bursary`, or `discount` |
| `Amount` | ✅ | Numeric reduction amount in Naira |
| `Description` | ❖ | e.g. `Staff Child — 50% Tuition Waiver` |
| `Approved_By` | ❖ | Defaults to `Admin` |

### Using the Import Tab

1. In Financial Hub, click the **📥 Bulk Import** tab.
2. Click **⬇️ Download Template** for the import type you need.
3. Open the template in Excel or Google Sheets, fill in your data, and save as CSV.
4. Click **📂 Choose CSV & Import** and select your file.
5. A result message appears instantly: `✅ N rows imported successfully` or `❌ Error: ...`.
6. The Fee Roster refreshes automatically on success.

> [!TIP]
> All three imports are atomic — if the transaction fails mid-file (e.g. a DB error), no partial data is written. Fix the error and re-import the whole file.

---

## Tier Availability

* **Silver Tier**: Basic Paid/Unpaid tracking per student. No bulk invoicing.
* **Gold Tier**: Bulk fee schedules, individual adjustments, payment receipts, Fee Shield, CSV Bulk Import.
* **Diamond Tier**: All Gold features plus multi-admin audit logs (every payment stamped with the recording bursar's name), Exam Clearance QR Codes, and Google Drive export.
