# Nexus School OS: Subscribing to the Silver Plan

This guide explains how to select the Silver subscription plan for your school — the perfect starting point for institutions adopting digital school management for the first time.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **Silver Plan** gives your school access to core Nexus features including student and teacher registries, basic payment tracking, and standard report card generation. It is ideal for small-to-medium schools taking their first step into structured digital management.

---

## 1. Choosing the Silver Plan

After verifying your account, you will land on the **Subscription Plans** page.

1. Review the feature comparison table on screen.
2. Click **Select Plan** under the **Silver** column.
3. You will be taken to the checkout screen.

---

## 2. First Time Install vs. Renewal

On the checkout screen, you will see a checkbox option:

> ☑ **This is a first-time installation on a new device**

| Scenario | What to do |
| :--- | :--- |
| **Brand new school, first device** | Keep this checked ✅ |
| **Renewing an existing subscription** | Uncheck this ✗ (enter your existing License Serial instead) |
| **Adding a second admin device** | Uncheck this ✗ (use the Device Expansion flow in Settings instead) |

> [!IMPORTANT]
> Checking "First Time Install" generates a brand new hardware-bound license. Unchecking it triggers the renewal flow which preserves your existing school data and device bindings.

---

## 3. Completing the Checkout

1. Confirm your school details on the order summary page.
2. Select your preferred payment method (Card, Bank Transfer).
3. Complete the payment.
4. Your **License Key** and download link will be displayed on screen and sent to your registered email address.

---

## 4. What You Get with Silver

| Feature | Silver |
| :--- | :--- |
| Student & Teacher Registries | ✅ |
| Offline Score Entry (Desktop) | ✅ |
| Basic Report Card (Classic Template) | ✅ |
| Basic Fee Tracking (Paid/Unpaid) | ✅ |
| Local Wi-Fi Broadcaster | ❌ |
| Fee Shield (Results Lock) | ❌ |
| Mobile App Sync | ❌ |

---

## Tier Availability

This guide covers the **Silver Tier** onboarding flow. See the Gold and Diamond guides to explore upgrade paths.
