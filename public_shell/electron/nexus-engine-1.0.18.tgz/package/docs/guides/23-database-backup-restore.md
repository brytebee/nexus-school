# Nexus School OS: Database Backup & Restore

This guide explains how to back up and restore your school database in Nexus School OS, ensuring data integrity and protection against hardware failure or accidental data loss.

> [!NOTE]
> **Video Guide**: A walkthrough video demonstrating how to perform backups and restores will be embedded here.

---

## Overview

All school records — including classes, teachers, students, grades, attendance, and fee status — are stored locally on your master node in a high-performance SQLite database. Managing backups of this file is essential for safe school administration.

---

## 1. Creating Database Backups

Nexus provides two main ways to back up your database:

### A. Automatic Local Backup on Reset
Whenever an administrator triggers a **Reset All Data** command (Settings → Reset All Data), the system forces a security check.
1. Enter your **Sudo PIN**.
2. A database reset protection modal will appear asking: *Would you like to save a local backup of your database before wiping all data?*
3. Click **Save Local Backup** to generate a copy of the database before the wipe proceeds.

### B. Manual Local Backups
To manually back up your database, you can copy the active SQLite file directly from your system directory:
* **Storage Location**: `~/Library/Application Support/NexusSchoolOS/nexus.sqlite` (on macOS) or `%APPDATA%/NexusSchoolOS/nexus.sqlite` (on Windows).
* Simply copy this file to an external drive or cloud storage.

---

## 2. Restoring a Database Backup

If you need to restore your school data from an existing `.sqlite` backup copy (e.g. recovering from a device upgrade, or reverting a mistake):

1. Open Nexus School OS on the master node and navigate to **Settings** in the left sidebar.
2. Click **📋 Data Templates** in the header to slide open the right drawer.
3. Scroll to the bottom of the drawer to find the **Restore Database Backup** card.
4. Click **Select Backup file**.
5. Read the warning prompt carefully: *This will completely replace the current database with the selected backup. All existing changes will be lost, and the application will restart.*
6. Click **Yes, Restore Backup** to confirm.
7. A system file chooser will open. Locate and select your `.sqlite` or `.db` backup file.
8. The application will immediately close the active database connection, overwrite it with the selected file, and automatically restart.

> [!WARNING]
> Restoring a database completely replaces your current records. Any grades, registrations, or payments entered since the backup was taken will be permanently lost. Always create a safety copy of your current active database before performing a restore.

> [!NOTE]
> **Complete Settings & Identity Restore**: School identity configurations (including school name, address, motto, primary/accent colors, principal signature, and logo assets) are fully serialized and synced to the database file itself under the `school_identity` configuration key. Restoring a backup SQLite file will automatically extract, re-populate, and overwrite the local `identity.json` configuration file, ensuring a full and unified restore of both school records and branding details.

---

## 3. Cloud Backups (Nexus Pulse)

For schools subscribed to the **Diamond Tier**, Nexus Pulse handles automated, encrypted cloud database backups.
- Configured via the **Nexus Pulse** tab.
- Automatically encrypts and uploads database snapshots to the school's configured Google Drive folder at scheduled intervals.
- Protects the school from physical hardware theft or hard drive failure.

---

## 3. Backup Coverage & Restraints

### What is Covered (Database-Level Data)
The SQLite database backup (`nexus.sqlite` / `nexus_os.db`) contains all configurations, rules, and student records. Restoring a backup completely restores — and a factory reset completely clears — data for the following modules:
* **Result Studio & Print Hub**: All student grades, assessment parameters, subject structures, form teacher comments, principal remarks, and report configurations.
* **Financial Hub**: Termly billing, student fee ledgers, transaction records, receipts, and fee adjustments.
* **CBT Arena**: Question banks, active exam configurations, batches, external candidate registrations, exam tokens, and candidate answer sheets.
* **Portal Content**: Dynamically configured news articles, categories, school policies, and student-submitted portal receipts.
* **Nexus Pulse**: Outbound message queues, system sync configuration thresholds, and Google Drive auth configurations.
* **School Identity Settings**: All metadata settings (school name, address, motto, primary/accent colors, principal signature, and logo assets) are synced inside the database.

### What is NOT Covered (System Caches & Restraints)
Because certain configurations live outside the SQLite database as physical system files, they are subject to the following restraints:
* **WhatsApp Bot Authentication Session**: The active authenticated WhatsApp session profile is saved locally on the machine's file system under `.nexus_pulse_auth` in the user's home folder. This browser profile is linked to the physical hardware. It is NOT included in the database backup. During a **Reset All Data** factory wipe, this session is permanently deleted to log out the WhatsApp bot cleanly.
* **Nexus Scholar Knowledge Index**: The AI knowledge base document index is stored in a separate JSON file (`nexus_knowledge_index.json` in Electron's userData folder) outside the database. A factory reset wipes this index cleanly. Database backups do not contain these index files. If you restore a backup on a new system, you must re-upload your knowledge base PDFs in the Scholar tab.

---

## 4. Tier Availability

* **Standalone Pack**: Local file backup/restores via Settings drawer.
* **Silver Tier**: Local file backup/restores via Settings drawer.
* **Gold Tier**: Local file backup/restores via Settings drawer.
* **Diamond Tier**: Full local database backup/restores + automated, encrypted cloud sync via Nexus Pulse (Google Drive).
