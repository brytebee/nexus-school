# Nexus School OS: Networking Architecture — Developer Reference

This document describes the server networking architecture of Nexus School OS. It is intended for engineers building new client modules, adding route groups, or diagnosing connectivity issues.

---

## Overview

Nexus School OS runs a **single Express server on Port 3000**. All client types — the mobile Grader app, the Sovereign Parent Portal, the CBT Arena, and any future modules — connect to this one port. There are no separate servers, no separate ports, and no reverse-proxy layer. This design eliminates firewall configuration errors and is purpose-built for **Zero-Router (hotspot) deployments** where the school laptop acts as the network hub.

---

## Port Layout

| Port | Purpose |
| :--- | :--- |
| **3000** | All traffic — sync, portal, CBT, and future modules share one Express instance |

> [!IMPORTANT]
> Do **not** introduce a second port for a new module. Mount all new route groups on the existing Port 3000 Express app using a unique path prefix. See [How to Add a New Route Group](#how-to-add-a-new-route-group).

---

## Express Router Tree

```
Port 3000
├── POST /handshake              → Mobile Grader Day-1 pairing (V1 — legacy mount)
├── POST /sync                   → Mobile Grader grade submission (V1 — legacy mount)
├── /portal/*                   → Sovereign Parent Portal
│   ├── GET  /portal
│   ├── POST /portal/api/request-otp
│   ├── POST /portal/api/verify-otp
│   └── GET  /portal/api/student-data
└── /cbt/*                      → CBT Arena
    ├── GET  /cbt
    ├── POST /cbt/api/verify-token
    └── POST /cbt/api/submit-exam
```

All routes are defined inside `startServer()` in `private_engine/src/server.js`.

---

## Legacy Shim Note

`/handshake` and `/sync` are currently **mounted directly on `app`** (not under an `/api` prefix). This matches the existing Android Grader client which calls these paths without the prefix.

A compatibility shim will be added when the Android client is updated:

- Future canonical paths: `/api/handshake` and `/api/sync`
- Until the Android client is updated, **both** `/handshake` and `/api/handshake` must resolve to the same handler

> [!WARNING]
> Do not remove the legacy `/handshake` and `/sync` mounts until the Android client has been updated and confirmed in production. Removing them prematurely will break all field-deployed devices.

---

## Zero-Router Setup (Hotspot)

Nexus is designed to operate without a router. The school laptop itself acts as the Wi-Fi access point.

1. Admin enables **Windows Mobile Hotspot** (or macOS Internet Sharing).
2. The laptop self-assigns `192.168.137.1` (Windows) or a similar link-local IP.
3. All client devices (phones, tablets) connect to the hotspot SSID.
4. Nexus advertises `nexus.local` via **Bonjour/mDNS** pointing to Port 3000.
5. Clients resolve the hostname automatically — no manual IP entry required:

| Client | URL |
| :--- | :--- |
| Android Grader | `http://nexus.local/handshake` |
| Parent Portal | `http://nexus.local/portal` |
| CBT Arena | `http://nexus.local/cbt` |

---

## Bonjour / mDNS

| Property | Value |
| :--- | :--- |
| Library | `bonjour` npm package |
| Service name | `nexus.local` |
| Advertised port | 3000 |
| Discovery | Automatic — clients resolve the hostname without manual IP configuration |

> [!TIP]
> On Windows, Bonjour is bundled with iTunes or can be installed as a standalone package. If `nexus.local` does not resolve on a client device, confirm that the Bonjour service is running on the host laptop (`services.msc` → Bonjour Service → Running).

---

## How to Add a New Route Group

Follow this checklist when adding a new client module:

1. **Create an Express Router** in `server.js`:
   ```js
   const myRouter = express.Router();
   ```

2. **Add your routes** to the router:
   ```js
   myRouter.get('/', (req, res) => { /* ... */ });
   myRouter.post('/api/action', (req, res) => { /* ... */ });
   ```

3. **Mount the router** on a unique prefix:
   ```js
   app.use('/myprefix', myRouter);
   ```

4. **Serve static files** if the module has a frontend:
   ```js
   app.use('/myprefix', express.static(path.join(__dirname, '../public/myprefix')));
   ```

5. **Update the Router Tree** diagram in this guide with the new prefix and routes.

6. **Add a Bonjour service alias** (optional) if the module needs its own mDNS name for discovery. Otherwise, clients can simply use `http://nexus.local/myprefix`.

---

## Key Files

| File | Responsibility |
| :--- | :--- |
| `private_engine/src/server.js` | All Express routes defined inside `startServer()` |
| `public_shell/electron/main.js` | Calls `startServer()` on Electron `app.ready` |
| `networking-upgrade.md` | Original architectural specification and design rationale |

---

## Implementation Status

| Item | Status |
| :--- | :--- |
| Single Port 3000 | ✅ Complete |
| `/portal` routes | ✅ Complete |
| `/cbt` routes | ✅ Complete |
| `/api` Router extraction | 🔄 Pending (Android client coordination required) |
| `/handshake` legacy deprecation | 📅 Future — after Android update ships |

---

## Tier Availability

Networking is **infrastructure-level and not gated by license**. All tiers — Standalone, Silver, Gold, and Diamond — run the same single-port Express architecture. Feature access within each connected module (portal content, CBT question banks, etc.) is governed by the tier, but the transport layer is identical across all deployments.
