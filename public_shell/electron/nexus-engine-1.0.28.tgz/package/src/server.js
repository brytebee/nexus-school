const express = require('express');
const app = express();
const address = require('address');
const fs = require('fs');
const csv = require('csv-parser');
const crypto = require('crypto');

const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

const database = require('./database');
const reports = require('./report-compiler.js');

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// ── Scoped LAN Security Middlewares ──────────────────────────────────────────
const handshakeRates = new Map();
function handshakeRateLimiter(req, res, next) {
    const ip = req.ip || req.socket.remoteAddress;
    const now = Date.now();
    let rate = handshakeRates.get(ip);
    if (!rate || now > rate.resetTime) {
        rate = { count: 1, resetTime: now + 60000 };
        handshakeRates.set(ip, rate);
        return next();
    }
    if (rate.count >= 10) {
        return res.status(429).json({ error: "Too many requests. Please try again after a minute." });
    }
    rate.count++;
    next();
}

function requireDeviceAuth(req, res, next) {
    const deviceId = req.headers['x-device-id'] || req.body?.device_id;
    if (!deviceId) {
        return res.status(401).json({ error: "Unauthorized: Missing device identifier" });
    }
    const db = database.getDb();
    const device = db.prepare('SELECT 1 FROM connected_devices WHERE device_id = ?').get(deviceId);
    if (!device) {
        return res.status(403).json({ error: "Forbidden: Device not paired" });
    }
    const isRevoked = db.prepare("SELECT 1 FROM revoked_devices WHERE device_id = ?").get(deviceId);
    if (isRevoked) {
        return res.status(403).json({ error: "Forbidden: Device is revoked" });
    }
    next();
}

// ── Activity Log Helper ───────────────────────────────────────────────────────
// Call this from any handler (desktop or server) to record an auditable action.
// Never throws — logging failures are non-fatal.
function logActivity({ device_id = 'DESKTOP', device_model = 'Desktop App',
                       actor_label = 'Admin', event_type, payload = null }) {
    try {
        const db = database.getDb();
        const hash = payload
            ? crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex').slice(0, 16)
            : null;
        db.prepare(`
            INSERT INTO activity_log (device_id, device_model, actor_label, event_type, payload_hash)
            VALUES (?, ?, ?, ?, ?)
        `).run(device_id, device_model, actor_label, event_type, hash);
    } catch (e) {
        console.warn('[ActivityLog] Failed to write log entry:', e.message);
    }
}

function sortGradingComponents(components) {
    if (!components || !Array.isArray(components)) return [];
    return [...components].sort((a, b) => {
        const aKey = (a.key || a.label || '').toLowerCase();
        const bKey = (b.key || b.label || '').toLowerCase();
        const isACaOrExam = aKey.startsWith('ca') || aKey.includes('exam');
        const isBCaOrExam = bKey.startsWith('ca') || bKey.includes('exam');
        if (isACaOrExam && !isBCaOrExam) return 1;
        if (!isACaOrExam && isBCaOrExam) return -1;
        if (isACaOrExam && isBCaOrExam) {
            const isAExam = aKey.includes('exam');
            const isBExam = bKey.includes('exam');
            if (isAExam && !isBExam) return 1;
            if (!isAExam && isBExam) return -1;
        }
        return aKey.localeCompare(bKey, undefined, { numeric: true, sensitivity: 'base' });
    });
}

function checkLockState(db, type) {
    try {
        const lockRow = db.prepare(`SELECT value FROM app_settings WHERE key = 'mobile_${type}_locked'`).get();
        if (lockRow && lockRow.value === '1') return true;

        const lockAtRow = db.prepare(`SELECT value FROM app_settings WHERE key = 'mobile_${type}_lock_at'`).get();
        if (lockAtRow && lockAtRow.value) {
            const lockAtTime = new Date(lockAtRow.value).getTime();
            if (!isNaN(lockAtTime) && Date.now() >= lockAtTime) {
                return true;
            }
        }
    } catch (e) {
        console.error(`[checkLockState] Failed to evaluate lock for ${type}:`, e.message);
    }
    return false;
}

function getLockAtMillis(db, type) {
    try {
        const lockAtRow = db.prepare(`SELECT value FROM app_settings WHERE key = 'mobile_${type}_lock_at'`).get();
        if (lockAtRow && lockAtRow.value) {
            const lockAtTime = new Date(lockAtRow.value).getTime();
            return isNaN(lockAtTime) ? 0 : lockAtTime;
        }
    } catch (e) {
        console.error(`[getLockAtMillis] Failed to get lock_at time for ${type}:`, e.message);
    }
    return 0;
}
function normalizeTermName(term) {
    if (!term) return 'First Term';
    const clean = term.toString().trim().toLowerCase();
    if (clean.includes('1') || clean.includes('first')) return 'First Term';
    if (clean.includes('2') || clean.includes('second')) return 'Second Term';
    if (clean.includes('3') || clean.includes('third')) return 'Third Term';
    return term.trim();
}

// ─── Prompt 2: The CSV Matrix Parser ─────────────────────────────────────────
function normalizeSubjectName(subject, className) {
    if (!subject) return 'General';
    let norm = subject.trim();

    // ── Mathematics: WAEC uses 'Mathematics' for JSS, 'General Mathematics' for SSS
    const isJSS = className && (className.toUpperCase().startsWith('JS') || className.toUpperCase().startsWith('JSS'));
    const isSSS = className && (className.toUpperCase().startsWith('SS'));

    // Normalise common misspellings / abbreviations first
    const table = {
        'Further Maths':              'Further Mathematics',
        'Further Mathematic':         'Further Mathematics',
        'Add Maths':                  'Further Mathematics',
        'Additional Mathematics':     'Further Mathematics',
        'Lit in English':             'Literature in English',
        'Literature':                 'Literature in English',
        'Lit':                        'Literature in English',
        'Eng Lang':                   'English Language',
        'English':                    'English Language',
        'English Studies':            'English Language',
        'Gen Maths':                  'General Mathematics',
        'General Maths':              'General Mathematics',
        'Maths':                      isSSS ? 'General Mathematics' : 'Mathematics',
        'Math':                       isSSS ? 'General Mathematics' : 'Mathematics',
        'CRS':                        'Christian Religious Studies',
        'CRK':                        'Christian Religious Studies',
        'Christian Religious Knowledge': 'Christian Religious Studies',
        'IRK':                        'Islamic Studies',
        'Islamic Religious Knowledge': 'Islamic Studies',
        'Islamic Religious Studies':  'Islamic Studies',
        'Civic Education':            'Citizenship and Heritage Studies',
        'Civic Ed':                   'Citizenship and Heritage Studies',
        'Govt':                       'Government',
        'Agric':                      'Agriculture',
        'Agric Science':              'Agriculture',
        'Agricultural Science':       'Agriculture',
        'Econs':                      'Economics',
        'Fin Accounting':             'Financial Accounting',
        'Account':                    'Accounting',
        'Accounts':                   'Accounting',
        'Financial Acc':              'Financial Accounting',
        'Commerce':                   'Commerce',
        'Tech Drawing':               'Technical Drawing',
        'PHE':                        'Physical Education',
        'Physical & Health Education': 'Physical Education',
        'Health Edu':                 'Health Education',
        'Food & Nutrition':           'Food and Nutrition',
        'Food Nutrition':             'Food and Nutrition',
        'Home Mgt':                   'Home Management',
        'Catering':                   'Catering Craft',
        'Yoruba Language':            'Yoruba',
        'Igbo Language':              'Igbo',
        'Hausa Language':             'Hausa',
        'French Language':            'French',
        'Digital Tech':               'Digital Technologies',
        'ICT':                        'Digital Technologies',
        'Computer Science':           'Digital Technologies',
        'Basic Science':              'Integrated Science',
        'Intermediate Science':       'Integrated Science',
        'Social Studies':             'Social and Citizenship Studies',
        'Social & Citizenship Studies': 'Social and Citizenship Studies',
        'Nigerian History':           'History',
        'Visual Arts':                'Fine Art',
        'Fine Arts':                  'Fine Art',
    };

    if (table[norm]) norm = table[norm];

    // JSS/SSS Mathematics swap
    if (norm === 'General Mathematics' && isJSS) return 'Mathematics';
    if (norm === 'Mathematics' && isSSS) return 'General Mathematics';

    return norm;
}

// Parses a phase-8 CSV with Teacher_ID, Teacher_Name, Teacher_Phone, and
// pipe-delimited Subjects. Inserts securely into SQLite via prepared statements.
function handleCSVUpload(filePath, callback, newStudentLimit) {
    const rows = [];

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            if (rows.length === 0) {
                if (callback) callback(0, 'INVALID_TEMPLATE: The uploaded CSV file is empty.');
                return;
            }

            // Extract and normalize headers
            const headers = Object.keys(rows[0] || {}).map(h => h.trim().toLowerCase());
            const hasStudentCols = headers.includes('student_id') || headers.includes('first_name') || headers.includes('last_name') || headers.includes('parent_phone');
            const hasTeacherCols = headers.includes('teacher_id') || headers.includes('teacher_name') || headers.includes('teacher_phone');

            if (!hasStudentCols && !hasTeacherCols) {
                if (callback) callback(0, 'INVALID_TEMPLATE: CSV headers do not match Student or Teacher templates. Expected columns: Student_ID, First_Name, Last_Name, Class OR Teacher_ID, Teacher_Name, Subjects.');
                return;
            }

            let db;
            try {
                db = database.getDb();
            } catch (e) {
                console.error('[CSV] Database not initialized. Aborting import.', e);
                if (callback) callback(0, 'DB not initialized');
                return;
            }

            // Prepare parameterized statements — no raw interpolation, SQL injection-proof
            const upsertTeacher = db.prepare(`
                INSERT INTO teachers (id, name, phone)
                VALUES (@id, @name, @phone)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name, phone=excluded.phone
            `);

            const upsertAllocation = db.prepare(`
                INSERT OR IGNORE INTO teacher_allocations (teacher_id, class_name, subject)
                VALUES (@teacher_id, @class_name, @subject)
            `);

            const upsertStudentSubject = db.prepare(`
                INSERT OR IGNORE INTO student_subjects (student_id, subject)
                VALUES (@student_id, @subject)
            `);

            const upsertFormTeacher = db.prepare(`
                INSERT INTO form_teachers (class_name, teacher_id)
                VALUES (?, ?)
                ON CONFLICT(class_name) DO UPDATE SET teacher_id = excluded.teacher_id
            `);

            const configs = db.prepare("SELECT hierarchy_class FROM class_configs").all();
            const sortedConfigs = configs.map(c => c.hierarchy_class).sort((a, b) => b.length - a.length);

            const splitClass = (selected) => {
                for (const prefix of sortedConfigs) {
                    if (selected === prefix) {
                        return { class_name: prefix, class_arm: '' };
                    }
                    if (selected.startsWith(prefix + ' ')) {
                        return { class_name: prefix, class_arm: selected.substring(prefix.length + 1).trim() };
                    }
                }
                const lastSpace = selected.lastIndexOf(' ');
                if (lastSpace > -1) {
                    return {
                        class_name: selected.substring(0, lastSpace).trim(),
                        class_arm: selected.substring(lastSpace + 1).trim()
                    };
                }
                return { class_name: selected, class_arm: '' };
            };

            const upsertStudent = db.prepare(`
                INSERT INTO students (id, name, class_name, class_arm, parent_name, parent_email, parent_phone, reg_no, gender, dob)
                VALUES (@id, @name, @class_name, @class_arm, @parent_name, @parent_email, @parent_phone, @reg_no, @gender, @dob)
                ON CONFLICT(id) DO UPDATE SET 
                    name=excluded.name, 
                    class_name=excluded.class_name,
                    class_arm=excluded.class_arm,
                    parent_name=COALESCE(excluded.parent_name, students.parent_name),
                    parent_email=COALESCE(excluded.parent_email, students.parent_email),
                    parent_phone=COALESCE(excluded.parent_phone, students.parent_phone),
                    reg_no=COALESCE(NULLIF(excluded.reg_no, ''), students.reg_no),
                    gender=COALESCE(NULLIF(excluded.gender, ''), students.gender),
                    dob=COALESCE(NULLIF(excluded.dob, ''), students.dob)
            `);

            // Wrap all inserts in a single transaction for speed + atomicity
            const runImport = db.transaction((rows) => {
                let studentCount = 0;
                let teacherIds = new Set();
                let allocationCount = 0;
                let warnings = [];
                let newStudentsInserted = 0;

                // If a cap is provided, query the current count once before the loop
                const hasCap = typeof newStudentLimit === 'number' && isFinite(newStudentLimit) && newStudentLimit < 999999;
                let currentCount = hasCap ? db.prepare('SELECT COUNT(id) AS c FROM students').get().c : 0;
                const availableSlots = hasCap ? Math.max(0, newStudentLimit - currentCount) : Infinity;

                for (const row of rows) {
                    const studentId    = (row['Student_ID']    || row['ID'] || '').trim();
                    const firstName    = (row['First_Name']    || '').trim();
                    const lastName     = (row['Last_Name']     || '').trim();
                    const className    = (row['Class']         || '').trim();
                    const teacherId    = (row['Teacher_ID']    || '').trim();
                    const teacherName  = (row['Teacher_Name']  || '').trim();
                    const teacherPhone = (row['Teacher_Phone'] || '').trim();
                    const subjectsRaw  = (row['Subjects']      || '').trim();
                    
                    const parentName   = (row['Parent_Name']   || '').trim();
                    const parentEmail  = (row['Parent_Email']  || '').trim();
                    const parentPhone  = (row['Parent_Phone']  || '').trim();
                    const gender       = (row['Gender']        || '').trim();
                    const dob          = (row['DOB']           || row['Date_of_Birth'] || '').trim();
                    const regNo        = (row['Registration_Number'] || row['Reg_No'] || row['Registration_No'] || '').trim();
                    const classHostValRaw = (row['Class_Host'] || '').trim();
                    const classHostValUpper = classHostValRaw.toUpperCase();

                    // 1. If row defines a Teacher, process teacher logic
                    if (teacherId) {
                        if (!teacherIds.has(teacherId)) {
                            upsertTeacher.run({ id: teacherId, name: teacherName || teacherId, phone: teacherPhone });
                            teacherIds.add(teacherId);
                        }
                        // Upsert allocation if class and subjects exist
                        if (className) {
                            const classes = className.split('|').map(c => c.trim()).filter(Boolean);
                            const subjects = subjectsRaw
                                ? subjectsRaw.split('|').map(s => s.trim()).filter(Boolean)
                                : ['General'];
                            for (const cls of classes) {
                                for (const subject of subjects) {
                                    upsertAllocation.run({ teacher_id: teacherId, class_name: cls, subject: normalizeSubjectName(subject, cls) });
                                    allocationCount++;
                                }
                            }
                            
                            // Resolve Form Teacher (Class Host)
                            let hostClassName = null;
                            if (classHostValUpper === 'TRUE' || classHostValUpper === '1' || classHostValUpper === 'YES') {
                                hostClassName = classes[0]; // First class in the list
                            } else if (classHostValRaw && classHostValUpper !== 'FALSE' && classHostValUpper !== '0' && classHostValUpper !== 'NO') {
                                hostClassName = classHostValRaw; // Explicit class name
                            }

                            if (hostClassName) {
                                try {
                                    // Expand bare hierarchy class name to arm-expanded name so it
                                    // matches the fullList used by the Class Hosts modal.
                                    // e.g. "JSS 1" → "JSS 1 Gold" (first configured arm).
                                    // If hostClassName already includes an arm (e.g. "JSS 1 Gold"),
                                    // the query below returns nothing and the name is kept as-is.
                                    const allArms = db.prepare(
                                        `SELECT arm FROM class_arms WHERE hierarchy_class = ? ORDER BY rowid`
                                    ).all(hostClassName);
                                    const resolvedHostClass = allArms.length > 0
                                        ? `${hostClassName} ${allArms[0].arm}`
                                        : hostClassName;

                                    // Warn when boolean TRUE was used and multiple arms exist —
                                    // the admin should use an explicit arm name instead so the
                                    // assignment is unambiguous.
                                    const usedBoolean = (classHostValUpper === 'TRUE' || classHostValUpper === '1' || classHostValUpper === 'YES');
                                    if (usedBoolean && allArms.length > 1) {
                                        const armList = allArms.map(a => `${hostClassName} ${a.arm}`).join(', ');
                                        warnings.push(
                                            `Teacher "${teacherName || teacherId}": Class_Host=TRUE is ambiguous — ` +
                                            `"${resolvedHostClass}" was assumed (first arm). ` +
                                            `Use an explicit arm name to be precise (e.g. ${armList}).`
                                        );
                                    }

                                    upsertFormTeacher.run(resolvedHostClass, teacherId);
                                } catch (ftErr) {
                                    console.error(`[CSV] Failed to assign form teacher for ${hostClassName}:`, ftErr.message);
                                }
                            }
                        }
                    }

                    // 2. If row defines a Student, process student logic
                    if (studentId && (firstName || lastName) && className) {
                        // ── Seat cap enforcement ───────────────────────────────────
                        // Determine if this student already exists (update vs new insert)
                        const isExisting = hasCap
                            ? db.prepare('SELECT 1 FROM students WHERE id = ? LIMIT 1').get(studentId) !== undefined
                            : false;

                        if (!isExisting && hasCap && newStudentsInserted >= availableSlots) {
                            // New student exceeds the available seat budget — skip
                            warnings.push(`Seat cap reached: student '${studentId}' (${firstName} ${lastName}) was skipped.`);
                            continue;
                        }

                        const splitResult = splitClass(className);
                        upsertStudent.run({
                            id: studentId,
                            name: `${firstName} ${lastName}`.trim(),
                            class_name: splitResult.class_name,
                            class_arm: splitResult.class_arm,
                            parent_name: parentName || null,
                            parent_email: parentEmail || null,
                            parent_phone: parentPhone || null,
                            reg_no: regNo || '',
                            gender: gender || '',
                            dob: dob || ''
                        });

                        if (!isExisting) newStudentsInserted++;

                        // Bug #2 fix: also write the student's subject enrollment so
                        // the handshake and Print Hub can filter correctly per subject.
                        if (subjectsRaw) {
                            const stuSubjects = subjectsRaw
                                .split('|')
                                .map(s => s.trim())
                                .filter(Boolean);
                            for (const subj of stuSubjects) {
                                upsertStudentSubject.run({ student_id: studentId, subject: normalizeSubjectName(subj, className) });
                            }
                        }

                        studentCount++;
                    }
                }

                return { studentCount, teacherCount: teacherIds.size, allocationCount, warnings, newStudentsInserted };
            });

            try {
                const result = runImport(rows);
                console.log(`[CSV] ✅ Import complete — ${result.studentCount} students, ${result.teacherCount} teachers, ${result.allocationCount} allocations.`);
                logActivity({
                    event_type: 'ROSTER_CSV_IMPORTED',
                    payload: { students: result.studentCount, teachers: result.teacherCount, allocations: result.allocationCount }
                });
                if (result.warnings && result.warnings.length > 0) {
                    result.warnings.forEach(w => console.warn(`[CSV] ⚠️  ${w}`));
                }
                if (callback) callback(result.studentCount, null, result);
            } catch (err) {
                console.error('[CSV] ❌ Transaction failed:', err.message);
                if (callback) callback(0, err.message);
            }
        });
}
// ─────────────────────────────────────────────────────────────────────────────
// ─── CBT ENGINE LOCAL SERVING & API ──────────────────────────────────────────

const path = require('path');
// Serve the local student client
app.use('/cbt', express.static(path.join(__dirname, '../public/cbt')));

app.post('/api/cbt/auth', (req, res) => {
    const { token, dob_day, dob_month, dob_year } = req.body;
    if (!token) return res.status(400).json({ error: "Token required" });
    
    let db;
    try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT * FROM cbt_tokens WHERE token = ?").get(token.toUpperCase());
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    if (tk.status === 'submitted') return res.status(403).json({ error: "Exam already submitted" });
    
    // Validate Batch Window
    if (tk.batch_id) {
        const batch = db.prepare("SELECT status FROM cbt_batches WHERE id = ?").get(tk.batch_id);
        if (!batch || batch.status !== 'active') {
            return res.status(403).json({ error: "Your exam batch is not currently active." });
        }
    }
    
    // External 2FA Validation
    let candidateName = "";
    if (tk.external_candidate_id) {
        if (!dob_day || !dob_month || !dob_year) return res.status(401).json({ error: "Date of Birth required for external candidates." });
        const ext = db.prepare("SELECT * FROM cbt_external_candidates WHERE id = ?").get(tk.external_candidate_id);
        if (!ext || ext.dob_day !== dob_day || ext.dob_month !== dob_month || ext.dob_year !== dob_year) {
            return res.status(401).json({ error: "Authentication failed. Token and DOB do not match." });
        }
        candidateName = ext.name;
    } else {
        const stu = db.prepare("SELECT name FROM students WHERE id = ?").get(tk.student_id);
        candidateName = stu ? stu.name : "Internal Student";
    }

    const exam = db.prepare("SELECT * FROM cbt_exams WHERE id = ?").get(tk.exam_id);
    if (!exam || exam.status !== 'active') return res.status(403).json({ error: "Exam is closed or inactive." });

    // Mark active if not already
    if (tk.status === 'unused') {
        db.prepare("UPDATE cbt_tokens SET status = 'active', started_at = ? WHERE id = ?").run(new Date().toISOString(), tk.id);
    }

    res.json({ success: true, token_id: tk.id, candidate_name: candidateName, exam });
});

app.post('/api/cbt/paper', (req, res) => {
    const { token_id } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT exam_id, question_seed FROM cbt_tokens WHERE id = ?").get(token_id);
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    
    const exam = db.prepare("SELECT bank_id, question_count, shuffle_questions, shuffle_options FROM cbt_exams WHERE id = ?").get(tk.exam_id);
    
    // --- Seeded Fisher-Yates shuffle ---
    // Uses the token's question_seed to deterministically shuffle for this candidate.
    // This means every candidate gets a unique order while the server can always
    // reproduce it — no snapshot storage required (~8 bytes per student).
    function seededRandom(seed) {
        // Simple mulberry32 PRNG from a string seed
        let h = 0;
        for (let i = 0; i < seed.length; i++) {
            h = Math.imul(31, h) + seed.charCodeAt(i) | 0;
        }
        return function() {
            h |= 0; h = h + 0x6D2B79F5 | 0;
            let t = Math.imul(h ^ h >>> 15, 1 | h);
            t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }

    function fisherYates(arr, rng) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(rng() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }

    // Get questions — never send correct_option to the client!
    let qs = db.prepare("SELECT id, question_text, option_a, option_b, option_c, option_d FROM cbt_questions WHERE bank_id = ?").all(exam.bank_id);

    const seed = tk.question_seed || 'DEFAULTSEED';
    const rng  = seededRandom(seed);

    if (exam.shuffle_questions) {
        qs = fisherYates(qs, rng);
    }

    // Slice to exam question count
    qs = qs.slice(0, exam.question_count || qs.length);

    if (exam.shuffle_options) {
        // Each question gets its own seeded option shuffle derived from seed + question id
        qs = qs.map(q => {
            const optRng = seededRandom(seed + String(q.id));
            const opts = [
                { key: 'option_a', val: q.option_a },
                { key: 'option_b', val: q.option_b },
                { key: 'option_c', val: q.option_c },
                { key: 'option_d', val: q.option_d },
            ].filter(o => o.val);
            fisherYates(opts, optRng);
            return {
                id: q.id,
                question_text: q.question_text,
                option_a: opts[0]?.val || '',
                option_b: opts[1]?.val || '',
                option_c: opts[2]?.val || '',
                option_d: opts[3]?.val || '',
            };
        });
    }

    // Note: correct_option is never sent to the client.
    res.json({ success: true, questions: qs, config: exam });
});

app.post('/api/cbt/heartbeat', (req, res) => {
    const { token_id, tab_switches } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    if (tab_switches > 0) {
        db.prepare("UPDATE cbt_tokens SET tab_switches = tab_switches + ? WHERE id = ?").run(tab_switches, token_id);
    }
    res.json({ ok: true });
});

app.post('/api/cbt/submit', (req, res) => {
    const { token_id, answers } = req.body;
    let db; try { db = database.getDb(); } catch(e) { return res.status(500).json({ error: "DB Offline" }); }
    
    const tk = db.prepare("SELECT exam_id, status FROM cbt_tokens WHERE id = ?").get(token_id);
    if (!tk) return res.status(401).json({ error: "Invalid Token" });
    // Prevent double-submission
    if (tk.status === 'submitted') return res.status(403).json({ error: "Exam already submitted. Results are final." });
    
    // Auto Grade
    let score = 0;
    const insertAnswer = db.prepare("INSERT OR IGNORE INTO cbt_answers (token_id, question_id, selected_option, is_correct) VALUES (?, ?, ?, ?)");
    const getCorrect = db.prepare("SELECT correct_option, marks FROM cbt_questions WHERE id = ?");
    
    const tx = db.transaction(() => {
        for (const ans of answers) {
            const q = getCorrect.get(ans.question_id);
            if (!q) continue;
            const isCorrect = q.correct_option === ans.selected_option ? 1 : 0;
            score += isCorrect * (q.marks || 1);
            insertAnswer.run(token_id, ans.question_id, ans.selected_option, isCorrect);
        }
        db.prepare("UPDATE cbt_tokens SET status = 'submitted', score = ?, submitted_at = ? WHERE id = ?")
          .run(score, new Date().toISOString(), token_id);
    });
    
    try {
        tx();
        // Fetch result_release_policy to decide what to return
        const exam = db.prepare("SELECT result_release_policy FROM cbt_exams WHERE id = ?").get(tk.exam_id);
        const policy = exam?.result_release_policy || 'immediate';
        if (policy === 'immediate') {
            res.json({ success: true, score });
        } else {
            // Delayed or manual — score is held; candidate sees acknowledgement only
            res.json({ success: true, score: null, held: true, message: 'Your submission was received. Results will be released by your school.' });
        }
    } catch (e) {
        res.status(500).json({ error: "Failed to grade exam: " + e.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────

// The "Day 1" Handshake Endpoint
// Helper to retrieve license status from app locals
function getLicenseStatus() {
    const VALID_TIERS = ['Standalone', 'Silver', 'Gold', 'Diamond'];
    try {
        if (app.locals.license_limit?.payload) {
            const parsed = JSON.parse(app.locals.license_limit.payload);
            // Security: reject any tier not on the canonical allowlist
            if (!VALID_TIERS.includes(parsed.tier)) {
                console.warn(`[Security] getLicenseStatus: unrecognised tier '${parsed.tier}' — clamping to Silver.`);
                return { tier: 'Silver' };
            }
            return parsed;
        }
    } catch (_) {}
    return { tier: 'Silver' }; // default fallback
}

// The "Day 1" Handshake Endpoint
const handleHandshake = (req, res) => {
    const { device_id, teacher_id, teacher_name, public_key, thermal_status, device_model } = req.body;

    console.log(`[Handshake] Received identity from ${teacher_name} [${teacher_id || 'NO_ID'}] (${device_id})`);

    let db;
    try {
        db = database.getDb();
    } catch (e) {
        return res.status(500).json({ error: "Database not initialized" });
    }

    // Identity check: require teacher_id to be present in the QR payload
    if (!teacher_id) {
        return res.status(400).json({ error: "Missing teacher_id in handshake payload." });
    }

    const isStandalone = getLicenseStatus().tier === 'Standalone';
    let teacher;
    let role = 'teacher';

    if (isStandalone) {
        // Standalone mode: ALL device pairings are admin-level regardless of what
        // teacher_id the QR contains. A device may carry a stale teacher QR from
        // a previous session — we normalise it to STANDALONE_ADMIN instead of
        // hard-failing with a 404. The 2-device slot limit is enforced below.
        if (teacher_id !== 'STANDALONE_ADMIN') {
            console.log(`[Handshake] Standalone mode — normalising stale QR identity '${teacher_id}' → STANDALONE_ADMIN`);
        }
        teacher = { id: 'STANDALONE_ADMIN', name: 'Admin' };
        role = 'super_admin';
    } else if (teacher_id === 'STANDALONE_ADMIN') {
        // STANDALONE_ADMIN identity on a non-Standalone license is rejected
        return res.status(403).json({ error: "STANDALONE_ADMIN identity is only valid for Standalone licenses." });
    } else if (teacher_id.startsWith('admin_')) {
        // ── Admin companion pairing (subscription tiers) ──────────────────────
        // QR teacher_id for admins is encoded as 'admin_<id>' by the desktop app.
        const rawAdminId = teacher_id.replace(/^admin_/, '');
        const adminRow = db.prepare('SELECT id, username, role_level FROM admin_users WHERE id = ? LIMIT 1').get(rawAdminId);
        if (!adminRow) {
            console.warn(`[Handshake] Admin ID not found in admin_users: ${rawAdminId}`);
            return res.status(404).json({ error: "Admin account not found in the vault." });
        }
        teacher = { id: adminRow.id, name: adminRow.username };
        // Map role_level → Android role string consumed by AppLaunchActivity
        if (adminRow.role_level >= 9)      role = 'it_admin';
        else if (adminRow.role_level >= 7) role = 'principal';
        else if (adminRow.role_level >= 5) role = 'bursar';
        else                               role = 'result_clerk';
        console.log(`[Handshake] Admin '${adminRow.username}' (level ${adminRow.role_level}) → role '${role}'`);
    } else {
        // First check if this exists in staff_roles
        const staff = db.prepare('SELECT id, name, role FROM staff_roles WHERE id = ? LIMIT 1').get(teacher_id);
        if (staff) {
            teacher = { id: staff.id, name: staff.name };
            role = staff.role;
        } else {
            // Subscription path: look up by teacher ID (from QR)
            teacher = db.prepare('SELECT id, name, sync_revoked FROM teachers WHERE id = ? LIMIT 1').get(teacher_id);
            if (!teacher) {
                console.warn(`[Handshake] Teacher ID not found in teachers or staff_roles: ${teacher_id}`);
                return res.status(404).json({ error: "Teacher ID not found in the vault." });
            }
            if (teacher.sync_revoked === 1) {
                return res.status(403).json({ error: "TEACHER_REVOKED", message: "This teacher's sync access has been revoked." });
            }
            role = 'teacher';
        }
    }

    // Connect device limit checks for Standalone
    if (isStandalone) {
        const existingDevice = db.prepare('SELECT device_id FROM connected_devices WHERE device_id = ?').get(device_id);
        if (!existingDevice) {
            const count = db.prepare('SELECT COUNT(*) as c FROM connected_devices').get().c;
            if (count >= 2) {
                return res.status(403).json({
                    error: "DEVICE_LIMIT_REACHED",
                    message: "Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."
                });
            }
        }
        // Save the device into connected_devices
        db.prepare('INSERT OR REPLACE INTO connected_devices (device_id, device_model) VALUES (?, ?)').run(
            device_id,
            device_model || 'Android Device'
        );
    }

    // Notify Main Process
    eventEmitter.emit('handshake-success', req.body);

    // Resolve form/homeroom class for this teacher (null if they are not a form teacher)
    let formClass = null;
    if (teacher.id !== 'STANDALONE_ADMIN' && role === 'teacher') {
        const formTeacherRow = db.prepare(
            'SELECT class_name FROM form_teachers WHERE teacher_id = ? LIMIT 1'
        ).get(teacher.id);
        formClass = formTeacherRow?.class_name || null;
    }

    // Bug #1 fix: fetch students filtered by BOTH class AND subject enrollment.
    // A student only appears in a subject tab if they are explicitly enrolled in
    // that subject (student_subjects row exists).
    // PLUS: We union ALL students in the teacher's form_class under the 'General' subject 
    // so they are available on-device for Attendance taking.
    let students;
    if (isStandalone || role !== 'teacher') {
        // Standalone or admin staff roles: return every student with every subject they are enrolled in.
        // The UNION 'General' row is kept in the raw query so students with no
        // subject rows are not silently dropped — but ALL 'General' rows are
        // stripped from the payload below before sending to the device.
        const rawStudents = db.prepare(`
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, ss.subject
            FROM students s
            JOIN student_subjects ss ON ss.student_id = s.id
            UNION
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, 'General' AS subject
            FROM students s
        `).all();

        // Remove 'General' sentinel rows — they exist only for attendance tracking.
        // Students whose ONLY row is 'General' (not yet enrolled in any subject)
        // are excluded from the grading payload; they appear in Attendance-only view.
        const realSubjectIds = new Set(
            rawStudents.filter(r => r.subject !== 'General').map(r => r.id)
        );
        students = rawStudents.filter(r => r.subject !== 'General');

        // For completeness, log how many students have no subject assignment yet
        const noSubjectCount = rawStudents
            .filter(r => r.subject === 'General' && !realSubjectIds.has(r.id)).length;
        if (noSubjectCount > 0) {
            console.log(`[Handshake] ${noSubjectCount} student(s) have no subject assignment yet — excluded from grading roster.`);
        }
    } else {
        // Subscription path: filter by teacher allocation, then strip 'General' sentinel.
        const rawStudents = db.prepare(`
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, a.subject
            FROM students s
            JOIN teacher_allocations a
              ON (UPPER(replace(s.class_name, ' ', '')) = UPPER(replace(a.class_name, ' ', ''))
               OR UPPER(replace(s.class_name || COALESCE(s.class_arm, ''), ' ', '')) = UPPER(replace(a.class_name, ' ', '')))
            WHERE a.teacher_id = ?
              AND (
                EXISTS (
                  SELECT 1 FROM student_subjects ss
                  WHERE ss.student_id = s.id AND ss.subject = a.subject
                )
                OR NOT EXISTS (
                  SELECT 1 FROM student_subjects ss2
                  WHERE ss2.student_id = s.id
                )
              )
            UNION
            SELECT s.id, s.name, s.class_name, s.class_arm, s.reg_no, s.admission_no, s.gender, s.dob, s.photo AS photo_base64, s.parent_email, s.parent_phone, s.parent_name, 'General' as subject
            FROM students s
            WHERE UPPER(TRIM(replace(s.class_name, ' ', ''))) = ? 
               OR UPPER(TRIM(replace(s.class_name || COALESCE(s.class_arm, ''), ' ', ''))) = ?
               OR (s.class_arm IS NOT NULL AND s.class_arm != ''
                   AND UPPER(TRIM(replace(s.class_name, ' ', ''))) = SUBSTR(?, 1, LENGTH(UPPER(TRIM(replace(s.class_name, ' ', '')))))
                   AND ? LIKE '%' || UPPER(TRIM(replace(s.class_arm, ' ', ''))))
        `).all(teacher.id,
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS',
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS',
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS',
               formClass ? formClass.replace(/\s+/g, '').toUpperCase() : 'NONE_CLASS');

        // Strip 'General' sentinel — only keep real subject rows for grading payload.
        students = rawStudents.filter(r => r.subject !== 'General');
    }

    // Read score_components from school_term_config so the tablet knows what fields to collect
    let scoreComponents = null;
    try {
        const termCfg = db.prepare('SELECT grading_scale, attendance_score_weight, include_attendance_in_grades FROM school_term_config WHERE id = 1').get();
        if (termCfg?.grading_scale) {
            const parsed = JSON.parse(termCfg.grading_scale);
            if (parsed && Array.isArray(parsed) && parsed.length > 0) {
                // Bare array format: [{key, label, max}, ...]
                scoreComponents = parsed;
            } else if (parsed && !Array.isArray(parsed) && parsed.components && parsed.components.length > 0) {
                // Object format: { scale: ..., components: [...] }
                scoreComponents = parsed.components;
            }
        }
        // Append Attendance as a scoreable component if the school allocated marks for it
        // AND include_attendance_in_grades is true (1)
        const attWeight = termCfg?.attendance_score_weight || 0;
        const includeAtt = termCfg?.include_attendance_in_grades !== 0; // default to true if not explicit 0
        if (attWeight > 0 && includeAtt) {
            if (!scoreComponents) scoreComponents = [];
            const alreadyHas = scoreComponents.find(c => c.key === 'ATT' || c.key === 'Attendance' ||
                (c.label && c.label.toLowerCase().includes('attend')));
            if (!alreadyHas) {
                scoreComponents.push({ key: 'ATT', label: 'Attendance', max: attWeight });
            }
        }
    } catch(e) { /* use default if config unreadable */ }
    if (!scoreComponents || scoreComponents.length === 0) {
        scoreComponents = [
            { key: "CA1",  label: "C.A. 1", max: 10 },
            { key: "CA2",  label: "C.A. 2", max: 10 },
            { key: "Exam", label: "Exam",   max: 80 },
        ];
    }
    scoreComponents = sortGradingComponents(scoreComponents);

    // ── WAEC/NECO-aligned master subject lists ──────────────────────────────────
    // These cover ALL streams (Science, Arts, Commercial) so the phone always
    // has a complete picker. Class-level split keeps JSS students from seeing SS
    // subjects and vice versa.  School-specific subjects from the DB are merged in.
    const MASTER_JSS = [
        'English Language', 'Mathematics', 'Integrated Science',
        'Social and Citizenship Studies', 'Agricultural Science',
        'Christian Religious Studies', 'Islamic Studies',
        'Physical and Health Education', 'French', 'Arabic',
        'Yoruba', 'Igbo', 'Hausa',
        'Home Economics', 'Business Studies', 'Digital Technologies',
        'Fine Art', 'Music', 'Technical Drawing',
        'Cultural and Creative Arts', 'Civic Education',
        'History', 'Geography'
    ];

    const MASTER_SS = [
        // Core
        'English Language', 'General Mathematics', 'Further Mathematics',
        // Sciences
        'Physics', 'Chemistry', 'Biology', 'Agricultural Science',
        'Technical Drawing', 'Food and Nutrition',
        // Commercial
        'Commerce', 'Financial Accounting', 'Economics',
        'Office Practice', 'Shorthand', 'Marketing',
        // Arts / Social
        'Government', 'History', 'Geography',
        'Literature in English', 'Christian Religious Studies',
        'Islamic Studies', 'Arabic', 'French',
        'Yoruba', 'Igbo', 'Hausa',
        // Technical / Creative
        'Fine Art', 'Music', 'Physical and Health Education',
        'Digital Technologies', 'Data Processing',
        'Catering Craft', 'Home Management',
        'Clothing and Textiles',
        // General / Civic
        'Civic Education', 'Insurance'
    ];

    // Helper: is this class name a JSS-level class?
    const isJSSClass = (cn) => {
        const u = (cn || '').toUpperCase();
        return u.startsWith('JS') || u.startsWith('JSS') || u.startsWith('JHS');
    };

    // Pull school-specific subjects (DB) and normalize them
    const rawSubjectRows = db.prepare(`
        SELECT subject FROM teacher_allocations WHERE subject != 'General'
        UNION
        SELECT subject FROM student_subjects WHERE subject != 'General'
    `).all();
    const dbSubjectsNorm = rawSubjectRows.map(row => normalizeSubjectName(row.subject, null));

    // Master all_subjects = union of JSS + SS master lists + DB subjects, sorted
    const allSubjects = [...new Set([
        ...MASTER_JSS, ...MASTER_SS, ...dbSubjectsNorm
    ])].sort();

    // Per-class subjects: start from class's master list, add DB subjects for that class
    const classRows = db.prepare(`
        SELECT DISTINCT a.class_name, a.subject
        FROM teacher_allocations a
        WHERE a.subject != 'General'
        UNION
        SELECT DISTINCT s.class_name, ss.subject
        FROM students s
        JOIN student_subjects ss ON ss.student_id = s.id
        WHERE ss.subject != 'General'
    `).all();

    // Collect distinct class names from DB
    const allClassNames = [...new Set(classRows.map(r => r.class_name).filter(Boolean))];

    // Build classSubjectsMap: master list for level + school-specific DB additions
    const classSubjectsMap = {};
    allClassNames.forEach(className => {
        const base = isJSSClass(className) ? [...MASTER_JSS] : [...MASTER_SS];
        classSubjectsMap[className] = [...new Set([...base])].sort();
    });

    // Merge DB subjects into their respective class
    classRows.forEach(row => {
        const normSubject = normalizeSubjectName(row.subject, row.class_name);
        if (!classSubjectsMap[row.class_name]) classSubjectsMap[row.class_name] = [];
        if (!classSubjectsMap[row.class_name].includes(normSubject)) {
            classSubjectsMap[row.class_name].push(normSubject);
            classSubjectsMap[row.class_name].sort();
        }
    });


    // Form class was resolved above to support the new union query.

    // Merge saved school_config with guaranteed defaults so Android always
    // receives a valid modules array and primary_color regardless of what
    // fields the identity.json was saved with.
    const baseConfig = app.locals.school_config || {};
    const modules = Array.isArray(baseConfig.modules)
                     ? [...baseConfig.modules]
                     : ["grading", "attendance"];
    
    // Ensure student_photo is present in modules list for all plans
    if (!modules.includes("student_photo")) {
        modules.push("student_photo");
    }

    // Derive the plan tier to display on the device Settings screen.
    // Priority: explicit planTier field → premiumPlan flag → module inference.
    let planTier = baseConfig.planTier || baseConfig.plan_tier || null;
    if (!planTier) {
        if (modules.some(m => m === 'custom_result'))  planTier = 'Diamond';
        else if (modules.some(m => m === 'parent_contact')) planTier = 'Gold';
        else if (baseConfig.premiumPlan === true || baseConfig.premiumPlan === 'true') planTier = 'Silver';
        else planTier = 'Standalone';
    }

    const registrationLocked = checkLockState(db, 'registration');
    const gradesLocked       = checkLockState(db, 'grades');
    const attendanceLocked   = checkLockState(db, 'attendance');
    const registrationLockAt = getLockAtMillis(db, 'registration');
    const gradesLockAt       = getLockAtMillis(db, 'grades');
    const attendanceLockAt   = getLockAtMillis(db, 'attendance');

    const schoolConfig = {
        name:          baseConfig.name          || baseConfig.school_name || "Nexus School",
        primary_color: baseConfig.themePrimary  || baseConfig.primary_color || "#1A237E",
        logoBase64:    baseConfig.logoBase64    || null,
        modules:       modules,
        plan_tier:     planTier,
        registration_locked: registrationLocked,
        grades_locked:       gradesLocked,
        attendance_locked:   attendanceLocked,
        registration_lock_at: registrationLockAt,
        grades_lock_at:       gradesLockAt,
        attendance_lock_at:   attendanceLockAt
    };

    // ── Sync existing Hub scores to device on handshake ─────────────────────
    // Expands each student_records breakdown into individual component rows
    // matching the Android StudentScore Room entity (student_id, subject, component_key, score).
    let existingScores = [];
    try {
        const termCfgForScores = db.prepare('SELECT academic_session, term FROM school_term_config WHERE id = 1').get();
        if (termCfgForScores && students.length > 0) {
            const uniqueIds = [...new Set(students.map(s => s.id))];
            const placeholders = uniqueIds.map(() => '?').join(',');
            const scoreRows = db.prepare(`
                SELECT student_id, subject, score, breakdown
                FROM student_records
                WHERE student_id IN (${placeholders})
                  AND academic_session = ?
                  AND term = ?
            `).all(...uniqueIds, termCfgForScores.academic_session, termCfgForScores.term);

            for (const r of scoreRows) {
                let bd = {};
                try { bd = JSON.parse(r.breakdown) || {}; } catch (_) {}
                const entries = Object.entries(bd || {}).filter(([, v]) => v != null);
                if (entries.length > 0) {
                    for (const [key, val] of entries) {
                        // Normalize the key to match active components
                        const normKey = key.toLowerCase().replace(/[^a-z0-9]/g, '');
                        const matchedComp = scoreComponents.find(c =>
                            c.key.toLowerCase().replace(/[^a-z0-9]/g, '') === normKey ||
                            c.label.toLowerCase().replace(/[^a-z0-9]/g, '') === normKey
                        );
                        const finalKey = matchedComp ? matchedComp.key : key;
                        existingScores.push({
                            student_id:    r.student_id,
                            subject:       r.subject,
                            component_key: finalKey,
                            score:         Number(val) || 0,
                        });
                    }
                } else if (r.score != null && r.score > 0) {
                    // Fallback: no breakdown stored (score entered from desktop admin panel).
                    // Map the aggregate to the heaviest score component (usually "Exam") so
                    // the teacher sees the value pre-filled and can adjust components if needed.
                    const heaviest = scoreComponents.reduce(
                        (best, c) => (!best || (c.max || 0) > (best.max || 0) ? c : best),
                        scoreComponents[scoreComponents.length - 1] || null
                    );
                    if (heaviest) {
                        existingScores.push({
                            student_id:    r.student_id,
                            subject:       r.subject,
                            component_key: heaviest.key,
                            score:         Math.min(Number(r.score) || 0, heaviest.max || 100),
                        });
                    }
                }
            }
        }
    } catch (scoreErr) {
        console.warn('[Handshake] Could not fetch existing scores (non-fatal):', scoreErr.message);
    }

    const payloadObj = {
        status: "MARRIED",
        message: `Welcome to the ecosystem, ${teacher.name}.`,
        role: role,
        school_config: schoolConfig,
        score_components: scoreComponents,
        students: students,
        all_subjects: allSubjects,
        class_subjects: classSubjectsMap,
        form_class: formClass,
        scores: existingScores,             // pre-existing Hub scores for the matched roster
        server_timestamp: new Date().toISOString()
    };

    const jsonString = JSON.stringify(payloadObj);


    // PM Rule: Gzip if > 500 students to prevent Heat Spikes on the mobile side
    // For testing/QA, let's keep the threshold tight or test dynamically, 
    // but the prompt specifies chunk/gzip if > 500.
    if (students.length > 500) {
        console.log(`[Eco-Mode] Payload > 500 targeted students (${students.length}). Gzipping for ${device_id}...`);
        const zlib = require('zlib');
        zlib.gzip(jsonString, (err, buffer) => {
            if (!err) {
                res.setHeader('Content-Encoding', 'gzip');
                res.setHeader('Content-Type', 'application/json');
                res.status(200).send(buffer);
            } else {
                res.status(500).json({ error: "Compression error" });
            }
        });
    } else {
        console.log(`[Handshake] Sending ${students.length} targeted student records to ${device_id}`);
        res.status(200).json(payloadObj);
    }
};

// The "Day 2" Sync Endpoint
const handleSync = (req, res) => {
    const { device_id, teacher_id, teacher_name, signature, events, device_model } = req.body || {};
    const eventsArray = events || [];

    console.log(`[Sync] Received ${eventsArray.length} signed events from device: ${device_id || 'UNKNOWN'}`);
    if (signature) {
        console.log(`[Sync] ECDSA Signature Attached: ${signature.substring(0, 30)}...`);
    }

    let db;
    try {
        db = database.getDb();
    } catch (e) {
        console.error("[Sync] DB not ready.");
        return res.status(500).json({ error: "Database not initialized" });
    }

    const registrationLocked = checkLockState(db, 'registration');
    const gradesLocked       = checkLockState(db, 'grades');
    const attendanceLocked   = checkLockState(db, 'attendance');
    const registrationLockAt = getLockAtMillis(db, 'registration');
    const gradesLockAt       = getLockAtMillis(db, 'grades');
    const attendanceLockAt   = getLockAtMillis(db, 'attendance');

    const isStandalone = getLicenseStatus().tier === 'Standalone';
    const isStandaloneDevice = db.prepare('SELECT 1 FROM connected_devices WHERE device_id = ?').get(device_id) ? true : false;

    if (isStandalone && !isStandaloneDevice) {
        console.warn(`[Sync] Blocked sync request from unregistered/revoked device: ${device_id}`);
        return res.status(403).json({
            error: "DEVICE_REVOKED_OR_NOT_PAIRED",
            message: "Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."
        });
    }

    let teacherId = "UNKNOWN_TEACHER";
    let role = "teacher";
    if (isStandaloneDevice || teacher_id === 'STANDALONE_ADMIN') {
        teacherId = 'STANDALONE_ADMIN';
        role = "super_admin";
    } else if (teacher_id && teacher_id.startsWith('admin_')) {
        // ── Admin companion sync (subscription tiers) ────────────────────────
        const rawAdminId = teacher_id.replace(/^admin_/, '');
        const adminRow = db.prepare('SELECT id, username, role_level FROM admin_users WHERE id = ? LIMIT 1').get(rawAdminId);
        if (adminRow) {
            teacherId = adminRow.id;
            if (adminRow.role_level >= 9)      role = 'it_admin';
            else if (adminRow.role_level >= 7) role = 'principal';
            else if (adminRow.role_level >= 5) role = 'bursar';
            else                               role = 'result_clerk';
        }
    } else if (teacher_id) {
        // First check if this exists in staff_roles
        const staff = db.prepare('SELECT id, role FROM staff_roles WHERE id = ? LIMIT 1').get(teacher_id);
        if (staff) {
            teacherId = staff.id;
            role = staff.role;
        } else {
            const teacher = db.prepare('SELECT id, sync_revoked FROM teachers WHERE id = ? LIMIT 1').get(teacher_id);
            if (teacher) {
                if (teacher.sync_revoked === 1) {
                    return res.status(403).json({ error: "TEACHER_REVOKED", message: "This teacher's sync access has been revoked." });
                }
                teacherId = teacher.id;
                role = "teacher";
            }
        }
    } else if (teacher_name) {
        // Fallback for older tablet app versions
        const teacher = db.prepare('SELECT id, sync_revoked FROM teachers WHERE name = ? COLLATE NOCASE LIMIT 1').get(teacher_name);
        if (teacher) {
            if (teacher.sync_revoked === 1) {
                return res.status(403).json({ error: "TEACHER_REVOKED", message: "This teacher's sync access has been revoked." });
            }
            teacherId = teacher.id;
            role = "teacher";
        }
    }

    let actorLabel = teacher_name || "Teacher";
    if (teacherId === 'STANDALONE_ADMIN') {
        actorLabel = "Admin";
    } else if (teacherId !== 'UNKNOWN_TEACHER') {
        if (role !== "teacher") {
            const staff = db.prepare('SELECT name FROM staff_roles WHERE id = ?').get(teacherId);
            if (staff) actorLabel = staff.name;
        } else {
            const dbTeacher = db.prepare('SELECT name FROM teachers WHERE id = ?').get(teacherId);
            if (dbTeacher) actorLabel = dbTeacher.name;
        }
    }

    // Read current active session/term so every grade record is queryable by session+term.
    // This fixes the root cause of scores showing "—" in generated reports.
    const termRow      = db.prepare('SELECT academic_session, term FROM school_term_config WHERE id = 1').get() || {};
    const activeSession = termRow.academic_session || '2024/2025';
    const activeTerm    = termRow.term             || 'First Term';

    // Process Ledger insertions in a single atomic transaction.
    // Using INSERT OR IGNORE for the audit log so that idempotent re-syncs
    // (same deterministic event_id GRADE_<student>_<subject>) don't throw a
    // PRIMARY KEY conflict and silently abort the grade upsert that follows.
    const insertLog    = db.prepare('INSERT OR IGNORE INTO sync_logs (event_id, device_id, teacher_id, payload) VALUES (?, ?, ?, ?)');
    const upsertRecord = db.prepare(`
        INSERT OR REPLACE INTO student_records 
        (student_id, subject, academic_session, term, assessment, score, breakdown, teacher_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertStudent = db.prepare('INSERT OR IGNORE INTO students (id, name, class_name) VALUES (?, ?, ?)');
    const insertStudentSubject = db.prepare('INSERT OR IGNORE INTO student_subjects (student_id, subject) VALUES (?, ?)');
    const upsertStudent = db.prepare(`
        INSERT INTO students (id, name, class_name, class_arm, reg_no, admission_no, gender, dob, photo, parent_name, parent_email, parent_phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET 
            name = excluded.name, 
            class_name = excluded.class_name,
            class_arm = COALESCE(nullif(excluded.class_arm, ''), class_arm),
            reg_no = COALESCE(nullif(excluded.reg_no, ''), reg_no),
            admission_no = COALESCE(nullif(excluded.admission_no, ''), admission_no),
            gender = COALESCE(nullif(excluded.gender, ''), gender),
            dob = COALESCE(nullif(excluded.dob, ''), dob),
            photo = COALESCE(excluded.photo, photo),
            parent_name = COALESCE(nullif(excluded.parent_name, ''), parent_name),
            parent_email = COALESCE(nullif(excluded.parent_email, ''), parent_email),
            parent_phone = COALESCE(nullif(excluded.parent_phone, ''), parent_phone)
    `);
    const insertActivityLog = db.prepare(`
        INSERT INTO activity_log (device_id, device_model, actor_label, event_type, payload_hash)
        VALUES (?, ?, ?, ?, ?)
    `);

    let successfullyInserted = 0;
    const failedEvents = [];
    
    // Check if device is explicitly revoked
    const isRevoked = db.prepare("SELECT 1 FROM revoked_devices WHERE device_id = ?").get(device_id);
    if (isRevoked) {
        return res.status(403).json({ error: "REVOKED" });
    }

    // License Check State
    let currentStudentCount = db.prepare('SELECT COUNT(id) AS c FROM students').get().c;
    const maxStudents = app.locals.license_limit?.payload ? JSON.parse(app.locals.license_limit.payload).student_count || 999999 : 999999;

    const processSyncTransaction = db.transaction(() => {
        for (const evt of eventsArray) {
            // 1. Audit Trail (INSERT OR IGNORE — safe on re-sync)
            try {
                insertLog.run(evt.event_id, device_id || 'UNKNOWN', teacherId, JSON.stringify(evt));
            } catch (auditErr) {
                console.warn(`[Sync] Audit log skipped for ${evt.event_id}:`, auditErr.message);
            }

            // 2. Add Student Interceptor (The Hawk)
            if (evt.event_type === "ADD_STUDENT") {
                try {
                    // ── Mobile registration lock check ────────────────────────────
                    if (registrationLocked) {
                        console.log(`[Sync] ADD_STUDENT blocked — mobile registration is disabled by admin.`);
                        failedEvents.push(evt.event_id);
                        continue;
                    }
                    // ─────────────────────────────────────────────────────────────
                    if (currentStudentCount >= maxStudents) {
                        failedEvents.push(evt.event_id);
                        continue; // Skip this insertion
                    }
                    const p = JSON.parse(evt.payload);
                    upsertStudent.run(
                        p.student_id,
                        p.name,
                        p.class_name,
                        p.class_arm || '',
                        p.reg_no || '',
                        p.admission_no || '',
                        p.gender || '',
                        p.dob || '',
                        p.photo_base64 || null,
                        p.parent_name || '',
                        p.parent_email || '',
                        p.parent_phone || ''
                    );
                    insertStudentSubject.run(p.student_id, p.subject || 'General');
                    currentStudentCount++;
                } catch (e) {
                    console.error("Failed to add student:", e);
                }
            }

            // 3. Ledger Upsert — runs independently so audit errors never block grade writes
            if (evt.event_type === "UPDATE_GRADE") {
                if (gradesLocked) {
                    console.log(`[Sync] UPDATE_GRADE blocked — mobile grades entry is locked by admin.`);
                    failedEvents.push(evt.event_id);
                    continue;
                }
                try {
                    const p = JSON.parse(evt.payload);
                    const breakdownStr = p.breakdown ? JSON.stringify(p.breakdown) : "{}";
                    const incomingSubject = p.subject || 'General';

                    // --- SUBJECT CONSISTENCY ENGINE ---
                    // 1. Get the student's canonical class + arm to check allocations
                    const studentRow = db.prepare('SELECT class_name, COALESCE(class_arm, \'\') as class_arm FROM students WHERE id = ?').get(p.student_id);
                    if (studentRow && teacherId && teacherId !== 'STANDALONE_ADMIN' && incomingSubject !== 'General') {
                        const fullClass = studentRow.class_name + studentRow.class_arm;
                        // 2. Check allocation against both bare class_name and composite (e.g. 'JSS1' AND 'JSS1A')
                        const allocationCheck = db.prepare(
                            "SELECT 1 FROM teacher_allocations WHERE teacher_id = ? AND (UPPER(replace(class_name, ' ', '')) = ? OR UPPER(replace(class_name, ' ', '')) = ?) AND subject = ?"
                        ).get(teacherId, 
                              (studentRow.class_name || '').replace(/\s+/g, '').toUpperCase(), 
                              (fullClass || '').replace(/\s+/g, '').toUpperCase(), 
                              incomingSubject);
                        
                        if (!allocationCheck) {
                            // 3. Mismatch detected! Log warning, but DO NOT drop the data (per requirements)
                            try {
                                db.prepare('INSERT INTO sync_warnings (device_id, teacher_id, student_id, mismatched_subject) VALUES (?, ?, ?, ?)').run(device_id, teacherId, p.student_id, incomingSubject);
                            } catch (warnErr) {
                                console.error("[Sync] Failed to log sync_warning:", warnErr.message);
                            }
                        }
                    }
                    // ----------------------------------

                    upsertRecord.run(
                        p.student_id,
                        incomingSubject,
                        activeSession,
                        activeTerm,
                        p.assessment || 'CA1',
                        p.score,
                        breakdownStr,
                        teacherId
                    );
                    successfullyInserted++;
                } catch (gradeErr) {
                    console.error(`[Sync] Grade upsert failed for ${evt.event_id}:`, gradeErr.message);
                }
            }

            // 4. Attendance Interceptor
            if (evt.event_type === "ATTENDANCE_UPDATE") {
                if (attendanceLocked) {
                    console.log(`[Sync] ATTENDANCE_UPDATE blocked — mobile attendance entry is locked by admin.`);
                    failedEvents.push(evt.event_id);
                    continue;
                }
                try {
                    const p = JSON.parse(evt.payload);
                    const source = p.source || 'teacher';

                    // Reject future-dated attendance
                    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
                    if (p.date && p.date > today) {
                        console.warn(`[Sync] ATTENDANCE_UPDATE rejected — future date ${p.date} (today is ${today})`);
                        failedEvents.push(evt.event_id);
                        continue;
                    }

                    const upsertAttendance = db.prepare(`
                        INSERT INTO daily_attendance
                        (student_id, class_name, date, status, academic_session, term, recorded_by_teacher_id, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(student_id, date) DO UPDATE SET 
                        status=excluded.status, 
                        recorded_by_teacher_id=excluded.recorded_by_teacher_id,
                        source=excluded.source
                        WHERE daily_attendance.source != 'admin' OR excluded.source = 'admin'
                    `);
                    upsertAttendance.run(
                        p.student_id,
                        p.class_name,
                        p.date,
                        p.status,
                        activeSession,
                        activeTerm,
                        teacherId,
                        source
                    );
                    successfullyInserted++;

                    // Guardian Shield: Emit alert event if absent
                    if (p.status === 'Absent') {
                        eventEmitter.emit('attendance-alert', {
                            student_id: p.student_id,
                            date: p.date
                        });
                    }
                } catch (attErr) {
                    console.error(`[Sync] Attendance upsert failed for ${evt.event_id}:`, attErr.message);
                }
            }

            // 5. Activity Log write (all tiers)
            try {
                const crypto = require('crypto');
                const hash = crypto.createHash('sha256').update(evt.payload || '').digest('hex');
                insertActivityLog.run(
                    device_id || 'UNKNOWN',
                    device_model || null,
                    actorLabel,
                    evt.event_type,
                    hash
                );
            } catch (actErr) {
                console.warn(`[Sync] Activity log failed for ${evt.event_id}:`, actErr.message);
            }
        }
    });



    try {
        processSyncTransaction();
        console.log(`[Sync] Successfully upserted ${successfullyInserted} grade records into Ledger.`);
    } catch (err) {
        console.error("[Sync] Transaction failed:", err);
    }

    // Forward enriched events to main.js via EventEmitter
    eventEmitter.emit('sync-events', { teacher_name: teacher_name || "A Teacher", events: eventsArray, count: successfullyInserted });

    // Inform Main App if limit was breached!
    if (failedEvents.length > 0) {
        eventEmitter.emit('capacity-alert', { totalFailed: failedEvents.length });
    }

    // Resolve license expiry so phone can show a countdown warning
    let expiresAt = 0;
    try {
        if (app.locals.license_limit?.payload) {
            expiresAt = JSON.parse(app.locals.license_limit.payload).expires_at || 0;
        }
    } catch (_) {}

    // --- SUBJECT CONSISTENCY ENGINE ---
    // Push the canonical list of subjects back to the Android app so it can fix stale lists
    let canonicalSubjects = [];
    try {
        if (teacherId) {
            canonicalSubjects = db.prepare('SELECT class_name, subject FROM teacher_allocations WHERE teacher_id = ?').all(teacherId);
        }
    } catch (e) {
        console.error("[Sync] Failed to fetch canonical subjects:", e.message);
    }

    // Push current score_components so every Sync Now refreshes grading fields on device.
    let syncScoreComponents = null;
    try {
        const termCfg2 = db.prepare('SELECT grading_scale, attendance_score_weight, include_attendance_in_grades FROM school_term_config WHERE id = 1').get();
        if (termCfg2?.grading_scale) {
            const p2 = JSON.parse(termCfg2.grading_scale);
            if (Array.isArray(p2) && p2.length > 0)            syncScoreComponents = p2;
            else if (p2?.components?.length > 0)               syncScoreComponents = p2.components;
        }
        const attW = termCfg2?.attendance_score_weight || 0;
        const includeAtt2 = termCfg2?.include_attendance_in_grades !== 0;
        if (attW > 0 && includeAtt2) {
            if (!syncScoreComponents) syncScoreComponents = [];
            const hasAtt = syncScoreComponents.find(c =>
                c.key === 'ATT' || c.key === 'Attendance' ||
                (c.label && c.label.toLowerCase().includes('attend'))
            );
            if (!hasAtt) syncScoreComponents.push({ key: 'ATT', label: 'Attendance', max: attW });
        }
    } catch (_) {}

    if (syncScoreComponents) {
        syncScoreComponents = sortGradingComponents(syncScoreComponents);
    }

    res.status(200).json({
        status: failedEvents.length > 0 ? 'PARTIAL_LIMIT' : 'ACK',
        failed_events: failedEvents,
        expires_at: expiresAt,
        role: role,
        canonical_subjects: canonicalSubjects,
        score_components: syncScoreComponents || [],
        registration_locked: registrationLocked,
        grades_locked:       gradesLocked,
        attendance_locked:   attendanceLocked,
        registration_lock_at: registrationLockAt,
        grades_lock_at:       gradesLockAt,
        attendance_lock_at:   attendanceLockAt
    });
};

app.post('/handshake', handshakeRateLimiter, (req, res, next) => {
    console.warn('[DEPRECATED] Bare route /handshake used. Clients should update to use /api/handshake.');
    next();
}, handleHandshake);
app.post('/api/handshake', handshakeRateLimiter, handleHandshake);

app.post('/sync', (req, res, next) => {
    console.warn('[DEPRECATED] Bare route /sync used. Clients should update to use /api/sync.');
    next();
}, handleSync);
app.post('/api/sync', handleSync);

// Helper for rendering PDF using Electron offscreen browser window
async function renderHtmlToPdf(htmlContent) {
    const path = require('path');
    const fs = require('fs');
    const os = require('os');
    let BrowserWindow;
    try {
        BrowserWindow = require('electron').BrowserWindow;
    } catch (e) {
        throw new Error('Electron environment not available for PDF rendering');
    }

    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-mob-reports-'));
    const htmlPath = path.join(tempDir, 'report.html');
    fs.writeFileSync(htmlPath, htmlContent, 'utf8');

    return new Promise((resolve, reject) => {
        let win = new BrowserWindow({
            show: false,
            width: 794,
            height: 1123,
            webPreferences: {
                offscreen: true,
                webSecurity: false
            }
        });
        win.loadFile(htmlPath);
        win.webContents.on('did-finish-load', async () => {
            try {
                await new Promise(r => setTimeout(r, 250));
                const pdfBuffer = await win.webContents.printToPDF({
                    printBackground: true,
                    pageSize: 'A4',
                    landscape: false
                });
                win.close(); win = null;
                try { fs.rmSync(tempDir, { recursive: true }); } catch(_) {}
                resolve(pdfBuffer);
            } catch (err) {
                if (win) { win.close(); win = null; }
                reject(err);
            }
        });
    });
}

// ── Mobile API: Generate Class Reports PDF ───────────────────────────────────
app.post('/api/generate-report', requireDeviceAuth, async (req, res) => {
    const { class_name } = req.body;
    if (!class_name) {
        return res.status(400).json({ error: "Class name is required" });
    }

    try {
        const path = require('path');
        const fs = require('fs');
        const os = require('os');
        const db = database.getDb();
        const termConfig = db.prepare('SELECT * FROM school_term_config WHERE id = 1').get();
        if (!termConfig) {
            return res.status(400).json({ error: "Term configuration not found" });
        }
        const session = termConfig.academic_session;
        const term = termConfig.term;

        const students = db.prepare(`
            SELECT * FROM students 
            WHERE UPPER(replace(class_name || COALESCE(' ' || NULLIF(class_arm, ''), ''), ' ', '')) = ? 
            ORDER BY name ASC
        `).all(class_name.replace(/\s+/g, '').toUpperCase());

        if (students.length === 0) {
            return res.status(404).json({ error: `No students found in class: ${class_name}` });
        }

        const getRecords = db.prepare(
          "SELECT subject, score, breakdown FROM student_records WHERE student_id = ? AND academic_session = ? AND term = ?"
        );
        const getDomains = db.prepare(
          "SELECT domain_type, trait, grade FROM student_domains WHERE student_id = ? AND academic_session = ? AND term = ?"
        );
        const getRemark = db.prepare(
          "SELECT remark, principal_remark FROM teacher_remarks WHERE student_id = ? AND academic_session = ? AND term = ?"
        );
        const getExplicitSubjects = db.prepare("SELECT subject FROM student_subjects WHERE student_id = ?");
        const getTermAttendance = db.prepare(
          "SELECT total_days, days_attended FROM student_attendance WHERE student_id = ? AND academic_session = ? AND term = ?"
        );

        let excludeUnregisteredFromTotals = false;
        try {
          const termCfgForExclude = db.prepare("SELECT exclude_unregistered_from_totals FROM school_term_config WHERE id = 1").get() || {};
          excludeUnregisteredFromTotals = termCfgForExclude.exclude_unregistered_from_totals === 1;
        } catch (_) {}

        const _maxSubjectsMap = {};
        try {
          db.prepare("SELECT hierarchy_class, max_subjects FROM class_configs").all()
            .forEach(c => { _maxSubjectsMap[c.hierarchy_class] = c.max_subjects; });
        } catch (_) {}

        const _resolveMax = (cn) => {
          if (!cn) return null;
          const normCn = cn.replace(/\s+/g, '').toUpperCase();
          for (const key of Object.keys(_maxSubjectsMap)) {
            if (normCn === key.replace(/\s+/g, '').toUpperCase()) return _maxSubjectsMap[key];
          }
          const keys = Object.keys(_maxSubjectsMap).sort((a, b) => b.replace(/\s+/g, '').length - a.replace(/\s+/g, '').length);
          for (const key of keys) {
            const normKey = key.replace(/\s+/g, '').toUpperCase();
            if (normCn.startsWith(normKey)) {
              const v = _maxSubjectsMap[key];
              if (v != null && v > 0) return v;
            }
          }
          return null;
        };

        const formTeacherMap = new Map();
        db.prepare(`
          SELECT f.class_name, t.name, t.signature 
          FROM form_teachers f
          JOIN teachers t ON f.teacher_id = t.id
        `).all().forEach(ft => formTeacherMap.set(ft.class_name, ft));

        const classDaysMap = new Map();
        db.prepare(`
          SELECT class_name, count(DISTINCT date) as total_days 
          FROM daily_attendance 
          WHERE academic_session = ? AND term = ? 
          GROUP BY class_name
        `).all(session, term).forEach(r => classDaysMap.set(r.class_name, r.total_days));

        const getStudentAttendanceCount = db.prepare(`
          SELECT count(*) as days_attended 
          FROM daily_attendance 
          WHERE student_id = ? AND status IN ('Present', 'Late') AND academic_session = ? AND term = ?
        `);

        const identityRow = db.prepare("SELECT value FROM app_settings WHERE key = 'school_identity'").get();
        const identityPacket = identityRow ? JSON.parse(identityRow.value) : {};

        const results = students.map((stu) => {
          const records = getRecords.all(stu.id, session, term);
          const explicitSubjs = getExplicitSubjects.all(stu.id).map(r => r.subject);
          const resolvedSubjects = new Map();
          const explicitSubjsSet = new Set(explicitSubjs);

          explicitSubjs.forEach(sName => {
            resolvedSubjects.set(sName, { name: sName, score: null, breakdown: {}, isRegistered: true });
          });

          records.forEach(r => {
            resolvedSubjects.set(r.subject, {
              name: r.subject,
              score: r.score,
              breakdown: (() => { try { const p = JSON.parse(r.breakdown); return (p && typeof p === 'object') ? p : {}; } catch { return {}; } })(),
              isRegistered: explicitSubjsSet.has(r.subject),
            });
          });

          let allSubjectsArray = Array.from(resolvedSubjects.values());
          const gradedSubjects = allSubjectsArray.filter(s =>
            s.score !== null && (!excludeUnregisteredFromTotals || s.isRegistered)
          );
          const totalScore = gradedSubjects.reduce((sum, s) => sum + s.score, 0);
          const _maxSubs = _resolveMax(stu.class_name);
          const _denom = (_maxSubs && _maxSubs > 0) ? _maxSubs : gradedSubjects.length;
          const avg = gradedSubjects.length ? (totalScore / _denom).toFixed(2) : "—";

          const domains = getDomains.all(stu.id, session, term);
          const remark = getRemark.get(stu.id, session, term) || {};
          const fullClassName = (stu.class_arm && !stu.class_name.includes(stu.class_arm))
            ? `${stu.class_name} ${stu.class_arm}`
            : stu.class_name;

          const ft = formTeacherMap.get(fullClassName) || {};
          const termAtt = getTermAttendance.get(stu.id, session, term);
          let classTotalDays = 0;
          let daysAttended = 0;
          if (termAtt) {
            classTotalDays = termAtt.total_days;
            daysAttended = termAtt.days_attended;
          } else {
            classTotalDays = classDaysMap.get(fullClassName) || 0;
            const attRow = getStudentAttendanceCount.get(stu.id, session, term) || { days_attended: 0 };
            daysAttended = attRow.days_attended;
          }

          return {
            ...stu,
            class_name: fullClassName,
            subjects: allSubjectsArray,
            total_score: totalScore,
            average: avg,
            domains,
            attendance: {
              total_days: classTotalDays,
              days_attended: daysAttended
            },
            remark: remark.remark || "",
            principal_remark: remark.principal_remark || "",
            form_teacher_name: ft.name || "",
            form_teacher_signature: ft.signature || null,
            principal_signature: identityPacket.signature || null,
          };
        });

        const baseDir = path.join(path.dirname(require.resolve('./report-compiler.js')), '..');
        const payload = {
            identity: identityPacket,
            students: results,
            termConfig,
            reportType: "terminal",
            format: "pdf"
        };

        const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-mob-reports-'));
        const html = reports.generateHTMLPages(payload, baseDir, tempDir);
        const pdfBuffer = await renderHtmlToPdf(html);
        try { fs.rmSync(tempDir, { recursive: true }); } catch(_) {}
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=TerminalReport_${class_name.replace(/\s+/g, '_')}.pdf`);
        res.send(pdfBuffer);
    } catch (err) {
        console.error('[Generate Report API] Error:', err);
        res.status(500).json({ error: "Failed to generate class reports: " + err.message });
    }
});

// ── Mobile API: Financial Summary (Bursar) ───────────────────────────────────
app.get('/api/fees/summary', requireDeviceAuth, (req, res) => {
    try {
        const db = database.getDb();
        const termConfig = db.prepare('SELECT * FROM school_term_config WHERE id = 1').get();
        if (!termConfig) {
            return res.status(400).json({ error: "Term configuration not found" });
        }
        const session = termConfig.academic_session;
        const term = termConfig.term;

        const summary = db.prepare(`
            SELECT 
                COALESCE(SUM(total_billed), 0) as total_billed,
                COALESCE(SUM(total_paid), 0) as total_paid,
                COALESCE(SUM(total_billed - total_paid), 0) as total_outstanding
            FROM student_fees
            WHERE academic_session = ? AND term = ?
        `).get(session, term);

        const statusCounts = db.prepare(`
            SELECT status, count(*) as count
            FROM student_fees
            WHERE academic_session = ? AND term = ?
            GROUP BY status
        `).all(session, term);

        const statuses = { cleared: 0, partial: 0, unpaid: 0 };
        statusCounts.forEach(row => {
            if (row.status in statuses) {
                statuses[row.status] = row.count;
            }
        });

        res.json({
            academic_session: session,
            term: term,
            total_billed: summary.total_billed,
            total_paid: summary.total_paid,
            total_outstanding: summary.total_outstanding,
            status_counts: statuses
        });
    } catch (err) {
        console.error('[Fees Summary API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile API: Paired Devices (IT Admin) ────────────────────────────────────
app.get('/api/devices', requireDeviceAuth, (req, res) => {
    try {
        const db = database.getDb();
        const devices = db.prepare("SELECT * FROM connected_devices ORDER BY paired_at DESC").all();
        res.json({ devices });
    } catch (err) {
        console.error('[Devices API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile API: Stats Summary Dashboard (Principal) ──────────────────────────
app.get('/api/dashboard-summary', requireDeviceAuth, (req, res) => {
    try {
        const db = database.getDb();
        const studentsCount = db.prepare("SELECT count(*) as c FROM students").get().c;
        const teachersCount = db.prepare("SELECT count(*) as c FROM teachers").get().c;
        
        let classesCount = 0;
        try {
            classesCount = db.prepare("SELECT count(*) as c FROM class_configs").get().c;
        } catch (_) {
            classesCount = db.prepare("SELECT count(DISTINCT class_name) as c FROM students").get().c;
        }

        let lastSyncTime = 'Never';
        try {
            const row = db.prepare("SELECT received_at FROM activity_log WHERE event_type = 'SYNC_RECEIVED' ORDER BY received_at DESC LIMIT 1").get();
            if (row) lastSyncTime = row.received_at;
        } catch (_) {}

        res.json({
            students_count: studentsCount,
            teachers_count: teachersCount,
            classes_count: classesCount,
            last_sync_time: lastSyncTime
        });
    } catch (err) {
        console.error('[Dashboard Summary API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

// ── Mobile API: Revoke Device (IT Admin) ─────────────────────────────────────
app.post('/api/revoke-device', requireDeviceAuth, (req, res) => {
    const { device_id } = req.body;
    if (!device_id) {
        return res.status(400).json({ error: "Device ID is required" });
    }
    try {
        const db = database.getDb();
        db.prepare("DELETE FROM connected_devices WHERE device_id = ?").run(device_id);
        db.prepare("INSERT OR IGNORE INTO revoked_devices (device_id) VALUES (?)").run(device_id);
        
        logActivity({
            device_id: 'DESKTOP',
            actor_label: 'IT Admin',
            event_type: 'DEVICE_REVOKED',
            payload: { device_id }
        });
        
        res.json({ ok: true });
    } catch (err) {
        console.error('[Revoke Device API] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

function startServer(port = 3000) {
    app.listen(port, () => {
        const ip = address.ip();
        console.log(`[Nexus Server] Listening at http://${ip}:${port}`);
    });
    return eventEmitter;
}

function setSchoolConfig(config) {
    app.locals.school_config = config;
}

function setSchoolLicense(license) {
    app.locals.license_limit = license;
}

function revokeDevice(deviceId) {
    const db = database.getDb();
    db.prepare("INSERT OR IGNORE INTO revoked_devices (device_id) VALUES (?)").run(deviceId);
}

function clearData() {
    const db = database.getDb();

    // PRAGMA must run OUTSIDE a transaction — SQLite silently ignores
    // pragma statements issued inside a transaction (they become no-ops).
    db.pragma('foreign_keys = OFF');

    try {
        db.transaction(() => {
            const tables = db.prepare(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).all();
            for (const table of tables) {
                // Quote names to handle any reserved-word table names safely
                db.prepare(`DELETE FROM "${table.name}"`).run();
            }
            try {
                db.prepare("DELETE FROM sqlite_sequence").run();
            } catch (seqErr) {
                // Ignore if sqlite_sequence does not exist
            }

            // Re-seed minimal defaults
            db.exec(`
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('class_hierarchy', '["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"]');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('pass_mark_threshold', '50');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('current_academic_session', '2025/2026');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_daily_attendance', 'true');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('enable_subject_attendance', 'false');
                INSERT OR IGNORE INTO system_settings (key, value) VALUES ('truancy_escalation_flow', '[{"step":1,"trigger_after":1,"notify":"form_teacher","channel":"in-app"},{"step":2,"trigger_after":3,"notify":"principal","channel":"in-app"},{"step":3,"trigger_after":5,"notify":"parent","channel":"whatsapp"}]');
                INSERT OR REPLACE INTO system_settings (key, value) VALUES ('roster_seeded', 'true');
            `);

            // Re-seed default class configs
            const defaultClasses = ["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"];
            const insertConfig = db.prepare("INSERT OR IGNORE INTO class_configs (hierarchy_class) VALUES (?)");
            defaultClasses.forEach(cls => insertConfig.run(cls));

            // NOTE: We intentionally do NOT re-seed a default admin here.
            // Zero rows in admin_users is the correct post-reset state.
            // BootGate detects the empty table and routes to <SetupWizard />
            // exactly as it does on a fresh first install.
            // See: private_engine/docs/guides/23-database-backup-restore.md § 5.4 Gap 1

            db.prepare(`
                INSERT INTO audit_logs (admin_id, action, target, details)
                VALUES (NULL, 'SYSTEM_RESET', 'database', 'Database was reset to factory defaults')
            `).run();
        })();

        console.log('[Reset] All tables cleared and defaults re-seeded successfully.');
    logActivity({ event_type: 'APP_RESET', payload: { cleared_by: 'Admin' } });
    } finally {
        // Always re-enable FK enforcement — even if the transaction threw
        db.pragma('foreign_keys = ON');
    }
}

// Parses a CSV with Student_ID, Subject, Assessment, Score, Session, Term and inserts into student_records.
function handleGradesCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Grades Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            // Get active components from school_term_config to normalize keys
            const termCfg = db.prepare('SELECT grading_scale FROM school_term_config WHERE id = 1').get();
            let activeComponents = [];
            if (termCfg?.grading_scale) {
                try {
                    const parsed = JSON.parse(termCfg.grading_scale);
                    activeComponents = Array.isArray(parsed) ? parsed : (parsed.components || []);
                } catch (_) {}
            }

            const upsertRecord = db.prepare(`
                INSERT INTO student_records (student_id, subject, assessment, score, breakdown, teacher_id, academic_session, term)
                VALUES (@student_id, @subject, @assessment, @score, @breakdown, 'STANDALONE_ADMIN', @session, @term)
                ON CONFLICT(student_id, subject, assessment, academic_session, term) 
                DO UPDATE SET score = excluded.score, breakdown = excluded.breakdown
            `);

            const runImport = db.transaction((rows) => {
                let count = 0;
                for (const row of rows) {
                    const cleanRow = {};
                    for (const key of Object.keys(row)) {
                        const normKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
                        cleanRow[normKey] = row[key];
                    }

                    const studentId = (cleanRow['studentid'] || cleanRow['id'] || '').toString().trim();
                    const subject   = (cleanRow['subject']   || '').toString().trim();
                    let assessment = (cleanRow['assessment'] || '').toString().trim();
                    if (!assessment) {
                        assessment = 'FULL';
                    }
                    const session   = (cleanRow['session']    || '2024/2025').toString().trim();
                    const term      = normalizeTermName((cleanRow['term'] || 'First Term').toString().trim());

                    if (!studentId || !subject || !assessment) continue;

                    // Build breakdown from any present *score columns (excluding exactly 'score')
                    const breakdown = {};
                    let totalFromBreakdown = 0;
                    let hasBreakdown = false;
                    for (const key of Object.keys(cleanRow)) {
                        if (key.endsWith('score') && key !== 'score') {
                            const valStr = (cleanRow[key] || '').toString().trim();
                            if (valStr !== '') {
                                const parsedVal = parseFloat(valStr);
                                if (!isNaN(parsedVal)) {
                                    const val = Math.round(parsedVal * 100) / 100;
                                    let originalLabel = key;
                                    for (const origKey of Object.keys(row)) {
                                        if (origKey.trim().toLowerCase().replace(/[^a-z0-9]/g, '') === key) {
                                            originalLabel = origKey.trim();
                                            if (originalLabel.toLowerCase().endsWith('_score')) {
                                                originalLabel = originalLabel.substring(0, originalLabel.length - 6);
                                            } else if (originalLabel.toLowerCase().endsWith(' score')) {
                                                originalLabel = originalLabel.substring(0, originalLabel.length - 6);
                                            }
                                            break;
                                        }
                                    }
                                    
                                    // Normalize key based on active components to ensure DB match
                                    const normLabel = originalLabel.toLowerCase().replace(/[^a-z0-9]/g, '');
                                    const matchedComp = activeComponents.find(c => 
                                        c.key.toLowerCase().replace(/[^a-z0-9]/g, '') === normLabel ||
                                        c.label.toLowerCase().replace(/[^a-z0-9]/g, '') === normLabel
                                    );
                                    const finalKey = matchedComp ? matchedComp.key : originalLabel;
                                    breakdown[finalKey] = val;
                                    totalFromBreakdown += val;
                                    hasBreakdown = true;
                                }
                            }
                        }
                    }

                    let score;
                    if (hasBreakdown) {
                        score = Math.round(totalFromBreakdown * 100) / 100;
                    } else {
                        const scoreVal = (cleanRow['score'] || '').toString().trim();
                        if (scoreVal === '') continue;
                        score = Math.round(parseFloat(scoreVal) * 100) / 100;
                        if (isNaN(score)) continue;
                    }

                    const breakdownStr = hasBreakdown ? JSON.stringify(breakdown) : null;

                    upsertRecord.run({
                        student_id: studentId,
                        subject,
                        assessment,
                        score,
                        breakdown: breakdownStr,
                        session,
                        term
                    });
                    count++;
                }
                return count;
            });

            try {
                const count = runImport(rows);
                logActivity({
                    event_type: 'GRADES_CSV_IMPORTED',
                    payload: { rows_inserted: count }
                });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// Parses a CSV with Student_ID, Session, Term, Total_Days, Days_Attended and inserts into student_attendance.
function handleAttendanceCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Attendance Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const upsertAtt = db.prepare(`
                INSERT INTO student_attendance (student_id, academic_session, term, total_days, days_attended)
                VALUES (@student_id, @session, @term, @total_days, @days_attended)
                ON CONFLICT(student_id, academic_session, term)
                DO UPDATE SET 
                    total_days = excluded.total_days,
                    days_attended = excluded.days_attended
            `);

            const runImport = db.transaction((rows) => {
                let count = 0;
                for (const row of rows) {
                    const cleanRow = {};
                    for (const key of Object.keys(row)) {
                        const normKey = key.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
                        cleanRow[normKey] = row[key];
                    }

                    const studentId = (cleanRow['studentid'] || cleanRow['id'] || '').toString().trim();
                    const session   = (cleanRow['session']    || '2024/2025').toString().trim();
                    const term      = normalizeTermName((cleanRow['term'] || 'First Term').toString().trim());
                    const totVal    = (cleanRow['totaldays'] || '').toString().trim();
                    const attVal    = (cleanRow['daysattended'] || '').toString().trim();

                    if (!studentId || totVal === '' || attVal === '') continue;
                    const total_days = parseInt(totVal, 10);
                    const days_attended = parseInt(attVal, 10);
                    if (isNaN(total_days) || isNaN(days_attended)) continue;

                    upsertAtt.run({
                        student_id: studentId,
                        session,
                        term,
                        total_days,
                        days_attended
                    });
                    count++;
                }
                return count;
            });

            try {
                const count = runImport(rows);
                logActivity({
                    event_type: 'ATTENDANCE_CSV_IMPORTED',
                    payload: { rows_inserted: count }
                });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// Parses a CSV with Class_Name, Max_Subjects, Pass_Mark_Override, Arms and updates configs/hierarchy/arms.
function handleClassesCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            console.error('[CSV] Classes Stream error:', err);
            if (callback) callback(0, err.message);
        })
        .on('end', () => {
            if (rows.length === 0) {
                if (callback) callback(0, 'INVALID_TEMPLATE: The uploaded CSV file is empty.');
                return;
            }

            // Extract and normalize headers
            const headers = Object.keys(rows[0] || {}).map(h => h.trim().toLowerCase());
            const hasClass = headers.includes('class_name') || headers.includes('class');
            const hasArmsOrMax = headers.includes('arms') || headers.includes('max_subjects');

            if (!hasClass || !hasArmsOrMax) {
                if (callback) callback(0, 'INVALID_TEMPLATE: CSV headers do not match Classes template. Expected columns: Class_Name, Arms, Max_Subjects, Pass_Mark_Override.');
                return;
            }

            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const upsertConfig = db.prepare(`
                INSERT INTO class_configs (hierarchy_class, max_subjects, pass_mark_override)
                VALUES (@class_name, @max_subjects, @pass_mark_override)
                ON CONFLICT(hierarchy_class) DO UPDATE SET
                    max_subjects = excluded.max_subjects,
                    pass_mark_override = COALESCE(excluded.pass_mark_override, class_configs.pass_mark_override)
            `);

            const insertArm = db.prepare(`
                INSERT OR IGNORE INTO class_arms (hierarchy_class, arm)
                VALUES (?, ?)
            `);

            const getHierarchy = db.prepare("SELECT value FROM system_settings WHERE key = 'class_hierarchy'");
            const updateHierarchy = db.prepare("INSERT OR REPLACE INTO system_settings (key, value) VALUES ('class_hierarchy', ?)");

            const runImport = db.transaction((rows) => {
                // Reset/overwrite instead of merge: delete existing configurations and arms first.
                // If the transaction fails, these deletions are rolled back automatically.
                db.prepare("DELETE FROM class_arms").run();
                db.prepare("DELETE FROM class_configs").run();
                db.prepare("DELETE FROM system_settings WHERE key = 'class_hierarchy'").run();

                let count = 0;
                let hierarchy = [];
                let hierarchyChanged = false;

                for (const row of rows) {
                    const className = (row['Class_Name'] || row['Class'] || '').trim();
                    const maxSubsVal = (row['Max_Subjects'] || '').trim();
                    const passMarkVal = (row['Pass_Mark_Override'] || '').trim();
                    const armsRaw = (row['Arms'] || '').trim();

                    if (!className) continue;

                    const max_subjects = maxSubsVal !== '' ? parseInt(maxSubsVal, 10) : 0;
                    const pass_mark_override = passMarkVal !== '' ? parseInt(passMarkVal, 10) : null;

                    upsertConfig.run({
                        class_name: className,
                        max_subjects: isNaN(max_subjects) ? 0 : max_subjects,
                        pass_mark_override: isNaN(pass_mark_override) ? null : pass_mark_override
                    });

                    // Add to hierarchy list if not present
                    if (!hierarchy.includes(className)) {
                        hierarchy.push(className);
                        hierarchyChanged = true;
                    }

                    // Process arms
                    if (armsRaw) {
                        const arms = armsRaw.split('|').map(a => a.trim()).filter(Boolean);
                        for (let arm of arms) {
                            // Normalise: if the admin entered the full class name as part
                            // of the arm (e.g. "JSS 1 Emerald" when className="JSS 1"),
                            // strip the prefix so only "Emerald" is stored.  This prevents
                            // getFullList from producing doubled names like "JSS 1 JSS 1 Emerald".
                            if (arm.toLowerCase().startsWith(className.toLowerCase() + ' ')) {
                                arm = arm.slice(className.length + 1).trim();
                            }
                            if (arm) insertArm.run(className, arm);
                        }
                    }


                    count++;
                }

                if (hierarchyChanged) {
                    updateHierarchy.run(JSON.stringify(hierarchy));
                }
                db.prepare("INSERT OR REPLACE INTO system_settings (key, value) VALUES ('classes_initialized', 'true')").run();

                return count;
            });

            try {
                const count = runImport(rows);
                logActivity({
                    event_type: 'CLASSES_CSV_IMPORTED',
                    payload: { rows_inserted: count }
                });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// ── Fee Structure CSV Import ─────────────────────────────────────────────────
// Columns: Class_Name, Item_Name, Amount, Term
function handleFeeStructureCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => { if (callback) callback(0, err.message); })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const upsert = db.prepare(`
                INSERT INTO fee_structures (class_name, item_name, amount, term)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(class_name, item_name, term)
                DO UPDATE SET amount = excluded.amount
            `);

            try {
                let count = 0;
                db.transaction(() => {
                    for (const row of rows) {
                        const className = (row['Class_Name'] || '').trim();
                        const itemName  = (row['Item_Name']  || '').trim();
                        const amount    = parseFloat(row['Amount'] || '0');
                        const term      = (row['Term'] || 'All Terms').trim();
                        if (!className || !itemName || isNaN(amount)) continue;
                        upsert.run(className, itemName, amount, term);
                        count++;
                    }
                })();
                logActivity({ event_type: 'FEE_STRUCTURE_CSV_IMPORTED', payload: { rows: count } });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// ── Fee Payment CSV Import ───────────────────────────────────────────────────
// Columns: Student_ID, Academic_Session, Term, Amount_Paid, Payment_Method,
//          Reference_Number (opt), Payment_Date (opt), Recorded_By (opt)
function handleFeePaymentCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => { if (callback) callback(0, err.message); })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const validMethods = ['cash', 'transfer', 'pos', 'bank_teller'];
            const insertTx = db.prepare(`
                INSERT INTO fee_transactions
                    (student_id, academic_session, term, amount, payment_method, reference_number, recorded_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `);
            const upsertFee = db.prepare(`
                INSERT INTO student_fees (student_id, academic_session, term, total_billed, total_paid, status)
                VALUES (?, ?, ?, 0, ?, 'partial')
                ON CONFLICT(student_id, academic_session, term)
                DO UPDATE SET
                    total_paid = total_paid + excluded.total_paid,
                    status = CASE
                        WHEN (total_paid + excluded.total_paid) >= total_billed AND total_billed > 0 THEN 'cleared'
                        WHEN (total_paid + excluded.total_paid) > 0 THEN 'partial'
                        ELSE 'unpaid'
                    END,
                    updated_at = datetime('now')
            `);

            try {
                let count = 0;
                let errors = [];
                db.transaction(() => {
                    for (const row of rows) {
                        const studentId = (row['Student_ID'] || '').trim();
                        const session   = (row['Academic_Session'] || '').trim();
                        const term      = (row['Term'] || '').trim();
                        const amount    = parseFloat(row['Amount_Paid'] || '0');
                        const method    = (row['Payment_Method'] || 'cash').trim().toLowerCase();
                        const ref       = (row['Reference_Number'] || '').trim();
                        const date      = (row['Payment_Date'] || new Date().toISOString().split('T')[0]).trim();
                        const recordedBy = (row['Recorded_By'] || 'Admin').trim();

                        if (!studentId || !session || !term || isNaN(amount) || amount <= 0) {
                            errors.push(`Invalid row: ${JSON.stringify(row)}`);
                            continue;
                        }
                        const method_safe = validMethods.includes(method) ? method : 'cash';
                        insertTx.run(studentId, session, term, amount, method_safe, ref, recordedBy, date);
                        upsertFee.run(studentId, session, term, amount);
                        count++;
                    }
                })();
                if (errors.length) console.warn('[FeePaymentCSV] Skipped rows:', errors);
                logActivity({ event_type: 'FEE_PAYMENT_CSV_IMPORTED', payload: { rows: count, skipped: errors.length } });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

// ── Fee Adjustment CSV Import ────────────────────────────────────────────────
// Columns: Student_ID, Academic_Session, Term, Adjustment_Type, Amount,
//          Description (opt), Approved_By (opt)
function handleFeeAdjustmentCSVUpload(filePath, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => { if (callback) callback(0, err.message); })
        .on('end', () => {
            let db;
            try { db = database.getDb(); }
            catch (e) { if (callback) callback(0, 'DB not initialized'); return; }

            const validTypes = ['scholarship', 'waiver', 'owner_grant', 'bursary', 'discount'];
            const insert = db.prepare(`
                INSERT INTO fee_adjustments
                    (student_id, academic_session, term, adjustment_type, description, amount, approved_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `);

            try {
                let count = 0;
                let errors = [];
                db.transaction(() => {
                    for (const row of rows) {
                        const studentId = (row['Student_ID'] || '').trim();
                        const session   = (row['Academic_Session'] || '').trim();
                        const term      = (row['Term'] || '').trim();
                        const adjType   = (row['Adjustment_Type'] || 'discount').trim().toLowerCase();
                        const amount    = parseFloat(row['Amount'] || '0');
                        const desc      = (row['Description'] || '').trim();
                        const approvedBy = (row['Approved_By'] || 'Admin').trim();

                        if (!studentId || !session || !term || isNaN(amount) || amount <= 0) {
                            errors.push(`Invalid row: ${JSON.stringify(row)}`);
                            continue;
                        }
                        const type_safe = validTypes.includes(adjType) ? adjType : 'discount';
                        insert.run(studentId, session, term, type_safe, desc, amount, approvedBy);
                        count++;
                    }
                })();
                if (errors.length) console.warn('[FeeAdjustmentCSV] Skipped rows:', errors);
                logActivity({ event_type: 'FEE_ADJUSTMENT_CSV_IMPORTED', payload: { rows: count, skipped: errors.length } });
                if (callback) callback(count, null);
            } catch (err) {
                if (callback) callback(0, err.message);
            }
        });
}

function validateCSVDryRun(filePath, type, callback) {
    const rows = [];
    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => rows.push(row))
        .on('error', (err) => {
            if (callback) callback(null, err.message);
        })
        .on('end', () => {
            if (rows.length === 0) {
                if (callback) callback({ cleanCount: 0, blocking: [{ rowIndex: 1, field: 'File', reason: 'The uploaded CSV file is empty.' }], normalizable: [] });
                return;
            }
            
            let db;
            try {
                db = database.getDb();
            } catch (e) {
                if (callback) callback(null, 'DB not initialized');
                return;
            }
            
            // Collect metadata for validation
            const classConfigs = db.prepare("SELECT hierarchy_class FROM class_configs").all().map(c => c.hierarchy_class.trim());
            const classArms = db.prepare("SELECT hierarchy_class, arm FROM class_arms").all().map(a => ({
                class_name: a.hierarchy_class.trim(),
                arm: a.arm.trim()
            }));
            
            const studentIds = new Set(db.prepare("SELECT id FROM students").all().map(s => s.id));
            
            // Helper to normalize strings for comparison (lowercase, strip all whitespace)
            const norm = (s) => (s || '').toString().toLowerCase().replace(/\s+/g, '');
            
            // Sort configs by length descending for class splitting (like splitClass in server.js)
            const sortedConfigs = [...classConfigs].sort((a, b) => b.length - a.length);
            const splitClass = (selected) => {
                const trimmed = (selected || '').trim();
                for (const prefix of sortedConfigs) {
                    if (trimmed === prefix) {
                        return { class_name: prefix, class_arm: '' };
                    }
                    if (trimmed.toLowerCase().startsWith(prefix.toLowerCase() + ' ')) {
                        return { class_name: prefix, class_arm: trimmed.substring(prefix.length + 1).trim() };
                    }
                }
                const lastSpace = trimmed.lastIndexOf(' ');
                if (lastSpace > -1) {
                    return {
                        class_name: trimmed.substring(0, lastSpace).trim(),
                        class_arm: trimmed.substring(lastSpace + 1).trim()
                    };
                }
                return { class_name: trimmed, class_arm: '' };
            };
            
            // Helper to validate a class + arm combo
            // Returns: { ok: boolean, error: string, normalized: { class_name, class_arm } }
            const validateClassCombo = (rawClassName) => {
                if (!rawClassName) {
                    return { ok: false, error: 'Class is empty' };
                }
                
                const split = splitClass(rawClassName);
                const resolvedClassNorm = norm(split.class_name);
                const resolvedArmNorm = norm(split.class_arm);
                
                // Find matching class config
                const matchedConfig = classConfigs.find(c => norm(c) === resolvedClassNorm);
                if (!matchedConfig) {
                    return { ok: false, error: `"${rawClassName}" has no matching class + arm` };
                }
                
                // Find arms configured for this class
                const armsForClass = classArms.filter(a => norm(a.class_name) === resolvedClassNorm);
                
                if (armsForClass.length > 0) {
                    // Class has arms, so the row MUST have a valid arm
                    if (!split.class_arm) {
                        return { ok: false, error: `"${matchedConfig}" has no matching class + arm` };
                    }
                    
                    const matchedArm = armsForClass.find(a => norm(a.arm) === resolvedArmNorm);
                    if (!matchedArm) {
                        return { ok: false, error: `"${matchedConfig} ${split.class_arm}" has no matching class + arm` };
                    }
                    
                    // Found match. Check if casing/spacing matches exactly
                    const exactMatch = split.class_name === matchedConfig && split.class_arm === matchedArm.arm;
                    return {
                        ok: true,
                        exactMatch,
                        normalized: { class_name: matchedConfig, class_arm: matchedArm.arm }
                    };
                } else {
                    // Class has no arms configured
                    if (split.class_arm) {
                        return { ok: false, error: `"${matchedConfig} ${split.class_arm}" has no matching class + arm` };
                    }
                    
                    const exactMatch = split.class_name === matchedConfig;
                    return {
                        ok: true,
                        exactMatch,
                        normalized: { class_name: matchedConfig, class_arm: '' }
                    };
                }
            };

            const blocking = [];
            const normalizable = [];
            let cleanCount = 0;
            
            // Check headers to auto-detect roster type if not specified
            const headers = Object.keys(rows[0] || {}).map(h => h.trim().toLowerCase());
            let resolvedType = type;
            if (type === 'roster' || type === 'students' || type === 'teachers') {
                const hasStudentCols = headers.includes('student_id') || headers.includes('first_name') || headers.includes('last_name') || headers.includes('parent_phone');
                const hasTeacherCols = headers.includes('teacher_id') || headers.includes('teacher_name') || headers.includes('teacher_phone');
                if (hasTeacherCols && !hasStudentCols) {
                    resolvedType = 'teachers';
                } else {
                    resolvedType = 'students';
                }
            }
            
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const rowIndex = i + 1;
                let isRowBlocking = false;
                let isRowNormalizable = false;
                const rowNorms = [];
                
                if (resolvedType === 'students') {
                    const studentId = (row['Student_ID'] || row['ID'] || '').trim();
                    const firstName = (row['First_Name'] || '').trim();
                    const lastName = (row['Last_Name'] || '').trim();
                    const className = (row['Class'] || '').trim();
                    
                    if (!studentId || (!firstName && !lastName) || !className) {
                        blocking.push({ rowIndex, field: 'Roster', reason: `Row is missing required student fields (Student_ID, Name, or Class)` });
                        continue;
                    }
                    
                    const classCheck = validateClassCombo(className);
                    if (!classCheck.ok) {
                        blocking.push({ rowIndex, field: 'Class', reason: classCheck.error });
                        isRowBlocking = true;
                    } else if (!classCheck.exactMatch) {
                        rowNorms.push({
                            field: 'Class',
                            from: className,
                            to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                        });
                        isRowNormalizable = true;
                    }

                    const parentPhone = (row['Parent_Phone'] || row['Phone'] || '').trim();
                    if (parentPhone) {
                        const cleanPhone = parentPhone.replace(/[\s\-()]/g, '');
                        const isNig = /^(\+?234|0)[789][01]\d{8}$/.test(cleanPhone);
                        const isIntl = /^\+?[1-9]\d{6,14}$/.test(cleanPhone);
                        if (!isNig && !isIntl) {
                            blocking.push({ rowIndex, field: 'Parent_Phone', reason: `"${parentPhone}" is not a valid phone number` });
                            isRowBlocking = true;
                        }
                    }

                    const parentEmail = (row['Parent_Email'] || row['Email'] || '').trim();
                    if (parentEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parentEmail)) {
                        blocking.push({ rowIndex, field: 'Parent_Email', reason: `"${parentEmail}" is not a valid email address` });
                        isRowBlocking = true;
                    }
                    
                } else if (resolvedType === 'teachers') {
                    const teacherId = (row['Teacher_ID'] || '').trim();
                    const teacherName = (row['Teacher_Name'] || '').trim();
                    const className = (row['Class'] || '').trim();
                    const classHost = (row['Class_Host'] || '').trim();
                    
                    if (!teacherId || !teacherName) {
                        blocking.push({ rowIndex, field: 'Teacher', reason: `Row is missing required teacher fields (Teacher_ID or Teacher_Name)` });
                        continue;
                    }

                    const teacherPhone = (row['Teacher_Phone'] || row['Phone'] || '').trim();
                    if (teacherPhone) {
                        const cleanPhone = teacherPhone.replace(/[\s\-()]/g, '');
                        const isNig = /^(\+?234|0)[789][01]\d{8}$/.test(cleanPhone);
                        const isIntl = /^\+?[1-9]\d{6,14}$/.test(cleanPhone);
                        if (!isNig && !isIntl) {
                            blocking.push({ rowIndex, field: 'Teacher_Phone', reason: `"${teacherPhone}" is not a valid phone number` });
                            isRowBlocking = true;
                        }
                    }
                    
                    // Validate allocated classes
                    if (className) {
                        const classes = className.split('|').map(c => c.trim()).filter(Boolean);
                        for (const cls of classes) {
                            const split = splitClass(cls);
                            // For allocated classes, check that the class name itself exists
                            const matchedClass = classConfigs.find(c => norm(c) === norm(split.class_name));
                            if (!matchedClass) {
                                blocking.push({ rowIndex, field: 'Class', reason: `"${cls}" has no matching class + arm` });
                                isRowBlocking = true;
                            } else if (split.class_name !== matchedClass) {
                                rowNorms.push({
                                    field: 'Class Allocation',
                                    from: cls,
                                    to: matchedClass + (split.class_arm ? ' ' + split.class_arm : '')
                                });
                                isRowNormalizable = true;
                            }
                        }
                    }
                    
                    // Validate class host (form teacher assignment)
                    if (classHost && classHost.toUpperCase() !== 'FALSE' && classHost.toUpperCase() !== 'NO' && classHost.toUpperCase() !== '0') {
                        let hostClassToValidate = classHost;
                        // If it's a simple boolean flag, retrieve the first class from className
                        if (classHost.toUpperCase() === 'TRUE' || classHost.toUpperCase() === '1' || classHost.toUpperCase() === 'YES') {
                            const classes = className.split('|').map(c => c.trim()).filter(Boolean);
                            hostClassToValidate = classes[0] || '';
                        }
                        
                        if (hostClassToValidate) {
                            // Enforce strict check on hostClassToValidate
                            const classCheck = validateClassCombo(hostClassToValidate);
                            if (!classCheck.ok) {
                                blocking.push({ rowIndex, field: 'Class_Host', reason: classCheck.error });
                                isRowBlocking = true;
                            } else if (!classCheck.exactMatch) {
                                rowNorms.push({
                                    field: 'Class Host',
                                    from: hostClassToValidate,
                                    to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                                });
                                isRowNormalizable = true;
                            }
                        }
                    }
                    
                } else if (resolvedType === 'grades') {
                    const studentId = (row['Student_ID'] || '').trim();
                    const subject = (row['Subject'] || '').trim();
                    
                    if (!studentId || !subject) {
                        blocking.push({ rowIndex, field: 'Grades', reason: `Row is missing required fields (Student_ID or Subject)` });
                        continue;
                    }
                    
                    if (!studentIds.has(studentId)) {
                        blocking.push({ rowIndex, field: 'Student_ID', reason: `Student ID "${studentId}" was not found` });
                        isRowBlocking = true;
                    }
                    
                } else if (resolvedType === 'attendance') {
                    const studentId = (row['Student_ID'] || '').trim();
                    const className = (row['Class'] || '').trim();
                    
                    if (!studentId || !className) {
                        blocking.push({ rowIndex, field: 'Attendance', reason: `Row is missing required fields (Student_ID or Class)` });
                        continue;
                    }
                    
                    if (!studentIds.has(studentId)) {
                        blocking.push({ rowIndex, field: 'Student_ID', reason: `Student ID "${studentId}" was not found` });
                        isRowBlocking = true;
                    }
                    
                    const classCheck = validateClassCombo(className);
                    if (!classCheck.ok) {
                        blocking.push({ rowIndex, field: 'Class', reason: classCheck.error });
                        isRowBlocking = true;
                    } else if (!classCheck.exactMatch) {
                        rowNorms.push({
                            field: 'Class',
                            from: className,
                            to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                        });
                        isRowNormalizable = true;
                    }
                    
                } else if (resolvedType === 'fee-structure') {
                    const className = (row['Class_Name'] || '').trim();
                    const itemName = (row['Item_Name'] || '').trim();
                    const term = (row['Term'] || 'All Terms').trim();
                    
                    if (!className || !itemName) {
                        blocking.push({ rowIndex, field: 'Fee Structure', reason: `Row is missing required fields (Class_Name or Item_Name)` });
                        continue;
                    }
                    
                    const classCheck = validateClassCombo(className);
                    if (!classCheck.ok) {
                        blocking.push({ rowIndex, field: 'Class_Name', reason: classCheck.error });
                        isRowBlocking = true;
                    } else if (!classCheck.exactMatch) {
                        rowNorms.push({
                            field: 'Class Name',
                            from: className,
                            to: `${classCheck.normalized.class_name}${classCheck.normalized.class_arm ? ' ' + classCheck.normalized.class_arm : ''}`
                        });
                        isRowNormalizable = true;
                    }
                    
                    // Validate term is one of the four valid values or a casing variant
                    const validTerms = ['All Terms', 'First Term', 'Second Term', 'Third Term'];
                    const matchedTerm = validTerms.find(t => norm(t) === norm(term));
                    if (!matchedTerm) {
                        blocking.push({ rowIndex, field: 'Term', reason: `Term "${term}" must be one of: All Terms, First Term, Second Term, Third Term` });
                        isRowBlocking = true;
                    } else if (term !== matchedTerm) {
                        rowNorms.push({
                            field: 'Term',
                            from: term,
                            to: matchedTerm
                        });
                        isRowNormalizable = true;
                    }
                    
                } else if (resolvedType === 'fee-adjustment') {
                    const studentId = (row['Student_ID'] || '').trim();
                    const amount = (row['Amount'] || '').trim();
                    
                    if (!studentId || !amount) {
                        blocking.push({ rowIndex, field: 'Fee Adjustment', reason: `Row is missing required fields (Student_ID or Amount)` });
                        continue;
                    }
                    
                    if (!studentIds.has(studentId)) {
                        blocking.push({ rowIndex, field: 'Student_ID', reason: `Student ID "${studentId}" was not found` });
                        isRowBlocking = true;
                    }
                }
                
                if (!isRowBlocking) {
                    if (isRowNormalizable) {
                        for (const normVal of rowNorms) {
                            normalizable.push({
                                rowIndex,
                                field: normVal.field,
                                from: normVal.from,
                                to: normVal.to
                            });
                        }
                    }
                    cleanCount++;
                }
            }
            
            if (callback) {
                callback({ cleanCount, blocking, normalizable });
            }
        });
}

module.exports = {
    startServer,
    setSchoolConfig,
    setSchoolLicense,
    revokeDevice,
    logActivity,
    handleCSVUpload,
    handleGradesCSVUpload,
    handleAttendanceCSVUpload,
    handleClassesCSVUpload,
    handleFeeStructureCSVUpload,
    handleFeePaymentCSVUpload,
    handleFeeAdjustmentCSVUpload,
    validateCSVDryRun,
    clearData
};
