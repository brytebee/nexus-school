# Nexus School OS — Sales & FAQ Playbook

## 🧨 Why Do Schools Need This Solution _Right Now_?

_(The ultimate pitch points for Principals and School Owners)_

- **Restoring Parent Trust:** Manual grading takes time and is highly susceptible to human errors or intentional manipulation to favor certain students. A biometric, locked system proves that a student's grade is their _actual_ grade.
- **Eliminating "Grade Hiding":** Low-performing students constantly find creative ways to ensure their parents aren't aware of their actual performance (tearing report cards, intercepting envelopes). Nexus generates instant, verifiable digital and physical copies that parents can trust.
- **Killing the Manual Grading Bottleneck:** Teachers spend entire weekends calculating percentages and positions manually when they should be preparing for the next term. Nexus calculates full school rankings and generates 500 reports in just 4 seconds.
- **A Holistic View of Academic History:** By digitizing results, tutors and parents gain a bird's-eye view of a student's performance over time. If a student is historically underperforming in Maths, data highlights this early so it can be strengthened. If they excel in Physics, this becomes a pointer for career advice—adding immense value for parents, teachers, and stakeholders.
- **Verifiable Transcripts for Admissions:** Producing transcripts for scholarly students applying to universities or pursuing careers abroad is currently a messy nightmare. The system acts as a goldmine of historical academic data, making instant transcript generation possible.
- **Projecting Modernity & Prestige:** A forward-thinking, progressing school that wants to employ tech to reach parents directly cannot rely on biro-graded Excel sheets. Going digital signals to prospective parents that the school is modern and doing exactly what top-tier schools are naturally doing now.

---

## 🎯 Additional Nigerian Secondary School Pain Points

_(Use these to build deeper rapport during sales pitches)_

1. **Power Outages & Internet Dependency:** Schools pay fortunes for data bundles, Starlinks, and generator fuel to keep cloud portals running. **Nexus Solution:** The whole sync process takes seconds locally and requires _zero internet data_. It can run entirely on laptop/phone batteries during a power cut.
2. **Teacher Turnover & Lost Records:** When a teacher leaves abruptly (or takes maternity leave), they often take their unsynced grades or physical ledger with them. **Nexus Solution:** Because syncs happen frequently over local Wi-Fi, the central Admin laptop always has the latest data.
3. **The "Formatting Nightmare":** Creating report cards in MS Word/Excel usually results in broken margins, missing logos, and messy printing. **Nexus Solution:** Our PDF Generator engine guarantees flawless symmetry, branding, and sizing on every single A4 printout.
4. **Data Extortion by Cloud Vendors:** Many Nigerian "school portal" SaaS companies hold a school's data hostage if they miss a subscription payment. **Nexus Solution:** Nexus is an offline-first system. The data lives on the Principal's laptop, completely owned by the school.

---

## 💳 Pricing & Payment Options

Our pricing structure is designed to be completely risk-free and scalable for your institution.

### Option A: The Premium Lifetime License

- **Cost:** ₦2M - ₦5M
- **Details:** A single upfront payment for a massive, customized perpetual license depending on features and maintenance overhead required over time. Best for well-established schools that want outright ownership over their OS.

### Option B: The Partnership Lease (Subscription)

- **Setup & Installation Fee:** ₦100,000 - ₦250,000 (Based on school size and hardware configuration needs)
- **Subscription:** ₦250 - ₦1,000 per student, _per term_.
- **Details:** Low barrier entry. We act as your IT partners. You pay a tiny fraction per term, and we ensure the software is flawlessly maintained over time.

🎁 **The Founder's Offer:** If you commit to a partnership within the next **7 days**, we are prepared to automatically apply a **generous 20-30% discount** to your plan fees.

---

## 💻 Infrastructure Requirements

_What exactly do we need to set this up today?_

1. **For the Admin/Principal:** A good and working laptop (Windows or Mac). This acts as the Command Center and data dashboard.
2. **For the Teachers:** Their existing personal Android smartphones. No extra hardware purchases required.
3. **Network:** A basic, standard Wi-Fi router. (It does not need active internet data—it simply connects the phones to the laptop over local radio waves).

---

## ❓ Frequently Asked Questions (FAQs)

**Q: What happens if a teacher's phone gets stolen? Is our data exposed?**
**A:** No. Nexus runs on a "Vault" protocol. The app locks automatically when minimized, and requires the teacher's biometric fingerprint to open. Furthermore, all data is cryptographically locked via SQLCipher. The thief gets nothing.

**Q: Do my teachers need active data subscriptions to upload results?**
**A:** Absolutely not. The Nexus "Marriage" protocol uses your school's local router as an invisible bridge. No MTN, Airtel, or Glo data is consumed during grading or syncing.

**Q: Can we change how grading works? For instance, we don't want to show "Positions" (1st, 2nd, 3rd) anymore.**
**A:** Yes. We have built-in toggles that allow schools to switch from standard Nigerian Ranking systems to individual-focused or British performance tracking systems with one click to suit your curriculum definition.

**Q: If we want to upgrade from Silver to Gold or downgrade later, how does that work?**
**A:** It is a seamless process locally. We simply issue the Admin a new License Token. Once inputted, your features upgrade instantly without any app reinstatement. If downgrading, past premium data is preserved seamlessly, though access to premium modules is locked.

**Q: What if the Admin laptop crashes or gets stolen?**
**A:** Nexus automatically generates secure, encrypted backups. Once the laptop connects to the internet (even once a week), it silently syncs to the school's private Google Drive. If a laptop dies, we just log in on a new one and restore exactly where you left off.

**Q: Will installing this app use up all the space on a teacher's phone?**
**A:** No. The database on the teacher's phone only stores data for their specific classes, not the whole school. The app itself is incredibly lightweight and designed heavily with "Eco-Mode" so it doesn't drain their battery or overheat their device.

**Q: What happens if a teacher tries to alter a grade later on?**
**A:** Every single grade entry is strictly timestamped and signed by that specific teacher's device cryptographically. Once the Admin clicks "Finalize Term", all teacher edits are permanently locked to ensure data integrity.
