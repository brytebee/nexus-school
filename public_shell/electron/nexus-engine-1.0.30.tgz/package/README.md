# Nexus (Private Engine) - INTERNAL USE ONLY

This directory contains the "Secret Sauce" of the Nexus ecosystem.

## Contents
- **Encryption**: Ed25519 Handshake & SQLCipher configurations.
- **Sync Protocol**: Low-level socket communication logic.
- **Schemas**: Master SQL definitions for multi-device consistency.

## Security
- Do not commit sensitive keys to this repository.
- Use the `identity.json` template for school-specific configurations.

---
**Core Credentials Placeholder**
- Sync Secret Hash: [PENDING_GEN]
- Device Auth Key: [PENDING_GEN]
