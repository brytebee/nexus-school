# Nexus School OS — Go-To-Market & Pricing Strategy

> **This is a private document. Do not share with schools or partners.**

---

## 💰 Pricing Architecture

### The Core Principle: Anchor High, Flex With Dignity

Nigerian school owners *expect* to negotiate. If you open at your real floor price, they will push below it and you will lose margin and respect. Always anchor above your floor and let them "win" a discount to close faster.

### Recommended Price Points

| Package | Who it's for | Per Term Fee | Installation |
|---|---|---|---|
| **Silver** | Schools < 200 students | ₦45,000/term | ₦75,000 (one-time) |
| **Gold** | Schools 200–500 students | ₦100,000/term | ₦100,000 (one-time) |
| **Diamond** | Schools 500+ students | Custom quote | ₦150,000+ |
| **Per-student model** (alt) | Any size | ₦300/student/term | ₦75,000 (one-time) |

> **Recommended for MVP demos:** Lead with the **per-student model**. It's self-explanatory, it scales with them, and it feels fair. "You only pay for the students you have."

### Founder Cohort Strategy (First 10 Schools)
- Waive installation fee OR charge a symbolic ₦20,000.
- Keep the term subscription at full price — that's your recurring income.
- Offer a "Founder Badge" they can show off: *"Charter Member — Nexus School OS".*
- These schools become your case studies, referrals, and pressure on competitors.

---

## 🩺 Framing Against Their Pain — The Deep Strategy

### The Principle

Nigerian private school owners don't buy *software*. They buy **relief from specific, expensive, embarrassing, or dangerous problems**. Your job in a sales conversation is never to describe features — it is to **name their pain loudly, then produce the cure**.

This is the difference between:
- ❌ *"Nexus has offline grade sync and biometric security."*
- ✅ *"You've had a parent storm into your office because their child's result was 'mysteriously' lower than expected. With Nexus, every score lives in a timestamped, tamper-proof log. No teacher can edit it after it's submitted. Show the parent the exact time the grade was entered."*

### The Five Pains That Close Deals

---

#### Pain 1: The Grade Manipulation Scandal
**What they fear:** A teacher changes a student's grade for money, out of favouritism, or under pressure from an influential parent. The school gets a reputation. Parents leave. WAEC investigators come.

**What Nexus sells them:**
> *"Every grade entered on the teacher's phone carries a device signature and a timestamp. Nexus stores a full audit trail — who entered it, when, from which device. If a grade is ever questioned, you open the log and show the truth in under 30 seconds."*

**Your demo moment:** On the Admin dashboard, show the live grade event feed. Point to the timestamp and device ID. Say: *"This is your court exhibit if you ever need one."*

---

#### Pain 2: Manual Result Computation Errors
**What they fear:** Results are calculated by hand — or worse, in Excel by an overwhelmed secretary. Errors happen. Parents discover them. The school reprints result sheets at a cost.

**What Nexus sells them:**
> *"The teacher enters CA1, CA2, and Exam. Nexus calculates the total, assigns the grade, and generates a print-ready PDF for every single student in one click. No calculations. No reprints. No shame."*

**Your demo moment:** Click "Generate Report Cards." Safari opens. Show them the A4 PDF with their school logo, colours, and a breakdown table. Say: *"This took 4 seconds."*

---

#### Pain 3: Lost Records
**What they fear:** A flood, fire, or laptop theft destroys all student records. Past results are unrecoverable. They can't respond to WAEC queries about historical data.

**What Nexus sells them:**
> *"Every grade is stored on the teacher's phone, the admin laptop, and backed up to the school's own Google Drive — automatically, silently, whenever connectivity exists. Your records survive anything short of the Rapture."*

**Your demo moment:** Describe the three-layer backup: Phone → Laptop → Cloud. Draw it on a piece of paper if needed. Simple is powerful here.

---

#### Pain 4: Teacher Accountability / Absenteeism
**What they fear:** Teachers don't grade. Results season becomes a crisis because nobody knows which class has been graded and which hasn't.

**What Nexus sells them:**
> *"Your Admin dashboard shows, in real time, which teachers have synced and which haven't. You don't have to chase anyone. You just look at the screen and know exactly who needs a phone call."*

**Your demo moment:** Show the Live Dashboard with the grade events feed and the teacher count. Point to the "X devices married" stat. Say: *"When you see this number stop growing before term ends, that teacher owes you a phone call."*

---

#### Pain 5: Parent Trust & Transparency
**What they fear:** Parents don't trust the school with their child's results. They believe manipulation is common. They question grades. This erodes the school's reputation even when it's honest.

**What Nexus sells them:**
> *"Imagine sending every parent a branded PDF report card — with your school logo, the principal's signature, and a full grade breakdown — on the last day of term, before they even ask. That's not just organisation. That's a statement: 'We are serious people.'"*

**Your demo moment:** Show them the generated report card PDF. Let them hold the laptop and read it. Ask: *"If your child's school sent you this, would you trust them more?"* They will say yes.

---

## 🎯 The Killer Closing Line

After the demo, when they ask *"how much?"*, do this:

1. Let there be a brief silence.
2. Say: *"Before I give you a number — what does one parent leaving your school cost you per term?"*
3. Wait for their answer. (It will be anywhere from ₦30,000 to ₦200,000 in fees.)
4. Then say: *"Nexus costs less than that. And it helps you keep more of them."*

This reframes the cost as ROI, not expense.

---

## 🚦 Demo Script (5 Minutes, Closes Deals)

1. Open Electron. Type the school's name in the settings screen in front of the Principal.
2. Upload a `Sample_Students.csv`. Say: *"Your secretary uploads the class list once per term."*
3. Display the QR → hand the phone to the teacher in the room.
4. Teacher scans → phone repaints in school colors instantly. (*Wow moment #1: the phone knows who they are.*)
5. Teacher enters 3–5 grades on the grading screen.
6. Point to the laptop. Grades appear live in the dashboard. (*Wow moment #2: data never left the room.*)
7. Lock the phone screen. Tap to open. Fingerprint prompt fires. (*Wow moment #3: bank-grade security, teacher's own finger.*)
8. Click "Generate Report Cards." PDF opens. (*Wow moment #4: "I'll take one of these for every student."*)
9. Tap the Eco-Guardian shield. Say: *"This tells you the teacher's phone will never overheat processing your data."*
10. Close with: *"Sir, your data never left this room. Not once."*

---

*Written by the Nexus product team. For internal use only.*
