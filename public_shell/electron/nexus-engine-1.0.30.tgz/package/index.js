const database = require('./src/database');
const server = require('./src/server');
const reports = require('./src/report-compiler');

module.exports = {
  database,
  server,
  reports
};
