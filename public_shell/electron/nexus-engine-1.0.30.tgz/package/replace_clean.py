import os
import re

d = "/Users/MAC/Documents/Projects/nexus-school/private_engine/assets/templates"
fp = os.path.join(d, "clean_slate.hbs")

with open(fp, 'r') as f:
    content = f.read()

content = re.sub('#1a2d5a', '{{tp}}', content, flags=re.IGNORECASE)
content = re.sub('#4a7fd4', '{{ts}}', content, flags=re.IGNORECASE)

with open(fp, 'w') as f:
    f.write(content)
