-- SEEDING SAMPLE GRADES FOR DEMO PURPOSES
-- We'll grade STU-001 (Science), STU-006 (Art), and STU-011 (Commercial)

-- 1. CHIDI ABIOLA (STU-001) - FULLY GRADED SCIENCE STUDENT
INSERT INTO student_records (student_id, subject, academic_session, term, score, breakdown, teacher_id) VALUES 
('STU-001', 'Mathematics', '2024/2025', 'First Term', 85, '{"CA1":12,"CA2":13,"Exam":60}', 'T-AKI'),
('STU-001', 'Further Maths', '2024/2025', 'First Term', 92, '{"CA1":15,"CA2":12,"Exam":65}', 'T-AKI'),
('STU-001', 'English Language', '2024/2025', 'First Term', 78, '{"CA1":10,"CA2":13,"Exam":55}', 'T-BEL'),
('STU-001', 'Civic Education', '2024/2025', 'First Term', 80, '{"CA1":12,"CA2":13,"Exam":55}', 'T-BEL'),
('STU-001', 'Physics', '2024/2025', 'First Term', 88, '{"CA1":14,"CA2":14,"Exam":60}', 'T-YUS'),
('STU-001', 'Chemistry', '2024/2025', 'First Term', 75, '{"CA1":10,"CA2":10,"Exam":55}', 'T-YUS'),
('STU-001', 'Biology', '2024/2025', 'First Term', 82, '{"CA1":13,"CA2":14,"Exam":55}', 'T-YUS');

-- 2. EMEKA BELLO (STU-006) - PARTIALLY GRADED ART STUDENT
INSERT INTO student_records (student_id, subject, academic_session, term, score, breakdown, teacher_id) VALUES 
('STU-006', 'Mathematics', '2024/2025', 'First Term', 45, '{"CA1":8,"CA2":7,"Exam":30}', 'T-AKI'),
('STU-006', 'English Language', '2024/2025', 'First Term', 90, '{"CA1":15,"CA2":15,"Exam":60}', 'T-BEL'),
('STU-006', 'Literature', '2024/2025', 'First Term', 88, '{"CA1":14,"CA2":14,"Exam":60}', 'T-OKO'),
('STU-006', 'Government', '2024/2025', 'First Term', 82, '{"CA1":12,"CA2":15,"Exam":55}', 'T-OKO');

-- 3. BLESSING ALABI (STU-011) - MOSTLY GRADED COMMERCIAL STUDENT
INSERT INTO student_records (student_id, subject, academic_session, term, score, breakdown, teacher_id) VALUES 
('STU-011', 'Mathematics', '2024/2025', 'First Term', 65, '{"CA1":10,"CA2":10,"Exam":45}', 'T-AKI'),
('STU-011', 'English Language', '2024/2025', 'First Term', 72, '{"CA1":12,"CA2":10,"Exam":50}', 'T-BEL'),
('STU-011', 'Financial Accounting', '2024/2025', 'First Term', 95, '{"CA1":15,"CA2":15,"Exam":65}', 'T-DAV'),
('STU-011', 'Commerce', '2024/2025', 'First Term', 88, '{"CA1":14,"CA2":14,"Exam":60}', 'T-DAV'),
('STU-011', 'Economics', '2024/2025', 'First Term', 80, '{"CA1":12,"CA2":13,"Exam":55}', 'T-DAV');
