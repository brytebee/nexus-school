const fs = require('fs');
const path = require('path');

const templates = {
  prestige: { tp: '#0a192f', ts: '#14532d' },
  azure: { tp: '#1a2d5a', ts: '#4a7fd4' },
  royal: { tp: '#0d1f4e', ts: '#b8960c' },
  monarch: { tp: '#1b3a4b', ts: '#4ecdc4' },
  sovereign: { tp: '#0d1f4e', ts: '#b8960c' },
  sterling: { tp: '#0d1f4e', ts: '#b8960c' },
  apex: { tp: '#2d1060', ts: '#b8960c' }
};

for (const [name, colors] of Object.entries(templates)) {
  const fp = path.join(__dirname, 'assets/templates', `${name}.hbs`);
  if (!fs.existsSync(fp)) continue;
  
  let content = fs.readFileSync(fp, 'utf8');
  
  // Replace case-insensitive hex codes
  const rec = (str, hex, varName) => {
    return str.replace(new RegExp(hex, 'ig'), `{{${varName}}}`);
  };

  content = rec(content, colors.tp, 'tp');
  content = rec(content, colors.ts, 'ts');

  // Specific cleanup for exact templates where gradients might look weird if we only replace 1 stop
  if (name === 'royal' || name === 'sovereign' || name === 'sterling' || name === 'apex') {
      content = rec(content, '#f5d020', 'ts'); // Replace bright gold with secondary too
  }
  if (name === 'azure') {
      content = rec(content, '#eff6ff', 'transparent'); // Make backgrounds transparent instead of light blue
      content = rec(content, '#0f172a', 'tp');
      content = rec(content, '#1e293b', 'tp');
      content = rec(content, '#3b82f6', 'ts');
  }

  // Rewrite
  fs.writeFileSync(fp, content, 'utf8');
  console.log(`Updated ${name}.hbs`);
}
