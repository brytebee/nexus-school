# 🎓 Nexus School OS: Results & Print Hub (V2 Architecture)

This document outlines the architectural overhaul for the Nigerian Academic Result system, incorporating Session/Term logic, tier-gated features, and dynamic annually-bound templates.

## 1. Core Data Model (V2 Schema)
The legacy flat structure is migrated to support temporal filtering:
- **Academic Sessions:** (e.g., 2024/2025)
- **Terms:** (First, Second, Third)
- **Promotion Tracking:** Annual results derived from 3-term aggregation.

## 2. Advanced Result Typologies
1. **Terminal Result:** Mid/End of term report for a single student across all subjects.
2. **Annual Result:** Combined session performance for promotion.
3. **Master Broadsheet:** Large-scale grid per class/subject for administrative archiving.

## 3. Tier-Gated Features
| Feature | Basic | Gold | Diamond |
| :--- | :---: | :---: | :---: |
| Flat Grade PDF | ✅ | ✅ | ✅ |
| Custom Grading Logic | ❌ | ✅ | ✅ |
| Annual Premium Templates | ❌ | ✅ | ✅ |
| Dynamic School Stamp | ❌ | ✅ | ✅ |
| Student Passport Photos | ❌ | ❌ | ✅ |
| Parent Email/SMS Sync | ❌ | ✅ | ✅ |

## 4. The Annual Template Engine
To drive yearly recurring revenue, Premium schools gain access to specialized templates that are bound to an `academic_session`. 
- **Binding:** A session-specific configuration allows schools to refresh their look every year.
- **Legacy Reprints:** Reprints of older years automatically use the template bound to that specific historical session.

## 5. Technical Implementation Notes
- **Engine:** Headless Chromium (`printToPDF`) for high-fidelity rendering.
- **Persistence:** SQLite with `WAL` mode for high-concurrency sync during result entry.
- **Gating:** License engine validates signature against public key to unlock Diamond/Gold template paths.
