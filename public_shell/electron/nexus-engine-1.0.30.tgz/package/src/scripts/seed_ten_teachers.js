const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

function seed() {
    // Dynamically resolve database path in the private_engine root
    const dbPath = path.join(__dirname, '../../nexus.sqlite');
    console.log(`Connecting to database at: ${dbPath}`);
    const db = new Database(dbPath);
    
    console.log("--- STARTING NEXUS 10-TEACHER DEMO SEEDING ---");

    // Enable WAL for performance
    db.pragma('journal_mode = WAL');

    // Clean existing tables to prevent conflicts and ensure a pure grading test state
    console.log("Cleaning old tables...");
    db.exec(`
        DELETE FROM teacher_allocations;
        DELETE FROM student_subjects;
        DELETE FROM student_records;
        DELETE FROM sync_logs;
        DELETE FROM students;
        DELETE FROM teachers;
    `);

    // 1. TEACHERS (10 teachers representing different secondary disciplines)
    const teachers = [
        { id: 'T-001', name: 'Mr. Adebayo (Mathematics)', phone: '08011111111', email: 'adebayo@nexus.com' },
        { id: 'T-002', name: 'Mrs. Chima (English)', phone: '08022222222', email: 'chima@nexus.com' },
        { id: 'T-003', name: 'Dr. Ibrahim (Physics)', phone: '08033333333', email: 'ibrahim@nexus.com' },
        { id: 'T-004', name: 'Ms. Oyenusi (Chemistry)', phone: '08044444444', email: 'oyenusi@nexus.com' },
        { id: 'T-005', name: 'Mr. Okafor (Biology)', phone: '08055555555', email: 'okafor@nexus.com' },
        { id: 'T-006', name: 'Mrs. Balogun (Government)', phone: '08066666666', email: 'balogun@nexus.com' },
        { id: 'T-007', name: 'Mr. Nwachukwu (Economics)', phone: '08077777777', email: 'nwachukwu@nexus.com' },
        { id: 'T-008', name: 'Ms. Effiong (Literature)', phone: '08088888888', email: 'effiong@nexus.com' },
        { id: 'T-009', name: 'Engr. Musa (Further Maths)', phone: '08099999999', email: 'musa@nexus.com' },
        { id: 'T-010', name: 'Mrs. Kolawole (Civic Education)', phone: '08010101010', email: 'kolawole@nexus.com' }
    ];

    const insertTeacher = db.prepare("INSERT INTO teachers (id, name, phone, email) VALUES (?, ?, ?, ?)");
    teachers.forEach(t => insertTeacher.run(t.id, t.name, t.phone, t.email));
    console.log(`Inserted ${teachers.length} teachers.`);

    // 2. TEACHER ALLOCATIONS (Teacher -> Class -> Subject)
    const allocations = [
        // Mr. Adebayo (Mathematics)
        ['T-001', 'JSS1A', 'Mathematics'],
        ['T-001', 'JSS2A', 'Mathematics'],
        ['T-001', 'JSS3A', 'Mathematics'],
        ['T-001', 'SS1A', 'Mathematics'],
        
        // Mrs. Chima (English)
        ['T-002', 'JSS1A', 'English Language'],
        ['T-002', 'JSS2A', 'English Language'],
        ['T-002', 'JSS3A', 'English Language'],
        ['T-002', 'SS1A', 'English Language'],
        ['T-002', 'SS2A', 'English Language'],

        // Dr. Ibrahim (Physics)
        ['T-003', 'SS1A', 'Physics'],
        ['T-003', 'SS2A', 'Physics'],

        // Ms. Oyenusi (Chemistry)
        ['T-004', 'SS1A', 'Chemistry'],
        ['T-004', 'SS2A', 'Chemistry'],

        // Mr. Okafor (Biology)
        ['T-005', 'SS1A', 'Biology'],
        ['T-005', 'SS2A', 'Biology'],

        // Mrs. Balogun (Government)
        ['T-006', 'SS1A', 'Government'],
        ['T-006', 'SS2A', 'Government'],

        // Mr. Nwachukwu (Economics)
        ['T-007', 'SS1A', 'Economics'],
        ['T-007', 'SS2A', 'Economics'],

        // Ms. Effiong (Literature)
        ['T-008', 'SS1A', 'Literature in English'],
        ['T-008', 'SS2A', 'Literature in English'],

        // Engr. Musa (Further Maths)
        ['T-009', 'SS1A', 'Further Mathematics'],
        ['T-009', 'SS2A', 'Further Mathematics'],

        // Mrs. Kolawole (Civic Education)
        ['T-010', 'JSS3A', 'Civic Education'],
        ['T-010', 'SS2A', 'Civic Education']
    ];

    const insertAlloc = db.prepare("INSERT INTO teacher_allocations (teacher_id, class_name, subject) VALUES (?, ?, ?)");
    allocations.forEach(a => insertAlloc.run(a[0], a[1], a[2]));
    console.log(`Inserted ${allocations.length} teacher allocations.`);

    // 3. STUDENTS (6 students per class, 5 classes = 30 students total)
    const classes = {
        'JSS1A': [
            { id: 'S-J1-01', name: 'Abel John', reg: 'REG/2026/J1/01' },
            { id: 'S-J1-02', name: 'Beatrice Audu', reg: 'REG/2026/J1/02' },
            { id: 'S-J1-03', name: 'Charles Obi', reg: 'REG/2026/J1/03' },
            { id: 'S-J1-04', name: 'Deborah Danjuma', reg: 'REG/2026/J1/04' },
            { id: 'S-J1-05', name: 'Emmanuel Femi', reg: 'REG/2026/J1/05' },
            { id: 'S-J1-06', name: 'Faith Okon', reg: 'REG/2026/J1/06' }
        ],
        'JSS2A': [
            { id: 'S-J2-01', name: 'Gabriel Ade', reg: 'REG/2026/J2/01' },
            { id: 'S-J2-02', name: 'Helen Bassey', reg: 'REG/2026/J2/02' },
            { id: 'S-J2-03', name: 'Isaac Cole', reg: 'REG/2026/J2/03' },
            { id: 'S-J2-04', name: 'Joy David', reg: 'REG/2026/J2/04' },
            { id: 'S-J2-05', name: 'Kingsley Ezenwa', reg: 'REG/2026/J2/05' },
            { id: 'S-J2-06', name: 'Linda George', reg: 'REG/2026/J2/06' }
        ],
        'JSS3A': [
            { id: 'S-J3-01', name: 'Matthew Haruna', reg: 'REG/2026/J3/01' },
            { id: 'S-J3-02', name: 'Naomi Idowu', reg: 'REG/2026/J3/02' },
            { id: 'S-J3-03', name: 'Okey Jude', reg: 'REG/2026/J3/03' },
            { id: 'S-J3-04', name: 'Patricia Kola', reg: 'REG/2026/J3/04' },
            { id: 'S-J3-05', name: 'Richard Lawal', reg: 'REG/2026/J3/05' },
            { id: 'S-J3-06', name: 'Sarah Moses', reg: 'REG/2026/J3/06' }
        ],
        'SS1A': [
            { id: 'S-S1-01', name: 'Timothy Ndu', reg: 'REG/2026/S1/01' },
            { id: 'S-S1-02', name: 'Ursula Ojo', reg: 'REG/2026/S1/02' },
            { id: 'S-S1-03', name: 'Victor Peter', reg: 'REG/2026/S1/03' },
            { id: 'S-S1-04', name: 'Winifred Quadri', reg: 'REG/2026/S1/04' },
            { id: 'S-S1-05', name: 'Xavier Rufus', reg: 'REG/2026/S1/05' },
            { id: 'S-S1-06', name: 'Yvonne Sani', reg: 'REG/2026/S1/06' }
        ],
        'SS2A': [
            { id: 'S-S2-01', name: 'Zachariah Thomas', reg: 'REG/2026/S2/01' },
            { id: 'S-S2-02', name: 'Abigail Uche', reg: 'REG/2026/S2/02' },
            { id: 'S-S2-03', name: 'Benjamin Victor', reg: 'REG/2026/S2/03' },
            { id: 'S-S2-04', name: 'Charity Williams', reg: 'REG/2026/S2/04' },
            { id: 'S-S2-05', name: 'Daniel Yusuf', reg: 'REG/2026/S2/05' },
            { id: 'S-S2-06', name: 'Elizabeth Zack', reg: 'REG/2026/S2/06' }
        ]
    };

    const classSubjects = {
        'JSS1A': ['Mathematics', 'English Language'],
        'JSS2A': ['Mathematics', 'English Language'],
        'JSS3A': ['Mathematics', 'English Language', 'Civic Education'],
        'SS1A': ['Mathematics', 'English Language', 'Physics', 'Chemistry', 'Biology', 'Government', 'Economics', 'Literature in English', 'Further Mathematics'],
        'SS2A': ['English Language', 'Physics', 'Chemistry', 'Biology', 'Government', 'Economics', 'Literature in English', 'Further Mathematics', 'Civic Education']
    };

    const insertStudent = db.prepare("INSERT INTO students (id, name, class_name, reg_no) VALUES (?, ?, ?, ?)");
    const enrollSubject = db.prepare("INSERT INTO student_subjects (student_id, subject) VALUES (?, ?)");

    let totalStudents = 0;
    let totalSubjectEnrollments = 0;

    Object.keys(classes).forEach(className => {
        const studentList = classes[className];
        const subjects = classSubjects[className];

        studentList.forEach(student => {
            // Insert Student
            insertStudent.run(student.id, student.name, className, student.reg);
            totalStudents++;

            // Enroll Student in all subjects appropriate for their class
            subjects.forEach(subject => {
                enrollSubject.run(student.id, subject);
                totalSubjectEnrollments++;
            });
        });
    });

    console.log(`Inserted ${totalStudents} students across 5 classes.`);
    console.log(`Enrolled students in ${totalSubjectEnrollments} subject slots.`);
    console.log("All student_records (grades) and sync_logs have been cleared successfully.");
    console.log("--- DATABASE POPULATION COMPLETE ---");
    db.close();

    // Graceful exit for both Node and Electron environments
    try {
        const { app } = require('electron');
        if (app) {
            app.quit();
        } else {
            process.exit(0);
        }
    } catch (e) {
        process.exit(0);
    }
}

try {
    seed();
} catch (err) {
    console.error("FATAL ERROR: Seeding failed.", err.message);
    try {
        const { app } = require('electron');
        if (app) app.quit(); else process.exit(1);
    } catch (e) {
        process.exit(1);
    }
}
