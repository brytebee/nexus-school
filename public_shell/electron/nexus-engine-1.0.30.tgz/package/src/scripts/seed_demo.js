const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

/**
 * NEXUS SCHOOL OS - DEMO SEED SCRIPT
 * This script populates the database with:
 * 1. A standard set of Teachers.
 * 2. Teacher allocations to specific Classes and Subjects.
 * 3. Students categorized into Science, Art, and Commercial tracks.
 * 4. Distinct elective enrollments per track.
 */

function seed() {
    // Database location: usually in the root of private_engine or app userData
    // For this script, we'll create/use one in the project root for the demo.
    const dbPath = path.join(__dirname, '../../nexus.sqlite');
    const db = new Database(dbPath, { verbose: console.log });
    
    console.log("--- NEXUS DEMO SEEDING START ---");

    // Enable WAL for performance
    db.pragma('journal_mode = WAL');

    // Clean existing data to ensure a fresh demo state
    db.exec(`
        DELETE FROM teacher_allocations;
        DELETE FROM student_subjects;
        DELETE FROM students;
        DELETE FROM teachers;
    `);

    // 1. TEACHERS
    const teachers = [
        { id: 'T-AKI', name: 'Dr. Akinjide (Math/Sci)', phone: '08012345678', email: 'akinjide@nexus.com' },
        { id: 'T-OKO', name: 'Mrs. Okoro (HOD Arts)', phone: '08087654321', email: 'okoro@nexus.com' },
        { id: 'T-YUS', name: 'Mr. Yusuf (Physics/Chem)', phone: '08011122233', email: 'yusuf@nexus.com' },
        { id: 'T-BEL', name: 'Ms. Bello (English)', phone: '08044455566', email: 'bello@nexus.com' },
        { id: 'T-DAV', name: 'Engr. David (Commercial)', phone: '08099900011', email: 'david@nexus.com' }
    ];

    const insertTeacher = db.prepare("INSERT INTO teachers (id, name, phone, email) VALUES (?, ?, ?, ?)");
    teachers.forEach(t => insertTeacher.run(t.id, t.name, t.phone, t.email));

    // 2. ALLOCATIONS (Teacher -> Class -> Subject)
    // This defines what the TEACHERS see on their phones.
    const allocations = [
        ['T-AKI', 'SS1A', 'Mathematics'],
        ['T-AKI', 'SS1A', 'Further Maths'],
        ['T-BEL', 'SS1A', 'English Language'],
        ['T-BEL', 'SS1A', 'Civic Education'],
        ['T-YUS', 'SS1A', 'Physics'],
        ['T-YUS', 'SS1A', 'Chemistry'],
        ['T-OKO', 'SS1A', 'Literature'],
        ['T-OKO', 'SS1A', 'Government'],
        ['T-DAV', 'SS1A', 'Financial Accounting'],
        ['T-DAV', 'SS1A', 'Commerce']
    ];

    const insertAlloc = db.prepare("INSERT INTO teacher_allocations (teacher_id, class_name, subject) VALUES (?, ?, ?)");
    allocations.forEach(a => insertAlloc.run(a[0], a[1], a[2]));

    // 3. SUBJECT TRACKS
    const commonSubjects = ['Mathematics', 'English Language', 'Civic Education'];
    const scienceSubjects = ['Physics', 'Chemistry', 'Biology', 'Further Maths'];
    const artSubjects = ['Government', 'Literature', 'CRS', 'Fine Arts'];
    const commercialSubjects = ['Financial Accounting', 'Commerce', 'Economics', 'Insurance'];

    const tracks = {
        'Science': scienceSubjects,
        'Art': artSubjects,
        'Commercial': commercialSubjects
    };

    // 4. STUDENTS
    const names = [
        'Chidi Abiola', 'Aminu Danjuma', 'Oluwatobi Okonkwo', 'Nneka Adeyemi', 'Zainab Eze',
        'Emeka Bello', 'Funke Umar', 'Uche Nwosu', 'Sade Bakare', 'Musa Igwe',
        'Blessing Alabi', 'Mustafa Keita', 'Ifeanyi Ojo', 'Fatima Sule', 'Kolawole Jide'
    ];

    const insertStudent = db.prepare("INSERT INTO students (id, name, class_name, reg_no) VALUES (?, ?, ?, ?)");
    const enrollSubject = db.prepare("INSERT INTO student_subjects (student_id, subject) VALUES (?, ?)");

    let studentIdx = 0;
    Object.keys(tracks).forEach(trackName => {
        const trackElectives = tracks[trackName];
        
        // Add 5 students per track
        for (let i = 0; i < 5; i++) {
            const studentName = names[studentIdx % names.length] + ' (' + trackName + ')';
            const studentId = 'STU-' + (studentIdx + 1).toString().padStart(3, '0');
            const regNo = 'REG/' + (2026 + i) + '/' + (studentIdx + 1).toString().padStart(2, '0');
            
            insertStudent.run(studentId, studentName, 'SS1A', regNo);

            // Enroll in Common Subjects
            commonSubjects.forEach(s => enrollSubject.run(studentId, s));
            
            // Enroll in Track Specific Subjects
            trackElectives.forEach(s => enrollSubject.run(studentId, s));

            studentIdx++;
        }
    });

    console.log(`--- SUCCESS: Seeded 15 Students across 3 Tracks ---`);
    console.log(`Run the Desktop app to verify 'SS1A' rosters.`);
    db.close();
}

try {
    seed();
} catch (err) {
    console.error("FATAL: Seeding failed.", err.message);
}
