const nodemailer = require("nodemailer");
const fs = require("fs");
const path = require("path");
const { app, BrowserWindow } = require("electron");
const database = require("./database");
const reports = require("./report-compiler");

// Helper to encrypt/decrypt SMTP passwords (AES-256-GCM)
const crypto = require("crypto");
function getEncryptionKey() {
  const fingerprint = process.versions.node + process.platform + (process.env.COMPUTERNAME || process.env.HOSTNAME || "nexus-key-seed");
  return crypto.createHash("sha256").update(fingerprint).digest();
}

function encrypt(text) {
  if (!text) return "";
  try {
    const key = getEncryptionKey();
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
    let encrypted = cipher.update(text, "utf8", "hex");
    encrypted += cipher.final("hex");
    const authTag = cipher.getAuthTag().toString("hex");
    return iv.toString("hex") + ":" + authTag + ":" + encrypted;
  } catch (_) {
    return "";
  }
}

function decrypt(text) {
  if (!text) return "";
  try {
    const key = getEncryptionKey();
    const parts = text.split(":");
    if (parts.length !== 3) return "";
    const iv = Buffer.from(parts[0], "hex");
    const authTag = Buffer.from(parts[1], "hex");
    const encrypted = parts[2];
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encrypted, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  } catch (_) {
    return "";
  }
}

// Spawns a hidden BrowserWindow and prints report cards to A4 PDF
async function compileStudentPdf(student, termConfig, baseDir, tempDir) {
  const payload = {
    termConfig,
    students: [student],
    reportType: "terminal",
    templateId: "clean_slate",
    format: "pdf",
    useSchoolColors: true
  };

  const groupHtml = reports.generateHTMLPages(payload, baseDir, tempDir);
  const safeName = student.name.replace(/[^a-zA-Z0-9]/g, "_");
  const tempHtmlPath = path.join(tempDir, `result_${safeName}.html`);
  fs.writeFileSync(tempHtmlPath, groupHtml, "utf8");

  return new Promise((resolve, reject) => {
    let hw = new BrowserWindow({
      show: false,
      width: 794,
      height: 1123,
      webPreferences: {
        offscreen: true,
        webSecurity: false
      }
    });

    hw.loadFile(tempHtmlPath);
    hw.webContents.on("did-finish-load", async () => {
      try {
        await new Promise(r => setTimeout(r, 300));
        const buf = await hw.webContents.printToPDF({
          printBackground: true,
          pageSize: "A4",
          landscape: false
        });
        hw.close();
        hw = null;
        try { fs.unlinkSync(tempHtmlPath); } catch (_) {}
        resolve(buf);
      } catch (e) {
        if (hw) { hw.close(); hw = null; }
        reject(e);
      }
    });
  });
}

// Queries full student scores, remark, domain info for reports payload builder
function getStudentFullProfile(db, studentId, term, session) {
  const student = db.prepare("SELECT * FROM students WHERE id = ?").get(studentId);
  if (!student) return null;

  // Retrieve scores and marks
  const records = db.prepare("SELECT subject, score, breakdown FROM student_records WHERE student_id = ? AND academic_session = ? AND term = ?").all(studentId, session, term);
  const explicitSubjs = db.prepare("SELECT subject FROM student_subjects WHERE student_id = ?").all(studentId).map(r => r.subject);
  const explicitSubjsSet = new Set(explicitSubjs);

  const resolvedSubjects = new Map();
  explicitSubjs.forEach(sName => {
    resolvedSubjects.set(sName, { name: sName, score: null, breakdown: {}, isRegistered: true });
  });

  records.forEach(r => {
    resolvedSubjects.set(r.subject, {
      name: r.subject,
      score: r.score,
      breakdown: (() => { try { const p = JSON.parse(r.breakdown); return (p && typeof p === 'object') ? p : {}; } catch { return {}; } })(),
      isRegistered: explicitSubjsSet.has(r.subject),
    });
  });

  student.subjects = Array.from(resolvedSubjects.values());

  // Domains & Traits
  student.domains = db.prepare("SELECT domain_type, trait, grade FROM student_domains WHERE student_id = ? AND academic_session = ? AND term = ?").all(studentId, session, term);

  // Remarks
  const remarkRow = db.prepare("SELECT remark, principal_remark FROM teacher_remarks WHERE student_id = ? AND academic_session = ? AND term = ?").get(studentId, session, term);
  student.remark = remarkRow?.remark || "";
  student.principal_remark = remarkRow?.principal_remark || "";

  // Attendance
  const attRow = db.prepare("SELECT total_days, days_attended FROM student_attendance WHERE student_id = ? AND academic_session = ? AND term = ?").get(studentId, session, term);
  student.attendance = attRow?.days_attended || null;
  student.total_days = attRow?.total_days || null;

  // Sibling fee gating
  let feeStatus = 'cleared';
  try {
    const settingsRow = db.prepare("SELECT value FROM app_settings WHERE key = 'fee_settings'").get();
    const settings = settingsRow ? JSON.parse(settingsRow.value) : {};
    if (settings.fee_gate_enabled !== false) {
      const feeRow = db.prepare("SELECT status FROM student_fees WHERE student_id = ? AND academic_session = ? AND term = ?").get(studentId, session, term);
      feeStatus = feeRow?.status ?? 'cleared';
    }
  } catch (_) {}
  student.feeStatus = feeStatus;

  return student;
}

// SMTP send client helper
async function sendMailDirect(smtpConfig, toEmail, subject, bodyHtml, pdfBuffer, pdfFilename) {
  const transporter = nodemailer.createTransport({
    host: smtpConfig.host,
    port: Number(smtpConfig.port) || 587,
    secure: Number(smtpConfig.port) === 465,
    auth: {
      user: smtpConfig.user,
      pass: decrypt(smtpConfig.pass)
    }
  });

  const mailOptions = {
    from: smtpConfig.from,
    to: toEmail,
    subject: subject,
    html: bodyHtml,
    attachments: pdfBuffer ? [
      {
        filename: pdfFilename,
        content: pdfBuffer
      }
    ] : []
  };

  return transporter.sendMail(mailOptions);
}

// Drain queue for offline emails
async function processEmailQueue() {
  const db = database.getDb();
  let smtpConfig = null;
  try {
    const smtpRow = db.prepare("SELECT value FROM app_settings WHERE key = 'smtp_config'").get();
    if (smtpRow?.value) {
      smtpConfig = JSON.parse(smtpRow.value);
    }
  } catch (_) {}

  if (!smtpConfig || !smtpConfig.host || !smtpConfig.user) return;

  const pending = db.prepare("SELECT * FROM pending_emails WHERE status = 'pending' AND attempts < 3 LIMIT 5").all();
  if (!pending.length) return;

  for (const mail of pending) {
    try {
      const pdfBuffer = mail.attachment_b64 ? Buffer.from(mail.attachment_b64, "base64") : null;
      await sendMailDirect(smtpConfig, mail.to_email, mail.subject, mail.body_html, pdfBuffer, mail.attachment_name);
      db.prepare("UPDATE pending_emails SET status = 'sent', sent_at = datetime('now') WHERE id = ?").run(mail.id);
      console.log(`[Email Dispatcher] Successfully sent queued email to ${mail.to_email}`);
    } catch (err) {
      console.error(`[Email Dispatcher] Failed sending queued email to ${mail.to_email}:`, err.message);
      db.prepare("UPDATE pending_emails SET attempts = attempts + 1 WHERE id = ?").run(mail.id);
    }
  }
}

// Core Dispatcher IPC function
async function dispatchResults({ scope, studentId, className, term, academicSession, channels }) {
  const db = database.getDb();
  
  let schoolName = "Nexus School";
  try {
    const nameRow = db.prepare("SELECT value FROM app_settings WHERE key = 'school_name'").get();
    if (nameRow?.value) schoolName = nameRow.value;
  } catch (_) {}

  let baseDir = path.join(__dirname, "..");
  if (!fs.existsSync(baseDir) || !fs.existsSync(path.join(baseDir, "assets", "templates"))) {
      try {
          baseDir = path.dirname(require.resolve("@nexus/engine"));
      } catch (_) {}
  }
  const tempDir = fs.mkdtempSync(path.join(require('os').tmpdir(), 'nexus-results-'));

  let targetStudentIds = [];
  if (scope === "student" && studentId) {
    targetStudentIds = [studentId];
  } else if (scope === "class" && className) {
    targetStudentIds = db.prepare("SELECT id FROM students WHERE UPPER(replace(class_name || COALESCE(' ' || NULLIF(class_arm, ''), ''), ' ', '')) = ?")
      .all(className.replace(/\s+/g, '').toUpperCase())
      .map(r => r.id);
  } else {
    targetStudentIds = db.prepare("SELECT id FROM students").all().map(r => r.id);
  }

  let dispatched = 0;
  let skipped = 0;
  let queued = 0;

  let smtpConfig = null;
  try {
    const smtpRow = db.prepare("SELECT value FROM app_settings WHERE key = 'smtp_config'").get();
    if (smtpRow?.value) smtpConfig = JSON.parse(smtpRow.value);
  } catch (_) {}

  let pulseBot = null;
  try {
    pulseBot = require("./pulse-bot");
  } catch (_) {
    try {
      pulseBot = require("../../public_shell/electron/pulse-bot");
    } catch (_) {}
  }

  for (const id of targetStudentIds) {
    const profile = getStudentFullProfile(db, id, term, academicSession);
    if (!profile) continue;

    // Resolve parent phone/email
    const parentPhone = profile.parent_phone || profile.phone || "";
    const parentEmail = profile.parent_email || profile.email || "";

    if (!parentPhone && !parentEmail) {
      skipped++;
      continue;
    }

    try {
      const pdfBuffer = await compileStudentPdf(profile, { term, academic_session: academicSession }, baseDir, tempDir);
      const pdfFilename = `${profile.name.replace(/\s/g, "_")}_${term.replace(/\s/g, "_")}_Report_Card.pdf`;

      // WhatsApp Channel
      if (channels.includes("whatsapp") && parentPhone && pulseBot) {
        const caption = `🎓 *Results Out*\n\nDear Parent, kindly find attached the ${term} report card for *${profile.name}* (${profile.class_name}).\n\n_${schoolName} · Powered by Nexus Pulse_`;
        try {
          await pulseBot.sendReceiptPdf(parentPhone, pdfFilename, pdfBuffer, caption);
          dispatched++;
          await new Promise(r => setTimeout(r, 2000));
        } catch (waErr) {
          console.error(`Failed to send WhatsApp result to ${parentPhone}:`, waErr.message);
          skipped++;
        }
      }

      // Email Channel
      if (channels.includes("email") && parentEmail) {
        const subject = `🎓 Report Card: ${profile.name} — ${term}`;
        const bodyHtml = `
          <div style="font-family: sans-serif; padding: 20px; line-height: 1.6;">
            <h3>Academic Report Card</h3>
            <p>Dear Parent,</p>
            <p>Kindly find attached the official report card for <strong>${profile.name}</strong> for the <strong>${term} (${academicSession})</strong> academic term.</p>
            <p>For any enquiries or feedback, please contact the school office.</p>
            <br>
            <p>Best regards,</p>
            <p><strong>${schoolName}</strong></p>
          </div>
        `;

        if (smtpConfig && smtpConfig.host) {
          try {
            await sendMailDirect(smtpConfig, parentEmail, subject, bodyHtml, pdfBuffer, pdfFilename);
            dispatched++;
          } catch (smtpErr) {
            console.warn(`SMTP direct send failed for ${parentEmail}, enqueuing:`, smtpErr.message);
            db.prepare(`
              INSERT INTO pending_emails (to_email, subject, body_html, attachment_b64, attachment_name)
              VALUES (?, ?, ?, ?, ?)
            `).run(parentEmail, subject, bodyHtml, pdfBuffer.toString("base64"), pdfFilename);
            queued++;
          }
        } else {
          db.prepare(`
            INSERT INTO pending_emails (to_email, subject, body_html, attachment_b64, attachment_name)
            VALUES (?, ?, ?, ?, ?)
          `).run(parentEmail, subject, bodyHtml, pdfBuffer.toString("base64"), pdfFilename);
          queued++;
        }
      }

    } catch (pdfCompileErr) {
      console.error(`[Result Dispatcher] PDF Compilation failed for student ${profile.name}:`, pdfCompileErr.message);
      skipped++;
    }
  }

  try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}

  return { ok: true, dispatched, skipped, queued };
}

module.exports = {
  dispatchResults,
  processEmailQueue,
  compileBatchAndUpload,
  encrypt,
  decrypt
};

// ── Cloudinary PDF Upload (for parent portal publish flow) ────────────────────

/**
 * Uploads a PDF Buffer to Cloudinary using a signed upload preset.
 * Returns the secure_url of the uploaded asset.
 *
 * Env vars required:
 *   CLOUDINARY_CLOUD_NAME
 *   CLOUDINARY_UPLOAD_PRESET  (must allow raw/pdf uploads)
 *   CLOUDINARY_API_KEY        (for signed uploads)
 *   CLOUDINARY_API_SECRET
 */
async function uploadPdfToCloudinary(pdfBuffer, publicId) {
  const cloudName    = process.env.CLOUDINARY_CLOUD_NAME;
  const uploadPreset = process.env.CLOUDINARY_UPLOAD_PRESET;
  const apiKey       = process.env.CLOUDINARY_API_KEY;
  const apiSecret    = process.env.CLOUDINARY_API_SECRET;

  if (!cloudName || !apiKey || !apiSecret) {
    throw new Error("Cloudinary credentials not configured (CLOUDINARY_CLOUD_NAME / CLOUDINARY_API_KEY / CLOUDINARY_API_SECRET).");
  }

  // Build signed upload params
  const timestamp = Math.floor(Date.now() / 1000);
  const toSign    = `public_id=${publicId}&resource_type=raw&timestamp=${timestamp}&upload_preset=${uploadPreset || ""}${apiSecret}`;
  const signature = crypto.createHash("sha1").update(toSign).digest("hex");

  const formData = new FormData();
  formData.append("file",          new Blob([pdfBuffer], { type: "application/pdf" }), `${publicId}.pdf`);
  formData.append("public_id",     publicId);
  formData.append("resource_type", "raw");
  formData.append("timestamp",     String(timestamp));
  formData.append("api_key",       apiKey);
  formData.append("signature",     signature);
  if (uploadPreset) formData.append("upload_preset", uploadPreset);

  const res = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/raw/upload`,
    { method: "POST", body: formData, signal: AbortSignal.timeout(30_000) }
  );

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Cloudinary upload failed (${res.status}): ${err}`);
  }

  const data = await res.json();
  return data.secure_url;
}

/**
 * Generates PDFs for all students who have results for the given term/session,
 * uploads each to Cloudinary, and returns:
 *   {
 *     results:   [{ studentId, pdfUrl }],
 *     parentMap: { [phone]: [studentId, ...] },
 *     skipped:   number
 *   }
 *
 * Called from the results:publish IPC handler in main.js.
 */
async function compileBatchAndUpload(db, term, academicSession, baseDir) {
  const tempDir = path.join(require("os").tmpdir(), `nexus_batch_${Date.now()}`);
  fs.mkdirSync(tempDir, { recursive: true });

  // Fetch all students who have scores for this term/session
  const rows = db.prepare(`
    SELECT DISTINCT s.id, s.name, s.parent_phone
    FROM students s
    INNER JOIN scores sc ON sc.student_id = s.id
    WHERE sc.term = ? AND sc.academic_session = ?
      AND s.parent_phone IS NOT NULL AND s.parent_phone != ''
  `).all(term, academicSession);

  const results   = [];
  const parentMap = {};
  let skipped     = 0;

  for (const row of rows) {
    try {
      const profile  = getStudentFullProfile(db, row.id, term, academicSession);
      if (!profile) { skipped++; continue; }

      const pdfBuffer = await compileStudentPdf(profile, { term, academic_session: academicSession }, baseDir, tempDir);

      // Cloudinary public_id: results/<slug>/<studentId>/<termKey>
      // We don't have slug here — caller passes it in as part of publicId prefix
      const publicId  = `nexus_results/${row.id}_${term.replace(/\s+/g, "_")}_${academicSession.replace("/", "-")}`;
      const pdfUrl    = await uploadPdfToCloudinary(pdfBuffer, publicId);

      results.push({ studentId: row.id, pdfUrl });

      // Build parentMap entry
      const phone = row.parent_phone;
      if (!parentMap[phone]) parentMap[phone] = [];
      if (!parentMap[phone].includes(row.id)) parentMap[phone].push(row.id);

    } catch (err) {
      console.error(`[compileBatchAndUpload] Failed for student ${row.id}:`, err.message);
      skipped++;
    }
  }

  try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_) {}

  return { results, parentMap, skipped, total: rows.length };
}
