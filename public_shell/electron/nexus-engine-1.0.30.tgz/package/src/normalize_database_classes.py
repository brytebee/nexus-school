import os
import sqlite3

def split_class(selected, configs):
    sorted_configs = sorted(configs, key=lambda c: len(c), reverse=True)
    for prefix in sorted_configs:
        if selected == prefix:
            return prefix, ''
        if selected.startswith(prefix + ' '):
            return prefix, selected[len(prefix) + 1:].strip()
            
    last_space = selected.rfind(' ')
    if last_space > -1:
        return selected[:last_space].strip(), selected[last_space + 1:].strip()
    return selected, ''

def main():
    db_path = os.path.expanduser('~/Library/Application Support/nexusschoolos/nexus_os.db')
    if not os.path.exists(db_path):
        print(f"Database not found at: {db_path}")
        return

    print(f"Connecting to database at: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Load all configs
        cursor.execute("SELECT hierarchy_class FROM class_configs")
        configs = [row[0] for row in cursor.fetchall()]
        print(f"Loaded {len(configs)} class configs: {configs}")

        # Fetch all students
        cursor.execute("SELECT id, class_name, class_arm FROM students")
        students = cursor.fetchall()
        print(f"Scanning {len(students)} student records...")

        updates = 0
        for stu_id, class_name, class_arm in students:
            # Only normalise students whose class_arm is NOT already set.
            # If class_arm is already populated the record is correct — skip it.
            if class_arm:
                continue

            new_name, new_arm = split_class(class_name, configs)

            if new_name != class_name or new_arm != '':
                cursor.execute(
                    "UPDATE students SET class_name = ?, class_arm = ? WHERE id = ?",
                    (new_name, new_arm, stu_id)
                )
                updates += 1

        conn.commit()
        print(f"Successfully normalized {updates} student records in SQLite database!")
    except Exception as e:
        print(f"Error during migration: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == '__main__':
    main()
