const fs = require('fs');
const path = require('path');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');

/**
 * Nexus Scholar (Document Grounding Engine)
 * A lightweight, offline-first BM25/TF-IDF text search engine.
 * Elegant, efficient, and requires no heavy ML models or internet APIs.
 */
class NexusScholar {
    constructor() {
        // We store chunks of text. A chunk is a paragraph or a few sentences.
        this.chunks = []; // { id, docName, text, tokens }
        
        // Inverted index: word -> { chunkId: frequency }
        this.invertedIndex = {};
        
        // Document frequencies: word -> number of chunks containing the word
        this.docFrequencies = {};
        
        // Average chunk length
        this.avgChunkLen = 0;
    }

    init(userDataPath) {
        this.indexPath = path.join(userDataPath, 'nexus_knowledge_index.json');
        this.loadIndex();
    }

    _tokenize(text) {
        if (!text) return [];
        // Convert to lowercase, strip punctuation, split by whitespace
        return text.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/).filter(w => w.length > 2);
    }

    async ingestDocument(fileData, originalName) {
        try {
            const ext = path.extname(originalName).toLowerCase();
            let rawText = '';
            const dataBuffer = Buffer.from(fileData);

            if (ext === '.pdf') {
                const data = await pdfParse(dataBuffer);
                rawText = data.text;
            } else if (ext === '.docx') {
                const result = await mammoth.extractRawText({ buffer: dataBuffer });
                rawText = result.value;
            } else if (ext === '.txt') {
                rawText = dataBuffer.toString('utf8');
            } else {
                throw new Error('Unsupported file format. Use PDF, DOCX, or TXT.');
            }

            // Simple semantic chunking: Split by double newlines (paragraphs)
            const paragraphs = rawText.split(/\n\s*\n/).filter(p => p.trim().length > 40);
            
            let chunksAdded = 0;
            for (const p of paragraphs) {
                const text = p.trim().replace(/\s+/g, ' ');
                if (text.length < 50) continue; // Skip very small fragments
                
                const tokens = this._tokenize(text);
                if (tokens.length < 5) continue;

                const chunkId = `chk_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
                this.chunks.push({
                    id: chunkId,
                    docName: originalName,
                    text: text,
                    tokens: tokens
                });
                chunksAdded++;
            }

            this.rebuildIndex();
            this.saveIndex();
            
            return { ok: true, message: `Indexed ${chunksAdded} chunks from ${originalName}` };
        } catch (error) {
            console.error('[Nexus Scholar] Ingestion Error:', error);
            return { ok: false, error: error.message };
        }
    }

    rebuildIndex() {
        this.invertedIndex = {};
        this.docFrequencies = {};
        
        let totalLen = 0;
        
        for (const chunk of this.chunks) {
            totalLen += chunk.tokens.length;
            
            const termFreqs = {};
            for (const token of chunk.tokens) {
                termFreqs[token] = (termFreqs[token] || 0) + 1;
            }

            for (const [token, freq] of Object.entries(termFreqs)) {
                if (!this.invertedIndex[token]) {
                    this.invertedIndex[token] = {};
                    this.docFrequencies[token] = 0;
                }
                this.invertedIndex[token][chunk.id] = freq;
                this.docFrequencies[token]++;
            }
        }
        
        this.avgChunkLen = this.chunks.length > 0 ? (totalLen / this.chunks.length) : 0;
    }

    /**
     * BM25 Scoring algorithm + Optional Gemini Generation
     */
    async query(queryString, apiKey = null, topK = 3) {
        if (!this.chunks.length) return { results: [], answer: null };
        
        const queryTokens = this._tokenize(queryString);
        if (!queryTokens.length) return { results: [], answer: null };

        const k1 = 1.2;
        const b = 0.75;
        const N = this.chunks.length;

        const scores = {};

        for (const token of queryTokens) {
            if (!this.invertedIndex[token]) continue;
            
            const df = this.docFrequencies[token];
            const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5)); // IDF component

            for (const [chunkId, freq] of Object.entries(this.invertedIndex[token])) {
                const chunk = this.chunks.find(c => c.id === chunkId);
                if (!chunk) continue;
                
                const chunkLen = chunk.tokens.length;
                // TF component with length normalization
                const tf = (freq * (k1 + 1)) / (freq + k1 * (1 - b + b * (chunkLen / this.avgChunkLen)));
                
                scores[chunkId] = (scores[chunkId] || 0) + (idf * tf);
            }
        }

        const sortedIds = Object.keys(scores).sort((x, y) => scores[y] - scores[x]);
        
        const results = sortedIds.slice(0, topK).map(id => {
            const chunk = this.chunks.find(c => c.id === id);
            return {
                docName: chunk.docName,
                text: chunk.text,
                score: scores[id]
            };
        });

        // Minimum relevance threshold
        const filteredResults = results.filter(r => r.score > 0.8);

        let answer = null;
        if (apiKey && filteredResults.length > 0) {
            try {
                const { GoogleGenAI } = require('@google/genai');
                const ai = new GoogleGenAI({ apiKey });
                const contextText = filteredResults.map((r, i) => `[Source ${i+1}: ${r.docName}]\n${r.text}`).join('\n\n');
                
                const prompt = `You are Nexus Scholar, an AI assistant for a school. Use the following document extracts to answer the user's question concisely and accurately. If the answer is not contained in the text, simply state that you don't have enough information.\n\nContext:\n${contextText}\n\nQuestion: ${queryString}`;
                
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: prompt,
                });
                answer = response.text;
            } catch (err) {
                console.error('[Nexus Scholar] Gemini API Error:', err);
                answer = `AI Synthesis Failed: ${err.message}`;
            }
        }

        return { results: filteredResults, answer };
    }

    getStats() {
        const docs = [...new Set(this.chunks.map(c => c.docName))];
        return {
            documentCount: docs.length,
            documents: docs,
            chunkCount: this.chunks.length,
            vocabSize: Object.keys(this.invertedIndex).length
        };
    }

    saveIndex() {
        if (!this.indexPath) return;
        try {
            // We only need to save the chunks array; we can rebuild the inverted index in RAM rapidly.
            fs.writeFileSync(this.indexPath, JSON.stringify({ chunks: this.chunks }));
        } catch (err) {
            console.error('[Nexus Scholar] Failed to save index:', err);
        }
    }

    loadIndex() {
        if (!this.indexPath) return;
        try {
            if (fs.existsSync(this.indexPath)) {
                const data = JSON.parse(fs.readFileSync(this.indexPath, 'utf8'));
                this.chunks = data.chunks || [];
                this.rebuildIndex();
                console.log(`[Nexus Scholar] Loaded ${this.chunks.length} chunks into memory.`);
            }
        } catch (err) {
            console.error('[Nexus Scholar] Failed to load index:', err);
        }
    }
    
    clearIndex() {
        this.chunks = [];
        this.rebuildIndex();
        this.saveIndex();
    }

    // ── Smart MCQ Extractor — Gemini primary, regex fallback ─────────────────
    async extractQuestions(fileData, fileName, maxSizeMB = 15, apiKey = null) {
        try {
            const dataBuffer = Buffer.from(fileData);
            if (dataBuffer.length > maxSizeMB * 1024 * 1024) {
                const actual = (dataBuffer.length / 1024 / 1024).toFixed(1);
                return { ok: false, error: `File too large (${actual}MB). Maximum allowed is ${maxSizeMB}MB.` };
            }
            const ext = path.extname(fileName).toLowerCase();
            let rawText = '';
            if (ext === '.pdf') {
                const data = await pdfParse(dataBuffer);
                rawText = data.text;
            } else if (ext === '.docx') {
                if (apiKey) {
                    // HTML preserves table structure (answer-key tables, option columns)
                    const result = await mammoth.convertToHtml({ buffer: dataBuffer });
                    rawText = this._htmlToText(result.value);
                } else {
                    const result = await mammoth.extractRawText({ buffer: dataBuffer });
                    rawText = result.value;
                }
            } else if (ext === '.txt') {
                rawText = dataBuffer.toString('utf8');
            } else {
                return { ok: false, error: 'Unsupported format. Use PDF, DOCX, or TXT.' };
            }
            if (!rawText || rawText.trim().length < 30) {
                return { ok: false, error: 'File appears empty or is a scanned/image PDF. Use text-based PDFs or DOCX.' };
            }

            let questions, method;
            if (apiKey) {
                questions = await this._extractWithGemini(rawText, apiKey);
                method = 'gemini';
            } else {
                questions = this._parseQuestions(rawText);
                method = 'regex';
            }
            return { ok: true, questions, totalExtracted: questions.length, fileSizeKB: Math.round(dataBuffer.length / 1024), fileName, method };
        } catch (err) {
            console.error('[Scholar] extractQuestions error:', err);
            return { ok: false, error: err.message };
        }
    }

    // Convert mammoth HTML to structured plain text, preserving table rows
    _htmlToText(html) {
        let t = html;
        t = t.replace(/<table[^>]*>/gi, '\n[TABLE]\n');
        t = t.replace(/<\/table>/gi, '\n[/TABLE]\n');
        t = t.replace(/<tr[^>]*>/gi, '');
        t = t.replace(/<\/tr>/gi, '\n');
        t = t.replace(/<t[hd][^>]*>/gi, ' | ');
        t = t.replace(/<\/t[hd]>/gi, '');
        t = t.replace(/<li[^>]*>/gi, '\n• ');
        t = t.replace(/<br\s*\/?>/gi, '\n');
        t = t.replace(/<\/p>/gi, '\n').replace(/<\/h[1-6]>/gi, '\n');
        t = t.replace(/<[^>]+>/g, '');
        t = t.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(n));
        return t.replace(/\n{3,}/g, '\n\n').replace(/ {2,}/g, ' ').trim();
    }

    // Split text into chunks on year headings to stay within Gemini token limits
    _chunkByYear(text) {
        const HEADING = /(?=(?:^|\n)(?:(?:UTME|JAMB|WAEC|NECO|NABTEB)\s*)?\d{4}\s*(?:UTME|JAMB|WAEC|NECO|NABTEB|QUESTIONS?|EXAM|MATHS?|MATHEMATICS|ECONOMICS|PHYSICS|CHEMISTRY|ENGLISH|BIOLOGY)?)/i;
        const parts = text.split(HEADING).filter(c => c.trim().length > 80);
        return parts.length > 1 ? parts : [text];
    }

    async _extractWithGemini(rawText, apiKey) {
        const { GoogleGenAI } = require('@google/genai');
        const ai = new GoogleGenAI({ apiKey });
        const chunks = this._chunkByYear(rawText);
        const allQuestions = [];

        const PROMPT_PREFIX = `You are a specialist MCQ extraction engine for West African past-question papers (JAMB/UTME/WAEC/NECO/school-internal).

Return ONLY a valid JSON array — no preamble, no markdown fences. Each item:
{"question_text":"<stem>","option_a":"<A>","option_b":"<B>","option_c":"<C>","option_d":"<D>","correct_option":"<a|b|c|d|null>","marks":1,"year":<int|null>,"topic_hint":"<tag|null>","has_diagram":<bool>,"math_heavy":<bool>}

RULES:
- Questions start with "1." "2)" "(3)" "Q1." etc.
- Normalize all option formats (A. (A) A) bullet) to option_a–option_d
- Match answer keys (from "ANSWER KEYS:" tables or inline) back to each question
- year: detect from headings like "UTME 2010" or "Mathematics 1983"
- has_diagram: true if stem mentions diagram/figure/table/graph
- math_heavy: true if stem has equations/fractions/symbols/exponents
- correct_option must be lowercase letter or null
- EXCLUDE: "which paper type" meta-questions, page headers, blank entries
- Do NOT invent or complete missing text

Extract from:\n`;

        for (const chunk of chunks) {
            if (chunk.trim().length < 100) continue;
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: PROMPT_PREFIX + chunk.substring(0, 28000),
                });
                let jsonStr = response.text.trim().replace(/^```(?:json)?\n?/i, '').replace(/\n?```$/i, '').trim();
                const extracted = JSON.parse(jsonStr);
                if (Array.isArray(extracted)) allQuestions.push(...extracted);
            } catch (e) {
                console.warn('[Scholar] Gemini chunk skipped:', e.message);
            }
        }
        return allQuestions;
    }

    // Regex fallback parser (no API key required)
    _parseQuestions(rawText) {
        const text = rawText.replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\t/g, ' ').replace(/-\n([a-z])/g, '$1');
        const lines = text.split('\n');
        const questions = [];
        const Q_START = /^(?:(?:q(?:uestion)?\s*)?(\d{1,3})[.):\s]|^\((\d{1,3})\)\s)(.+)/i;
        const OPT = /^[(\s]*([A-Da-d])[.)]\s+(.+)/;
        const ANS = /\b(?:ans(?:wer)?|correct(?:\s+option)?|key)\s*[:\s]+([A-Da-d])\b/i;
        let i = 0;
        while (i < lines.length) {
            const line = lines[i].trim();
            if (!line) { i++; continue; }
            const qMatch = line.match(Q_START);
            if (!qMatch) { i++; continue; }
            let qText = qMatch[3].trim();
            let j = i + 1;
            while (j < lines.length && j < i + 6) {
                const next = lines[j].trim();
                if (!next || OPT.test(next) || Q_START.test(next)) break;
                qText += ' ' + next; j++;
            }
            qText = qText.replace(/\s+/g, ' ').trim();
            const opts = { a: '', b: '', c: '', d: '' };
            let answerKey = '', k = j, optCount = 0;
            while (k < lines.length && k < j + 14) {
                const ol = lines[k].trim();
                if (!ol) { k++; continue; }
                const ansMatch = ol.match(ANS);
                if (ansMatch && !answerKey) { answerKey = ansMatch[1].toLowerCase(); k++; continue; }
                const optMatch = ol.match(OPT);
                if (optMatch) {
                    const letter = optMatch[1].toLowerCase();
                    let optText = optMatch[2].trim();
                    let m = k + 1;
                    while (m < lines.length && m < k + 3) {
                        const cont = lines[m].trim();
                        if (!cont || OPT.test(cont) || Q_START.test(cont) || ANS.test(cont)) break;
                        optText += ' ' + cont; m++;
                    }
                    k = m;
                    if (letter in opts) { opts[letter] = optText.trim(); optCount++; }
                    continue;
                }
                if (optCount >= 2 && Q_START.test(ol)) break;
                if (optCount === 0 && k > j + 4) break;
                k++;
            }
            if (!answerKey) {
                const block = lines.slice(i, Math.min(i + 15, lines.length)).join(' ');
                const m = block.match(ANS);
                if (m) answerKey = m[1].toLowerCase();
            }
            if (qText.length > 8 && optCount >= 2) {
                questions.push({ question_text: qText, option_a: opts.a || '—', option_b: opts.b || '—', option_c: opts.c || '—', option_d: opts.d || '—', correct_option: answerKey || 'a', marks: 1, has_diagram: false, math_heavy: false });
            }
            i = Math.max(k, j, i + 1);
        }
        return questions;
    }
}

module.exports = new NexusScholar();


