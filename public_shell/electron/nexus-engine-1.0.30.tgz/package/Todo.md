# Todo: MVP Roadmap

## Immediate Tasks
- [ ] Implement Ed25519 asymmetric key generation for Device Handshake.
- [ ] Create the JSON 'School Shard' manifest structure for customization.
- [ ] Build the mDNS local discovery service for 'Zero-Config' connection.
- [ ] Develop the Room 'Event-Sourcing' table for offline data persistence.

## Phase 1: The Handshake
- [ ] Electron IP discovery & QR generation.
- [ ] Android QR scan & Secure Socket establishment.
- [ ] Marriage protocol (Admin Approval).
