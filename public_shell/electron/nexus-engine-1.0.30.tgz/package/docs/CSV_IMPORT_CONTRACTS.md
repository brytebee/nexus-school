# CSV & File Import Contracts — Nexus School OS

**Location:** `private_engine/docs/CSV_IMPORT_CONTRACTS.md`  
**Last Updated:** 2026-07-16  
**Status:** Authoritative reference — update whenever a new import pipeline is added.

---

## Purpose

This document defines the complete contract for every file import pipeline in the
system: expected input format, required vs optional fields, which tables are
written, the IPC channel, the preload bridge method, the UI component that calls
it, and what validation (or lack of it) currently guards each handler.

It also establishes the **Standard Pattern** that every future import must follow
to ensure format mismatches are caught before any database write occurs.

---

## Import Order & Prerequisites

> [!IMPORTANT]
> Every import pipeline has a dependency. Uploading in the wrong order produces
> orphaned records, missing allocations, and silent data gaps. This section defines
> the canonical order, the prerequisite each pipeline must verify before proceeding,
> and the current implementation status of each check.

### Canonical Import Order

```
1. Identity (school profile)        no dependencies
       |
       v
2. Classes & Arms                   no dependencies (creates the class registry)
       |
       +----> 3. Teachers           requires: class_arms >= 1 row
       |
       +----> 4. Students (Roster)  requires: class_configs >= 1 row
                   |
                   +----> 5. Grades          requires: students >= 1 row
                   +----> 6. Attendance      requires: students >= 1 row
                   +----> 7. Fee Structure   requires: class_configs >= 1 row
                   +----> 8. Fee Payments    requires: students >= 1 row
                   +----> 9. Fee Adjustments requires: students >= 1 row
```

> [!NOTE]
> Teachers and Students are siblings — neither depends on the other.
> Both only require Classes to be set up first.

---

### Prerequisite Check Matrix

This table documents what each import handler **should** check before beginning,
what currently exists in the codebase, and what is missing.

| Import | Prerequisite | Check location | Current state | Severity |
|---|---|---|---|---|
| Identity | None | — | N/A | — |
| Classes | None | — | N/A | — |
| Teachers | `class_arms` >= 1 row | `Teachers.tsx handleCSVUpload` | ❌ Missing | High |
| Students | `class_configs` >= 1 row | `Students.tsx handleCSVUpload` | ❌ Missing | High |
| Grades | `students` >= 1 row | `Students.tsx handleGradesCSVUpload` | ❌ Missing | Medium |
| Attendance | `students` >= 1 row | `Students.tsx handleAttendanceCSVUpload` | ❌ Missing | Medium |
| Fee Structure | `class_configs` >= 1 row | Financial Hub upload handler | ❌ Missing | Medium |
| Fee Payments | `students` >= 1 row | Financial Hub upload handler | ❌ Missing | Medium |
| Fee Adjustments | `students` >= 1 row | Financial Hub upload handler | ❌ Missing | Medium |

**Research audit findings (confirmed 2026-07-16):**

- `handleClassesCSVUpload` (`server.js:2115`) — no identity or settings guard. The
  hierarchy read at line 2142 is a read-to-merge, not a gate.
- `handleCSVUpload` teacher branch (`server.js:320`) — blindly calls
  `upsertAllocation.run()` for whatever class strings come from the CSV. The
  `class_arms` query at line 353 resolves a form teacher arm name, it is not a gate.
- `handleCSVUpload` student branch (`server.js:382`) — `splitClass()` at line 395
  falls back to a last-space split if no class match is found; no existence check
  against `class_arms`.
- `handleGradesCSVUpload` (`server.js:1916`) — only guard is empty-string skip at
  line 1965. No `SELECT 1 FROM students WHERE id = ?` gate before inserting.
- `handleAttendanceCSVUpload` (`server.js:2046`) — only guards are empty-string and
  non-integer skips at lines 2084-2087. No student existence check.
- `students:validate-csv` (`main.js:2594`) — validates seat quota only. Does not
  inspect column headers or verify that target class names exist in `class_arms`.
- All three UI handlers (`Teachers.tsx:145`, `Students.tsx:310`, `Classes.tsx:58`)
  call their IPC channels directly with no pre-flight DB query.

---

### Available IPC Infrastructure (Already Wired)

The following preload methods are already exposed and can be called in any upload
handler to perform the prerequisite check **before** firing the import IPC:

| Preload method | IPC channel | Returns | Use for |
|---|---|---|---|
| `window.electronAPI.getDbStats()` | `get-db-stats` | `{ classes, teachers, students }` | All upstream checks — `classes` = `COUNT(*) FROM class_arms` |
| `window.electronAPI.dashboard.getSnapshot()` | `dashboard:getSnapshot` | Same fields + fee/sync data | Alternative; heavier, prefer `getDbStats` for pre-flight |
| `window.electronAPI.students.getCount()` | `students:get-count` | `{ count, cap }` | Grades / Attendance / Fee upstream check |

`get-db-stats` is the **preferred preflight call** — it is fast (three `COUNT(*)`
queries, no joins), already used by the Admin Setup Wizard gate logic, and returns
everything needed for all prerequisite checks in a single IPC round-trip.

---

### Implementation Spec — UI Pre-flight Guards

Each upload handler that has a dependency **must** call `getDbStats()` first and
abort with a user-readable Swal modal if the prerequisite is not met.

#### Pattern (copy-paste template)

```tsx
const handleXxxCSVUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0];
  e.target.value = '';
  if (!file) return;

  // Prerequisite pre-flight
  const stats = await window.electronAPI.getDbStats();
  if (stats.classes === 0) {    // change condition per pipeline
    const Swal = (window as any).Swal;
    if (Swal) {
      await Swal.fire({
        title: 'Setup Step Required',
        text: 'No classes have been set up yet. Import your Classes CSV first, then return here.',
        icon: 'info',
        background: '#0b0f19',
        color: '#fff',
        confirmButtonColor: '#f59e0b',
        confirmButtonText: 'Go to Classes'
      });
      // Optionally navigate: onNavigate('classes');
    } else {
      alert('No classes found. Import Classes first.');
    }
    return;   // block the import
  }

  setCsvStatus('Uploading and processing CSV...');
  window.electronAPI.processCSV(file.path);
};
```

#### Per-pipeline conditions and messages

| Pipeline | Abort condition | Modal title | Modal text | Button text |
|---|---|---|---|---|
| Teachers | `stats.classes === 0` | `'Setup Step Required'` | `'No classes have been set up yet. Import your Classes CSV first, then return here to import teachers.'` | `'Go to Classes'` |
| Students | `stats.classes === 0` | `'Setup Step Required'` | `'No classes have been set up yet. Import your Classes CSV before importing students.'` | `'Go to Classes'` |
| Grades | `stats.students === 0` | `'No Students Found'` | `'No student records exist yet. Import your Roster CSV first, then return to import grades.'` | `'Go to Students'` |
| Attendance | `stats.students === 0` | `'No Students Found'` | `'No student records exist yet. Import your Roster CSV first, then return to import attendance.'` | `'Go to Students'` |
| Fee Structure | `stats.classes === 0` | `'Setup Step Required'` | `'No classes have been set up yet. Import your Classes CSV before setting up fee structures.'` | `'Go to Classes'` |
| Fee Payments | `stats.students === 0` | `'No Students Found'` | `'No student records exist yet. Import your Roster CSV before recording payments.'` | `'Go to Students'` |
| Fee Adjustments | `stats.students === 0` | `'No Students Found'` | `'No student records exist yet. Import your Roster CSV before recording adjustments.'` | `'Go to Students'` |

> [!TIP]
> The `confirmButtonText` (e.g. `'Go to Classes'`) should navigate the admin to the
> correct view if the app supports programmatic navigation. Pass an `onNavigate`
> callback or dispatch a navigation action so the admin does not have to manually
> find the right section.

---

### Admin-Facing Import Guide (UX copy)

The following callout text should appear in the UI **before** the admin attempts
each import — as a persistent info box in the import section or a tooltip on the
upload button:

| Section | Callout |
|---|---|
| Classes | No prerequisites — this is the first step after setting your school identity. |
| Teachers | Classes must be imported first. Teacher allocations cannot be saved until class arms exist in the database. |
| Students | Classes must be imported first. Students are assigned to class arms during import. |
| Grades | Student Roster must be imported first. Grade records require matching Student IDs in the database. |
| Attendance | Student Roster must be imported first. Attendance records require matching Student IDs. |
| Fee Structure | Classes must be imported first. Fee structures are defined per class. |
| Fee Payments | Student Roster must be imported first. Payments are recorded against Student IDs. |
| Fee Adjustments | Student Roster must be imported first. Adjustments are applied to Student IDs. |

---

## Known Gap — Root Cause (v1.0.2 Incident)

**Symptom:** A user uploaded the **Classes CSV** through the **Roster/Teacher
import** button. The engine received it, ran the combined handler, found no
recognisable columns, imported 0 records, and returned a *success* event with
`count = 0`. The UI displayed no warning. The database was left with 62 teachers
and 331 allocations referencing arm-level classes (`JSS 1 Gold`, `SS 2 Science-
Einstein`) that were never registered in `class_arms` (0 rows).

**Root cause:** No handler performs upfront **header fingerprinting** — the step
of reading `Object.keys(rows[0])` before any loop and verifying that the required
columns for *this specific* pipeline are present. Without it, the engine silently
accepts any CSV, attempts to extract columns that do not exist, gets empty strings
everywhere, and either skips every row or, in the worst case (shared `ID` fallback
— see T1), creates garbage records in the wrong table.

---

## Import Pipeline Index

| ID | Name | File Type | Handler / Location | IPC Channel |
|---|---|---|---|---|
| T1 | Roster — Student + Teacher (Combined) | `.csv` | `handleCSVUpload` · `server.js:207` | `process-csv` |
| T2 | Classes & Arms | `.csv` | `handleClassesCSVUpload` · `server.js:2115` | `process-classes-csv` |
| T3 | Grades / Scores | `.csv` | `handleGradesCSVUpload` · `server.js:1916` | `process-grades-csv` |
| T4 | Attendance | `.csv` | `handleAttendanceCSVUpload` · `server.js:2046` | `process-attendance-csv` |
| T5 | Fee Structure | `.csv` | `handleFeeStructureCSVUpload` · `server.js:2224` | `process-fee-structure-csv` |
| T6 | Fee Payments | `.csv` | `handleFeePaymentCSVUpload` · `server.js:2266` | `process-fee-payment-csv` |
| T7 | Fee Adjustments | `.csv` | `handleFeeAdjustmentCSVUpload` · `server.js:2333` | `process-fee-adjustment-csv` |
| T8 | CBT — Bulk Questions (JSON array) | JSON payload | `cbt:bulk-import-questions` · `cbt-ipc-handlers.js:120` | `cbt:bulk-import-questions` |
| T9 | CBT — NexPack (Encrypted Question Bank) | `.nexpack` | `cbt:install-nexpack` · `cbt-ipc-handlers.js:29` | `cbt:install-nexpack` |
| T10 | CBT — External Candidates | `.csv` (renderer-parsed) | `cbt:import-external-candidates` · `cbt-ipc-handlers.js:202` | `cbt:import-external-candidates` |
| T11 | CBT — Nexus Scholar Extract (AI/PDF) | `.pdf` / `.docx` / `.txt` | `cbt:scholar-extract` · `main.js:913` | `cbt:scholar-extract` |
| T12 | License File | `.nexus` | `license:import` · `main.js:6335` | `license:import` |
| T13 | Identity / School Config | JSON (in-memory, saved via IPC) | `save-identity` · `main.js` | `save-identity` |

---

## Detailed Contracts

---

### T1 — Roster (Student + Teacher Combined)

| Field | Value |
|---|---|
| **Handler** | `handleCSVUpload()` — `private_engine/src/server.js:207` |
| **IPC channel** | `process-csv` |
| **Preload bridge** | `window.electronAPI.processCSV(filePathOrPayload)` |
| **Payload shape** | `string` (file path) OR `{ filePath, limit }` for quota-capped imports |
| **Reply event** | `csv-loaded` → `{ count, warnings[], newStudentsInserted }` |
| **Pre-import quota IPC** | `students:validate-csv` → `main.js:2594` (quota check only, not template check) |
| **UI callers** | `Students.tsx:326,370,379` · `Teachers.tsx:149` |
| **Sample files** | `public_shell/electron/Sample_Students.csv` · `Sample_Teachers.csv` |
| **Activity log event** | `ROSTER_CSV_IMPORTED` |

This is a **combined** handler. A single CSV may contain student rows, teacher
rows, or both. Each row is independently tested against two branch conditions:

#### Student branch — triggered when:
```
studentId && (firstName || lastName) && className
```

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ Required | Falls back to `ID` — see danger note |
| `First_Name` | ✅ One of First/Last | |
| `Last_Name` | ✅ One of First/Last | |
| `Class` | ✅ Required | Full class string e.g. `JSS 1 Gold`; split by `splitClass()` |
| `Parent_Name` | Optional | |
| `Parent_Email` | Optional | |
| `Parent_Phone` | Optional | E.164 recommended e.g. `2348012345678` |
| `Gender` | Optional | |
| `DOB` or `Date_of_Birth` | Optional | |
| `Registration_Number` / `Reg_No` / `Registration_No` | Optional | |
| `Subjects` | Optional | Pipe-delimited e.g. `Mathematics\|English\|Physics` |

**Writes to:** `students`, `student_subjects`

#### Teacher branch — triggered when:
```
teacherId (truthy)
```

| Column | Required | Notes |
|---|---|---|
| `Teacher_ID` | ✅ Required | Falls back to `ID` — see danger note |
| `Teacher_Name` | Optional | Defaults to Teacher_ID value if blank |
| `Teacher_Phone` | Optional | |
| `Class` | Optional | Pipe-delimited for multi-class `Teacher_ID\|JSS 1 Gold\|JSS 2 Gold` |
| `Subjects` | Optional | Pipe-delimited; defaults to `General` |
| `Class_Host` | Optional | `TRUE`/`1`/`YES` → form teacher for first class; explicit class name also accepted |

**Writes to:** `teachers`, `teacher_allocations`, `form_teachers`

> [!CAUTION]
> **Shared `ID` fallback — cross-contamination bug**
> Both `studentId` and `teacherId` fall back to `row['ID']` when their primary
> column is absent. A CSV with a generic `ID` column fires **both** branches
> simultaneously — the same row creates a student record AND a teacher record.
> Fix: remove `row['ID']` from one or both branch triggers (see Fix Specification).

#### Current validation status
- ❌ No header fingerprint check before the row loop
- ⚠️ `students:validate-csv` (`main.js:2594`) only checks quota, not template validity
- ✅ Row-level skip when both branch triggers are absent
- 🔴 Silent success (count=0, error=null) when wrong CSV is uploaded

---

### T2 — Classes & Arms

| Field | Value |
|---|---|
| **Handler** | `handleClassesCSVUpload()` — `private_engine/src/server.js:2115` |
| **IPC channel** | `process-classes-csv` |
| **Preload bridge** | `window.electronAPI.processClassesCSV(filePath)` |
| **Reply event** | `classes-csv-loaded` → `{ count, error }` |
| **UI callers** | `Classes.tsx:62` |
| **Activity log event** | `CLASSES_CSV_IMPORTED` |

| Column | Required | Notes |
|---|---|---|
| `Class_Name` or `Class` | ✅ Required | Hierarchy name e.g. `JSS 1` or `SS 2` |
| `Max_Subjects` | Optional | Integer; 0 = unlimited |
| `Pass_Mark_Override` | Optional | Integer percentage |
| `Arms` | Optional | Pipe-delimited bare arm names e.g. `Gold\|Emerald\|Ruby\|Sapphire` |

**Writes to:** `class_configs`, `class_arms`, `system_settings` (`class_hierarchy` key)

> [!IMPORTANT]
> Arms are stored as bare arm names (`Gold`, `Emerald`) NOT full class strings.
> Handler strips the class prefix automatically (e.g. `JSS 1 Gold` → `Gold`).
> Always verify `class_arms` is populated after import — teacher allocations and
> form teacher assignments depend on it. If `class_arms` is empty, arm-level
> class names exist only as orphaned strings in `teacher_allocations`.

#### Current validation status
- ❌ No header fingerprint check
- ✅ Row-level skip if `className` is empty
- ❌ No error surfaced to UI when 0 rows are processed

---

### T3 — Grades / Scores

| Field | Value |
|---|---|
| **Handler** | `handleGradesCSVUpload()` — `private_engine/src/server.js:1916` |
| **IPC channel** | `process-grades-csv` |
| **Preload bridge** | `window.electronAPI.processGradesCSV(filePath)` |
| **Reply event** | `grades-csv-loaded` → `{ count, error }` |
| **UI callers** | Not yet confirmed — check Print Hub / Grades view |
| **Activity log event** | `GRADES_CSV_IMPORTED` |

Uses **fuzzy case-insensitive column matching**: all keys are normalised with
`.toLowerCase().replace(/[^a-z0-9]/g, '')` before lookup.

| Column | Required | Notes |
|---|---|---|
| `Student_ID` or `ID` | ✅ Required | Fuzzy match: `studentid` or `id` |
| `Subject` | ✅ Required | |
| `Assessment` | Optional | Defaults to `FULL` |
| `Session` | Optional | Defaults to `2024/2025` |
| `Term` | Optional | Normalised via `normalizeTermName()`; defaults to `First Term` |
| `Score` | ✅ Required (if no breakdown columns) | Final total score |
| `*_Score` / `* Score` columns | Optional | Any column ending in `_score` or ` score` is treated as a breakdown component (e.g. `CA_Score`, `Exam Score`). Sum becomes the total. Keys are matched against active grading scale components. |

**Writes to:** `student_records` (upserts on `student_id, subject, assessment, academic_session, term`)

> [!NOTE]
> Breakdown logic is **dynamic** — any column whose normalised name ends in `score`
> (except the bare `score` column) is treated as a component. A wrongly-named
> column is silently ignored rather than rejected.

#### Current validation status
- ❌ No header fingerprint check
- ✅ Row-level skip if `studentId`, `subject`, or `assessment` are empty
- ✅ Row-level skip if no valid `score` and no breakdown columns resolve to a number

---

### T4 — Attendance

| Field | Value |
|---|---|
| **Handler** | `handleAttendanceCSVUpload()` — `private_engine/src/server.js:2046` |
| **IPC channel** | `process-attendance-csv` |
| **Preload bridge** | `window.electronAPI.processAttendanceCSV(filePath)` |
| **Reply event** | `attendance-csv-loaded` → `{ count, error }` |
| **UI callers** | Attendance view (not yet confirmed) |
| **Activity log event** | `ATTENDANCE_CSV_IMPORTED` |

Uses same **fuzzy case-insensitive key normalisation** as T3.

| Column | Required | Notes |
|---|---|---|
| `Student_ID` or `ID` | ✅ Required | Fuzzy match: `studentid` or `id` |
| `Session` | Optional | Defaults to `2024/2025` |
| `Term` | Optional | Normalised; defaults to `First Term` |
| `Total_Days` | ✅ Required | Integer |
| `Days_Attended` | ✅ Required | Integer |

**Writes to:** `student_attendance` (upserts on `student_id, academic_session, term`)

#### Current validation status
- ❌ No header fingerprint check
- ✅ Row-level skip if `studentId`, `Total_Days`, or `Days_Attended` are empty or non-numeric

---

### T5 — Fee Structure

| Field | Value |
|---|---|
| **Handler** | `handleFeeStructureCSVUpload()` — `private_engine/src/server.js:2224` |
| **IPC channel** | `process-fee-structure-csv` |
| **Preload bridge** | `window.electronAPI.processFeeStructureCSV(filePath)` |
| **Reply event** | `fee-structure-csv-loaded` → `{ count, error }` |
| **UI callers** | Financial Hub — fee structure section |
| **Activity log event** | `FEE_STRUCTURE_CSV_IMPORTED` |

| Column | Required | Notes |
|---|---|---|
| `Class_Name` | ✅ Required | Must match a class in `class_configs` |
| `Item_Name` | ✅ Required | Fee line item e.g. `Tuition`, `Books`, `Development Levy` |
| `Amount` | ✅ Required | Numeric; parsed as float |
| `Term` | Optional | Defaults to `All Terms`; part of the upsert conflict key |

**Writes to:** `fee_structures` (upserts on `class_name, item_name, term`)

#### Current validation status
- ❌ No header fingerprint check
- ✅ Row-level skip if `className` or `itemName` are empty, or `amount` is NaN

---

### T6 — Fee Payments

| Field | Value |
|---|---|
| **Handler** | `handleFeePaymentCSVUpload()` — `private_engine/src/server.js:2266` |
| **IPC channel** | `process-fee-payment-csv` |
| **Preload bridge** | `window.electronAPI.processFeePaymentCSV(filePath)` |
| **Reply event** | `fee-payment-csv-loaded` → `{ count, error }` |
| **UI callers** | Financial Hub — bulk payment upload |
| **Activity log event** | `FEE_PAYMENT_CSV_IMPORTED` |

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ Required | Must match an existing student |
| `Academic_Session` | ✅ Required | e.g. `2025/2026` |
| `Term` | ✅ Required | e.g. `First Term` |
| `Amount_Paid` | ✅ Required | Numeric > 0 |
| `Payment_Method` | Optional | `cash` / `transfer` / `pos` / `bank_teller`; invalid values silently default to `cash` |
| `Reference_Number` | Optional | |
| `Payment_Date` | Optional | ISO date `YYYY-MM-DD`; defaults to today |
| `Recorded_By` | Optional | Defaults to `Admin` |

**Writes to:** `fee_transactions`, `student_fees`

> [!WARNING]
> Invalid `Payment_Method` values (e.g. `cheque`, `online`) are silently coerced
> to `cash`. Skipped rows (bad `amount`, missing required fields) are only logged
> to console — never surfaced to the UI.

#### Current validation status
- ❌ No header fingerprint check
- ✅ Row-level skip if `studentId`, `session`, `term` are empty or `amount <= 0`
- ⚠️ Skipped rows are console-only, not returned to UI

---

### T7 — Fee Adjustments

| Field | Value |
|---|---|
| **Handler** | `handleFeeAdjustmentCSVUpload()` — `private_engine/src/server.js:2333` |
| **IPC channel** | `process-fee-adjustment-csv` |
| **Preload bridge** | `window.electronAPI.processFeeAdjustmentCSV(filePath)` |
| **Reply event** | `fee-adjustment-csv-loaded` → `{ count, error }` |
| **UI callers** | Financial Hub — adjustments / scholarships section |
| **Activity log event** | `FEE_ADJUSTMENT_CSV_IMPORTED` |

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ Required | |
| `Academic_Session` | ✅ Required | |
| `Term` | ✅ Required | |
| `Adjustment_Type` | Optional | `scholarship` / `waiver` / `owner_grant` / `bursary` / `discount`; invalid values silently default to `discount` |
| `Amount` | ✅ Required | Numeric > 0 |
| `Description` | Optional | |
| `Approved_By` | Optional | Defaults to `Admin` |

**Writes to:** `fee_adjustments`

#### Current validation status
- ❌ No header fingerprint check
- ✅ Row-level skip if `studentId`, `session`, `term` are empty or `amount <= 0`
- ⚠️ Skipped rows are console-only, not returned to UI

---

### T8 — CBT: Bulk Question Import (JSON Array)

| Field | Value |
|---|---|
| **Handler** | `cbt:bulk-import-questions` — `cbt-ipc-handlers.js:120` |
| **IPC channel** | `cbt:bulk-import-questions` (invoke) |
| **Preload bridge** | `window.electronAPI.cbt.bulkImport({ bank_id, questions })` |
| **Payload shape** | `{ bank_id: number, questions: QuestionObject[] }` — JSON, NOT a file |
| **Reply** | `{ success, count, skipped }` |
| **UI callers** | `CbtArena.tsx` — after Nexus Scholar AI extraction parses a PDF/DOCX |
| **Activity log event** | None |

This handler receives a pre-parsed **JSON array** of question objects (produced
by the Nexus Scholar AI pipeline — see T11), not a raw CSV file.

| Field | Required | Notes |
|---|---|---|
| `bank_id` | ✅ Required | ID of an existing `cbt_question_banks` row |
| `questions[].question_text` | ✅ Required | Blank stems are skipped |
| `questions[].option_a` | Optional | Defaults to `—` if blank |
| `questions[].option_b` | Optional | Defaults to `—` if blank |
| `questions[].option_c` | Optional | Defaults to `—` if blank |
| `questions[].option_d` | Optional | Defaults to `—` if blank |
| `questions[].correct_option` | Optional | Defaults to `A` if blank or null |
| `questions[].marks` | Optional | Defaults to `1` |

**Writes to:** `cbt_questions`

> [!NOTE]
> `correct_option` is silently coerced to `A` when null/blank. This means AI
> extraction failures for answer keys insert plausible-looking but wrong data
> rather than flagging the question as incomplete.

#### Current validation status
- ✅ `bank_id` and `questions` are checked implicitly (crash if missing)
- ✅ Row-level skip for empty `question_text`
- ❌ No validation that `bank_id` exists in the database before the transaction
- ❌ No detection of null `correct_option` surfaced to the UI

---

### T9 — CBT: NexPack Encrypted Question Bank

| Field | Value |
|---|---|
| **Handler** | `cbt:install-nexpack` — `cbt-ipc-handlers.js:29` |
| **IPC channel** | `cbt:install-nexpack` (invoke) |
| **Preload bridge** | `window.electronAPI.cbt.installNexPack({ filePath })` |
| **File type** | `.nexpack` — AES-256-CBC encrypted JSON, NOT a CSV |
| **Reply** | `{ success, imported, skipped, total, bank_id }` |
| **UI callers** | `CbtArena.tsx:704` — `handleNexpackUpload()` |
| **Activity log event** | None |

A `.nexpack` file is a JSON envelope with two fields:

```json
{ "iv": "<hex string>", "data": "<aes-256-cbc hex ciphertext>" }
```

Decrypted payload schema:

| Field | Required | Notes |
|---|---|---|
| `pack_id` | ✅ Required | Unique pack identifier; used to detect re-installs |
| `title` | ✅ Required | Name of the question bank |
| `subject` | ✅ Required | |
| `class_category` | ✅ Required | |
| `questions` | ✅ Required | Array; must be non-empty |
| `questions[].question_text` | ✅ Required | |
| `questions[].option_a/b/c/d` | ✅ Required | |
| `questions[].correct_option` | ✅ Required | `A`/`B`/`C`/`D` |
| `questions[].marks` | Optional | Defaults to `1` |
| `questions[].difficulty` | Optional | |
| `questions[].hash` | ✅ Required | SHA hash for dedup; duplicate hashes within the same bank are skipped |

**Writes to:** `cbt_question_banks` (creates if `pack_id` not found), `cbt_questions`

> [!IMPORTANT]
> The decryption key is hardcoded: `NEXUS_NEXPACK_SECRET_2026`. This means any
> `.nexpack` file encrypted with this key will be accepted regardless of source.
> There is no signature or origin check beyond the `iv/data` structure check.

#### Current validation status
- ✅ Checks for `iv` and `data` fields before decrypting
- ✅ Checks `pack_id` and `questions.length > 0` after decryption
- ✅ Deduplicates questions by `question_hash` within the same bank
- ❌ No origin/signature verification
- ❌ No schema validation on individual question fields

---

### T10 — CBT: External Candidates CSV

| Field | Value |
|---|---|
| **Handler (IPC)** | `cbt:import-external-candidates` — `cbt-ipc-handlers.js:202` |
| **IPC channel** | `cbt:import-external-candidates` (invoke) |
| **Preload bridge** | `window.electronAPI.cbt.importExternalCandidates(candidates[])` |
| **Parser location** | **Renderer-side** `parseCsv()` in `CbtArena.tsx:743` |
| **File type** | `.csv` |
| **Reply** | `{ success, count, ids[] }` |
| **UI callers** | `CbtArena.tsx:836` — during `handleDeployExam()` for external exam type |
| **Activity log event** | None |

> [!IMPORTANT]
> **Parsing happens in the renderer, not the engine.** The CSV is read and parsed
> in `CbtArena.tsx:743` using a custom inline parser (not `csv-parser`). The
> resulting JavaScript array of objects is then sent to the main process via IPC.
> This means the validation contract lives in the frontend, not in the engine.

The renderer parser uses **fuzzy header matching** (strips `'`, `"`, `_`, `-`,
lowercases everything):

| Column (accepted variants) | Required | Notes |
|---|---|---|
| `Name` / `First_Name` + `Last_Name` | ✅ Required | If neither present, uses `cols[0]` as name |
| `Phone` / `Guardian_Phone` | Optional | Guardian contact for token delivery |
| `Class` / `Target_Class` | Optional | Defaults to the deploy-selected class |

**Fields hardcoded by the renderer (not in CSV):**

| Field | Hardcoded value | Impact |
|---|---|---|
| `exam_year/month/day` | `new Date()` | Today |
| `subjects` | `'General'` | Not imported from CSV |

> [!NOTE]
> **Date of Birth (DOB) Resolution:**
> The CSV parser now actively looks for DOB-related columns (e.g. `dob`, `dateofbirth`, `birthdate`, or split columns like `dobyear`/`dobmonth`/`dobday`). If any candidates are missing their Date of Birth, a warning notification is displayed to the administrator showing the exact security risk of fallbacks before the deployment is executed.

**Writes to:** `cbt_external_candidates`

#### Current validation status
- ✅ Empty file check (0 candidates triggers a Swal warning, not a silent success)
- ⚠️ Headless name fallback — name falls back to cols[0] (first column value) if no recognised header
- ✅ DOB validation — parses DOB columns; warns admin on fallback usage to prevent security risks
- ❌ No validation that the target exam/batch ID exists before inserting

---

### T11 — CBT: Nexus Scholar AI Extract (PDF/DOCX/TXT → Questions)

| Field | Value |
|---|---|
| **Handler** | `cbt:scholar-extract` — `main.js:913` |
| **IPC channel** | `cbt:scholar-extract` (invoke) |
| **Preload bridge** | `window.electronAPI.cbt.scholarExtract({ fileData, fileName })` |
| **Payload shape** | `{ fileData: ArrayBuffer, fileName: string }` |
| **File types accepted** | `.pdf`, `.docx`, `.txt` |
| **Reply** | Gemini API response OR regex fallback → `{ questions[] }` |
| **UI callers** | `CbtArena.tsx:647` — `handleScholarExtract()` |
| **Activity log event** | None |
| **Depends on** | `private_engine/src/scholar.js` · Gemini API key stored in DB |

This is **not a direct import** — it is an AI-assisted extraction pipeline.
The document is uploaded, sent to Gemini (or processed by regex fallback), and
the returned question objects are then passed to T8 (`bulkImport`) to write to
the database.

Input contract (what `scholar.extractQuestions()` receives):

| Field | Required | Notes |
|---|---|---|
| `fileData` | ✅ Required | Raw file bytes as ArrayBuffer |
| `fileName` | ✅ Required | Used to detect MIME type (`.pdf`, `.docx`, `.txt`) |
| `limit` | Optional | Max questions to extract; hardcoded to `15` at call site |
| `apiKey` | Optional | Gemini API key read from DB; if absent, regex fallback is used |

Output contract (what is then passed to T8):

Each question object must conform to the T8 `QuestionObject` schema:
`{ question_text, option_a, option_b, option_c, option_d, correct_option, marks }`

> [!NOTE]
> The AI fallback path (regex) produces `correct_option = null` when no answer
> key is found in the document. These nulls are coerced to `A` by the T8 handler
> — producing silently incorrect answer keys in the database.

#### Current validation status
- ✅ File type validation at call site (only `.pdf`, `.docx`, `.txt` accepted)
- ✅ Empty extraction result triggers a Swal warning in `CbtArena.tsx`
- ⚠️ Null `correct_option` silently becomes `A` — no user warning
- ❌ No page/size limit enforced before sending to Gemini

---

### T12 — License File (`.nexus`)

| Field | Value |
|---|---|
| **Handler** | `license:import` — `main.js:6335` |
| **IPC channel** | `license:import` (invoke) |
| **Preload bridge** | `window.electronAPI.license.importFile()` |
| **File type** | `.nexus` (binary/encrypted license blob) |
| **Reply** | `{ ok: true }` on success · `{ ok: false, reason }` on failure |
| **UI callers** | Lock screen · `QuotaEnforcementModal` in `App.tsx:534` |

The handler opens a **native file picker** (dialog) filtered to `.nexus` files,
then copies the selected file to `userData/license.nexus`. There is no in-process
decryption or field-level validation — the file is accepted as-is and the app
must be relaunched to re-read the license.

| Field | Required | Notes |
|---|---|---|
| File extension | ✅ Required | Dialog filter enforces `.nexus` — user cannot select other types through the dialog |

**Writes to:** Filesystem only — `userData/license.nexus`  
**Does NOT write to SQLite.**

#### Current validation status
- ✅ File picker filter to `.nexus` extension
- ❌ No content validation — any file renamed to `.nexus` will be accepted and
  copied; the app will fail at relaunch when the license parser rejects it
- ❌ No hash/signature check at import time; error only surfaces on app restart

---

### T13 — Identity / School Config (`identity.json`)

| Field | Value |
|---|---|
| **Handler** | `save-identity` IPC handle in `main.js` |
| **IPC channel** | `save-identity` (invoke) |
| **Preload bridge** | `window.electronAPI.saveIdentity(packet)` |
| **File type** | JSON object (in-memory, persisted to `userData/identity.json`) |
| **Reply** | `{ ok: true }` |
| **UI callers** | `Settings.tsx` — school profile settings form |

This is not a file-picker import — it is an IPC call from the Settings screen
that writes the school's identity configuration to disk.

| Field | Required | Notes |
|---|---|---|
| `schoolName` | ✅ Required | Displayed in reports, WhatsApp messages, headers |
| `address` | Optional | |
| `phone` | Optional | |
| `email` | Optional | |
| `portalSlug` | Optional | URL-safe slug for the school portal; uniqueness NOT validated locally |
| `motto` | Optional | |
| `principalName` | Optional | |
| `logoBase64` | Optional | Base64-encoded school crest/logo |
| `colors` | Optional | `{ primary, secondary }` hex strings for branding |

**Writes to:** `userData/identity.json` + updates in-memory `identityPacket`  
**Does NOT write to SQLite directly** (read at startup, injected into server config).

> [!IMPORTANT]
> `portalSlug` uniqueness is checked against the remote sovereign portal API,
> NOT locally. If the network is unavailable, the slug is saved without a
> uniqueness check. A later sync may reject it. Always validate slug availability
> online before saving in production.

#### Current validation status
- ❌ No field-level schema validation in the IPC handler
- ❌ `portalSlug` uniqueness not enforced locally
- ✅ Form-level validation exists in `Settings.tsx` (client-side only)

---

## Validation Gap Summary

| ID | Template | Header/Format Check | Row Skip | UI Error on 0 | Silent Risk |
|---|---|---|---|---|---|
| T1 | Roster | ❌ None | ✅ Partial | ❌ No | 🔴 High |
| T2 | Classes | ❌ None | ✅ Partial | ❌ No | 🔴 High |
| T3 | Grades | ❌ None | ✅ Partial | ❌ No | 🟡 Medium |
| T4 | Attendance | ❌ None | ✅ Partial | ❌ No | 🟡 Medium |
| T5 | Fee Structure | ❌ None | ✅ Partial | ❌ No | 🟡 Medium |
| T6 | Fee Payments | ❌ None | ✅ Partial | ❌ No | 🟡 Medium |
| T7 | Fee Adjustments | ❌ None | ✅ Partial | ❌ No | 🟡 Medium |
| T8 | CBT Bulk Questions | ✅ Implicit | ✅ Empty stem | ✅ Yes | 🟢 Low |
| T9 | NexPack | ✅ Envelope check | ✅ Dedup hash | ✅ Yes | 🟡 Medium (no origin check) |
| T10 | External Candidates | ⚠️ Fuzzy renderer | ✅ Empty check | ✅ Yes | 🟢 Low (DOB parsed, admin warned on fallback) |
| T11 | Scholar Extract | ✅ File type | ✅ Empty check | ✅ Yes | 🟡 Medium (null answer keys) |
| T12 | License File | ⚠️ Extension only | N/A | ✅ Yes (at restart) | 🟡 Medium |
| T13 | Identity/Config | ❌ None | N/A | N/A | 🟡 Medium (slug uniqueness) |

---

## Standard Pattern for All Future Import Handlers

Every new CSV import handler **MUST** implement all five of these layers:

### Layer 1 — Header Fingerprint (Engine Side)

Check required columns **before** any database transaction opens. Place this
immediately after the `.on('end', ...)` block opens and before `db.transaction()`:

```js
// ── Layer 1: Header fingerprint ───────────────────────────────────────────
if (rows.length === 0) {
    if (callback) callback(0, 'CSV_EMPTY: The file contains no data rows.');
    return;
}

const REQUIRED_COLUMNS = ['Column_A', 'Column_B']; // exact header strings
const presentHeaders = Object.keys(rows[0]);
const missing = REQUIRED_COLUMNS.filter(
    col => !presentHeaders.some(h => h.trim() === col)
);
if (missing.length > 0) {
    if (callback) callback(0,
        `WRONG_TEMPLATE: Missing required columns: ${missing.join(', ')}. ` +
        `Found: ${presentHeaders.join(', ')}`
    );
    return;
}
// ─────────────────────────────────────────────────────────────────────────
```

### Layer 2 — Row-Level Skip with Accumulated Warnings

```js
const warnings = [];
for (const row of rows) {
    const val = (row['Required_Col'] || '').trim();
    if (!val) {
        warnings.push(`Row ${count + 1}: Missing Required_Col — skipped.`);
        continue;
    }
    // ... write to DB
    count++;
}
return { count, warnings };
```

### Layer 3 — Callback Contract

The callback signature is `callback(count, errorString, result)`:

| count | errorString | Meaning |
|---|---|---|
| 0 | `null` | Legitimate empty file |
| 0 | `'WRONG_TEMPLATE: ...'` | Wrong CSV selected |
| 0 | `'DB not initialized'` | Infrastructure failure |
| N | `null` | Full success |
| N | `null` | Partial success — check `result.warnings` |

**Never** call `callback(0, null)` when zero rows were processed due to a
missing column situation.

### Layer 4 — IPC Reply Must Surface Error to the Renderer

```js
// main.js
ipcMain.on('process-TEMPLATE-csv', (event, filePath) => {
    handleTEMPLATECSVUpload(filePath, (count, err, result) => {
        event.reply('TEMPLATE-csv-loaded', {
            count,
            error: err || null,         // ← always include
            warnings: result?.warnings || []
        });
    });
});
```

### Layer 5 — UI Listener Must Distinguish All States

```tsx
window.electronAPI.onTEMPLATECSVLoaded((result) => {
    if (result.error) {
        showErrorToast(`Import failed: ${result.error}`);
        return;
    }
    if (result.count === 0) {
        showWarningToast(
            'No rows were imported. Check that you selected the correct template.'
        );
        return;
    }
    showSuccessToast(`Imported ${result.count} row(s) successfully.`);
    if (result.warnings?.length) {
        showWarningList(result.warnings);
    }
});
```

---

## Required Column Fingerprints (Reference)

```js
const FINGERPRINTS = {
    roster_student:  ['Student_ID', 'First_Name', 'Class'],
    roster_teacher:  ['Teacher_ID', 'Teacher_Name'],
    classes:         ['Class_Name'],
    grades:          ['Student_ID', 'Subject'],        // use fuzzy normalisation
    attendance:      ['Student_ID', 'Total_Days', 'Days_Attended'], // fuzzy normalisation
    fee_structure:   ['Class_Name', 'Item_Name', 'Amount'],
    fee_payment:     ['Student_ID', 'Academic_Session', 'Term', 'Amount_Paid'],
    fee_adjustment:  ['Student_ID', 'Academic_Session', 'Term', 'Amount'],
    // T8 (bulk questions) and T9 (NexPack) are JSON/binary — no CSV fingerprint needed
    cbt_candidates:  ['Name'],  // renderer-side check; phone/class are optional
};
```

> [!NOTE]
> T3 (Grades) and T4 (Attendance) use fuzzy key normalisation. Their fingerprint
> check must normalise the same way:
> `key.trim().toLowerCase().replace(/[^a-z0-9]/g, '')`

---

## Shared `ID` Fallback — Fix Specification (T1)

```js
// CURRENT — dangerous (both branches read row['ID']):
const studentId = (row['Student_ID'] || row['ID'] || '').trim();
const teacherId = (row['Teacher_ID'] || row['ID'] || '').trim();

// CORRECT — dedicated columns only; Layer 1 fingerprint gates the file:
const studentId = (row['Student_ID'] || '').trim();
const teacherId = (row['Teacher_ID'] || '').trim();
```

The Layer 1 fingerprint check will catch any CSV that lacks both `Student_ID`
and `Teacher_ID` and return a `WRONG_TEMPLATE` error before a single row is
processed.

---

## Checklist — Adding a New Import Pipeline

Before shipping any new import handler, verify all of the following:

### Engine (server.js)
- [ ] Handler function defined with a unique name
- [ ] Exported from `module.exports` at the bottom of `server.js`
- [ ] **Layer 1**: Header fingerprint implemented (required columns checked before transaction)
- [ ] **Layer 2**: Row-level skip accumulates `warnings[]`
- [ ] **Layer 3**: Callback always sends `(count, errorString, { warnings })`

### Main Process (main.js / cbt-ipc-handlers.js)
- [ ] Handler imported from `server` (or inline for CBT handlers)
- [ ] IPC channel registered (`ipcMain.on` or `ipcMain.handle`)
- [ ] **Layer 4**: IPC reply includes `{ count, error, warnings }`

### Preload Bridge (preload.js)
- [ ] `send` method added for the new channel
- [ ] `on` listener method added for the reply event

### UI (src/views/)
- [ ] **Layer 5**: Listener distinguishes `error !== null`, `count === 0`, and success
- [ ] Error and warning messages are user-readable (not raw error strings)

### Documentation
- [ ] Column contract added to this file under a new `T{N}` section
- [ ] Fingerprint key added to the `FINGERPRINTS` reference table above
- [ ] `import Pipeline Index` table at the top of this file updated
- [ ] Template CSV sample file created or linked in the relevant UI help text
