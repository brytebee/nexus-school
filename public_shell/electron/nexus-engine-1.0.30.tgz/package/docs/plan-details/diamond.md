# 💎 Diamond Plan — Elite Intelligence
## Nexus School OS · Premium Tier

> **Primary Trigger:** PRESTIGE & GROWTH — *"The best school in the region uses this."*
> **Price:** ₦750 per student, per term

---

## What Diamond Schools Buy

Gold gives a school a voice. Diamond makes it an institution. It answers
the three biggest unsolved problems every ambitious Nigerian school owner faces:

1. *"How do I run exams without renting a cyber café?"* → CBT-as-a-Service
2. *"How do I track performance patterns, not just report cards?"* → Elite Analytics
3. *"How do I operate like a real institution?"* → Fee Ledger, Always-On, Multi-Admin

---

## Feature Set

| Feature | Description |
|---|---|
| **Fee Ledger** | Full transaction history, audit trail, multi-admin payment recording |
| **Fee Shield** | Report card watermarked/blocked for outstanding debtors |
| **Exam Clearance QR** | Scan student ID → 🟢 Cleared or 🔴 Fee outstanding |
| **CBT Engine** | Question bank, exam scheduling, browser-based exam, auto-grading |
| **CBT-as-a-Service** | Host entrance/mock exams for external candidates |
| **Live Quiz Arena** | Kahoot-style real-time classroom quiz (browser-only) |
| **Always-On Portal** | 24/7 public parent web portal via Vercel + Google Drive |
| **Nexus Scholar** | AI RAG Knowledge Base answering parent queries via Drive documents |
| **Analytics Dashboard** | At-risk flagging, subject heatmaps, grade progression |
| **Granular Attendance** | Subject-level truancy detection (Mode B) |
| **Mobile Command Center** | Admin controls Hub from their phone |
| **Nexus Notes Marketplace** | Digital storefront for teachers to sell curated study materials |
| **Skill Mastery Tracking** | International IEP-standard academic progress reports |
| **Student Pulse** | Welfare & Bullying monitor |

---

## The Nexus Local Hub

The Nexus app already runs an Express server inside itself. Diamond adds
routes to that same server. **No separate server is required.**
**One laptop = the entire school's digital infrastructure.**

### Capacity by School Size

| Size | Students | Devices | Hub Spec | Cost |
|---|---|---|---|---|
| Small | up to 300 | 50–200 | Existing admin laptop | ₦0 |
| Medium | 300–800 | 200–600 | Intel NUC / Beelink Mini-PC | ₦180k–₦320k |
| Large | 800–2000 | 600–1500 | Mini workstation, 16GB RAM | ₦400k–₦700k |
| Enterprise | 2000–5000 | 1500–4000 | Refurbished server | ₦800k–₦2m |

See `docs/requirements/hardware.md` for full setup guide.

---

## CBT-as-a-Service — The Flagship Feature

### Three Scenarios (All Must Work)

**Scenario A — Computer Lab (LAN)**
All lab PCs on the same network. Each opens a browser → `http://[hub-ip]/cbt`. No software install. Just a browser.

**Scenario B — BYOD (Laptop Hotspot or School WiFi)**
Students use personal phones/tablets. Connect to school WiFi or laptop hotspot. Open browser → same URL. Up to ~15 devices per laptop hotspot; more with a router.

**Scenario C — Offline Emergency (USB Distribution)**
No WiFi. Admin generates self-contained HTML exam files, distributes via USB. Students complete locally, submit answer files when connectivity returns.

### Feature Set

| Feature | Description |
|---|---|
| Question Bank | Questions, options, correct answer, subject, topic, difficulty, marks |
| Paper Generation | N questions selected by filter, shuffled per student (anti-cheat) |
| Exam Scheduling | Start time, duration, class. Auto-locks at end. |
| Token Access | Each student gets a 6-digit token (printed or on portal card) |
| Auto-Grading | Score computed server-side instantly on submission |
| Score Integration | CBT scores importable as CA or exam score in main records |
| Invigilation Dashboard | Live: "42/80 submitted · 12 active · 26 not started" |
| Malpractice Detection | Tab-switch events logged. Question order randomised per student. |
| CBT-as-a-Service | External candidates for entrance/mock exams (fee-per-candidate) |

### Live Quiz Arena
Kahoot-style real-time quiz. Teacher projects a question, students answer on phones. Leaderboard updates live. Browser-only — no app install. Closes deals in a 60-second demo.

---

## Financial Hub — Full Ledger

| Capability | Gold | Diamond |
|---|---|---|
| Class fee schedule + bulk billing | ✅ | ✅ |
| Scholarship / waiver adjustments | ✅ | ✅ |
| Transaction ledger (audit trail) | ❌ | ✅ |
| Multi-admin simultaneous recording | ❌ | ✅ |
| Fee Shield (block report for debtors) | ❌ | ✅ |
| Exam Clearance QR | ❌ | ✅ |
| Financial analytics | ❌ | ✅ |

---

## Always-On Parent Portal

### Architecture (₦0 Cost)
```
Hub Laptop → pulse_cache.enc → School's Google Drive
                                        ↓
                               Vercel Worker (free tier)
                                        ↓
                      Parents anywhere → browser
                      https://[school-slug].nexusschoolos.app
```

Data never stored on Vercel. Decrypted only in memory per request. Parent
enters registered phone number → sees only their own children's data.

---

## Analytics Dashboard

| Metric | Description |
|---|---|
| At-Risk Flagging | Students whose average dropped ≥20% between terms |
| Subject Heatmap | Which subjects have lowest class averages? |
| Grade Progression | Student trajectory across 3+ terms |
| Attendance-Performance | Correlation between absences and results |
| WAEC/JAMB Readiness | SS3 performance-based readiness estimate |

---

## Granular Attendance — Mode B (Diamond)

Gold: *"Is the student in school today?"* (Form teacher, daily binary)

Diamond: *"Is the student in every class?"* (Subject teacher roll call — truancy detection)

Super Admin toggle:
- **Mode A (Gold):** `daily_attendance` table
- **Mode B (Diamond):** `subject_attendance(student_id, subject_id, date, status)`

Mode B report cards show per-subject attendance: `Math: 85% | English: 72% ⚠️`

---

## Build Phases

| Phase | Features | Timeline |
|---|---|---|
| 7A | Fee Ledger, Fee Shield, At-Risk Analytics | 4–6 weeks |
| 7B | CBT Engine, Question Bank, Invigilation Dashboard | 6–10 weeks |
| 7C | Always-On Vercel Web Portal | 2 weeks (parallel) |
| 7D | Nexus Scholar (Knowledge Base + Pulse Inbox) | 3–4 weeks |
| 8 | Live Quiz Arena, WAEC Analytics, Granular Attendance | 8–12 weeks |
| 9 | Notes Marketplace, Skill Mastery, Student Pulse | Future |
| 10 | Multi-Campus, Self-Serve Onboarding | Future |

---

## Nexus Scholar — Intelligent Knowledge Base (Diamond)

### The Problem With Structured-Only Bots

The current Nexus Pulse bot handles structured, predictable queries:
Result → lookup student → format data. Attendance → same. Fees → same.

But parents ask unstructured questions every day:
- *"What are the admission requirements for JSS1?"*
- *"My child had a medical emergency — what is your protocol?"*
- *"Why are students being asked to buy a new uniform?"*
- *"When does the second term resumption date start?"*

None of these have a database column. The bot currently has no answer.

### The Solution: Grounded Document Intelligence

Nexus Scholar allows the school to upload their own institutional documents
(PDF, DOCX, TXT) into a dedicated folder on their Google Drive. The bot
reads these documents and uses them — and **only** them — to formulate answers.

**The cardinal rule: The bot never provides an answer without a reference.**
If the answer is not in the uploaded documents, the bot does not guess.
It queues the question for the admin.

---

### How It Works — Full Flow

```
┌─────────────────────────────────────────────────────────────────┐
│  STEP 1: Admin uploads documents (one-time setup, ongoing)      │
│                                                                 │
│  Nexus App → "Knowledge Base" panel in Pulse settings           │
│  Admin uploads: Admission_Guide_2025.pdf                        │
│                 School_Rules.pdf                                │
│                 Medical_Emergency_Protocol.docx                 │
│                 Uniform_Update_Notice.txt                       │
│                                                                 │
│  App extracts text → chunks into passages → creates embeddings  │
│  Uploads indexed knowledge to Google Drive:                     │
│  /Nexus School OS/[School]/Knowledge Base/nexus_index.json      │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│  STEP 2: Parent asks a question via WhatsApp                    │
│                                                                 │
│  Parent: "What is the admission requirement for JSS1?"          │
│                                                                 │
│  Vercel worker:                                                 │
│  → Embeds the question (vector)                                 │
│  → Fetches nexus_index.json from Google Drive                   │
│  → Cosine similarity search across all document passages        │
│  → Finds best matching passage(s) from Admission_Guide_2025.pdf │
└────────────────────────────┬────────────────────────────────────┘
                             │
          ┌──────────────────┴──────────────────┐
          │ Relevant passage found?              │
          │ (similarity score > threshold)       │
          ▼                                      ▼
    ┌───────────┐                         ┌──────────────┐
    │    YES    │                         │      NO      │
    └─────┬─────┘                         └──────┬───────┘
          │                                      │
          ▼                                      ▼
  Grounded answer sent             Question queued for admin
  to parent with citation:         Bot replies:
                                   "Thank you for your question.
  "Based on our *Admission         Our admin will respond to
  Guide 2025*: JSS1 applicants     you shortly. 🕐"
  must be between 10–12 years
  old and pass an entrance test.
  📄 Source: Admission Guide 2025"
```

---

### The "No Answer Without Reference" Policy

This is enforced architecturally, not by instruction alone.

The Vercel worker system prompt includes a hard constraint:
> *"You are a school information assistant. You may ONLY answer using the
> provided document excerpts. If the provided context does not contain
> the answer, respond with exactly: ESCALATE. Do not speculate.
> Do not use general knowledge."*

When the worker returns `ESCALATE`, the question goes to the admin queue.
The parent receives a warm acknowledgment. The bot has not hallucinated.

Every answer that IS provided always ends with:
`📄 Source: [Document Name]`

This citation builds parent trust. They know the bot is reading real school
documents, not making things up.

---

### Admin Response Queue — The Pulse Inbox

When the bot cannot answer, the question is not lost. It enters the
**Pulse Inbox** — a new panel in the Nexus Pulse UI.

```
Pulse Inbox                              [3 pending]

┌────────────────────────────────────────────────────┐
│ 🕐 Mrs. Adeyemi (+234 803 xxx xxxx)                │
│    "Can my daughter be excused from swimming        │
│     classes due to a medical condition?"            │
│    Received: Today, 8:42 AM · Status: ✓ Delivered  │
│    [Reply]  [Mark Resolved]                         │
├────────────────────────────────────────────────────┤
│ 🕐 Mr. Balogun (+234 706 xxx xxxx)                 │
│    "What is the procedure for late school fees?"    │
│    Received: Yesterday, 3:15 PM · Status: ✓✓ Read  │
│    [Reply]  [Mark Resolved]                         │
└────────────────────────────────────────────────────┘
```

Admin types a reply → bot sends it via WhatsApp under the school's number.
To the parent, it appears as a seamless continuation of the conversation.
The parent never knows whether they're talking to the bot or the admin.

---

### WhatsApp Message Status — Used as an Advantage

The Meta Business API returns delivery status webhooks for every sent message:
`sent` → `delivered` (✓✓) → `read` (✓✓ blue)

Nexus uses these to intelligently manage the queue:

| Status Event | What the System Does |
|---|---|
| Bot sends acknowledgment → `sent` | Queue item created, shows "Sending" |
| `delivered` (✓✓) | Shows "Parent received notification" |
| `read` (✓✓ blue) | Shows "Parent is active — respond soon" |
| Admin replies → parent `read`s | Queue item auto-marked Resolved |
| No `delivered` after 24h | Shows "Parent may have blocked or changed number" |
| No `read` after 48h | Escalation flag: "Parent may not have seen our response" |

The admin sees a live status badge next to each queued message — not just
a static list. They know exactly who is waiting and who is actively engaged.

---

### Document Types Supported

| Format | Extraction Method | Notes |
|---|---|---|
| `.pdf` | `pdf-parse` (Node.js) | Handles multi-page, text-based PDFs |
| `.docx` | `mammoth` (Node.js) | Preserves headings and paragraphs |
| `.txt` | Native `fs.readFile` | Plain text, fastest to process |
| `.md` | Native `fs.readFile` | Markdown files supported |
| Image-based PDFs | ❌ Not supported v1 | Requires OCR (future roadmap) |

---

### Admin Upload UI (Nexus App — Knowledge Base Panel)

Located in: Pulse → Cloud Bridge → Knowledge Base tab

```
Knowledge Base                          [Upload Document]

Uploaded Documents (4)
┌──────────────────────────────────────────────────────┐
│ 📄 Admission_Guide_2025.pdf         Indexed ✅        │
│    Uploaded: Apr 28, 2026 · 12 passages              │
│    [Remove]                                          │
├──────────────────────────────────────────────────────┤
│ 📄 School_Rules_and_Regulations.pdf  Indexed ✅      │
│    Uploaded: Apr 28, 2026 · 34 passages              │
│    [Remove]                                          │
├──────────────────────────────────────────────────────┤
│ 📄 Medical_Emergency_Protocol.docx   Indexed ✅      │
│    Uploaded: Apr 28, 2026 · 8 passages               │
│    [Remove]                                          │
├──────────────────────────────────────────────────────┤
│ 📝 Uniform_Update_Notice.txt         Indexed ✅      │
│    Uploaded: Today · 2 passages                      │
│    [Remove]                                          │
└──────────────────────────────────────────────────────┘

💡 Tip: Upload your school handbook, admission guide, and
   policy documents to help the bot answer parent questions
   accurately — with citations from your own documents.
```

---

## Google Drive Folder Architecture

### The Problem: Files Scattered Everywhere

Without a defined folder strategy, Nexus would create files across the
school's Google Drive in unpredictable locations:
- `nexus.sqlite.enc` somewhere in root
- `pulse_cache.json` somewhere else
- Knowledge base files wherever the admin uploaded them
- Result PDFs in a different place

This is unacceptable for a product that claims to be an
"Institutional Infrastructure Partner." The school's Drive
must reflect the same sovereignty and organisation as the system itself.

### The Solution: One Root Folder, Predictable Structure

**Every file Nexus ever touches in Google Drive lives under one root:**

```
📁 Nexus School OS/
   └── 📁 [School Name]/              ← created automatically at setup
       │
       ├── 📁 Backups/                ← encrypted DB snapshots
       │   ├── nexus_2025-01-15.enc
       │   ├── nexus_2025-03-20.enc
       │   └── nexus_2025-04-30.enc   ← latest
       │
       ├── 📁 Cache/                  ← active bot data (auto-managed)
       │   └── pulse_cache.enc        ← what the cloud worker reads
       │
       ├── 📁 Knowledge Base/         ← school-uploaded documents
       │   ├── Admission_Guide_2025.pdf
       │   ├── School_Rules.pdf
       │   ├── Medical_Emergency_Protocol.docx
       │   └── nexus_knowledge_index.json   ← auto-generated, do not edit
       │
       ├── 📁 Exports/                ← on-demand generated reports
       │   ├── 📁 Fee Reports/
       │   │   └── Fee_Summary_Term3_2025.pdf
       │   └── 📁 Attendance Reports/
       │       └── Attendance_JSS1_Term3.pdf
       │
       └── 📁 Pulse Inbox Archive/    ← resolved admin Q&A (audit log)
           └── inbox_2025-04-30.json
```

### Why This Approach Is Correct

**1. Single access grant:** When the school authorises Nexus (OAuth), they
grant access to the `Nexus School OS` folder only — not their entire Drive.
This is a hard privacy boundary. If the school ever revokes access, we lose
access to exactly one folder. Nothing else in their Drive is touched.

**2. Auditable:** The school principal can open Google Drive, navigate to
`Nexus School OS → [School Name]` and see exactly what Nexus is storing.
No hidden files. Full transparency.

**3. Recovery-friendly:** If the admin laptop dies, they can restore by
pointing a new installation at the same Google account. The folder structure
is self-explanatory. The latest `.enc` backup file is always in `Backups/`.

**4. Vercel worker clarity:** The cloud worker knows exactly where to look:
- Bot data: `/Nexus School OS/[School]/Cache/pulse_cache.enc`
- Knowledge index: `/Nexus School OS/[School]/Knowledge Base/nexus_knowledge_index.json`
- Inbox: `/Nexus School OS/[School]/Pulse Inbox Archive/`

No guessing. No searching. Every path is deterministic.

**5. Multi-tenant safe:** If a developer manages multiple schools' Google
accounts, each school's data is cleanly separated under their own
`[School Name]` subfolder. Cross-contamination is architecturally impossible.

### Implementation Note

The `pulse-exporter.js` module needs to be updated to:
1. Check if `Nexus School OS/[School Name]` folder exists on first run
2. Create the full folder tree if it doesn't (one-time setup per school)
3. Cache all folder IDs in `app_settings` so subsequent operations
   use the folder IDs directly (no searching by name, which is slow)
4. All existing file write operations updated to target the correct subfolder

---

## Development Strategy (What to Build vs. What to Skip)

With 20 hours to build for production sales, Diamond features must be ruthlessly prioritised based on the Pitch Document's ROI.

| Feature | Pitch Alignment | Action for 20-Hour Sprint |
|---|---|---|
| **Fee Ledger & Shield** | "The Revenue Engine" | **BUILD.** Critical for Diamond close. |
| **CBT Engine (Full)** | "Monetize Idle Assets" | **BUILD.** The most visible Diamond feature. |
| **Always-On Portal** | "Prestige & Engagement" | **BUILD.** Essential Vercel worker. |
| **Nexus Scholar & Inbox** | Grounded Bot Intelligence | **BUILD.** Required to stop AI hallucinations. |
| **Live Quiz Arena** | "Interactive Engagement" | **SKIP.** Very cool, but takes days to build real-time socket sync. Defer to V2. |
| **Analytics Dashboard** | "Elite Intelligence" | **SKIP.** Schools need data first before analytics matter. Defer to V2. |
| **Nexus Notes Marketplace** | "Passive Income" | **SKIP.** High effort (payment gateways, PDF rendering). Defer to V2. |
| **Granular Attendance** | "Truancy Detection" | **SKIP.** Too complex for initial data models. |

---

## The Diamond Pitch

*"Sir, I want to show you something."*
[Opens browser on a student's phone, connects to school WiFi]
[An exam interface appears]

*"Your SS3 students can write their JSSCE mock exam right now, on their
phones, in this room. Results are ready the moment the last student submits.
The Hub grades 500 scripts in 3 seconds. Your Google Drive has a backup of
everything before they even leave the exam hall.*

*And when a parent WhatsApps at 10 PM asking about the admission requirements,
the bot reads your own school's admission guide and replies — with a citation.
If it doesn't know the answer, you wake up to an inbox. The parent already
received an acknowledgment. Nothing falls through the cracks."*

That closes Diamond.

---

*Nexus School OS — Diamond Tier Plan Details v1.2 · April 2026*
*Aligned with Pitch Document & 20-Hour Sprint Strategy*

