# 🥇 Gold Plan — Connected Campus
## Nexus School OS · Complete Strategy & Engineering Analysis

> **Primary Trigger:** ENGAGEMENT — *"Your school is always in their pocket."*
> **Price:** ₦500 per student, per term

---

## Part 1: Strategic Vision

### What Gold Promises (Pitch Commitments)

| # | Feature | Commercial Value |
|---|---|---|
| G1 | **Nexus Pulse (WhatsApp Bot)** | Automated fee recovery + parent Q&A |
| G2 | **Verified Student Public Profiles** | Brand differentiation, word-of-mouth |
| G3 | **Parental Access Portal** | Live results, attendance, fees on parent's phone |
| G4 | **Digital Assignment Hub** | Teacher → student task pipeline |
| G5 | **Class Attendance Module** | Digital register, auto-reports, Guardian Shield |

### What Actually Sells Gold

The sales trigger is not the feature list. It is the emotional outcome:
> *"Your school is always in their pocket."*

**G1 (Nexus Pulse)** is the most commercially powerful Gold feature:
- Quantified ROI: ₦3.6M–₦4.2M recovered per term for a 300-student school
- Built-in upsell justification: *"Gold pays for itself in the first term"*
- Connects to Diamond: Pulse reads the Fee Ledger (Diamond), creating a natural upgrade path
- Cost to school: ₦0 for the Office-Hours local bot. They bring their own WhatsApp number.

**G3 (Parental Portal)** is the #2 conversion driver — parents immediately notice it.

**G5 (Attendance)** is the hidden workhorse — feeds G1, G3, and Diamond's At-Risk flagging.

**G4 + G2** are prestige features. They differentiate the school's brand but don't directly
recover revenue. Build them last within Gold.

---

## Part 2: Dependency Map

```
G5 Attendance ──────────────────────────────────────────────┐
                                                             ▼
G1 Pulse ─── requires ─── Fee Data (student_fees table)   G3 Portal
                       └── Student/Attendance Data ──────────┘
                                                             │
G2 Profiles ─── requires ─── G3 Portal (public URL base)   │
                          └── G5 Attendance data             │
                                                             ▼
G4 Assignments ─── requires ─── G3 Portal (submission UI)
                             └── Teacher Allocation (✅ done)
```

**Key insight:** G3 (Portal) is a **platform**, not just a feature. G2 and G4
live inside it. Build G3 right and G2/G4 are simply routes on it.

---

## Part 3: Build Phases

### GOLD PHASE A — Foundation (Invisible Infrastructure)
> **Goal:** Lay the data + network layer every other Gold feature depends on.

#### A1 — Class Attendance Module (G5)

**Implementation:** Android Teacher Daily Tap (recommended over manual or QR scan).
Teachers open the Nexus app, select their class, tap absent/late students.
Syncs when in range. Fallback: Admin manual entry on desktop.

**What was built:**
- `daily_attendance` table: `student_id, class_name, date, status, academic_session, term`
- `student_attendance` aggregate: `student_id, session, term, total_days, days_attended`
- Desktop: class-by-class attendance register, history view
- Print Hub: injects attendance summary into report cards (Silver read, Gold write)
- Android: daily tap UI

**Known Issues to Fix:**
1. **N+1 Query Bug** — `save-daily-attendance` runs one COUNT per student to
   recompute aggregates. For 40 students this is 80+ queries. Fix: single
   `GROUP BY student_id` after bulk insert.
2. **Guardian Shield alerts only fire on tablet sync**, not desktop save.
   Admin-entered absences never trigger parent WhatsApp alerts.
3. **No school calendar** — weekends count as school days in the attendance %.
   Add a `school_holidays` exclusion table.

#### A2 — Parent Data Schema & Network Broadcaster
- Express route namespace `/parent/*` — authenticated, read-only
- OTP-based parent auth (phone number → WhatsApp PIN delivery)
- Network broadcaster: Hub IP shown as QR on admin screen
- Parent QR: admin prints/displays a QR → one scan opens the portal

---

### GOLD PHASE B — The Revenue Engine (Nexus Pulse)

#### B1 — WhatsApp Bot: Office-Hours Mode (Local, Free)
- `whatsapp-web.js` embedded in Electron. Admin scans QR to link the school phone.
- Bot answers: RESULT, ATTENDANCE, FEES queries via local SQLite
- 4-strategy phone number resolution (handles LID/device IDs correctly)
- JID-to-phone resolution cache (eliminates 200ms–5s delay on repeat messages)
- Session management: 5-minute TTL (should be configurable, 15–30 min preferred)
- Status: ✅ Core bot works. Start Bot button is now wired.

**Known Issues Fixed This Session:**
- `btn-start-pulse` had zero event listeners (now fully wired in pulse-ui.js)
- Duplicate `id="view-pulse"` (Guardian Shield renamed to `id="view-guardian"`)
- `sendFeeStatus()` read from stale `students.fee_status` column — now queries
  `student_fees` table with real balance arithmetic (billed / paid / balance)

#### B2 — WhatsApp Bot: Always-On Mode (Cloud Bridge, Diamond tier)
- Desktop exports encrypted `pulse_cache.enc` to school's Google Drive
- Vercel cloud worker reads cache, decrypts with school's Pulse Security Key
- Answers parents 24/7 via Meta WhatsApp Business API
- School's data never stored on Vercel — lives only in their own Google Drive

#### B3 — Fee Structure (Production Blocker — Not Yet Built)
**Critical gap:** The system requires manual `total_billed` entry per student.
A school with 300 students must enter 300 rows per term (900/year).

**What's needed:**
- `fee_structures` table: class group → fee components → total
- "Apply Schedule" bulk billing: admin sets schedule once, one click bills all students
- Fee components: Tuition + Levy + PTA shown individually on WhatsApp and portal
- `fee_adjustments` table: per-student overrides for scholarships, grants, bursaries
  (separate from base fee to preserve aggregate billing accuracy)

#### B4 — Message Queue for Bulk WhatsApp Sends
All bulk outbound messages (fee reminders, Guardian Shield alerts, weekly digest)
must go through a queue. Sending 900 messages in a tight loop freezes the PC
and risks WhatsApp rate-limiting/banning.

**Queue design:**
- `pending_pulse_messages` table in SQLite (populated in one fast bulk insert)
- Worker dequeues one message every 3–4 seconds via `setInterval` in main process
- 900 students × 3s = 45 minutes. Comfortable, WhatsApp-safe, UI stays responsive
- Progress shown to admin: "Sending fee reminders: 247 / 900"
- If app closes mid-send, queue resumes from last unsent row on next launch
- Automated reminder dates trigger this same queue at the configured date/time

---

### GOLD PHASE C — The Parent Portal (Sovereign Portal)

#### Architecture
- Express server in Electron (port 3002)
- Server-side rendered HTML — works on any cheap Android phone browser
- Parent authenticates via OTP sent to their registered WhatsApp number

#### Parent Dashboard Shows:
```
[School Logo] [School Name]
Welcome, Parent of CHUKWUDI OKONKWO

📊 Latest Results — Third Term · 2024/2025
   Average: 78.4% · Position: 3rd of 42

📅 Attendance
   Days Present: 72/80 (90%)

💰 Fee Status
   Billed: ₦45,000 · Paid: ₦20,000 · Balance: ₦25,000

📋 Assignments Due (Gold D feature)
   Mathematics: Submit by Friday
```

#### Known Issues:
1. **OTP fails silently when bot is offline** — API returns `ok: true` but
   parent never receives the message. Must show a clear error: "WhatsApp
   delivery unavailable — contact the school reception."
2. **Portal is LAN-only** — parents must be on school WiFi. Gold schools
   can use **Cloudflare Tunnel** (free, zero infrastructure) to expose the
   portal via a public URL whenever the laptop is online.
3. **No term selector** — portal only shows current term. Previous terms
   exist in the DB but no UI to select them.
4. **No OTP rate limiting** — 5 attempts per IP per hour minimum needed.

#### Online Access Strategy (Gold)
For Gold schools without the Diamond Always-On cloud portal, Cloudflare Tunnel
provides free online access:
- Admin runs `cloudflared` on the hub laptop (one-time setup, single binary)
- Cloudflare provides a public URL: `https://nexus-graceacademy.trycloudflare.com`
- Parents anywhere in Nigeria open that URL — they see the portal
- When the laptop is off, the URL is unreachable (expected, Gold tier)
- Cost: ₦0

---

### GOLD PHASE D — Prestige Features

#### D1 — Digital Assignment Hub
- Teacher creates assignment on desktop: class, due date, instructions
- Parent sees pending assignments on portal
- Student marks done on Android app (or teacher confirms)

#### D2 — Verified Student Public Profiles
- Public URL: `nexusschoolos.com/profile/[hash]`
- School-curated academic highlights, term-by-term average trend
- Shareable by parents on WhatsApp (marketing flywheel for Nexus)
- Only Gold feature requiring Nexus cloud infrastructure (Vercel/Render, free tier)

---

## Part 4: Guardian Shield

Guardian Shield is the automated parent communication system built on Nexus Pulse.

| Feature | Status | Fix Required |
|---|---|---|
| Morning Briefing (9 AM to principal) | ✅ Works if bot is started | Add auto-start option |
| Attendance Safety Net alerts | ⚠️ Tablet-sync only | Emit from desktop save too |
| Weekly Academic Digest (Friday 4 PM) | ❌ Stub (logs only) | Implement with queue |
| Financial Recovery Pulse | ✅ Works | Add queue for 900+ schools |
| Fee Reminder Dates | ✅ Stored | Scheduler must read & act on them |
| "Shield Active" badge | ❌ Static HTML | Wire to real bot running state |

**Critical:** All Guardian Shield features fail silently if the bot is not running.
An auto-start option (persisted to `app_settings`) fixes this.

---

## Part 5: Admin Authentication & Lock Screen (The Vault)

**From Master Plan Phase 9:** The system requires multi-admin authentication to track who recorded which fee or attendance entry.

**The Feature:**
- A simple lock screen on boot: Select Admin → Enter PIN.
- Idle timeout lock (like the Android app).
- **Developer Bypass:** To prevent you from typing passwords 100 times a day during testing, this will respect a `.env` flag: `DEV_AUTO_LOGIN=true`.

---

## Part 6: Development Strategy (What to Build vs. What to Skip)

With a 20-hour sprint before Monday's sales meetings, we must ruthlessly prioritize what generates revenue and what closes deals.

| Feature | Pitch Alignment | Action for 20-Hour Sprint |
|---|---|---|
| **Fee Structure & Bulk Billing** | Resolves "Hidden Cost of Manual Processing" | **BUILD.** Critical blocker for Pulse. |
| **WhatsApp Message Queue** | Powers "Automated Fee Recovery" | **BUILD.** Without this, Pulse crashes the PC. |
| **Local Parent Portal** | Delivers "Engagement" | **BUILD.** Very visual demo tool. |
| **Admin Authentication** | Delivers "Zero-Knowledge Vault" | **BUILD.** (With `.env` bypass for dev speed). |
| **Digital Assignment Hub** | "Prestige Feature" | **SKIP.** Teachers won't use this on Day 1. Defer to V2. |
| **Student Public Profiles** | "Marketing Flywheel" | **SKIP.** Requires cloud infrastructure setup. High effort, zero day-1 revenue. Defer to V2. |
| **Cloudflare Tunnel (Online Portal)** | "Always-On" workaround | **SKIP.** We are building the real Vercel Always-On for Diamond. Gold remains strict LAN-only for the demo to force the Diamond upsell. |

---

## Part 7: Demo Conversion Moments

| Phase | Demo Line | Emotional Trigger |
|---|---|---|
| **A** | *"Your attendance is now digital. It auto-appears on every report card."* | Relief |
| **B** | *"This bot will recover ₦7 million of outstanding fees this term. Without your admin making a single call."* | Greed (positive) |
| **C** | *"Open this link on your phone. That's what every parent sees — live. Right now. From your school's WiFi."* | Pride |

---

*Nexus School OS — Gold Tier Plan Details v2.1 (Aligned with Master Pitch)*
