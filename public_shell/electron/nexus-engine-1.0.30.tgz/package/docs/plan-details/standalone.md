# 📦 Standalone Pack — Admin Extension Product
## Nexus School OS · One-Time Purchase

> **Origin:** Field-tested. Designed from direct school demo and marketing experience.
> **Commercial Model:** One-time flat fee (no recurring subscription)
> **Internal Tier ID:** `"Standalone"` (never confused with `"Silver"` in code)

---

## Why This Exists

During active school demos, a recurring friction point emerged: school administrators respond
excellently to the product but baulk at the concept of termly subscription payments. They are
familiar with buying software once, owning it, and using it until it stops working.

The Standalone Pack meets schools at this expectation — giving them a genuinely powerful
result management system at a flat one-time price, while keeping the door open for upgrade
to a subscription plan as trust is built.

---

## What the Standalone Pack Is NOT

- ❌ It is **not the Silver plan**. The Silver plan (termly payments) has **unlimited mobile devices** and full Silver-tier feature access. Silver plan code paths are completely untouched.
- ❌ It is not a trial or demo mode.
- ❌ It does not expire.

---

## What Schools Get

### ✅ Included Features

| Feature | Detail |
|---|---|
| **Student Database** | Add, edit, and view all enrolled students |
| **Teacher Directory** | Manage teacher profiles and allocations |
| **Result Studio** | Scope locked to "Entire School" — no per-class or per-subject filtering |
| **Print Hub** | Clean Slate + class_photo templates. No attendance section. No portal section. |
| **Sync Hub** | Up to 2 mobile devices in Admin Extension mode |
| **Mobile Grade Entry** | Admin or assistant enters grades for any class from the mobile device |
| **Student Photo on Report Cards** | via the `class_photo` template |

### ❌ Locked Features

| Feature | Available On |
|---|---|
| Daily Attendance Register (mobile) | Silver Plan (termly) |
| WhatsApp Bot (Nexus Pulse) | Gold Plan |
| Parent Portal | Gold Plan |
| Fee Tracking & Financial Hub | Gold Plan |
| Nexus Scholar (AI) | Diamond Plan |
| CBT Arena | Diamond Plan |
| Unlimited Mobile Devices | Gold Plan |
| Per-class / Per-teacher Result Scope | Silver Plan (termly) |

---

## The Admin Extension Mobile Model

This is the most important architectural difference between the Standalone Pack and all
subscription tiers.

### On Subscription Plans (Silver → Diamond)
- Mobile devices are **teacher-tied**: each phone is married to a specific teacher.
- The teacher's phone only shows their assigned classes and subjects.
- Grades are attributed to the teacher by name.

### On the Standalone Pack
- Mobile devices are **school-tied**: each phone is married to the school hub directly.
- The phone shows **all classes and all subjects** across the entire school.
- The user (admin or assistant) can navigate between classes freely — like a portable
  version of the admin desktop, but limited to grade entry.
- Grades are attributed to `"Admin"` with device metadata in the activity log.
- There is **no teacher picker** in the Sync Hub for this tier — a single "Generate Admin QR"
  button replaces it.

### Why This Works for Small Schools
Most small schools (the primary Standalone Pack target) have a single admin, one or two
assistants, and a principal. They don't have 15 teachers each with personal Android phones.
The Standalone Pack lets the admin's phone (or a shared assistant phone) act as a mobile
grade-entry terminal for the entire school — fast, offline, and practical.

---

## Device Limit and Upgrade Messaging

When a 3rd mobile device attempts to connect:

```
403 Forbidden
{
  "error": "DEVICE_LIMIT_REACHED",
  "message": "Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."
}
```

The same message appears in the Android app Sync Hub:
```
📲 Device Slots: 2 / 2 used
Migrate to a payment plan to enjoy the full features of Nexus School OS for your school.
[Contact Us →]
```

---

## The class_photo Report Template

The Standalone Pack introduces the `class_photo` report card template — a companion to the
existing `clean_slate` template that renders each student's passport photograph alongside
their result data.

This template is available to:
- ✅ **Standalone Pack** — as a primary selling point
- ✅ **Silver Plan (termly)** — extended as a value-add to subscription schools
- ✅ **Gold / Diamond** — naturally included

The photograph data flows through the existing `photo_base64` column in the `students` table
(already present in the schema as of V1). The Android Add Student form already has a camera
capture UI — it is currently gated behind a `student_photo` module flag. This gate will be
set to `true` for both Standalone and Silver+ tiers.

> **Schema confirmation:** `students.photo TEXT DEFAULT NULL` — exists in `private_engine/src/database.js`.
> **Android confirmation:** `photo_base64` is persisted locally in Room already. The sync event currently omits the photo from the Hub payload (see `SyncEventsHelper.kt` kdoc: *"Hub photo sync is a Phase 5 concern"*). This must be resolved as part of Standalone Pack implementation.

---

## Go-To-Market Strategies

### Strategy 1 — Loss-Leader Demo Close
Price aggressively (₦25,000 – ₦50,000 one-time). Pitch during demos:
> *"You can take this home today for ₦X. You own it, forever. But once you see what it does with just 2 devices on it, you'll understand why schools on the full plan get 10x the value."*

Schools that buy are now customers — psychologically far easier to upsell than cold prospects.

### Strategy 2 — Trial-to-Plan Pipeline
Set an agreed review date 3 months after handover. Visit or call to review their experience.
Use their own data (grades compiled, time saved, parents impressed) as the upsell pitch.

### Strategy 3 — Bundle with Onboarding Service
> *₦50,000 software + ₦30,000 onboarding (CSV import, teacher setup, first-term reports)*

Raises cash per sale without inflating the perceived software price.

### Strategy 4 — Referral Incentive
Every school that buys a Standalone Pack and refers another school gets their referral credited
toward upgrading to a subscription plan.

### Strategy 5 — Subscription Objection Reframe
Offer a ₦0 first month on the Silver plan for schools that won't commit. The Standalone Pack
becomes the fallback, not the primary offer.

---

## Implementation Notes

See `private_engine/docs/tasks/version2_dev.md` — Initiatives 9 and 10 for full technical plan.

See also the implementation plan artifact for the Standalone Pack build sequence.

---

*Nexus School OS — Standalone Pack Product Spec v1.0*
*Origin: Field demo experience — June 2026*
