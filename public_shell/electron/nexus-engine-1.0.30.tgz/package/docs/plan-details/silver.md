# 🥈 Silver Plan — Result Pro
## Nexus School OS · Foundation Tier

> **Primary Trigger:** RELIEF — *"No more manual calculations at midnight."*
> **Price:** ₦250 per student, per term

---

## What Silver Promises

Silver is the foundation every school needs before they can want anything else.
It answers the single most painful question a Nigerian school admin asks every
term-end: *"How do I produce 300 report cards without making a single calculation error?"*

Silver schools get a complete, professional grading and result management system.
No WhatsApp bots. No parent portals. Just accurate, beautifully printed report cards.

---

## Feature Set

### ✅ Core Grading Engine
- Grade entry via Android app (teacher enters scores in classroom, offline)
- Automatic weighted average calculation (CA + Exam split configured by admin)
- Class positions computed automatically, ties handled correctly
- Subject totals, averages, and grade letters derived from school's own grading scale
- Form teacher and principal remarks (text fields, saved per student per term)

### ✅ Report Card Templates (8 Premium Designs)
| Template | Style | Notes |
|---|---|---|
| Clean Slate | Classic, minimal | Free — available to all tiers |
| Prestige | Corporate, bold header | Silver+ |
| Azure Edge | Modern, blue accent | Silver+ |
| Royal | Gold-accented, premium | Gold+ |
| Monarch | Dark, authoritative | Gold+ |
| Sovereign | Glassmorphism, elite | Diamond only |
| Sterling | Clean luxury | Diamond only |
| Apex | Maximum prestige | Diamond only |

### ✅ School Branding
- School name, logo, motto, and address on every report card
- Primary and secondary color customization (live preview)
- Principal's signature (uploaded image or typed name)
- School stamp / seal (Round, Rectangular, or Legal Seal styles)
- Brand colors applied to report card templates (Silver+ templates)

### ✅ Print Hub
- 2-column layout: left panel = controls, right panel = live template preview
- Generate individual or bulk PDF report cards
- Scope filters: entire school, by class, by teacher, or single student
- Output formats: PDF (print-ready), HTML (shareable), PNG (shareable image)
- Copy image to clipboard for direct WhatsApp sharing

### ✅ Teacher & Staff Management
- Teacher directory with subjects and class allocations
- Teacher allocation editor: assign teacher → class → subject(s)
- Each teacher sees only their own students on the Android app
- Device revocation (remove a lost or compromised teacher phone)

### ✅ Student Management
- Student directory: name, class, registration number, gender, parent phone
- CSV bulk import (admin uploads existing Excel/CSV roster)
- Per-student subject enrollment

### ✅ The Marriage (Sync Protocol)
- Admin shows QR code on laptop screen
- Teacher scans with Android app → linked securely
- Grades sync over local WiFi — no internet required
- Biometric lock on Android: fingerprint required to re-enter app after 30 seconds background

### ✅ Attendance Summary on Report Cards (Silver Read)
- If attendance data exists (entered by a Gold+ school or manually), Silver
  can display "Days Present: 72/80" on the report card
- Silver cannot *enter* attendance via the Android daily register (Gold feature)
- Silver schools can manually enter term totals via the Print Hub configuration

---

## What Silver Cannot Do

| Feature | Available At |
|---|---|
| Daily attendance digital register (Android tap) | Gold+ |
| WhatsApp Bot (Nexus Pulse) | Gold+ |
| Parent Portal (results, attendance, fees online) | Gold+ |
| Fee tracking and management | Gold+ (lightweight) / Diamond (full ledger) |
| Guardian Shield (automated parent alerts) | Gold+ |
| Computer-Based Testing (CBT) | Diamond |
| Analytics dashboard | Diamond |
| Always-On 24/7 parent access | Diamond |

---

## Hardware Requirements

Silver schools need only:
1. **Admin laptop** — any Core i3+ with 4GB RAM and Windows 10+ or macOS 11+
2. **Teacher Android phones** — personal phones, Android 8+, WiFi-capable
3. **WiFi** — the school's existing WiFi, or the laptop's built-in hotspot

No router purchase required for Silver. No internet required.

---

## Demo Script (3 Minutes, Closes Silver)

1. Open the app. Set the school name + colors in front of the principal. Logo appears instantly.
2. Load the demo roster — *"These are your students. Imported from Excel in 30 seconds."*
3. Hand an Android phone to a teacher. They enter 5 grades.
4. Point to the laptop — grades appear live. *"That's The Pulse."*
5. Lock the phone — fingerprint required. *"Teacher's data is biometrically protected."*
6. Generate one report card. Show the premium template with logo and stamp.
7. *"Sir, your data never left this room. That's the Nexus Sovereign Shield."*

---

## Silver → Gold Upgrade Trigger

The natural upgrade moment happens when a Silver school experiences one of:
- A parent asking: *"Can I check my child's result from home?"*
- The admin spending hours making phone calls about outstanding fees
- A student marking themselves present when they weren't

Any of these conversations opens the Gold pitch naturally.

---

*Nexus School OS — Silver Tier Plan Details v1.0*
