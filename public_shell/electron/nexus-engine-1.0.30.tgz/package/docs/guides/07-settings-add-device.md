# Nexus School OS: Adding a New Device (Terminal Architecture)

This guide explains how to authorise additional mobile or desktop devices to connect to your Nexus School OS hub — whether you're adding a new teacher's phone, a bursar's laptop, or replacing a lost device.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

Nexus operates on a **Hub-and-Spoke architecture**: one central Desktop Hub (the admin's laptop) manages all data, and authorised mobile/desktop terminals connect to it securely over the school's local Wi-Fi. Every terminal must be explicitly authorised — no device can connect without your approval.

---

## 1. Understanding the Terminal Architecture Panel

Navigate to **Settings → Terminal Architecture** in the Nexus desktop app. You will see:

- **Active Terminals**: A list of all devices currently authorised to connect to this Hub.
- **Pending Requests**: Any device that has attempted to connect but is awaiting your approval.
- **Revoked Devices**: Historical log of devices that have been disconnected.

Each entry shows the device name, its type (Mobile / Desktop), the teacher assigned to it, and the date it was added.

---

## 2. Authorising a New Mobile Device (Teacher's Phone)

### On the Teacher's Android Phone:
1. Install the **Nexus Mobile App** from the Play Store.
2. Open the app and tap **Connect to School Hub**.
3. The app will display a **Device Registration QR Code** unique to that phone.

### On the Desktop Hub (Admin):
1. Go to **Settings → Terminal Architecture**.
2. Click **Scan New Device**.
3. Point your Mac's webcam at the QR code displayed on the teacher's phone.
4. Nexus identifies the device and shows a confirmation prompt: *"Authorise Mrs. Fatima's Samsung Galaxy A54 as a new terminal?"*
5. Select the **teacher to assign this terminal to** from the dropdown.
6. Click **Authorise Device**.

The teacher's phone will immediately receive a confirmation and connect to the Hub.

---

## 3. Revoking a Device

If a teacher leaves the school or a device is lost:

1. In **Settings → Terminal Architecture**, find the device in the Active Terminals list.
2. Click **Revoke Access** next to that device.
3. Confirm the revocation.

> [!CAUTION]
> Once revoked, that device cannot sync or submit data to the Hub. Any unsynced data still on the phone will be discarded on the next connection attempt.

---

## 4. Device Limits by Tier

| Tier | Max Authorised Devices | Mode |
| :--- | :---: | :--- |
| **Standalone Pack** | 2 | Admin Extension (any class, all subjects) |
| **Silver** | Unlimited | Teacher-tied (own class/subject only) |
| **Gold** | Up to 10 | Teacher-tied |
| **Diamond** | Unlimited | Teacher-tied + Remote management |

---

## Tier Availability

* **Standalone Pack**: Up to 2 Admin Extension devices. No teacher picker — the mobile device sees the entire school roster and is attributed to "Admin" in activity logs.
* **Silver Tier**: Unlimited teacher-tied mobile terminals. Each device is linked to a specific teacher and sees only their assigned classes and subjects.
* **Gold Tier**: Up to 10 authorised teacher mobile terminals with QR pairing.
* **Diamond Tier**: Unlimited terminals plus remote device management from the cloud portal.
