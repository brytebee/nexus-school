# Nexus School OS: Activity Log — Admin & Developer Guide

This guide covers the Activity Log system from two perspectives: how **admins** review the live audit feed in the Sync Hub, and how **developers** query, extend, or integrate the log in code.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

Every write action in Nexus School OS — whether performed on the desktop or arriving from a mobile sync — is automatically recorded in the `activity_log` table. No setup is required; logging is always active. Admins can review this feed inside the Sync Hub's **Activity Feed** panel. Developers can query it directly in SQLite for auditing, debugging, or compliance reporting.

---

## For Admins — Activity Feed in the Sync Hub

### 1. Locating the Activity Feed

1. Open Nexus School OS → click **Sync Hub** in the left sidebar.
2. Scroll to the bottom of the page — the **Activity Feed** panel is the last section.
3. The table loads automatically each time the Sync Hub opens.
4. Click **Refresh** at any time to reload the latest entries manually.

### 2. Reading the Feed

The Activity Feed displays the last **100 actions** in a scrollable table with the following columns:

| Column | Description |
| :--- | :--- |
| **Event** | The event type badge (colour-coded — see below) |
| **Actor** | The label of the user or process that triggered the action |
| **Device** | `DESKTOP` for all local actions; the device ID for mobile sync events |
| **Time** | Timestamp of the action (`YYYY-MM-DD HH:MM:SS`) |

### 3. Event Badge Colours

Events are visually grouped by colour so you can scan the feed at a glance:

| Colour | Category |
| :--- | :--- |
| 🟢 Green | Backup events (`BACKUP_CREATED`, `BACKUP_RESTORED`) |
| 🔵 Cyan | Fee-related events (`FEE_*` imports) |
| 🟠 Orange | Roster events — student and teacher CSV imports |
| 🟣 Purple | Grades and Attendance CSV imports |
| 🔴 Red | Destructive actions (`APP_RESET`, `DEVICE_REVOKED`) |
| 🔷 Dark Blue | Mobile sync events (`SYNC_RECEIVED`) |

### 4. Actions That Are Logged

The following desktop and mobile operations always produce an activity log entry:

- All CSV imports: Roster, Grades, Attendance, Classes, Fee Structure, Fee Payment, Fee Adjustment
- Backup created / Backup restored
- App reset
- Mobile sync received (one entry per sync event)
- Fee payments recorded manually
- Device revocation

---

## Event Type Vocabulary

| Category | Event Types |
| :--- | :--- |
| Roster CSV | `ROSTER_CSV_IMPORTED` |
| Grades CSV | `GRADES_CSV_IMPORTED` |
| Attendance CSV | `ATTENDANCE_CSV_IMPORTED` |
| Classes CSV | `CLASSES_CSV_IMPORTED` |
| Fee Structure CSV | `FEE_STRUCTURE_CSV_IMPORTED` |
| Fee Payment CSV | `FEE_PAYMENT_CSV_IMPORTED` |
| Fee Adjustment CSV | `FEE_ADJUSTMENT_CSV_IMPORTED` |
| Backup | `BACKUP_CREATED`, `BACKUP_RESTORED` |
| System | `APP_RESET` |
| Mobile Sync | `SYNC_RECEIVED` |

> [!TIP]
> When you add a new loggable action, register its event type string here so the team has a single source of truth for all valid event types.

---

## For Developers — Schema

The `activity_log` table is created in the **V2.6 schema migration**:

```sql
CREATE TABLE IF NOT EXISTS activity_log (
    log_id       TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(8)))),
    device_id    TEXT NOT NULL,
    device_model TEXT,
    actor_label  TEXT NOT NULL,
    event_type   TEXT NOT NULL,
    payload_hash TEXT,
    received_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

| Column | Notes |
| :--- | :--- |
| `log_id` | Auto-generated 8-byte random hex string — globally unique |
| `device_id` | `'DESKTOP'` for all desktop actions; actual device ID for mobile sync |
| `device_model` | Human-readable device name where available; `NULL` for desktop |
| `actor_label` | Free-text label — typically the admin name or `'System'` |
| `event_type` | One of the event type strings from the vocabulary table above |
| `payload_hash` | First 16 hex characters of the SHA-256 hash of the event payload JSON — used for tamper detection, **not** data storage |
| `received_at` | UTC timestamp; set automatically by SQLite default |

> [!IMPORTANT]
> `payload_hash` is a fingerprint, not a data store. The original payload is **never persisted** — only the hash. Do not attempt to reverse or decode it.

---

## The `logActivity()` Helper

The canonical way to write to the activity log is via the exported `logActivity()` helper defined in `private_engine/src/server.js`.

**Signature:**

```js
logActivity({
  device_id?,    // string — defaults to 'DESKTOP'
  device_model?, // string — optional, e.g. 'Samsung A54'
  actor_label?,  // string — defaults to 'System'
  event_type,    // string — REQUIRED, e.g. 'ROSTER_CSV_IMPORTED'
  payload?       // object — hashed to payload_hash; not stored
})
```

**Key behaviours:**

- **Never throws.** Any internal failure is reported via `console.warn` only — a logging failure will never crash a business operation.
- Already exported from `server.js` and available wherever `server` is destructured in `main.js`.
- The `payload` parameter is SHA-256 hashed in-process; the original object is discarded immediately.

---

## How to Add a New Log Site

Follow these steps whenever you add a new loggable action:

1. **In `server.js`**: After a successful DB write inside your handler, call:
   ```js
   logActivity({
     event_type: 'YOUR_EVENT_TYPE',
     actor_label: 'System', // or derive from session context
     payload: { /* relevant metadata */ }
   });
   ```

2. **In `main.js`**: `logActivity` is already available via the `server` destructure import. Call it inside any `ipcMain.handle()` block after the operation completes successfully:
   ```js
   const { logActivity } = require('./server');
   // ...inside your handler:
   await doSomething();
   logActivity({ event_type: 'YOUR_EVENT_TYPE', payload: { ... } });
   ```

3. **Register the event type**: Add the new string to the [Event Type Vocabulary](#event-type-vocabulary) table in this guide.

4. **Verify in the Activity Feed**: Open Sync Hub → Activity Feed → trigger the action → click Refresh and confirm the entry appears.

---

## IPC Interface

| IPC Channel | Direction | Description |
| :--- | :--- | :--- |
| `activity-log:get` | `ipcMain.handle` | Returns `{ ok: boolean, data: ActivityEntry[] }` |

**Options payload** (optional):

```js
{ limit: number } // default: 100
```

**Renderer usage:**

```js
const result = await window.electronAPI.getActivityLog();
// result: { ok: true, data: [ { log_id, device_id, actor_label, event_type, received_at, ... } ] }
```

---

## Querying Directly in SQLite

Use these queries during development or support investigations:

```sql
-- Last 50 actions across all types
SELECT * FROM activity_log ORDER BY received_at DESC LIMIT 50;

-- All fee-related events logged today
SELECT * FROM activity_log
WHERE event_type LIKE 'FEE%'
  AND date(received_at) = date('now');

-- All mobile sync events from a specific device
SELECT * FROM activity_log
WHERE device_id = 'abc123'
ORDER BY received_at DESC;

-- Count of each event type (useful for health checks)
SELECT event_type, COUNT(*) AS total
FROM activity_log
GROUP BY event_type
ORDER BY total DESC;
```

> [!TIP]
> Open the live database with `sqlite3 nexus.db` from the app data directory. The database path is logged to the console on app startup.

---

## Tier Availability

The Activity Log is **available on all tiers** — Standalone, Silver, Gold, and Diamond. The Activity Feed panel in the Sync Hub is visible to any logged-in admin regardless of subscription level.
