# Nexus School OS: Configuring the Print Hub (Report Card Templates)

This guide explains how to choose and customise your school's report card layout using the Nexus Print Hub — selecting templates, configuring score components, and setting up comments before generating end-of-term results.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **Print Hub** is the control centre for your school's academic output. This is where the school administrator selects which premium report card template to use, configures the grading columns, enables or disables optional sections (like attendance and position), and triggers the final PDF generation. Getting this right once means every term's results are generated consistently and professionally.

---

## 1. Opening the Print Hub

1. Open Nexus School OS on the admin desktop.
2. Click **Print Hub** in the left sidebar.
3. The Print Hub dashboard loads, showing the currently active template preview on the left and the configuration panel on the right.

---

## 2. Selecting a Report Card Template

In the **Template** dropdown, choose from your available premium layouts:

| Template | Design Style | Tier Required |
| :--- | :--- | :---: |
| **Classic Minimalist** | Clean monochrome grid | Silver |
| **Azure Flex** | Corporate blue, compact layout | Gold |
| **Compact Summary** | High-density single-page view | Gold |
| **Emerald Grid** | Forest green, spacious table | Gold |
| **Sovereign Cumulative** | Dark navy, multi-term averages | Diamond |
| **Crimson Bold** | Warm burgundy, performance gauges | Diamond |
| **Modernist Slate** | Glassmorphism, rounded cards | Diamond |
| **Royal Gold** | Purple & gold trim, ornate header | Diamond |

After selecting a template, a **live preview** updates on the left panel showing how a sample student's report card will look with your school's logo and data.

---

## 3. Configuring Score Components

In the **Score Components** section, define how marks are broken down for this term:

| Component | Default Max | Editable |
| :--- | :---: | :---: |
| CA1 | 10 | ✅ |
| CA2 | 10 | ✅ |
| CA3 | 10 | ✅ |
| Exam | 70 | ✅ |

> [!TIP]
> If your school only uses CA + Exam (no CA2 or CA3), simply set the unused components to `0`. They will be hidden from the printed report card automatically.

---

## 4. Configuring Optional Report Sections

Use the toggle switches to include or exclude the following from the report card:

- **Class Position** — Shows each student's rank in their class (e.g. *3rd out of 42*).
- **Attendance Summary** — Shows days attended vs. total school days.
- **Include Attendance in Grade Computation** — If checked, attendance score weight is factored into student grading and totals. If unchecked, attendance points are set to 0 and excluded from the grade table, though attendance summary stats still show on the report footer if attendance is tracked.
- **Skip students with 0 grades** — Excludes students with zero entered scores from batch compilation, improving compilation speed and saving paper.
- **Teacher's Comment** — Dynamic auto-generated comment based on the student's average.
- **Principal's Comment** — A free-text field filled in by the admin.
- **Next Term Resumption Date** — Displayed in the footer of the report card.

---

## 5. School Branding & Tiered Signatures

### 🏢 School Address & Motto
Every template header automatically renders the school's **Address** and **Motto** below the school name. If these fields are blank in settings, the layout dynamically adjusts to preserve space.

### ✍️ Tiered Signature Gates
To support different pricing models, digital signature rendering behaves differently based on license tiers:

| Tier | Teacher Signature | Principal Signature | Stamp & Seal |
| :--- | :---: | :---: | :---: |
| **Standalone Pack** | ❌ Suppressed | ❌ Suppressed | Premium Fallback SVG Stamp Only |
| **Silver Tier** | ✅ Rendered | ❌ Suppressed | Premium Fallback SVG Stamp Only |
| **Gold Tier** | ✅ Rendered | ✅ Rendered | Full Stamp Selector (4 Styles) |
| **Diamond Tier** | ✅ Rendered | ✅ Rendered | All Styles (including Custom Upload) |

> [!TIP]
> **Signature Fallbacks**: Whenever a digital signature is suppressed or no image has been uploaded, templates gracefully fall back to rendering the teacher's or principal's name in a clean signature font aligned to the bottom of the slot.

---

## 6. Setting the Report Scope & Generating

1. In the **Scope** dropdown, select:
   - **By Class** — Choose a specific class (e.g. *JSS3 Gold*).
   - **Entire School** — Compile all classes at once.
2. Confirm the **Session** and **Term** (e.g. *2025/2026 — Second Term*).
3. Click **Generate Report Cards**.
4. Nexus compiles all results, applies the template, and saves the output PDF to your desktop.

---

## Tier Availability

* **Standalone Pack**: Classic Minimalist and class_photo templates. Attendance statistics show but no computation is included. Bypasses watermark, suppresses signature blocks, prints fallback stamp.
* **Silver Tier**: Classic Minimalist and class_photo templates. Manual score entry only. Suppresses principal signature block, prints fallback stamp.
* **Gold Tier**: 4 premium templates, mobile score sync, attendance and position columns, full signature profiles, and stamps.
* **Diamond Tier**: All 8 templates, multi-term cumulative columns, batch Google Drive export, Fee Shield integration.

