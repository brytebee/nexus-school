# Nexus School OS: Getting Started with the Standalone Pack

This guide walks you through setting up and using the Nexus School OS Standalone Pack — the one-time purchase edition of Nexus designed for schools that manage their results independently.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **Standalone Pack** gives your school a complete result management system for a single, one-time payment. No recurring fees. No subscriptions. You install it once and it works as long as you need it.

Key differences from subscription plans:
- Mobile devices in the Standalone Pack act as **Admin Extensions** — not teacher-specific.
- Up to **2 mobile devices** can be connected at the same time.
- The mobile app gives the holder access to the **full school roster**, allowing grade entry for any class.
- All features are reporting-focused: no attendance, no fee tracking, no parent portal.

---

## 1. What You Need

- ✅ **Admin laptop** — any Core i3+ with 4GB RAM, Windows 10+ or macOS 11+
- ✅ **Up to 2 Android phones** — Android 8+, capable of connecting to school Wi-Fi
- ✅ **School Wi-Fi** — or the laptop's built-in hotspot (no internet required)
- ✅ **Nexus Mobile App** — installed on the Android device(s)

---

## 2. Connecting Your First Admin Extension Device

Unlike subscription plans, there is no teacher assignment step. The mobile device is connected directly to the school hub.

### On the Desktop Hub:
1. Open Nexus School OS.
2. Navigate to **Sync Hub**.
3. Click **Generate Admin QR**.
4. A QR code appears on screen encoding the Hub's local network address.

### On the Android Device:
1. Open the **Nexus Mobile App**.
2. Tap **Connect to School Hub**.
3. Tap **Scan Hub QR Code**.
4. Point the camera at the QR code on the desktop screen.
5. The app connects and downloads the full school roster.

Once connected, the mobile device can enter grades for any class in the school.

---

## 3. Entering Grades on the Admin Extension Device

1. Open the Nexus app on the paired phone.
2. The **Class Roster** screen appears, showing all classes grouped by level.
3. Tap a class tab (e.g. *JSS 1A*) then a subject tab (e.g. *Mathematics*).
4. The students in that class and subject appear.
5. Tap **Grade Class – Focus Mode** to enter scores card by card.
6. Tap **Sync Now** when connected to the school Wi-Fi — grades are pushed to the Hub instantly.

> [!TIP]
> Grades are saved locally on the phone even without Wi-Fi. They sync automatically the next time the device connects to the school network.

---

## 4. The 2-Device Limit

The Standalone Pack supports a maximum of 2 connected Admin Extension devices. If a third device attempts to connect:

> *"Migrate to a payment plan to enjoy the full features of Nexus School OS for your school."*

To add a third device, upgrade to any Nexus subscription plan (Silver, Gold, or Diamond).

---

## 5. Generating Report Cards

1. On the desktop, navigate to **Result Studio**.
2. The scope is set to **Entire School** (the only option in Standalone).
3. Select the **Session** and **Term**.
4. Navigate to **Print Hub** and select a template:
   - **Clean Slate** — Classic minimalist layout
   - **class_photo** — Includes student passport photographs inline with results
5. Click **Generate Report Cards**.
6. Nexus compiles all results and saves the PDF to your desktop.

---

## 6. Upgrading to a Subscription Plan

When your school is ready for more:
- **Unlimited mobile devices** — Silver Plan (termly)
- **Daily attendance register** — Silver Plan (termly)
- **WhatsApp notifications to parents** — Gold Plan
- **Parent Portal, Fee Tracking** — Gold Plan
- **AI academic analytics, CBT exams** — Diamond Plan

Contact your Nexus representative or reach out via the in-app support button.

---

## Tier Availability

* **Standalone Pack**: Full access to features described in this guide.
* **Silver Tier and above**: All Standalone features plus teacher-tied devices, attendance, and more.
