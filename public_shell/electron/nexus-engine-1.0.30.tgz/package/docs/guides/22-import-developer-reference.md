# Nexus School OS: Import System — Developer Reference

This document describes the internal architecture of every data import mechanism in Nexus School OS. It is intended for engineers maintaining, extending, or debugging the import pipeline.

---

## Architecture Overview

Nexus uses a **split responsibility** model for imports:

| Import Type | Where parsing occurs | Transport |
| :--- | :--- | :--- |
| School Identity JSON | React frontend (`Settings.tsx`) | None — direct `useState` / SQLite write via existing identity IPC |
| Teachers CSV | Electron main process (`server.js`) | IPC: `process-csv` |
| Students CSV | Electron main process (`server.js`) | IPC: `process-csv` |
| Classes CSV | Electron main process (`server.js`) | IPC: `process-classes-csv` |
| Grades CSV | Electron main process (`server.js`) | IPC: `process-grades-csv` |
| Attendance CSV | Electron main process (`server.js`) | IPC: `process-attendance-csv` |
| Portal Content (Markdown) | React frontend (`PortalContent.tsx`) | Existing `school_config` IPC |

The Identity JSON and Portal Content imports have **no backend involvement** — parsing and validation happen entirely in the renderer process, and the resulting data is written through existing, already-secured IPC channels. All CSV imports pass the raw file buffer over IPC to the main process, where `better-sqlite3` transactions guarantee atomicity.

---

## IPC Channel Map

| IPC Channel | Handler Function | Source File | Handles |
| :--- | :--- | :--- | :--- |
| `process-csv` | `handleCSVUpload` | `server.js` | Teachers and Students CSV |
| `process-classes-csv` | `handleClassesCSVUpload` | `server.js` | Classes & Arms CSV |
| `process-grades-csv` | `handleGradesCSVUpload` | `server.js` | Grades CSV |
| `process-attendance-csv` | `handleAttendanceCSVUpload` | `server.js` | Attendance CSV |

> **Note**: `process-csv` is a shared channel — the payload includes a `type` discriminator field (`"teachers"` | `"students"`) which `handleCSVUpload` uses to branch its logic.

---

## Data Schema Reference

### Teachers CSV → `teachers` + `form_teachers`

| Field | Type | Required | Target | Notes |
| :--- | :--- | :---: | :--- | :--- |
| `Teacher_ID` | string | ✓ | `teachers.teacher_id` | Upsert key |
| `Teacher_Name` | string | ✓ | `teachers.name` | |
| `Teacher_Phone` | string | — | `teachers.phone` | Preserved on blank |
| `Class` | string | ✓ | `teachers.class` | Pipe-split before allocation. Teacher allocated to each class. |
| `Subjects` | string | ✓ | `teachers.subjects` (JSON array) | Pipe-split before storage |
| `Class_Host` | boolean / string | ✓ | `form_teachers.teacher_id` | `TRUE`/`1`/`YES` defaults to first class in Class list; explicit name maps directly. Overwrites existing. |

### Students CSV → `students` + `parents`

| Field | Type | Required | Target | Notes |
| :--- | :--- | :---: | :--- | :--- |
| `Student_ID` | string | ✓ | `students.student_id` | Upsert key |
| `First_Name` | string | ✓ | `students.first_name` | |
| `Last_Name` | string | ✓ | `students.last_name` | |
| `Class` | string | ✓ | `students.class` | Must pre-exist in `class_arms` |
| `Subjects` | string | ✓ | `students.subjects` (JSON array) | Pipe-split before storage |
| `Parent_Name` | string | — | `parents.name` | `COALESCE` — blank preserves existing |
| `Parent_Email` | string | — | `parents.email` | `COALESCE` — blank preserves existing |
| `Parent_Phone` | string | — | `parents.phone` | `COALESCE` — blank preserves existing |

### Classes CSV → `class_configs` + `class_arms`

| Field | Type | Required | Target | Notes |
| :--- | :--- | :---: | :--- | :--- |
| `Class_Name` | string | ✓ | `class_configs.class_name` | Hierarchy-level name only (e.g. `JSS 1`) |
| `Max_Subjects` | integer | — | `class_configs.max_subjects` | NULL → system default applies |
| `Pass_Mark_Override` | integer | — | `class_configs.pass_mark` | NULL → system default applies |
| `Arms` | string | — | `class_arms.arm_name` (one row per arm) | Pipe-split; composite name = `Class_Name + ' ' + arm` |

### Grades CSV → `grades`

| Field | Type | Required | Target | Notes |
| :--- | :--- | :---: | :--- | :--- |
| `Student_ID` | string | ✓ | `grades.student_id` | FK — must exist in `students` |
| `Subject` | string | ✓ | `grades.subject` | |
| `Assessment` | string | ✓ | `grades.assessment` | Must match `assessment_categories` config |
| `Score` | number | ✓ | `grades.score` | Parsed as float |
| `Session` | string | ✓ | `grades.session` | Format: `YYYY/YYYY` |
| `Term` | integer | ✓ | `grades.term` | 1, 2, or 3 |

### Attendance CSV → `attendance`

| Field | Type | Required | Target | Notes |
| :--- | :--- | :---: | :--- | :--- |
| `Student_ID` | string | ✓ | `attendance.student_id` | FK — must exist in `students` |
| `Session` | string | ✓ | `attendance.session` | Format: `YYYY/YYYY` |
| `Term` | integer | ✓ | `attendance.term` | 1, 2, or 3 |
| `Total_Days` | integer | ✓ | `attendance.total_days` | |
| `Days_Attended` | integer | ✓ | `attendance.days_attended` | Validated: must be ≤ `Total_Days` |

---

## Error Handling & Atomicity

All CSV handlers wrap their database operations in a **`better-sqlite3` transaction**:

```js
const importMany = db.transaction((rows) => {
  for (const row of rows) {
    // validate row, throw on hard error
    stmt.run(row);
  }
});
importMany(parsedRows); // atomic — all or nothing on uncaught throw
```

- **Hard errors** (missing required field, FK violation): throw inside the transaction → full rollback, error surfaced to renderer via IPC reply.
- **Soft errors** (e.g. `Days_Attended > Total_Days`): row is skipped with a warning appended to the response payload; the transaction continues.
- **Duplicate / upsert**: all handlers use `INSERT OR REPLACE` or `INSERT … ON CONFLICT DO UPDATE` so re-importing a corrected file is always safe.
- **`COALESCE` pattern** (Students parent fields): `UPDATE … SET parent_name = COALESCE(?, parent_name)` preserves existing data when the incoming value is `NULL` or an empty string.

---

## How to Add a New Import Type

Follow this checklist when adding a new bulk import:

1. **`server.js` — Add handler function**
   ```js
   function handleFooCSVUpload(event, csvBuffer) {
     const rows = parseCSV(csvBuffer);
     const importFoo = db.transaction((rows) => { /* ... */ });
     importFoo(rows);
     event.reply('foo-csv-result', { success: true });
   }
   ```

2. **`server.js` — Register IPC listener**
   ```js
   ipcMain.on('process-foo-csv', handleFooCSVUpload);
   ```

3. **`preload.js` — Expose the channel to the renderer**
   ```js
   processFooCSV: (buffer) => ipcRenderer.send('process-foo-csv', buffer),
   fooCSVResult: (cb) => ipcRenderer.on('foo-csv-result', (_, data) => cb(data)),
   ```

4. **Frontend TSX — Add upload UI**
   - Add a `<FileUpload />` component (or equivalent drag-drop zone) in the relevant view.
   - On file selection, read the file as an `ArrayBuffer` and call `window.api.processFooCSV(buffer)`.
   - Subscribe to `window.api.fooCSVResult` to display success/error feedback.
   - Add a **Download Template** button that triggers a pre-formatted sample CSV download.

5. **Add the template file** to the bundled assets and register it in the Settings Data Templates download section.

6. **Write at minimum one integration test** covering: valid import, duplicate upsert, and a row with a hard validation failure.

---

## Known Constraints & Gotchas

| Constraint | Detail |
| :--- | :--- |
| Class names must pre-exist | `Students CSV` requires every `Class` value to match a record in `class_arms`. Import the **Classes CSV first** when onboarding a new school from scratch. |
| Assessment names are config-bound | `Grades CSV` rejects any `Assessment` value not present in the system's `assessment_categories` configuration. Ensure categories (e.g. `CA1`, `CA2`, `Exam`) are set up before importing grades. |
| Pipe delimiter, not comma | Multi-value fields (`Subjects`, `Arms`) use `|` as the delimiter. A comma inside a subject name (e.g. `Economics, Commerce`) will not be misread, but a pipe in a name would cause a split bug — avoid pipes in field values. |
| `Class_Host` overwrites silently | Importing two teachers with `Class_Host=TRUE` for the same class in the same CSV will result in the **last row winning** (last upsert). The admin is warned, but no error is thrown. |
| Identity JSON is frontend-only | `handleIdentityJSONUpload` in `Settings.tsx` has no backend. If you need server-side validation of identity fields (e.g. slug uniqueness), a dedicated IPC channel must be added. |
| Portal Markdown stored as text | Policy and news content are stored as raw markdown strings in `school_config`. There is no version history or rollback — overwriting a policy replaces it permanently. |

---

## Related Source Files

| File | Responsibility |
| :--- | :--- |
| `private_engine/src/server.js` | All CSV IPC handlers and `better-sqlite3` transactions |
| `private_engine/src/main.js` | IPC channel registration |
| `private_engine/src/preload.js` | Renderer-facing API surface |
| `src/views/Settings.tsx` | Identity JSON upload (`handleIdentityJSONUpload`) and Data Templates UI |
| `src/views/Students.tsx` | Grades and Attendance import drawers |
| `src/views/Classes.tsx` | Classes & Arms import trigger |
| `src/views/PortalContent.tsx` | Markdown article/policy editor and `school_config` writes |
