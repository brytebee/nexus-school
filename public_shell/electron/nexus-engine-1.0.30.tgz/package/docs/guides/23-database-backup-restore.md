# Nexus School OS: Database Backup & Restore

This guide explains how to back up and restore your school database in Nexus School OS, ensuring data integrity and protection against hardware failure or accidental data loss.

> [!NOTE]
> **Video Guide**: A walkthrough video demonstrating how to perform backups and restores will be embedded here.

---

## Overview

All school records — including classes, teachers, students, grades, attendance, and fee status — are stored locally on your master node in a high-performance SQLite database. Managing backups of this file is essential for safe school administration.

---

## 1. Creating Database Backups

Nexus provides two main ways to back up your database:

### A. Automatic Local Backup on Reset
Whenever an administrator triggers a **Reset All Data** command (Settings → Reset All Data), the system forces a security check.
1. Enter your **Sudo PIN**.
2. A database reset protection modal will appear asking: *Would you like to save a local backup of your database before wiping all data?*
3. Click **Save Local Backup** to generate a copy of the database before the wipe proceeds.

### B. Manual Local Backups
To manually back up your database, you can copy the active SQLite file directly from your system directory:
* **Storage Location**: `~/Library/Application Support/NexusSchoolOS/nexus.sqlite` (on macOS) or `%APPDATA%/NexusSchoolOS/nexus.sqlite` (on Windows).
* Simply copy this file to an external drive or cloud storage.

---

## 2. Restoring a Database Backup

If you need to restore your school data from an existing `.sqlite` backup copy (e.g. recovering from a device upgrade, or reverting a mistake):

1. Open Nexus School OS on the master node and navigate to **Settings** in the left sidebar.
2. Click **📋 Data Templates** in the header to slide open the right drawer.
3. Scroll to the bottom of the drawer to find the **Restore Database Backup** card.
4. Click **Select Backup file**.
5. Read the warning prompt carefully: *This will completely replace the current database with the selected backup. All existing changes will be lost, and the application will restart.*
6. Click **Yes, Restore Backup** to confirm.
7. A system file chooser will open. Locate and select your `.sqlite` or `.db` backup file.
8. The application will immediately close the active database connection, overwrite it with the selected file, and automatically restart.

> [!WARNING]
> Restoring a database completely replaces your current records. Any grades, registrations, or payments entered since the backup was taken will be permanently lost. Always create a safety copy of your current active database before performing a restore.

> [!NOTE]
> **Complete Settings & Identity Restore**: School identity configurations (including school name, address, motto, primary/accent colors, principal signature, and logo assets) are fully serialized and synced to the database file itself under the `school_identity` configuration key. Restoring a backup SQLite file will automatically extract, re-populate, and overwrite the local `identity.json` configuration file, ensuring a full and unified restore of both school records and branding details.

---

## 3. Cloud Backups (Nexus Pulse)

For schools subscribed to the **Diamond Tier**, Nexus Pulse handles automated, encrypted cloud database backups.
- Configured via the **Nexus Pulse** tab.
- Automatically encrypts and uploads database snapshots to the school's configured Google Drive folder at scheduled intervals.
- Protects the school from physical hardware theft or hard drive failure.

---

## 3. Backup Coverage & Restraints

### What is Covered (Database-Level Data)
The SQLite database backup (`nexus.sqlite` / `nexus_os.db`) contains all configurations, rules, and student records. Restoring a backup completely restores — and a factory reset completely clears — data for the following modules:
* **Result Studio & Print Hub**: All student grades, assessment parameters, subject structures, form teacher comments, principal remarks, and report configurations.
* **Financial Hub**: Termly billing, student fee ledgers, transaction records, receipts, and fee adjustments.
* **CBT Arena**: Question banks, active exam configurations, batches, external candidate registrations, exam tokens, and candidate answer sheets.
* **Portal Content**: Dynamically configured news articles, categories, school policies, and student-submitted portal receipts.
* **Nexus Pulse**: Outbound message queues, system sync configuration thresholds, and Google Drive auth configurations.
* **School Identity Settings**: All metadata settings (school name, address, motto, primary/accent colors, principal signature, and logo assets) are synced inside the database.

### What is NOT Covered (System Caches & Restraints)
Because certain configurations live outside the SQLite database as physical system files, they are subject to the following restraints:
* **WhatsApp Bot Authentication Session**: The active authenticated WhatsApp session profile is saved locally on the machine's file system under `.nexus_pulse_auth` in the user's home folder. This browser profile is linked to the physical hardware. It is NOT included in the database backup. During a **Reset All Data** factory wipe, this session is permanently deleted to log out the WhatsApp bot cleanly.
* **Nexus Scholar Knowledge Index**: The AI knowledge base document index is stored in a separate JSON file (`nexus_knowledge_index.json` in Electron's userData folder) outside the database. A factory reset wipes this index cleanly. Database backups do not contain these index files. If you restore a backup on a new system, you must re-upload your knowledge base PDFs in the Scholar tab.
* **License File (`license.nexus` / internal activation state)**: The device's cryptographic license and hardware binding are **intentionally preserved** across a factory reset. See Section 5 below for the full policy.
* **Activation Banner State**: The `license_banner_dismissed` flag is stored in the local `electron-store` settings file, not the database. A factory reset may reset this flag, causing the activation banner to reappear even on a previously configured, licensed machine.

---

## 5. Factory Reset — Behaviour, Policy & Known Code Gaps

> [!IMPORTANT]
> This section documents the **intended design** of the factory reset operation. It also records known gaps between what the current code does and what it should do. Developers implementing V2 must resolve these gaps.

### 5.1 What the reset is for

A factory reset is triggered by a Superadmin (`role_level = 9`) from **Settings → Reset All Data**. Its purpose is to **wipe all operational school data** — students, teachers, fees, grades, attendance records, admin accounts — so the school can start a fresh academic cycle, correct a catastrophic import error, or hand a machine to a new operator within the same licensed school.

**It is NOT a device transfer tool.** The license remains on the machine because the licensed school is not changing — only its data is being cleared.

### 5.2 License Preservation Policy

The `.nexus` license file and the internal hardware binding (device fingerprint) are **preserved** across all factory resets. This is an explicit design decision:

- The license represents a commercial agreement between the school and Nexus Infrastructure Ltd.
- If a school wants to transfer their license to a different machine, they must contact Nexus support to revoke the current hardware binding and issue a fresh activation.
- If a brand-new school needs the software, the expectation is for them to register via the portal (`nexusos.com.ng`) or contact Nexus directly — they do not inherit a wiped machine's license.

> [!CAUTION]
> **Never** remove the license file or hardware binding during a reset. A school that has paid for a license and clears their data should not be forced to re-purchase or re-activate. Only the Sovereign operator can revoke a hardware binding.

### 5.3 Correct Post-Reset Landing State

After a factory reset completes, the app relaunches. With the license still present and valid, the correct landing state is:

```
app.relaunch()
  └→ BootGate checks: license valid? YES
       └→ admin_users table empty? YES
            └→ render <SetupWizard />   ← correct landing
```

The admin must go through the full Setup Wizard — school identity, Superadmin credentials, class structure — exactly as they did on first install.

### 5.4 Known Code Gaps (To Be Fixed in V2)

> [!WARNING]
> The following gaps exist in the current `clearData()` implementation in `private_engine/src/server.js`. They must be resolved before V2 ships.

#### Gap 1 — `clearData()` re-seeds a backdoor admin ❌

**Current behaviour** (`server.js` line ~1842):
```javascript
// Re-seed default admin (PIN: 0000)
const defaultHash = Buffer.from("0000").toString('base64');
db.prepare(`INSERT INTO admin_users (username, secret_hash, auth_type, role_level)
            VALUES ('admin', ?, 'pin', 9)`).run(defaultHash);
```
This inserts an `admin/0000` Superadmin unconditionally, bypassing the Setup Wizard entirely. Any insider who knows this seed can log straight into a wiped machine.

**Fix**: Remove the `admin` re-seed block entirely. Zero rows in `admin_users` is the correct post-reset state. The `BootGate` component detects the empty table and routes to `<SetupWizard />` automatically.

#### Gap 2 — Post-reset navigation is a race condition ❌

**Current behaviour**: `main.js` calls `app.relaunch()` then `app.exit(0)` synchronously. The IPC handler returns `{ ok: true }` after the process has already begun exiting — this return value never reaches the renderer. Meanwhile `Settings.tsx` calls `window.location.reload()` which races against the OS-level relaunch.

**Fix**: Before calling `app.relaunch()`, send a push event to the renderer:
```javascript
mainWindow.webContents.send('app:factory-reset-complete');
// Small delay so the renderer can render a "Resetting..." screen
setTimeout(() => { app.relaunch(); app.exit(0); }, 400);
```
The renderer listens for `app:factory-reset-complete` and shows a spinner/confirmation screen. The OS then relaunches into the Setup Wizard.

#### Gap 3 — `db:clear-data` is fully implemented \u2705 *(docs were wrong)*

The documentation incorrectly flagged this as a ghost channel. It is fully implemented:
- **`preload.js`**: `window.electronAPI.db.clearData(data)` → `ipcRenderer.invoke('db:clear-data', data)` ✅
- **`main.js`** (`ipcMain.handle("db:clear-data", ...)`): Supports `type: "grades"` (clears `student_records`, `sync_warnings`) and `type: "attendance"` (clears all attendance tables). Both paths write audit logs and call `logActivity`. ✅

This channel is used for **granular selective clearing** (e.g. wiping only grades at the start of a new term) and is separate from the full factory reset (`reset-app-data`). No action required.


---

## 4. Tier Availability

* **Standalone Pack**: Local file backup/restores via Settings drawer.
* **Silver Tier**: Local file backup/restores via Settings drawer.
* **Gold Tier**: Local file backup/restores via Settings drawer.
* **Diamond Tier**: Full local database backup/restores + automated, encrypted cloud sync via Nexus Pulse (Google Drive).
