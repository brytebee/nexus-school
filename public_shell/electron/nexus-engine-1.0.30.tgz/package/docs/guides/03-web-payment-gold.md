# Nexus School OS: Upgrading or Downgrading Your Subscription Plan

This guide explains how to change your school's Nexus subscription — whether upgrading to unlock premium features mid-term or downgrading at renewal time.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

Nexus subscriptions are flexible. As your school grows — or as the new term begins — you may want to move to a higher tier (e.g. Silver → Gold → Diamond) to unlock features like the Mobile App Sync, Fee Shield, WhatsApp Pulse, or the Sovereign Parent Portal.

---

## 1. Initiating an Upgrade or Downgrade

There are two ways to change your plan:

### A. From the Web Portal
1. Log in to the Nexus web portal with your admin credentials.
2. Navigate to **My School → Subscription**.
3. Click **Change Plan**.
4. Select your new tier (Silver, Gold, or Diamond).

### B. From Inside the Desktop App
1. Open Nexus School OS on your desktop.
2. Click **About** in the sidebar navigation.
3. Click **Upgrade / Change Plan**.
4. You will be redirected to the web portal to complete the process.

---

## 2. Upgrade Flow (e.g. Silver → Gold)

1. On the plan selection screen, click **Select Plan** under **Gold**.
2. Uncheck "First Time Install" — you are upgrading, not starting fresh.
3. Enter your **existing License Serial** number (found in your email or the About page).
4. Click **Proceed to Payment**. You are redirected to **Paystack** secure checkout.
5. Complete payment via card or bank transfer.
6. A **new upgraded License Key** is generated automatically and emailed to your registered address.

> [!IMPORTANT]
> If you are not redirected back after paying, check your email. Do not pay again.

---

## 3. Applying the New License Key

Once you receive the upgraded license key:
1. Open the Nexus desktop app.
2. Go to **About → Enter New License Key**.
3. Paste the new key and click **Activate**.
4. The app will restart, instantly unlocking the new features.

> [!TIP]
> You do not lose any data when upgrading. All student records, grades, fees, and settings are preserved. Nexus simply unlocks the additional feature gates.

---

## 4. Feature Comparison Across Tiers

| Feature | Silver | Gold | Diamond |
| :--- | :---: | :---: | :---: |
| Core Registries | ✅ | ✅ | ✅ |
| Mobile App Sync | ❌ | ✅ | ✅ |
| Bulk Fee Invoicing + Fee Shield | ❌ | ✅ | ✅ |
| Local Wi-Fi Parent Portal | ❌ | ✅ | ✅ |
| WhatsApp Pulse (Nexus Pulse) | ❌ | ✅ | ✅ |
| Cloud Always-On Portal | ❌ | ❌ | ✅ |
| CBT Arena | ❌ | ❌ | ✅ |
| Nexus Scholar (Student Portals) | ❌ | ❌ | ✅ |

---

## Tier Availability

Plan management is available at **all tiers**. Upgrades take effect immediately upon license key activation.
