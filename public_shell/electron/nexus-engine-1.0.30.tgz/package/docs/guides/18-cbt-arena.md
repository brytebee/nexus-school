# Nexus School OS: CBT Arena Deployment Guide

This guide explains how to construct multiple-choice question banks, ingest documents using Nexus Scholar AI, deploy examinations to classrooms, and invigilate live student status offline.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **CBT Arena** is a complete, offline-first computer-based testing suite. It allows you to create high-fidelity exam papers, import question lists using local AI model extraction, and run secure, locked-down classroom exams with zero internet dependencies.

---

## 1. Creating Question Banks

A Question Bank holds your subject-specific test questions.

1. Open Nexus School OS → click **CBT Arena** in the left sidebar.
2. Under **Question Banks**, click **+ Create Bank**.
3. Fill in:
   - **Bank Name**: e.g., *WAEC Mock 2026*
   - **Category**: e.g., *English Language*
4. Click **Confirm** to save the bank.

---

## 2. Adding Questions manually, via CSV, or via AI Ingestion

You can add questions manually, import them in bulk using a standard CSV template, or use Nexus Scholar AI to auto-extract them from document templates (PDF/DOCX/TXT).

### Manual Addition:
1. Open your Question Bank card → click **Question Studio**.
2. Click **+ Add Question**.
3. Enter the question text, options A–D, mark the correct answer, and set point value.
4. Save the question.

### Bulk CSV Import:
1. Open your Question Bank card → click **Question Studio** → click **+ Add Question**.
2. Select the **Import CSV** tab in the modal.
3. Click **Download template ↗** to obtain the correct schema layout.
4. Fill in the columns (`question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option` (A-D), and `marks`), select the completed CSV file, and click **Import Questions**.

### AI Scholar Import:
1. Inside the Question Studio, click **Upload via Nexus Scholar 🪄**.
2. Select your question document (maximum 15MB).
3. Nexus Scholar will run local pattern matching to extract numbered questions with options.
4. Review the preview list and click **Import All** to add them to your bank.

---

## 3. Deploying an Exam

To let students sit for an exam, you must deploy it. The deployment form links the questions directly to student records and handles scheduling.

1. Click the **Deploy Exam** tab.
2. Fill in the deployment form:
   - **Exam Title**: e.g., *SS 1 Termly Mathematics*
   - **Question Bank**: Select from your library.
   - **Target Class**: Select the target class level or a specific class arm from the searchable Combobox (e.g. `SS 1` to target all arms, or `SS 1 Gold` to target a specific arm).
   - **Functional PC Count**: Input the number of functional computers available in the lab. The system will auto-calculate the number of batches required (e.g., 60 students ÷ 20 PCs = 3 batches) and auto-split the students into named batches (Batch 1, Batch 2, etc.).
   - **Academic Session & Term**: The session is auto-pulled from your school settings. Select the term (e.g., *First*, *Second*, *Third*) to tag results for reporting.
   - **Duration**: e.g., *60 Minutes*
   - **Kiosk Mode**: Force fullscreen and lock browser tab switching.
3. Click **Deploy Exam**. The system will query student profiles matching the class/arm selection, split them into batches, and automatically generate and assign candidate exam tokens.

---

## 4. Live Invigilation & Clearance

Once deployed, monitor candidate sessions in real time:

1. Click the **Live Invigilation** tab.
2. Select the active exam.
3. View batch status, candidate tokens, and connection status.
4. Use the **Clearance Scanner** to scan student registration QR codes and verify tuition payment status before allowing access.
5. If a student needs to write in a different batch for logistical reasons, admins can easily reassign the student to an alternate batch here.

---

## 5. Exam Security & Anti-Collusion

When running exams in multiple batches (especially over different days), the CBT Arena applies a three-layer security framework to prevent collusion:

1. **Question Diversity (Seeded Shuffle)**: Every candidate gets a unique question and option sequence. Using a lightweight, unique 8-character `question_seed` stored on their token, the system performs a seeded Fisher-Yates shuffle. This is extremely storage-friendly (~8 bytes per token) and allows the system to run smoothly on standard 8GB RAM / 250GB HDD school computers while remaining fully auditable.
2. **Temporal Lockout**: Students can only access the CBT Portal during their assigned batch's start and end times. Trying to log in early or late will return an authorization error.
3. **Identity & Single-Use Binding**: Tokens are bound to student IDs. Once a token is loaded, its status changes to `in_progress`. Upon submission, it is permanently set to `completed`. Re-entry is blocked.
4. **Result Release Policies**: Select when students can see their scores:
   - *Immediate*: Scores are displayed on submit.
   - *Delayed (1h / 24h)*: Scores are hidden until the exam window closes.
   - *Manual*: Scores are blacked out until the administrator manually releases them after all batches finish.

---

## Tier Availability

* **Silver Tier**: Local manual question bank creation and offline paper exporting.
* **Gold Tier**: Up to 3 active deployed exams, basic token generation, and local browser invigilation.
* **Diamond Tier**: Unlimited exams, class arms level management, PC-based batch auto-splitting, multi-batch security (seeded shuffles, temporal locks, and result blackout policies), full Nexus Scholar AI document extraction, secure Kiosk locking browser, real-time invigilation radar, and automated WhatsApp result digests.

