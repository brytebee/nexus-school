# Nexus School OS: Entering Grades & Generating Result Reports

This guide explains how teachers enter CA and Exam scores on the mobile app, how the Desktop Hub compiles the results, and how the admin generates print-ready report cards for every student.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete. This video will show a **side-by-side view** — the teacher entering scores on their phone on the left, and the result table compiling live on the desktop on the right.

---

## Overview

Nexus automates every step of the results workflow — from mobile score entry by subject teachers to automatic grade computation, class position ranking, and PDF report card generation. No manual averaging. No sorting. No hand-writing.

---

## 1. Entering Scores on the Mobile App (Teacher)

1. The subject teacher opens the **Nexus Mobile App**.
2. Taps **Grade Class** from the home navigation.
3. Selects the target class (e.g. *JSS2 Silver*) and subject (e.g. *Mathematics*).
4. The student roster appears with score input fields for each student.

### Score Components:
| Component | Abbreviation | Max Score |
| :--- | :--- | :--- |
| Continuous Assessment 1 | CA1 | 10 |
| Continuous Assessment 2 | CA2 | 10 |
| Continuous Assessment 3 | CA3 | 10 |
| Examination | Exam | 70 |
| **Attendance (Optional)** | **Att** | **10** |
| **Total** | | **100** |

5. The teacher enters each student's scores across the components.
6. Taps **Save Scores** — records are stored locally and sync to the Hub when Wi-Fi is available.

> [!NOTE]
> **Handshake Score Synchronization**: When marrying a new Android mobile device to the Desktop Hub, Nexus automatically downloads existing database grades to the client device. This prevents grade data loss and ensures teachers are always working with up-to-date rosters when registering a replacement or secondary device.

---

## 2. Configuring the Grading Scale & Sudo Override (Desktop — Admin)

Before generating reports, confirm the grading scale is set:

1. Open Nexus Desktop App → **Settings → Grading Scale**.
2. Verify or customise the grade boundaries (e.g. 75–100 = A1 Excellent, 70–74 = B2 Very Good, etc.).
3. Click **Save Scale**.

### 🔐 Sudo Admin Grade Override
If grades need to be updated directly on the desktop rather than synced from a mobile device, admins can toggle **Sudo Mode** inside the student details modal. This unlocks direct text editing for all score components in the database.

---

## 3. Setting Up Your Report Card Template & Attendance Computation (Print Hub)

1. Navigate to **Print Hub** in the desktop sidebar.
2. Select the **Template** (e.g. *Sovereign Cumulative*, *Azure Flex*).
3. Select the **Session** and **Term** (e.g. *2025/2026 — First Term*).
4. Configure attendance options under **Show Attendance Stats**:
   - **Include Attendance in Grade Computation**: If checked, attendance stats are computed as a grading component (defaulting to 10 points). If unchecked, attendance points are set to `0` and excluded from the grading table, but summary statistics (days attended/days opened) are still printed in the student header/footer panels.
5. Toggle optional columns: Class Position, Principal Comments.
6. Select the **Output Format** — PDF (printable) or HTML (web view).

---

## 4. Generating the Report Cards

1. Click **Generate Report Cards**.
2. Choose the scope:
   - **By Class**: Select a specific class using the searchable Combobox.
   - **Entire School**: Compile report cards for all enrolled students.
3. Nexus instantly computes:
   - Total scores and averages per student.
   - Class positions (with tie-breaking handled automatically).
   - Grade labels and remarks for every subject.
   - Attendance percentage (if enabled).

> [!TIP]
> **Stable Average Calculations**: Student averages are calculated using the configurable *Max Subjects* setting defined on the **Classes** screen. This provides a stable average denominator, ensuring correct average calculation and class position ranking even when students have different numbers of registered subjects.
4. A PDF is generated and saved to your desktop, ready to print and distribute.

---

## 5. The Fee Shield Check

If the **Fee Shield** is active, Nexus checks each student's fee balance before including them in the report output:
- Students with outstanding balances above the threshold receive **watermarked** or **locked** report cards.
- Students with cleared balances receive full, clean report cards.

---

## Tier Availability

* **Silver Tier**: Core score entry, automated grade computation, Classic Minimalist report card template.
* **Gold Tier**: Mobile score sync, 4 premium templates, dynamic comments, form teacher signatures.
* **Diamond Tier**: All Gold features plus all 8 premium templates, multi-term cumulative averages, batch PDF export to Google Drive, Fee Shield integration.
