# Nexus School OS: Managing Fees in the Financial Hub

This guide explains how to set up fee billing schedules, invoice students in bulk, record payments, and use the Fee Shield to enforce payment compliance across your school.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **Financial Hub** is where all school billing, payment records, and debt management happen. Instead of spreadsheets, paper ledgers, or WhatsApp messages asking *"Has Obi paid?"*, Nexus gives you a live, real-time financial dashboard for every student — with automated invoicing and enforcement built in.

---

## 1. Setting Up a Fee Structure

A Fee Structure defines what items make up the total term bill.

1. Open Nexus School OS → click **Financial Hub** in the left sidebar → go to the **Fee Structure** tab.
2. Select your class from the searchable **Class** Combobox (e.g. `JSS 1 Gold`).
3. Add billing items individually (e.g. *Tuition: ₦35,000*, *PTA: ₦5,000*, *Dev Levy: ₦5,000*).
4. If you have multiple arms for the same class level (e.g. *JSS 1 Gold*, *JSS 1 Silver*, *JSS 1 Blue*), click the **📋 Copy to all arms of JSS 1** button to copy all configured fee items to the other arms in a single click.
5. Once the structure is ready, select the target term and click **⚡ Apply to Class** to instantly bill all students enrolled in those classes.

---

## 2. Recording a Student Payment

When a parent pays:

1. In the **Financial Hub**, search for the student by name or registration number.
2. Click **Record Payment**.
3. Enter:
   - **Amount Paid**: e.g. ₦25,000
   - **Payment Method**: Cash / Bank Transfer / Card
   - **Transaction Reference**: e.g. bank teller number
   - **Payment Date**
4. Click **Save Payment**.

The student's ledger instantly updates — showing the new balance, payment history, and current status (Unpaid / Partial / Cleared).

---

## 3. Adding Adjustments & Scholarships

For students on scholarships, staff waivers, or sibling discounts:

1. Open the **Adjustments** tab in the Financial Hub.
2. Under **New Fee Adjustment**, select the class using the searchable **Class Filter** Combobox to filter the student list.
3. Search and select the student in the **Student (Search)** field.
4. Fill in the adjustment details:
   - **Adjustment Type**: Discount / Waiver / Credit
   - **Amount**: e.g. ₦15,000
   - **Reason**: *"Staff Child — 50% Tuition Waiver"*
5. Click **Save**. The student's net balance is instantly recalculated.

---

## 4. Activating the Fee Shield (Debtor Results Lock)

The **Fee Shield** prevents report cards from being issued to students with outstanding balances.

1. In the Financial Hub, click **Fee Shield Settings**.
2. Configure the threshold:
   - **Mode**: Fixed amount (e.g. any balance over ₦0) or Percentage (e.g. outstanding > 30% of total bill).
   - **Enforcement**: Watermark only (card shows "BALANCE OUTSTANDING") or Hard Lock (no card generated).
3. Toggle **Enable Fee Shield** to ON.

> [!TIP]
> **Commercial ROI**: Schools using the Fee Shield report recovering an average of **₦3.6M – ₦4.2M** in outstanding fees per term for a school of 300 students.

---

## 5. Generating Financial Reports

1. In the Financial Hub, click **Reports**.
2. Choose scope: **By Class**, **Entire School**, or **Debtors Only**.
3. Click **Export PDF** to generate a clean financial summary for the school owner.

---

## 6. Bulk Import via CSV

The **📥 Bulk Import** tab in Financial Hub allows you to load large volumes of fee data from spreadsheet files instead of entering each record manually.

> [!NOTE]
> 🎥 Video guide: *How to use the Bulk Fee Import templates*

### 6.1 Fee Structure CSV

Defines billing line items for each class and term. Upserts existing rows — re-importing the same file is safe.

| Column | Required | Notes |
|---|---|---|
| `Class_Name` | ✅ | Must match a class configured in the Classes screen (e.g. `JSS 1 Gold`) |
| `Item_Name` | ✅ | Label for the fee item (e.g. `Tuition`, `PTA Levy`) |
| `Amount` | ✅ | Numeric amount in Naira — no commas (e.g. `35000`) |
| `Term` | ✅ | `First Term`, `Second Term`, `Third Term`, or `All Terms` |

**Example row:**
```
JSS 1 Gold,Tuition,35000,First Term
```

### 6.2 Fee Payment CSV

Bulk-records payments against student accounts. Updates both the transaction ledger and student balance.

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ | Must exist in the Students database |
| `Academic_Session` | ✅ | e.g. `2025/2026` |
| `Term` | ✅ | e.g. `First Term` |
| `Amount_Paid` | ✅ | Numeric amount in Naira |
| `Payment_Method` | ✅ | `cash`, `transfer`, `pos`, or `bank_teller` |
| `Reference_Number` | ❖ | Bank teller or transfer reference |
| `Payment_Date` | ❖ | ISO format `YYYY-MM-DD` — defaults to today |
| `Recorded_By` | ❖ | Staff name — defaults to `Admin` |

> [!IMPORTANT]
> Invalid rows (missing required fields, zero amount) are skipped and logged to the console. The rest of the file still imports.

### 6.3 Fee Adjustment CSV

Bulk-applies scholarships, waivers, and discounts.

| Column | Required | Notes |
|---|---|---|
| `Student_ID` | ✅ | Must exist in the Students database |
| `Academic_Session` | ✅ | e.g. `2025/2026` |
| `Term` | ✅ | e.g. `First Term` |
| `Adjustment_Type` | ✅ | `scholarship`, `waiver`, `owner_grant`, `bursary`, or `discount` |
| `Amount` | ✅ | Numeric reduction amount in Naira |
| `Description` | ❖ | e.g. `Staff Child — 50% Tuition Waiver` |
| `Approved_By` | ❖ | Defaults to `Admin` |

### Using the Import Tab

1. In Financial Hub, click the **📥 Bulk Import** tab.
2. Click **⬇️ Download Template** for the import type you need.
3. Open the template in Excel or Google Sheets, fill in your data, and save as CSV.
4. Click **📂 Choose CSV & Import** and select your file.
5. A result message appears instantly: `✅ N rows imported successfully` or `❌ Error: ...`.
6. The Fee Roster refreshes automatically on success.

> [!TIP]
> All three imports are atomic — if the transaction fails mid-file (e.g. a DB error), no partial data is written. Fix the error and re-import the whole file.

---

## 7. Enabling Paystack Online Fee Payments

Nexus Pulse integrates with **Paystack** to let parents pay school fees directly from WhatsApp — no bank app switching, no teller queues. The payment is confirmed in real-time and the student's ledger updates automatically.

> [!IMPORTANT]
> **Requirements**: Gold or Diamond tier · Nexus Pulse bot running and authenticated · At least one school bank account added and verified in Financial Hub.

### Step 1 — Add and verify your school's bank account
1. Open **Financial Hub → Fee Settings → Bank Accounts**.
2. Click **Add Bank Account** and fill in:
   - Bank name (select from list)
   - Account number (10 digits)
   - Account name (auto-resolved via Paystack)
3. Click **Verify & Connect**. Nexus creates a Paystack **subaccount** linked to this account so payments settle directly into your school's account.
4. Once verified, a ✅ badge appears on the account row.

### Step 2 — Set the active settlement account
1. In **Bank Accounts**, click **Set as Active** on the verified account you want fee payments deposited into.
2. Nexus automatically sets `paystack_connected = true` — the bot now offers the "Pay Online" option to parents.

### Step 3 — (Optional) Configure installment plans
If your school accepts part-payments or milestone payments:
1. Go to **Fee Settings → Installment Plans**.
2. Add plans with a label and percentage, e.g.:
   - *First Installment — 50%*
   - *Second Installment — 50%*
3. Parents will see these as numbered options when they choose to pay online.

---

### The Parent Experience (WhatsApp → Paystack → Receipt)

Once Paystack is connected, a parent who messages the school WhatsApp number sees:

```
💰 Outstanding Balance: ₦60,000 (2 children)

How would you like to pay?
  Reply 1 to Pay Online via Paystack 💳
  Or transfer to:
  First Bank — 0123456789 — Green Valley High

Reply 0 to return to main menu.
```

If the parent replies **1**:
1. The bot generates a unique Paystack checkout link (valid for that session only).
2. The link is sent via WhatsApp. Parent taps it — Paystack checkout opens in their browser.
3. Parent pays with card or bank transfer inside Paystack.
4. **Automatically**: Nexus receives the Paystack webhook, verifies the payment, and:
   - Allocates the amount across siblings (oldest outstanding first)
   - Updates `fee_transactions` and `student_fees` in the database
   - Sends the parent a detailed WhatsApp receipt:

```
✅ Payment Confirmed!

Thank you for your payment to Green Valley High.
━━━━━━━━━━━━━━━━━━━━
💳 Transaction Details:
   Reference:  PAY-1751371234-5678
   Total Paid: ₦60,000
   Channel:    Paystack Online
   Date:       01/07/2026

👤 Student Allocations:
   • Ada Obi:
     Allocated: ₦30,000
     New Balance: ₦0
   • Obi Obi:
     Allocated: ₦30,000
     New Balance: ₦30,000
━━━━━━━━━━━━━━━━━━━━
_Your official school records have been updated automatically._
_Powered by Nexus Pulse_ 🎓
```

> [!TIP]
> The webhook flow is fully offline-resilient. If the bot is temporarily unavailable when the webhook fires, the payment is still recorded in the database — the WhatsApp receipt is the only thing that may be delayed.

---

## Tier Availability

* **Silver Tier**: Basic Paid/Unpaid tracking per student. No bulk invoicing.
* **Gold Tier**: Bulk fee schedules, individual adjustments, payment receipts, Fee Shield, CSV Bulk Import, **Paystack online parent fee payments**.
* **Diamond Tier**: All Gold features plus multi-admin audit logs (every payment stamped with the recording bursar's name), Exam Clearance QR Codes, Google Drive export, and installment/partial payment plans.

---

## 8. Controlling Installment Plan Behaviour

When a school creates an installment plan, the default behaviour allows a parent to keep using the same percentage option repeatedly. For example, a "50% First Instalment" could theoretically be used three times, paying 50% of a dwindling balance each time.

**Occurrence limits** give you full control over this.

### Setting occurrence limits:

1. Go to **Financial Hub → Fee Settings → Installment Plans**.
2. Open any milestone (e.g. *50% First Instalment*).
3. Set the **Allowed Times** field to a number between 1 and 7:
   - **1** — can only be used once per term per student (most common for schools with strict two-phase collections)
   - **2–7** — allows multiple uses, useful for weekly/monthly repayment structures
   - **Unlimited** (default, 0) — original behaviour
4. Click **Save**.

> [!TIP]
> The simplest setup for a standard Nigerian school: create two milestones set to 1 occurrence each — *"50% First Instalment"* and *"50% Balance"*. Parents must settle the first half before the second option appears. This is enforced automatically by the bot.

---

## 9. Configuring Payment Channels

These toggles (in **Financial Hub → Fee Settings → Payment Channels**) control which options parents see when they contact the bot:

| Toggle | Default | Effect when OFF |
|---|---|---|
| **Allow Manual Bank Transfer / Cash via Bot** | ON | Bot never shows the bank account details or cash payment option |
| **Allow Custom Amount Payments** | ON | Parents cannot type an arbitrary amount; only full balance or installment milestones are offered |

### Recommended configurations:

- **Paystack-only school**: Turn OFF manual payments. All collections flow through Paystack and are auto-reconciled.
- **Strict installment school**: Turn OFF custom amounts. Parents must follow your defined payment milestones.
- **Flexible school**: Leave both ON (default).

> [!NOTE]
> These settings take effect immediately on the next parent interaction — no restart required.

---

## 10. Sending Results via WhatsApp and Email

At the end of each term, instead of parents collecting physical report cards, Nexus can send them **directly to parents' phones**.

> [!IMPORTANT]
> **Requirements**: Gold or Diamond tier · Nexus Pulse bot running · Results compiled in Result Studio.

### 10.1 WhatsApp PDF Dispatch

1. In **Result Studio**, after compiling a class or student's results, look for the **📤 Send via WhatsApp** button.
2. Select your scope:
   - **Single student** — sends to that parent only
   - **Full class** — sends to all parents in the class in sequence
   - **Entire school** — batch dispatch to all parents (with a small delay between each to respect WhatsApp limits)
3. Click **Send**. Nexus generates a branded A4 PDF for each student and dispatches it.

Each parent receives:
```
🎓 Results are out!

Dear Mrs. Obi, kindly find attached the Third Term
report card for Ada Obi — JSS 2B.

Green Valley High · Powered by Nexus Pulse
```

### 10.2 Email Dispatch

1. In **Result Studio**, click **📧 Send via Email**.
2. Nexus queues an email with the PDF attached for every student whose parent has an email address on file.
3. Emails are sent immediately if the school PC has internet access. If offline, they are queued and sent automatically as soon as a connection is detected.

> [!TIP]
> To set up email sending, go to **Settings → Notifications → Email Setup** and enter your SMTP credentials (Gmail App Password, Zoho, or your school's mail server).

### 10.3 Parent Portal Download

If your school uses the **E-Portal** (your Nexus-hosted web page for parents):

1. After compiling results, go to **Portal Content** and toggle **Publish Results** for the relevant term.
2. Parents who log in to your school's portal will see a **Download Report Card** button for each child under their account.

This is the most convenient option for parents who prefer accessing results on their own schedule rather than waiting for a dispatch.

