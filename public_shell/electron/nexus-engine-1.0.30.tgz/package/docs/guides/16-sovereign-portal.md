# Nexus School OS: The Sovereign Parent Portal

This guide explains how to set up your school's Sovereign Parent Portal — an offline-first, local Wi-Fi broadcaster that gives parents instant, cost-free digital access to their children's report cards, fee statements, and attendance records directly from their mobile phones.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## The Vision: "Institutional Sovereignty"

Most modern school management systems store your student records on a server overseas. If the internet goes down, or the hosting company suffers an outage, your school's daily operations grind to a halt.

**Nexus operates differently.** 
Your school's data belongs to you. It resides entirely on your local Nexus computer inside your building. The **Sovereign Portal** allows parents to connect directly to your laptop over local school Wi-Fi to view their children's grades, fee status, and attendance — **100% offline, with absolute data privacy and zero internet cost**.

---

## 1. Setting Up the Local Wi-Fi Broadcaster

To allow parents to view portal data, you must turn on the Nexus Broadcaster from the Desktop Hub.

1. Connect your Nexus laptop to your school's local Wi-Fi router (no internet is needed on this router; it only acts as a wireless bridge).
2. Open the **Nexus School OS** desktop application and click **Sovereign Portal** in the left sidebar.
3. Click **Start Broadcaster Service**.
4. The system will initialize a local web server and display:
   * **Broadcasting Port**: `3002`
   * **School Local IP Address**: (e.g. `http://192.168.1.105:3002`)
   * An auto-generated **Broadcaster QR Code**.

> [!IMPORTANT]
> The Broadcaster Service must remain active on the desktop application for parents to connect. The hosting laptop must remain powered on and connected to the local Wi-Fi router.

---

## 2. Printing Parent Access Cards

Parents can access the portal by scanning their customized **Access QR Cards** or entering their private login credentials.

### How to print and distribute access cards:
1. In the **Sovereign Portal** dashboard, click **Print Access Slips**.
2. Select the target class using the searchable **Class** Combobox (or select all classes).
3. Click **Export PDF**, then print and cut the cards. For a premium touch, laminating them before distribution to parents is recommended.
4. Each card contains:
   * **Student Name & Admission Number**
   * **The Broadcaster Web Link** (and a direct QR Code)
   * **A private 6-digit Portal Access PIN** (unique to each parent)

---

## 3. How a Parent Connects (The Parent Experience)

When a parent visits the school (e.g. on Open Day, during PTA meetings, or at drop-off/pick-up times):

1. The parent connects their smartphone or tablet to the **School Wi-Fi network**.
2. They open their phone camera and scan the **Access QR Code** on their card.
3. Their phone browser instantly opens the **Nexus Parent Portal** (broadcasting directly from the laptop at reception).
4. The parent enters their child's **Access PIN**.
5. **The Dashboard is Live**: They instantly see a beautiful glassmorphic layout displaying their child's:
   * Academic grades, termly averages, and positions.
   * Total days attended and attendance metrics.
   * Outstanding invoices, payments made, and net balance due.

> [!NOTE]
> **Zero Data Cost**: Because the phone is communicating directly with your reception laptop via the local Wi-Fi router, **neither the school nor the parent consumes any internet data**! It is fast, instant, and completely free.

---

## 4. Cloud Portal Mirroring (Always-On Portal)

For Diamond Tier subscribers, Nexus offers the **Always-On Cloud Portal**. This bridges the offline-first architecture with the convenience of remote cloud access.

* **Automatic Encrypted Sync**: Once a day (or manually triggered by the admin), Nexus encrypts and uploads a highly compressed, secure data package to your dedicated Google Drive.
* **Vercel Serverless Hosting**: Parents can access the dashboard from their homes, anywhere in the country, via `https://[school].nexusschoolos.app`.
* **Zero Host Cost**: Leverages free-tier serverless platforms and the school's own cloud storage, meaning no expensive annual hosting subscriptions.

---

## Tier Availability

* **Silver Tier**: Local broadcasting disabled. Report cards must be physically printed and handed to parents.
* **Gold Tier**: Full Local Wi-Fi Broadcaster (Express on Port `3002`), printed access QR cards, and local smartphone lookup.
* **Diamond Tier**: Full unlocks! Includes both local Wi-Fi broadcasting and the **Always-On Cloud Portal** sync (auto-uploads an encrypted database clone to Google Drive for remote lookup).
