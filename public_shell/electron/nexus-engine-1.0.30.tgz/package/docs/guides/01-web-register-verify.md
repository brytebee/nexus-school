# Nexus School OS: Registering Your School & Verifying Your Account

Welcome! This guide walks you through the very first step in your Nexus journey — creating your school's account on the Nexus registration portal and verifying it so you can proceed to choose a subscription plan.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

Before installing the Nexus School OS desktop application, every school must first be registered on the Nexus cloud portal. This creates your school's unique identity in the system, generates your school's administrative credentials, and links your hardware license to the right institution.

---

## 1. Navigating to the Registration Portal

Open any modern web browser (Chrome, Firefox, Edge, or Safari) and visit the Nexus School OS registration page. You will be greeted by a clean, modern onboarding form.

---

## 2. Filling In Your School Profile

Complete the registration form with the following information:

| Field | Example |
| :--- | :--- |
| **School Name** | St. Joseph's College |
| **School Address** | 12 Education Lane, Abuja |
| **Administrator Full Name** | Mrs. Adaeze Okonkwo |
| **Admin Email Address** | admin@stjosephs.edu.ng |
| **Phone Number** | +234 801 234 5678 |
| **State / LGA** | FCT, Abuja Municipal |

> [!TIP]
> Use an email address that is actively monitored — your license key and activation link will be delivered there.

---

## 3. Submitting and Verifying Your Account

1. After filling in your details, click **Create School Account**.
2. A verification email will be sent to your registered address within seconds.
3. Open the email and click the **Verify My Account** button.
4. You will be redirected to the Nexus portal confirming your account is active.

> [!IMPORTANT]
> Check your spam or junk folder if the verification email does not appear within 2 minutes.

---

## 4. What Happens Next

Once your account is verified, you are ready to:
- Choose a subscription plan (Silver, Gold, or Diamond).
- Download the Nexus School OS desktop installer.
- Receive and activate your hardware-bound license key.

---

## Tier Availability

Account registration is **free and available to all tiers**. Your feature access is determined by the subscription plan you select in the next step.
