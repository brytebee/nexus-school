# Nexus School OS: Sending Reports via WhatsApp (Nexus Pulse)

This guide explains how to set up the Nexus Pulse WhatsApp Bot — your school's automated communication channel for sending report cards, fee alerts, and custom announcements directly to parents' WhatsApp accounts.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

**Nexus Pulse** turns your school's WhatsApp number into a 24/7 intelligent bot that parents can message to instantly receive their child's results, outstanding balance, and attendance records. No more printing and sharing photos of report sheets on class WhatsApp groups. Nexus Pulse is secure, private, and instant.

---

## 1. Connecting Your WhatsApp Account

Nexus Pulse uses **WhatsApp Web** to connect your school's business number to the system.

1. Open Nexus School OS → click **Nexus Pulse** in the left sidebar.
2. Click **Connect WhatsApp**.
3. A **QR code** will appear on screen.
4. On your school's WhatsApp phone, open **WhatsApp → Linked Devices → Link a Device**.
5. Scan the QR code with the phone camera.
6. Nexus Pulse will display: **"WhatsApp Connected Successfully — Bot is Active"**.

> [!IMPORTANT]
> The phone used to connect must remain powered on and connected to the internet for the bot to stay active. The school's dedicated admin smartphone is ideal for this purpose.

### 1.1 Monitoring Connection: The Guardian Shield Badge
To help administrators monitor the connection health at a glance, a **🛡️ Guardian Shield** badge is displayed inside the **Nexus Pulse** control center:
- **🟢 Shield Active**: The WhatsApp engine is authenticated, online, and actively processing pull queries and queued messages.
- **🔴 Shield Offline**: The WhatsApp engine is disconnected or stopped. Incoming parent queries will fail, and queued notifications will wait until the connection is restored.

### 1.2 Portal OTP Security Safeguard
When parents request a one-time password (OTP) to log into the school's Sovereign Portal, the system runs a pre-check:
- If the bot is **Online**, the OTP is sent immediately via WhatsApp.
- If the bot is **Offline**, the system detects this state and returns a clear, helpful error message to the parent (*"WhatsApp delivery is currently unavailable. Please contact the school reception"*). This prevents silent verification failures and ensures parents receive alternative guidance.

---

## 2. What Parents Can Request from the Bot

Once connected, parents can message your school's WhatsApp number with simple commands:

| Parent Message | Bot Response |
| :--- | :--- |
| `result` | Sends the child's latest compiled report card (PDF) |
| `balance` | Shows outstanding fee balance and last payment date |
| `attendance` | Shows the child's attendance percentage for the current term |
| `hi` or `hello` | Bot greets and lists available commands |

> [!NOTE]
> Each parent is identified by their registered phone number. The bot automatically finds the student linked to that number and returns their data — completely private to that parent.

---

## 3. Bulk Broadcasting to All Parents

The admin can proactively push notifications to all parents at once:

1. In Nexus Pulse, click **Broadcast Message**.
2. Choose the message type:
   - **Result Release Notification** — *"Dear Parent, [Student Name]'s First Term results are now available. Reply 'result' to receive."*
   - **Fee Reminder** — *"Dear Parent, the outstanding balance for [Student Name] is ₦[Amount]. Kindly make payment before [Date]."*
   - **Custom Announcement** — Type any school-wide message.
3. Select the target audience: All Parents, Debtors Only, or a specific class.
4. Click **Send Broadcast**.

---

## 4. Automated Report Card Dispatch

When the admin finishes generating report cards in the Print Hub:

1. Nexus Pulse shows a prompt: *"Report cards are ready. Send to all parents via WhatsApp?"*
2. Click **Send to All Parents**.
3. Nexus Pulse queues and sends each student's PDF report card directly to their parent's WhatsApp — one by one, personalized.

---

## Tier Availability

* **Silver Tier**: Nexus Pulse not available.
* **Gold Tier**: Full WhatsApp Bot (parent pull requests for result, balance, attendance), bulk broadcasts, automated report card dispatch.
* **Diamond Tier**: All Gold features plus subject-level attendance responses, truancy alerts pushed proactively to parents, and multi-number WhatsApp failover.
