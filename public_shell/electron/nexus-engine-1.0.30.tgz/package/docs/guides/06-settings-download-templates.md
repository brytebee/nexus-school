# Nexus School OS: Downloading & Using Data Import Templates

This guide explains how to access every available data import template in Nexus School OS, where each one lives in the interface, and what to do after filling one in.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

When onboarding a new school — or updating existing records in bulk — Nexus provides a set of ready-to-use import templates. Filling these offline and uploading them is dramatically faster than entering records one at a time through the UI. All templates are available from **Settings → Column 3: Data Templates**, with additional templates for grades and attendance accessible directly from the Students screen.

---

## Available Templates

| # | Template | Format | Location |
| :--- | :--- | :--- | :--- |
| 1 | School Identity Config | `.json` | Settings → Data Templates |
| 2 | Teachers & Class Hosts | `.csv` | Settings → Data Templates |
| 3 | Students & Parent Contacts | `.csv` | Settings → Data Templates |
| 4 | Classes & Arms | `.csv` | Classes screen header |
| 5 | Grades | `.csv` | Students → Settings Drawer |
| 6 | Attendance | `.csv` | Students → Settings Drawer |

---

## 1. School Identity Config (JSON)

The identity template pre-fills your school's branding configuration — name, motto, address, theme colours, and portal slug.

1. In **Settings → Data Templates**, click **📥 Download JSON** next to the *School Identity Template* card.
2. Open the file in any text editor, fill in the fields, and save it.
3. Click **📤 Upload JSON** to load the values into the Settings form.
4. Review the auto-populated fields, then click **Save Identity Shard** to persist them.

> [!IMPORTANT]
> The JSON import does **not** cover your school logo, principal's signature image, or stamp style. Those three items must be configured separately in the **Visual Identity** and **Stamp Studio** panels.

---

## 2. Teachers & Class Hosts (CSV)

Use this template to register all teaching staff, their subject allocations, and their Form Teacher (host class) assignments.

**Columns:** `Teacher_ID`, `Teacher_Name`, `Teacher_Phone`, `Class` (pipe-delimited with `|`), `Subjects` (pipe-delimited with `|`), `Class_Host` (`TRUE`/`FALSE` or Class Name)

1. Click **📥 Download Teachers.csv** in **Settings → Data Templates**.
2. Fill one teacher per row. Separate multiple classes and multiple subjects with a pipe (`|`), not a comma.
3. Set `Class_Host=TRUE` (hosts the first class in the list) or enter an explicit class name (e.g. `JSS 2 A`) to make them the Form Teacher.
4. Upload the file using the **Import Teachers** button in Settings.

> [!TIP]
> Teachers can be assigned to multiple classes and subjects in a single row by separating them with pipes (e.g., `Class` = `JSS 1 Gold|JSS 1 Silver`, `Subjects` = `Mathematics|English`). Use `Class_Host` to specify their form class (e.g. `JSS 1 Gold`).

---

## 3. Students & Parent Contacts (CSV)

Use this template to bulk-enrol students and optionally load their parent/guardian contact details in the same operation.

**Columns:** `Student_ID`, `First_Name`, `Last_Name`, `Class`, `Subjects` (pipe-delimited), `Parent_Name`, `Parent_Email`, `Parent_Phone`

1. Click **📥 Download Students.csv** in **Settings → Data Templates**.
2. Fill one student per row. The `Class` field must exactly match a class configured in your Classes screen (e.g. `JSS 1 Gold`).
3. Parent columns are optional — leave them blank to preserve any existing parent data for that student.
4. Upload the file using the **Import Students** button in Settings.

---

## 4. Classes & Arms (CSV)

Use this template to set up your entire class hierarchy, arm names, subject caps, and pass mark overrides in a single step.

**Columns:** `Class_Name`, `Max_Subjects`, `Pass_Mark_Override`, `Arms` (pipe-delimited)

1. Navigate to **Classes** in the left sidebar.
2. Click the **📥 Download Template** button in the screen header.
3. Fill one class level per row. List arm names pipe-delimited (e.g. `Gold|Silver|Bronze`).
4. Click **⚡ Import CSV** in the Classes header to upload.

> [!IMPORTANT]
> Import your Classes template **before** importing Students or Grades. The Students CSV requires class names to already exist in the system.

---

## 5. Grades (CSV)

Use this template to bulk-import assessment scores across subjects and terms.

**Columns:** `Student_ID`, `Subject`, `Assessment`, `Score`, `Session`, `Term`

1. Go to **Students** in the left sidebar, then open the **⚙ Settings Drawer**.
2. Click **📥 Download Grades Template** and fill it in.
3. Upload it using the **Import Grades** button in the same drawer.

---

## 6. Attendance (CSV)

Use this template to record per-term attendance totals for all students.

**Columns:** `Student_ID`, `Session`, `Term`, `Total_Days`, `Days_Attended`

1. Go to **Students** in the left sidebar, then open the **⚙ Settings Drawer**.
2. Click **📥 Download Attendance Template** and fill it in.
3. Upload it using the **Import Attendance** button in the same drawer.

> [!TIP]
> For the full column format specifications, example data, and tier availability for each template, refer to the **Bulk Data Import Guide** (Guide 21).

---

## Tier Availability

| Template | Silver | Gold | Diamond |
| :--- | :---: | :---: | :---: |
| Identity JSON | ✓ | ✓ | ✓ |
| Teachers CSV | ✓ | ✓ | ✓ |
| Students CSV | ✓ | ✓ | ✓ |
| Classes & Arms CSV | — | ✓ | ✓ |
| Grades CSV | ✓ | ✓ | ✓ |
| Attendance CSV | ✓ | ✓ | ✓ |
