# Nexus School OS: Bulk Data Import Guide

This guide explains how to use every available import mechanism in Nexus School OS — from your school's identity configuration through to grades and attendance — enabling you to onboard a fully operational school in a single session.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video demonstrating the end-to-end bulk import workflow is embedded in this guide slot inside the application.

---

## Overview

Nexus provides **six structured import types** plus a markdown import for your Sovereign Portal. Each import is accessible from the **Settings** screen, Column 3 — **Data Templates**. Download the appropriate template, fill it in offline using Excel or Google Sheets, then upload it back into the correct import panel. All CSV imports process atomically — if any row fails validation, the entire batch is safely rolled back.

---

## 1. School Identity JSON

The Identity JSON lets you configure your school's core profile in a single upload rather than filling individual fields manually.

### What it imports

| Field | Description |
| :--- | :--- |
| `name` | Official school name |
| `address` | School postal / physical address |
| `motto` | School motto text |
| `signature` | Principal's name / signature text |
| `principalPhone` | Principal's contact number |
| `portalSlug` | Unique URL slug for the Sovereign Portal |
| `themePrimary` | Primary brand colour (hex, e.g. `#1A3C6E`) |
| `themeSecondary` | Secondary/accent colour (hex) |

### Steps

1. Download `Nexus_Identity_Template.json` from **Settings → Data Templates**.
2. Open the file in any text editor and fill in each field.
3. In **Settings → School Identity**, drag-and-drop your completed JSON file into the upload zone (or click **Browse**).
4. The fields are populated instantly — review them on-screen.
5. Click **Save Identity Shard** to persist the changes to your local database.

> [!IMPORTANT]
> The Identity JSON does **not** include your school logo, signature image, or stamp style. These three items must be configured separately:
> - **Logo** — drag a PNG or JPEG into the logo upload panel.
> - **Signature image** — upload a PNG of the principal's hand-drawn or stylus signature.
> - **Stamp style** — select from the stamp gallery in the Identity settings panel.
>
> Failing to click **Save Identity Shard** after upload means your changes are **not** saved.

---

## 2. Teachers & Class Hosts CSV

### Template columns

| Column | Required | Format | Example |
| :--- | :--- | :--- | :--- |
| `Teacher_ID` | Yes | Alphanumeric | `TCH-001` |
| `Teacher_Name` | Yes | Full name | `Adaeze Okonkwo` |
| `Teacher_Phone` | No | Digits | `08033334444` |
| `Class` | Yes | Pipe-delimited full arm class names | `JSS 2 Gold\|JSS 3 Silver` |
| `Subjects` | Yes | Pipe-delimited subjects | `Mathematics\|English\|Physics` |
| `Class_Host` | Yes | Explicit arm class name (recommended) or `TRUE`/`FALSE` | `JSS 2 Gold` |

### Steps

1. Download **Sample_Teachers.csv** from **Settings → Data Templates**.
2. Fill in one teacher per row. Use the pipe character (`|`) — **not** a comma — to separate multiple classes in the `Class` column or subjects in the `Subjects` column.
3. Set `Class_Host` to the **exact arm class name** (e.g. `JSS 2 Gold`) for the class this teacher hosts as Form Teacher. Leave blank or set to `FALSE` if the teacher is not a Form Teacher.
4. In **Settings → Data Templates → Import Teachers**, select your completed file and click **Upload**.

> [!IMPORTANT]
> If a teacher is assigned as a class host, they will be registered as the Form Teacher for that class. If another teacher was previously the Form Teacher for that class, they will be **replaced** — you will see a warning notification confirming the overwrite. Only one Form Teacher per class is allowed at any time.

> [!TIP]
> **Schools with arms** (e.g. Gold, Silver, Bronze): always use the full arm class name in `Class_Host` (e.g. `JSS 1 Gold`). Each arm is treated as a separate class and needs its own Form Teacher.
>
> **Schools without arms**: you may use `TRUE` or `YES` as a shorthand — the system assigns the teacher as Form Teacher of the first class listed in their `Class` column.

> [!CAUTION]
> Using `Class_Host=TRUE` when your school has multiple arms configured is **ambiguous** — the system will assume the first configured arm and emit a warning in the import status bar. Re-import with an explicit arm name (e.g. `JSS 1 Gold`) to correct the assignment.

---

## 3. Students & Parent Contacts CSV

### Template columns

| Column | Required | Format | Example |
| :--- | :--- | :--- | :--- |
| `Student_ID` | Yes | Alphanumeric | `STU-2025-001` |
| `First_Name` | Yes | Text | `Chukwuemeka` |
| `Last_Name` | Yes | Text | `Obi` |
| `Class` | Yes | Exact class name | `SS 2 Gold` |
| `Subjects` | Yes | Pipe-delimited | `Biology\|Chemistry\|Further Maths` |
| `Parent_Name` | No | Full name | `Obi Nnamdi Sr.` |
| `Parent_Email` | No | Valid email | `nnamdi@example.com` |
| `Parent_Phone` | No | Digits | `07011112222` |

### Steps

1. Download **Sample_Students.csv** from **Settings → Data Templates**.
2. Fill one student per row. The `Class` value must exactly match a class configured in your Classes screen (e.g. `JSS 1 Gold`, not `JSS1Gold`).
3. Parent columns are optional — if left blank, any existing parent data for a returning student is preserved automatically.
4. In **Settings → Data Templates → Import Students**, select your file and click **Upload**.

> [!TIP]
> Importing the same `Student_ID` a second time performs an **upsert** — existing records are updated, not duplicated. This makes it safe to re-import corrected files without creating ghost profiles.

---

## 4. Classes & Arms CSV

Use this template to create your full class hierarchy and configure subject caps and arm names in a single operation.

### Template columns

| Column | Required | Format | Example |
| :--- | :--- | :--- | :--- |
| `Class_Name` | Yes | Hierarchy-level name | `JSS 1` |
| `Max_Subjects` | No | Integer | `12` |
| `Pass_Mark_Override` | No | Integer (0–100) | `40` |
| `Arms` | No | Pipe-delimited | `Gold\|Silver\|Bronze` |

### Steps

1. Download **Sample_Classes.csv** from **Settings → Data Templates**.
2. Enter one class level per row. `Class_Name` is the top-level name only — composite arm names are generated automatically (e.g. `JSS 1 Gold`, `JSS 1 Silver`).
3. Leave `Max_Subjects` or `Pass_Mark_Override` blank to apply system defaults.
4. In **Settings → Data Templates → Import Classes**, select your file and click **Upload**.

> [!NOTE]
> This import upserts into both the `class_configs` table (subject caps and pass marks) and the `class_arms` table (arm-composite class names). Existing arms **not** listed in the import are preserved — they are not deleted.

---

## 5. Grades CSV

Use this template to bulk-import assessment scores for any number of students, subjects, and terms.

### Template columns

| Column | Required | Format | Example |
| :--- | :--- | :--- | :--- |
| `Student_ID` | Yes | Must match enrolled student | `STU-2025-001` |
| `Subject` | Yes | Subject name | `Mathematics` |
| `Assessment` | Yes | Existing assessment category | `CA1` |
| `Score` | Yes | Numeric | `78` |
| `Session` | Yes | Academic year | `2025/2026` |
| `Term` | Yes | 1, 2, or 3 | `1` |

### Steps

1. Download **Sample_Grades.csv** from **Settings → Data Templates** (also accessible from the Students settings drawer).
2. Fill one score entry per row. A student will have multiple rows — one per subject per assessment type.
3. Navigate to **Students → Settings Drawer → Import Grades**, select your file, and click **Upload**.

> [!IMPORTANT]
> `Assessment` values must **exactly match** the assessment categories configured in your system (e.g. `CA1`, `CA2`, `Exam`). Rows with unrecognised assessment names will be skipped. `Score` must be a plain number — no percentage signs or letters.

---

## 6. Attendance CSV

This template allows bulk entry of per-term attendance totals for all students.

### Template columns

| Column | Required | Format | Example |
| :--- | :--- | :--- | :--- |
| `Student_ID` | Yes | Must match enrolled student | `STU-2025-001` |
| `Session` | Yes | Academic year | `2025/2026` |
| `Term` | Yes | 1, 2, or 3 | `2` |
| `Total_Days` | Yes | Integer | `65` |
| `Days_Attended` | Yes | Integer ≤ Total_Days | `58` |

### Steps

1. Download **Sample_Attendance.csv** from **Settings → Data Templates** (also accessible from the Students settings drawer).
2. Fill one row per student per term. A student attending across three terms will have three rows.
3. Navigate to **Students → Settings Drawer → Import Attendance**, select your file, and click **Upload**.

> [!TIP]
> `Days_Attended` cannot exceed `Total_Days`. Any row where `Days_Attended > Total_Days` will be flagged and skipped while the remaining valid rows in the batch are still committed.

---

## 7. Portal Content (Markdown)

Your **Sovereign Portal** supports News Articles and School Policy documents authored in plain Markdown — no HTML required.

### Steps

1. Navigate to **Portal Content** in the left sidebar.
2. To add a **News Article**: click **New Article**, write or paste your content in the Markdown editor, then click **Publish**.
3. To add a **School Policy**: click **New Policy**, paste your policy document in Markdown format, assign a category label, and click **Save Policy**.
4. Saved content is stored in the `school_config` table and immediately reflected on your live Sovereign Portal.

> [!TIP]
> Use `## Section Heading` for policy sub-sections, `**bold text**` for key terms, and `- Item` for bullet lists. Markdown tables are also supported for fee schedules or timetables displayed on the portal.

---

## 8. CBT Questions CSV

Use this template to bulk-import multiple-choice questions into any Question Bank.

### Template columns

| Column | Required | Format | Example |
| :--- | :--- | :--- | :--- |
| `question_text` | Yes | Text | `What is the value of 5 + 5?` |
| `option_a` | Yes | Text | `5` |
| `option_b` | Yes | Text | `10` |
| `option_c` | Yes | Text | `15` |
| `option_d` | Yes | Text | `20` |
| `correct_option` | Yes | Single letter (A–D) | `B` |
| `marks` | Yes | Integer | `2` |

### Steps

1. Navigate to **CBT Arena** in the left sidebar.
2. Select your Question Bank card and click **Question Studio**.
3. Click **＋ Add Question** in the header to open the modal.
4. Select the **Import CSV** tab, then click **Download template ↗**.
5. Populate the rows in Excel or Google Sheets, then upload the file using the upload zone in the modal.
6. Review the parsed preview of questions on-screen and click **Import Questions** to commit them.

---

## Tier Availability

| Feature | Silver | Gold | Diamond |
| :--- | :---: | :---: | :---: |
| Identity JSON import | ✓ | ✓ | ✓ |
| Teachers CSV import | ✓ | ✓ | ✓ |
| Students CSV import | ✓ | ✓ | ✓ |
| Classes & Arms CSV import | — | ✓ | ✓ |
| Grades CSV import | ✓ | ✓ | ✓ |
| Attendance CSV import | ✓ | ✓ | ✓ |
| CBT Questions CSV import | ✓ | ✓ | ✓ |
| Portal Content (Markdown) | — | ✓ | ✓ |
