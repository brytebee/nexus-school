# Nexus School OS: Setting Up Your School Identity & Stamp

This guide explains how to personalise your school's identity in Nexus — uploading your school logo, configuring your official seal, and setting the principal's digital signature that appears on every report card.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

First impressions matter. Before generating your first report card, set up your school's visual identity so that every document Nexus produces — from report cards to payment receipts — carries your school's official crest, colours, and authority.

---

## 1. Uploading Your School Logo / Crest

1. Open Nexus School OS and navigate to **Settings** in the left sidebar.
2. Scroll to the **School Identity** section.
3. Click **Upload Logo** and select your school crest image (PNG or JPG, minimum 200×200px recommended).
4. A live preview of how the logo appears on report card headers is shown immediately.
5. Click **Save Identity**.

> [!TIP]
> Use a transparent-background PNG for the cleanest look on report cards. Avoid logos with busy white or coloured backgrounds that clash with the template's header colour.

---

## 2. Configuring the Official Stamp / Seal

Nexus provides **5 professional stamp styles** that appear in the principal's endorsement panel on every report card:

| Seal Style | Appearance | Best For |
| :--- | :--- | :--- |
| **Classic Round** | Traditional circular school seal with school name around the perimeter | Government and mission schools |
| **Modern Rect** | Clean rectangular badge with a sharp, corporate finish | International-standard schools |
| **Ribbon Endorse** | Academic ribbon/banner design with decorative flourishes | High-prestige secondary schools |
| **Minimal Signature** | A clean, understated stamp that frames the principal's name | Schools preferring a professional, minimalist look |
| **Custom Upload** | Upload your school's actual digitized stamp image | Schools with an existing official digital seal |

### Steps to configure:
1. In **Settings**, scroll to the **Stamp & Seal** section.
2. Click through the available styles to preview each one on a sample report card.
3. Use the **Colour Picker** to match the stamp colour to your school's brand colour.
4. Click **Save Stamp Settings**.

> [!NOTE]
> **Premium Fallback Seal**: If no stamp style or custom image is uploaded, Nexus compiles report cards with an integrated premium multi-ring official SVG fallback seal. This seal features nested solid/dotted rings, stars, curved text, a realistic ink-bleed filter effect, and a `-3deg` rotation to replicate the off-angle alignment of manual document stamping.

---

## 3. Setting Principal, Form Teacher, and Header Metadata

For every signature panel and report card header to display the correct details:

1. In **Settings**, go to **Admin Profiles** or **School Identity**.
2. Enter the **School Address** and **Motto** — these will auto-populate directly beneath the school name in the header block of all compatible templates (with dynamic scaling if left blank).
3. Enter the **Principal's Full Name** and **Title** (e.g. *Mrs. Adaeze Okonkwo, B.Ed., M.Ed.*).
4. Optionally upload a **digital signature image** (a photographed or stylus-drawn signature on a white background).
5. Assign **Form Teachers** to their respective classes — their names will auto-populate in the class teacher signature block of each report card.

---

## 4. Tier Availability

* **Standalone Pack**: Logo, Address, and Motto configuration. Signature blocks are hidden (manual sign required). Stamp prints the premium SVG fallback seal.
* **Silver Tier**: Upload school logo, address, and motto. Principal signature block hidden; Class Teacher name displays as text. Stamp prints the premium SVG fallback seal.
* **Gold Tier**: Full stamp style selector (4 styles), colour picker, principal profile, and digital signature uploads.
* **Diamond Tier**: All stamp styles including Custom Seal Upload, digital signature images, and multi-admin profile management.

