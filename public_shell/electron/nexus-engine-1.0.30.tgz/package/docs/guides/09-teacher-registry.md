# Nexus School OS: Registering Teachers

This guide explains how to add teachers to the Nexus system — setting up their profiles, assigning class allocations, and defining their subject responsibilities.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

Before teachers can use the Nexus Mobile App to take attendance or enter grades, their profiles must be registered in the system by the school administrator. This links each teacher to their classes and subjects so their mobile app shows only what is relevant to them.

---

## 1. Opening the Teacher Registry

1. Launch Nexus School OS on the admin desktop.
2. Click **Teachers** in the left sidebar navigation.
3. The Teacher Registry table loads, displaying all current teaching staff.

---

## 2. Adding a New Teacher

1. Click the **＋ Add Teacher** button in the top-right corner.
2. The **Add Teacher Drawer** slides open on the right side of the screen.

### Profile Details:
| Field | Example |
| :--- | :--- |
| **Full Name** | Mrs. Fatima Al-Hassan |
| **Phone Number** | 2348011112222 |
| **Email Address** | fatima@school.edu.ng |

---

## 3. Setting Class Allocations & Subjects

A teacher can be assigned to multiple classes and subjects.

> [!IMPORTANT]
> **Prerequisite**: Classes and arms must be configured first in the **Classes** screen before they can be assigned to teachers.

1. **Host Class**: Select the teacher's host class using the searchable Combobox.
2. **Class Allocation**: Select all target classes from the searchable MultiSelectCombobox (which lists all configured classes and arms).
3. In the **Subjects** grid, select the subjects this teacher handles for those classes (e.g. tap **Mathematics**, **English Language**).
4. You can also type a **custom subject** in the text field and click **Add +** if it is not listed in the grid.
5. Click **＋ Append Allocation** to save this class assignment and start a new one (for teachers handling multiple classes).

> [!TIP]
> A teacher who takes both **JSS 1 Gold Mathematics** and **SS 2 Science Physics** should have two separate allocations appended — one for each class/subject combination.

---

## 4. Saving the Teacher Profile

1. After configuring all allocations, click **Save Teacher**.
2. The new teacher instantly appears in the **Teacher Registry** table.
3. Their mobile app will now show only the classes and subjects assigned to them.

---

## 5. Editing or Removing Teachers

- Click any teacher's row in the registry table to open their **Edit Profile** drawer.
- Modify their details or allocations and click **Save Changes**.
- To remove a teacher, click the **Delete** icon and confirm.

---

## Tier Availability

* **Silver Tier**: Unlimited teacher registration. No mobile sync.
* **Gold Tier**: Full teacher profiles with mobile app sync. Up to 10 paired devices.
* **Diamond Tier**: Unlimited teacher terminals plus multi-admin role management.
