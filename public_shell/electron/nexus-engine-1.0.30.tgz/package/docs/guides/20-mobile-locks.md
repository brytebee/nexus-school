# Nexus School OS: Mobile Terminal & Policy Locks

This guide explains how the central Desktop Hub controls what teacher companion mobile devices can do in the field — specifically locking/unlocking student registration, grade entry, and attendance registries.

---

## Overview

Companion mobile devices sync directly with the central PC Hub over local Wi-Fi. In many environments, the school administrator must restrict editing permissions. For example:
- **Registration Lock**: Prevents teachers from enrolling new students after rosters are finalized.
- **Grades Lock**: Blocks entering or updating student CA or Exam scores after grading deadlines.
- **Attendance Lock**: Prevents modifying daily registers retroactively.

Nexus School OS supports **immediate manual locks** and **scheduled automatic locks** that lock capability at a precise date and time.

---

## 1. Accessing the Lock Policies

1. Open Nexus School OS on the admin desktop.
2. Click **Students** in the left sidebar.
3. Click the ⚙️ gear icon or **Student Settings** button.
4. The **Student Directory Settings** drawer slides out on the right.

---

## 2. Lock Policies & Configuration

In the settings drawer, you can configure:

### 🔓 Mobile Registration Lock
- **Immediate Lock**: Toggle to disable new student enrolment from mobile companion terminals.
- *Existing student lookups, grade entry, and attendance registers remain unaffected.*

### 📝 Mobile Grade Entry Lock
- **Immediate Lock**: Toggle to instantly block teachers from saving or auto-saving student scores.
- **Scheduled Lock**: Select the checkbox to set an automatic date and time.
- *The UI displays a live relative countdown to when the lock will engage (e.g. "Locks in 2 days, 4 hours").*

### 📅 Mobile Attendance Lock
- **Immediate Lock**: Toggle to instantly block modifying class registers.
- **Scheduled Lock**: Select the checkbox to set an automatic date and time.

---

## 3. Under the Hood: The Sovereign Shield & Clock Protection

To ensure high reliability and security in offline school environments, Nexus implements two protection layers:

### 1. Offline Client-Side Checks (Immediate Feedback)
When the device performs a handshake or sync, it caches the current lock status and scheduled lock-at times in its encrypted local preferences. 
- Even when **completely offline** (without local Wi-Fi contact), the mobile app checks the local device clock. If it exceeds the cached scheduled deadline, the inputs are disabled.
- The grade cards display a locked banner, and inputs become read-only.
- Tapping attendance registers displays a lock warning Toast.

### 2. Online Server-Side Rejection (Tamper Protection)
If a teacher attempts to bypass the offline lock by manually altering their Android phone's system time:
- During the next sync cycle, the central server receives the queued `UPDATE_GRADE` or `ATTENDANCE_UPDATE` payloads.
- The server evaluates the lock status using its **authoritative PC system clock**.
- If the server time has passed the deadline, the sync loop rejects the payload. The events are pushed to the response's `failed_events` list, and the mobile app deletes the rejected queue logs, notifying the user.

---

## Tier Availability

* **Silver Tier**: Manual Mobile Registration Lock controls.
* **Gold Tier**: Manual Grade and Attendance Entry Locks.
* **Diamond Tier**: Full scheduled date-time automated locks and sync warning reports.
