# Nexus School OS: Enrolling Students

This guide explains how to register new students into the Nexus system — capturing their academic and parent/guardian details so they appear in the registry and are ready for grading, fee management, and portal access.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

Every student in your school must have a profile in Nexus before grades, fees, attendance, or report cards can be generated for them. Student enrolment can be done one-by-one through the desktop UI, or in bulk using the CSV import template (see the **Downloading Templates** guide).

---

## 1. Opening the Student Registry

1. Launch Nexus School OS on the admin desktop.
2. Click **Students** in the left sidebar navigation.
3. The Student Registry table loads with all currently enrolled students.

---

## 2. Adding a New Student

1. Click the **＋ Add Student** button in the top-right corner.
2. The **Enrolment Drawer** slides open on the right side of the screen.

### Student Profile Fields:

> [!IMPORTANT]
> **Prerequisite**: Classes and arms must be configured first in the **Classes** screen before they can be assigned to students.

| Field | Example |
| :--- | :--- |
| **Full Name** | Obi Emeka |
| **Class** | Select from the searchable Combobox (e.g. `SS 1 Gold`) |
| **Registration Number** | REG-100452 |
| **Gender** | Male |

### Parent / Guardian Details:

| Field | Example |
| :--- | :--- |
| **Parent / Guardian Name** | Emeka Senior |
| **Parent Phone Number** | 2348033334444 |

> [!TIP]
> The parent phone number is used by **Nexus Pulse** to send automated WhatsApp report card notifications. Ensure it is a valid WhatsApp-enabled number.

---

## 3. Assigning Subjects

In the **Subjects** section of the drawer:
1. Select the student's curriculum level tab (e.g. *Primary 4–6*, *JSS*, or *SSS*).
2. Tick the subjects this student will be graded on.
3. To add a subject not in the list, type it in the **Custom Subject** field and click **Add +**.

---

## 4. Saving the Student Profile

1. Click **Save Student**.
2. The student instantly appears in the **Student Registry** table.
3. Their record is now linked to the Financial Hub (for invoicing), the Attendance module (for marking), and the Print Hub (for report card generation).

---

## 5. Editing or Removing Students

- Click any student's row in the registry to open their **Edit Profile** drawer.
- Adjust their class, subjects, or parent contact details and click **Save Changes**.
- To remove a student (e.g. transfer out), click the **Archive** icon. Archived students are hidden from active views but their historical data is preserved.

---

## Tier Availability

* **All Tiers**: Unlimited student enrolment. Core profile fields (name, class, reg number, gender) are available on all plans.
* **Gold Tier**: Parent phone number field active (required for WhatsApp Pulse).
* **Diamond Tier**: Subject-level attendance tracking linked to student profiles.
