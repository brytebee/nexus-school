# Nexus School OS: Installing and Licensing the App (macOS)

This guide walks you through downloading the Nexus School OS desktop application, installing it on your Mac, and activating it with your license key.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

After subscribing to a Nexus plan, your License Key and download link are sent to your registered email address. This guide covers the complete installation process from downloading the `.dmg` installer to your first fully-licensed login.

---

## 1. Downloading the App

1. Open your email and find the message from **Nexus School OS** with subject: *"Your License Key & Download Link"*.
2. Click the **Download Nexus School OS (macOS)** button in the email.
3. Your browser will download the `NexusSchoolOS-[version]-arm64.dmg` file (for Apple Silicon Macs) or `NexusSchoolOS-[version]-x64.dmg` (for Intel Macs).

> [!TIP]
> Not sure which Mac you have? Click **Apple menu () → About This Mac**. If it shows **Apple M1/M2/M3**, download the `arm64` version.

---

## 2. Installing the App

1. Open the downloaded `.dmg` file from your Downloads folder.
2. In the installer window, **drag the Nexus School OS icon into your Applications folder**.
3. Eject the `.dmg` file.
4. Open **Finder → Applications** and double-click **Nexus School OS** to launch it.

> [!IMPORTANT]
> On first launch, macOS may show a security warning: *"Nexus School OS cannot be opened because the developer cannot be verified."*
> To proceed: **Right-click** the app icon → **Open** → **Open** again in the confirmation dialog. You only need to do this once.

---

## 3. Activating Your License

On first launch, Nexus will display the **License Activation Screen**.

1. Open your email and copy your **License Key** (e.g. `NXOS-SLV-2026-ABCD-EFGH-1234`).
2. Paste it into the **License Key** field on the activation screen.
3. Click **Activate License**.
4. Nexus will verify the key against your school's hardware fingerprint and unlock the application.

> [!IMPORTANT]
> Your license is **hardware-bound**. It will only activate on the specific Mac device associated with your subscription. To add a second device, see the **Adding a New Device** guide.

---

## 4. First Launch: The Main Dashboard

After activation, Nexus loads the main dashboard. You will see:
- Your **School Name** and **Active Tier** displayed in the top navigation bar.
- All navigation items for your tier unlocked in the left sidebar.
- A welcome prompt to begin setting up your school profile in **Settings**.

---

## Tier Availability

Installation and licensing is available at **all tiers**. Feature access depends on the plan activated.
