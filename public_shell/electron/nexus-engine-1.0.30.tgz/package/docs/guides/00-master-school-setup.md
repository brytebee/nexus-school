# 🎓 Nexus School OS — Master School Setup Guide

> This guide is the **complete map** for setting up a school on Nexus School OS — from the moment the installer finishes to the day the first report cards are printed. Each section gives you the essential steps and links out to the full dedicated guide for that topic. Use the collapsible sections to navigate only what you need.

---

<details>
<summary><strong>📍 How to use this guide</strong></summary>

This document is organized in the order a school would realistically work through setup. Follow it top-to-bottom for a first-time installation, or jump to any section using the collapsible headers. Every section ends with a link to its full guide for deeper reference.

**Symbol key used throughout:**
- 🟢 Available on all tiers (including Standalone Pack)
- 🥈 Requires Silver plan or higher
- 🥇 Requires Gold plan or higher
- 💎 Requires Diamond plan

</details>

---

## Phase 0 — Installation & Activation

<details>
<summary><strong>Step 1 · Web Registration & Account Setup 🟢</strong></summary>

Before installing the app, the school administrator creates their school account on the Nexus portal at **nexusos.com.ng/portal**. This is where plans are purchased, license keys are issued, and the school's portal subdomain is reserved.

**Key actions:**
1. Register your school at nexusos.com.ng/portal
2. Verify your email
3. Select and pay for your plan (Silver / Gold / Diamond) — or purchase the Standalone Pack as a one-time buy

📖 **Full guides:** 01-web-register-verify.md · 02-web-payment-silver.md · 03-web-payment-gold.md

</details>

<details>
<summary><strong>Step 2 · Onsite Installation & License Activation 🟢</strong></summary>

Download the Nexus School OS installer from the portal and run it on the designated admin computer. The first launch shows the **License Lock Screen** — activate before the full UI is accessible.

**Two activation paths:**
- **Import License File** — Copy `license.nexus` from the portal to a USB, then import it on the lock screen
- **Activate Online** — Click "Renew Online →"; the browser opens the portal with your hardware ID pre-filled

Once licensed, the app unlocks into the dashboard.

> After activation, manage your license at any time from **About → License Key** — import a new `.nexus` file or activate online without waiting for expiry.

📖 **Full guide:** 04-install-licensing.md

</details>

---

## Phase 1 — School Identity Setup

<details>
<summary><strong>Step 3 · Configuring School Identity & Branding 🟢</strong></summary>

The **Settings** screen ("School Identity Forge") is where your school's branding is configured. Complete this before generating any report card.

**Visual Identity (Column 1):**
- Upload School Crest/Logo (PNG or JPEG, drag-and-drop supported)
- Set Primary Theme and Accent colors
- **Stamp Studio** — choose from 5 seal styles. Gold/Diamond can customize ink color; Diamond adds Custom Upload

**School Metadata (Column 2):**
- School Name, Address, Motto
- Principal's Name and Signature Image upload
- Premium Plan toggle (enables WhatsApp "Digital Envelope" HTML exports)

**Quick tip — Bulk import via JSON:**
Click **📋 Data Templates** in the header to open the drawer. Download `Nexus_Identity_Template.json`, fill it in, upload it back to auto-populate all text fields, then click **Save Identity Shard**.

> The JSON import covers text fields only. Logo, signature image, and stamp style must still be configured manually.

**Database Backup & Restore:**
Protect your data from loss by backing up your database regularly. You can restore an existing backup `.sqlite` file at any time by opening the **Data Templates** drawer and using the **Restore Database Backup** section.

📖 **Full guides:** 05-settings-identity-stamp.md · 06-settings-download-templates.md · 23-database-backup-restore.md

</details>

---

## Phase 2 — Academic Structure (Classes)

<details>
<summary><strong>Step 4 · Building Your Class Hierarchy & Arms 🥇</strong></summary>

**Classes must be set up before teachers or students** — the class registry feeds every dropdown across the system.

Navigate to **Classes** in the sidebar:

1. **Class Hierarchy** — Drag chips to set progression order (JSS 1 → JSS 2 → SS 3). This drives Academic Rollover.
2. **Class Arms** — Each level can have multiple arms (Gold, Silver, Bronze). Arms create composite names like `JSS 1 Gold` that appear in all dropdowns.
3. **Max Subjects** — The stable average denominator. Ensures fair averages even when students take different subject counts.
4. **Pass Mark Override** — Override default pass mark per class level.

**Bulk import:** Download `Sample_Classes.csv` from Settings → Data Templates drawer, fill it, and import via the Classes screen header.

📖 **Full guide:** 20-class-management.md

</details>

---

## Phase 3 — People: Teachers & Students

<details>
<summary><strong>Step 5 · Registering Teachers 🟢</strong></summary>

Navigate to **Teachers** in the sidebar. For each teacher:
- Full Name, Phone, Email
- Class Allocation — classes they teach and subjects per class
- Class Host (Form Teacher) designation

**Two ways to register:**
- **Manual** — Click **＋ Add Teacher**, fill the drawer, Save
- **Bulk CSV** — Download `Nexus_Teachers_Template.csv` from the Settings drawer, populate, and import

> **Class_Host** designates a teacher as Form Teacher (class host) for report sign-off. For schools **with arms**, set this to the exact arm class name (e.g. `JSS 1 Gold`). For schools **without arms**, you may use `TRUE` as a shorthand for the first class in the teacher's list. Using `TRUE` when arms are configured is ambiguous — the system will assign the first arm and show a warning. Assigning a host overwrites any previous assignment for that class.

📖 **Full guides:** 09-teacher-registry.md · 21-bulk-data-import.md

</details>

<details>
<summary><strong>Step 6 · Enrolling Students 🟢</strong></summary>

Navigate to **Students** in the sidebar. For each student:
- Full Name, Class (must match a class/arm from Step 4), Registration Number, Gender
- Subjects to be graded on
- Parent/Guardian Name and WhatsApp number (required for Nexus Pulse 🥇)

**Two ways to enrol:**
- **Manual** — Click **＋ Add Student**, fill the drawer, Save
- **Bulk CSV** — Download `Nexus_Students_Template.csv` from the Settings drawer, populate, and import

> Re-importing the same `Student_ID` performs a safe **upsert** — no duplicate profiles created.

📖 **Full guides:** 10-student-enrolment.md · 21-bulk-data-import.md

</details>

---

## Phase 4 — Mobile App Setup

<details>
<summary><strong>Step 7 · Sync Hub & Pairing Mobile Devices 🥈</strong></summary>

Navigate to **Sync Hub**. Both the desktop and the Android device must be on the same Wi-Fi network.

**To pair a device:**
1. Open Sync Hub — note the QR code shown on screen
2. Open the Nexus Mobile App on the Android device, tap **Scan QR**
3. The teacher selects their name; handshake completes
4. The paired device now shows only their assigned classes and subjects

**Standalone Pack:** Supports up to 2 devices in Admin Extension mode — the device sees all classes/students. A 3rd pairing attempt returns an upgrade prompt.

📖 **Full guides:** 07-settings-add-device.md · 08-device-handshake.md · 19-standalone-pack.md

</details>

<details>
<summary><strong>Step 8 · Mobile App Locks & Device Security 🥇</strong></summary>

Configure **Mobile Locks** per device from the Sync Hub to restrict what teachers can do on their paired devices — preventing grade edits after submission, restricting to the current term, or enforcing sync-only mode.

📖 **Full guide:** 20-mobile-locks.md

</details>

---

## Phase 5 — Academic Sessions & Grades

<details>
<summary><strong>Step 9 · Academic Sessions & Auto-Increment 🟢</strong></summary>

Nexus tracks all data by **Session** (e.g. `2025/2026`) and **Term** (1, 2, or 3):

- The current session is set during first setup or via the identity config
- Sessions auto-increment: completing Term 3 → next entries default to the next session's Term 1
- At year-end, trigger **Academic Rollover** (Classes → Global Settings) to promote all students and initialize the new session
- Students in the final class (e.g. SS 3) are auto-moved to Graduated/Archived on rollover — historical records are preserved

📖 **Full guide:** 20-class-management.md (§ Academic Rollover)

</details>

<details>
<summary><strong>Step 10 · Entering Grades (Manual, Mobile Sync & CSV) 🟢</strong></summary>

Grades can enter the system through three paths:

1. **Mobile App sync** — Teachers enter grades on phones; desktop receives them over Wi-Fi when the teacher taps Sync
2. **Bulk CSV** — Download `Sample_Grades.csv` from Students → Settings Drawer, fill one row per student/subject/assessment, import
3. **Manual desktop entry** — Open a student's profile in Students and enter scores directly

Assessment component names (`CA1`, `CA2`, `Exam`) in the CSV must exactly match what is configured in the Print Hub.

📖 **Full guides:** 12-grading-results.md · 21-bulk-data-import.md

</details>

<details>
<summary><strong>Step 11 · Attendance Tracking 🥇</strong></summary>

The **Attendance** module allows teachers to mark daily attendance from mobile devices. Attendance scores can optionally be included in grade computation. Bulk import per-term is available via CSV (Students → Settings Drawer → Import Attendance).

📖 **Full guide:** 11-attendance-mobile.md

</details>

---

## Phase 6 — Reporting: Print Hub & Result Studio

<details>
<summary><strong>Step 12 · Configuring the Print Hub 🟢</strong></summary>

Navigate to **Print Hub**:

1. Select a **Report Card Template** (8 templates, tier-gated):
   - Standalone/Silver: Classic Minimalist, Class Photo
   - Gold: Azure Flex, Compact Summary, Emerald Grid
   - Diamond: Sovereign Cumulative, Crimson Bold, Modernist Slate, Royal Gold
2. Configure **Score Components** — set max marks for CA1, CA2, CA3, Exam (set unused to 0; they are hidden automatically)
3. Toggle optional sections: Class Position, Attendance Summary, Teacher/Principal Comments, Resumption Date
4. Set **Report Scope** — By Class or Entire School
5. Confirm Session and Term → click **Generate Report Cards**

📖 **Full guide:** 13-print-hub-templates.md

</details>

<details>
<summary><strong>Step 13 · Result Studio (Analytics & Positions) 🟢</strong></summary>

**Result Studio** provides a real-time compiled view of class grades, positions, and subject-level rankings before printing. Use it to review results, spot data entry errors, and check class averages before committing to PDF generation.

📖 **Full guide:** 12-grading-results.md

</details>

---

## Phase 7 — Advanced Features

<details>
<summary><strong>Financial Hub — Fee Management 🥇</strong></summary>

Manages student fee records, invoicing, and payment tracking:
- Create and assign fee templates per class
- Track Cleared / Partial / Unpaid status per student
- Generate fee receipts
- Diamond: Fee Shield blocks report card generation for unpaid students

**Bulk Import via CSV:**
Navigate to the **Bulk Import** tab inside the Financial Hub to download templates and import financial records:
- **Fee Structure** (`Class_Name,Item_Name,Amount,Term` columns) — Define billing line items per class.
- **Fee Payments** (`Student_ID,Academic_Session,Term,Amount_Paid,Payment_Method` etc.) — Bulk log student payments.
- **Fee Adjustments** (`Student_ID,Academic_Session,Term,Adjustment_Type,Amount` etc.) — Bulk apply scholarships and waivers.

📖 **Full guide:** 14-financial-hub.md

</details>

<details>
<summary><strong>Nexus Pulse — WhatsApp Notifications 🥇</strong></summary>

Automated WhatsApp report card delivery to parent phones after grade compilation. No printing, no manual distribution — Pulse sends each parent their child's result directly.

> Parent phone numbers must be loaded on student profiles (Step 6).

📖 **Full guide:** 15-nexus-pulse.md

</details>

<details>
<summary><strong>Sovereign Portal — School Website & Parent View 🥇</strong></summary>

Gives your school a live public website at `nexusos.com.ng/<your-slug>` with a school homepage, news, policies, and a Parent Portal where parents view results using the student's registration number.

📖 **Full guides:** 16-sovereign-portal.md · 17-portal-content.md

</details>

<details>
<summary><strong>Portal Content — News Articles & School Policies 🥇</strong></summary>

Publish news articles and official policy documents to the Sovereign Portal using a built-in Markdown editor:
- **News Articles** — Draft announcements, newsletters, or event schedules.
- **School Policies** — Document school rules, calendars, or fee schedules.
- **Dynamic Formatting** — Content supports Markdown headers, lists, and tables, stored in `school_config` and rendered immediately on parent smartphones.

📖 **Full guide:** 17-portal-content.md

</details>

<details>
<summary><strong>Nexus Scholar — AI Academic Analytics 💎</strong></summary>

AI-powered insights layer: at-risk student flagging, subject-level class weakness detection, WAEC readiness scoring, and predictive grade trajectories. Available on Diamond plan.

</details>

<details>
<summary><strong>CBT Arena — Computer-Based Testing 💎</strong></summary>

Run secure, offline-first computer-based exams over the local school network:
- **Question Ingestion** — Populate your Question Banks in three ways:
  - **Manual Entry** — Add questions option-by-option.
  - **Bulk CSV Import** — Download the spreadsheet template (`nexus_question_import_template.csv`) from the *Add Question* modal and upload populated sheets.
  - **AI Scholar Ingestion** — Drag and drop question papers (`.pdf`, `.docx`, `.txt` up to 15MB) into the Question Studio to auto-extract options and answers locally.
- **Exam Deployment** — Choose duration, target classes, and available computer counts. The system auto-calculates batches and generates one-time access tokens.
- **Student Access** — Students log into the local portal via browser (no internet required).
- **Anti-Collusion** — Features seeded fisher-yates question/option shuffles, temporal batch locks, identity-bound single-use tokens, and custom result blackout options.
- **Direct Grade Ingestion** — Deployed exam scores sync directly to the student grade ledger upon submission.

📖 **Full guide:** 18-cbt-arena.md

</details>

---

## Coming Soon

<details>
<summary><strong>⚡ Live Quiz Arena — Gamified Hall Quiz System 💎</strong></summary>

A local, internet-free gamified quiz competition system for school events:

- Admin laptop runs the **Host Stage** — projected onto a hall screen or TV
- Contestants join by scanning a QR code on their phone (opens contestant view in browser — no app install, no internet)
- Real-time animated scoreboard updates as contestants answer
- Buzzer button support for fastest-finger rounds

> Live Quiz Arena is the **only** "Coming Soon" feature scoped for near-term V2 rollout. Diamond plan. ETA: V2 Phase R3.

</details>

---

## Import Quick Reference

<details>
<summary><strong>📋 All Import Templates at a Glance</strong></summary>

| Template | Format | Location | Tier |
|---|---|---|---|
| School Identity Config | `.json` | Settings → Data Templates (drawer) | All |
| Teachers & Class Hosts | `.csv` | Settings → Data Templates (drawer) | All |
| Students & Parent Contacts | `.csv` | Settings → Data Templates (drawer) | All |
| Classes & Arms | `.csv` | Classes screen header | Gold+ |
| Grades | `.csv` | Students → Settings Drawer | All |
| Attendance | `.csv` | Students → Settings Drawer | Gold+ |
| Fee Structure | `.csv` | Financial Hub → Bulk Import (tab) | Gold+ |
| Fee Payments | `.csv` | Financial Hub → Bulk Import (tab) | Gold+ |
| Fee Adjustments | `.csv` | Financial Hub → Bulk Import (tab) | Gold+ |
| Portal News / Policy | Markdown | Portal Content screen | Gold+ |
| CBT Question Banks | `.pdf`, `.docx`, `.txt` | CBT Arena → Question Studio | Diamond |

**Import order for first-time setup:**
1. **Classes & Arms** (teachers/students reference class names — must exist first)
2. **Teachers**
3. **Students** (grades/payments/adjustments reference student profiles)
4. **Grades**
5. **Attendance**
6. **Fee Structure** (must be set up before logging transactions)
7. **Fee Payments & Adjustments**
8. **CBT Question Banks** (via local AI extraction in Question Studio)
9. **Portal Content** (Markdown news announcements and school policies)

📖 Full admin guide: 21-bulk-data-import.md
📖 Developer reference: 22-import-developer-reference.md

</details>

---

## V2 Development Status

<details>
<summary><strong>🚀 Version 2 Tracker — Completed & Pending Initiatives</strong></summary>

Completed items from the [V2 Development Tracker](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/docs/tasks/version2_dev.md):

| Initiative | Status |
|---|---|
| React Migration (Phase R0–R1) — all 12 views | ✅ Done |
| Test Suite — 28 Vitest tests (grading, ranking, scoring, attendance) | ✅ Done |
| Standalone Pack — tier gate, 2-device Admin Extension, feature locks | ✅ Done |
| Class Arms Architecture — class_arms table, CSV import, composite names | ✅ Done |
| Classes CSV Import — hierarchy, arms, Max Subjects, Pass Mark | ✅ Done |
| Identity JSON Import — template download/upload in Settings drawer | ✅ Done |
| Settings drawer refactor — Data Templates moved to slide-in drawer | ✅ Done |
| Gold tier "Manage Plan" button in About screen | ✅ Done |
| In-app License Management — import + activate from About (active plan) | ✅ Done |
| Reset All Data — sudo PIN + backup/delete modal + Pulse redirect | ✅ Done |
| Documentation — Admin Guides 01–22 + Dev Reference (synced to nexusos) | ✅ Done |
| Master School Setup Guide (this document) | ✅ Done |

Pending — next build cycle:

| Initiative | Status |
|---|---|
| CBT Exam Automation (batch deploy, seeded shuffle, batch windows) | 🔄 Planned |
| Activity Log & Device Ledger (Standalone attribution + RBAC foundation) | 🔄 Planned |
| Persistent Device Revocation (SQLite-backed, survives restarts) | 🔄 Planned |
| RBAC — multi-admin roles (Bursar, Form Teacher, Result Clerk, IT Admin) | 🔄 Planned |
| Technician Console — scoped license generation for field technicians | 🔄 Planned |
| Live Quiz Arena | ⏳ Coming Soon (V2 Phase R3) |

</details>

---

*Last updated: June 2026 · All 22 guides live in `private_engine/docs/guides/` and mirrored to `nexusos/docs/guides/`*
