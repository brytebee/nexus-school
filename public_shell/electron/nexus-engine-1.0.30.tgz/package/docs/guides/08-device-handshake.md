# Nexus School OS: Connecting a Teacher's Mobile Device (The Handshake)

This guide explains how teachers pair their Android phones to the Nexus Desktop Hub for the very first time — and how the sync connection is established securely over local school Wi-Fi.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

The **Nexus Device Handshake** is the one-time pairing process that securely links a teacher's Android phone to your school's Desktop Hub. Once completed, the teacher's phone can sync attendance records, grade entries, and student data directly to the central database — offline, fast, and privately.

---

## 1. Prerequisites

Before starting the pairing process:

- ✅ The Nexus Desktop Hub must be running on the admin's Mac.
- ✅ Both the admin's laptop **and** the teacher's phone must be connected to the **same school Wi-Fi network**.
- ✅ The **Nexus Mobile App** must be installed on the teacher's Android device (available on the Google Play Store).

---

## 2. Initiating the Pairing from the Desktop

1. Open Nexus School OS on the admin desktop.
2. Navigate to **Settings → Terminal Architecture**.
3. Click **Add New Device**.
4. A **Sync QR Code** will appear on screen — this code encodes the Hub's local IP address and a one-time secure session token.

> [!IMPORTANT]
> This QR code expires after **5 minutes** for security. If it expires, click **Refresh QR** to generate a new one.

---

## 3. Scanning the QR Code on the Teacher's Phone

1. On the teacher's Android phone, open the **Nexus Mobile App**.
2. Tap **Connect to School Hub** on the welcome screen.
3. Tap **Scan Hub QR Code**.
4. Point the phone camera at the QR code displayed on the desktop screen.
5. The app instantly reads the connection parameters and initiates the handshake.

---

## 4. Completing the Pairing on the Desktop

Within seconds of scanning, the admin's desktop screen will update:

- The QR code is replaced with a **"New Device Detected"** card showing the phone's model name.
- The admin selects **which teacher** to assign this device to from the dropdown.
- Click **Authorise & Pair**.

The teacher's phone receives an instant confirmation: **"Successfully connected to [School Name] Hub"**.

---

## 5. What Happens After Pairing

- The teacher's phone now appears in the **Active Terminals** list in Settings.
- The teacher can immediately begin using the Nexus app to take attendance, enter grades, and view their class roster — all synced in real time to the Hub.
- No internet is required. All data travels directly between the phone and the Hub over local Wi-Fi.
- **Lock Control Policies**: The school administrator can enforce immediate or scheduled locks for registration, grades, and attendance entry directly from the Desktop Hub settings panel. These locks are checked during sync and are enforced on mobile terminals both online and offline (see the **Mobile Terminal & Policy Locks** guide).

---

## Tier Availability

* **Standalone Pack**: Up to 2 Admin Extension devices. The Sync Hub shows a single "Generate Admin QR" button (no teacher dropdown). The mobile device receives the full school roster and can enter grades for any class.
* **Silver Tier**: Unlimited teacher-tied device pairings. Teacher selected from dropdown before QR generation.
* **Gold Tier**: Full QR-code device pairing for up to 10 teacher terminals.
* **Diamond Tier**: Unlimited pairings with remote management via the Always-On cloud portal.
