# Nexus School OS: Taking Attendance on the Mobile App

This guide explains how class teachers use the Nexus Mobile App to mark daily attendance for their students — and how those records sync instantly to the Desktop Hub.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete. This video will show a **side-by-side view** — the teacher marking attendance on their phone on the left, and the desktop attendance dashboard updating in real time on the right.

---

## Overview

In Nexus, attendance is taken by the class teacher directly on their Android phone, without needing internet access. All records are stored locally on the device and synced to the school's central Hub the moment the phone reconnects to the school Wi-Fi — fully automatic and transparent.

---

## 1. Opening the Attendance Register on Mobile

1. The teacher opens the **Nexus Mobile App** on their Android phone.
2. They tap **Attendance** from the home navigation.
3. The app automatically loads the register for their **assigned class** and **today's date**.

> [!NOTE]
> Teachers only see the classes and roles assigned to them by the admin in the Desktop Hub. A form teacher sees their form class register. Subject teachers see their subject roll call.

---

## 2. Marking Students Present or Absent

The register displays every student in the class in a scrollable list. For each student, the teacher taps:

- ✅ **Present** — Student is in class.
- ❌ **Absent** — Student did not attend.
- 🕐 **Late** — Student arrived after roll call (Diamond tier).

The interface is designed for speed — a full class of 40 students can be marked in under 60 seconds.

---

## 3. Submitting the Register

1. After marking all students, the teacher taps **Submit Register**.
2. The app confirms: *"Attendance for JSS1 Gold saved. Will sync when connected to Hub Wi-Fi."*
3. When the phone is in range of the school's Wi-Fi, the records sync automatically to the Desktop Hub.

---

## 4. Viewing Attendance on the Desktop Hub

The school admin can view all synced attendance data in real time:
1. Open the Central Desktop App.
2. Navigate to **Attendance** in the left sidebar.
3. Select the target class using the searchable Combobox.
4. Select the date and term to view the daily register.
5. Summary statistics (e.g. *Present: 37 / 40, Absent: 3*) are shown at the top of the table.

---

## 5. How Attendance Feeds Into Report Cards

At the end of the term, when the admin generates report cards in the **Print Hub**, Nexus automatically calculates each student's **attendance percentage** and includes it on the report card (e.g. *Total Days: 55 | Days Attended: 52 | Attendance: 94.5%*).

---

## Tier Availability

* **Silver Tier**: Manual attendance tracking only (admin logs directly in the desktop UI). No mobile sync.
* **Gold Tier**: Full mobile attendance sync. Daily Roll Call. Attendance percentage on report cards.
* **Diamond Tier**: Dual-layer attendance (Daily Roll Call + Subject Roll Call). Truancy Radar and automated WhatsApp parent alerts. Late arrival tracking.
