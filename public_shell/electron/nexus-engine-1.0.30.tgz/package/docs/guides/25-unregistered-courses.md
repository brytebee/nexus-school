# Nexus School OS: Managing Course Registration & Unregistered Course Alerts

This guide explains how course registration works, how the system identifies scores entered for unregistered subjects, and how to resolve the resulting amber warning labels on student report cards.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video will be embedded here once production is complete.

---

## Overview

In Nexus School OS, a student's curriculum is defined by their **Registered Subjects**. To prevent errors and ensure report card accuracy, the system cross-references entered scores against each student's registered subject profile. 

If a teacher submits a grade (via the mobile Grader app or the desktop Ledger) for a subject that a student is not officially registered to take, the system flags this as an **Unregistered Course**. Rather than blocking the score and losing the teacher's input, the system displays a clear amber warning badge next to the subject on report previews and exports.

---

## 1. How Unregistered Courses Occur

An unregistered course flag occurs under the following scenarios:
1. **Teacher Score Submission**: A classroom teacher enters assessment grades for a student in a subject that was not selected for that student during enrollment.
2. **Bulk CSV Grade Imports**: A grades spreadsheet is imported via the desktop settings drawer, containing scores for subjects that do not match the student's registered subject list.
3. **Curriculum Changes**: A student is moved to a new class or has their registered subjects modified after grades have already been recorded for a previous subject.

---

## 2. Identifying Unregistered Course Alerts

When a score is recorded for an unregistered subject, the system flags it on key administrative screens:

### 2.1 The Ledger & Result Studio
In the Result Studio and student grade drawers, the subject row will display an amber warning label:
`⚠️ UNREGISTERED`

### 2.2 Report Cards & PDF Exports
When compilation runs:
- The subject row on the student's printable report card displays a distinct amber label next to the subject name.
- A warning message is shown in the compiler summary: `[Warning] Student Student_Name has scores for unregistered subject Subject_Name`.
- This ensures administrators review and fix registration issues before printing or dispatching reports to parents.

---

## 3. Resolving Unregistered Course Alerts

There are two methods to resolve an unregistered course alert:

### Method A: Register the Subject (Recommended)
If the student is indeed taking the course:
1. Navigate to the **Students** list.
2. Click on the student's name to open their detail drawer.
3. Scroll to the **Registered Subjects** section.
4. Click the check box next to the subject to register it.
5. Click **Save Student Profile**. 
6. Recompile reports; the amber warning will disappear, and the subject will render as a fully registered course.

### Method B: Delete or Modify the Score
If the score was entered in error:
1. Navigate to the **Students** detail drawer or **Result Studio**.
2. Locate the subject marked `⚠️ UNREGISTERED`.
3. Clear the score fields or delete the score entry.
4. Once no score exists for the unregistered subject, the alert will clear.

---

## Tier Availability

Course registration and unregistered course warning labels are **standard infrastructure features available on all tiers** (Standalone, Silver, Gold, Diamond). Protecting report card data integrity is a core safety standard of the Nexus Sovereign Shield.
