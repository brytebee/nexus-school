# Nexus School OS: Class Management & Academics Configuration

This guide explains how to use the Classes dashboard to manage the school's class hierarchy, configure classroom arms, set up stable average calculation rules, and perform academic rollover transitions.

> [!NOTE]
> **Video Guide**: A 4K walkthrough video showing the Classes configuration view, adding class arms, and adjusting the global hierarchy is embedded in this guide slot in the application.

---

## Overview

The **Classes** screen centralizes your school's structural organization and academic rules. Instead of hardcoded text fields, Nexus uses a unified classes registry. This registry populates the searchable Combobox and MultiSelectCombobox elements across the entire ecosystem, ensuring consistent class allocations, student records, and fee invoicing.

---

## 1. Class Hierarchy & Drag-to-Reorder

The school class hierarchy defines the sequence of classes (from lower grades to upper grades) in your institution.

1. Navigate to **Classes** in the left sidebar.
2. In the **Global Settings** panel, you can view the active class hierarchy order.
3. Click and drag class level chips (e.g. `JSS 1`, `JSS 2`, `JSS 3`, `SS 1`) to change their logical progression.
4. Changing this order updates academic progression throughout the app, including the academic rollover.

---

## 2. Managing Class Arms

Each class level can have multiple specific divisions or "arms" (e.g. `Gold`, `Silver`, `Blue`).

1. Select a class from the hierarchy grid to open its card.
2. Under the **Arms** section, you will see a chip list of active arms.
3. To add a new arm, type its name in the input field (e.g. `Bronze`) and click **Add Arm** (or press Enter).
4. The system will automatically create the composite class name (e.g. `JSS 1 Bronze`) and add it to the searchable dropdown selections throughout the system.
5. To remove an arm, click the `×` on its chip.

---

## 3. Stable Average Denominator

In many traditional software packages, a student's terminal average is computed by dividing their total score by the number of subjects *they registered for*. This causes issues when some students take fewer subjects than others (e.g. they get a higher average despite doing less work).

Nexus solves this using a **Stable Average Denominator** configured per class level:

1. On the **Classes** screen, select the target class card.
2. Locate the **Max Subjects** field.
3. Input the maximum number of subjects allowed/offered for that grade level (e.g., `12` subjects).
4. **How it is used**: When the system computes termly reports, it divides the student's total score by this *Max Subjects* setting rather than their individual registered count, ensuring stable, fair average calculations and accurate class positions.

---

## 4. Academic Rollover

At the end of an academic session, the **Academic Rollover** utility automates the promotion of all students to the next class level in the hierarchy:

1. Click **Classes** → open **Global Settings**.
2. Locate the **Academic Rollover** section.
3. The system will show a preview of promotions based on the active class hierarchy:
   - Students in `JSS 1` promote to `JSS 2` (matching arms where possible).
   - Students in the final grade (e.g. `SS 3`) are automatically moved to **Graduated/Archived** status.
4. Click **Proceed with Rollover**.
5. Once confirmed, all student profiles are instantly updated in the database, and a new academic session is initialized.

---

## Tier Availability

* **Silver Tier**: Basic class list and hierarchy editing.
* **Gold Tier**: Dynamic class arms, custom hierarchy ordering, and Stable Average Denominator calculation.
* **Diamond Tier**: All Gold features plus the automated Academic Rollover assistant, and multi-term average denominators.
