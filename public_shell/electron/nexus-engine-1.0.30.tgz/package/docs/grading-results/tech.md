# Technical Architecture: Academic Grading and Results Compiler

This document details the engineering architecture of the Nexus School OS results compiler and the grading data structure.

---

## 1. Database Schema

Academic records, continuous assessments (CAs), and exam scores are stored in a relational SQLite structure.

```sql
-- Represents student subject scores for a specific term
CREATE TABLE academic_records (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    subject_id VARCHAR(64) NOT NULL,
    class_id VARCHAR(64) NOT NULL,
    term VARCHAR(16) NOT NULL,            -- "First Term", "Second Term", "Third Term"
    academic_session VARCHAR(16) NOT NULL,  -- e.g., "2025/2026"
    ca_1 REAL DEFAULT 0,                  -- CA Score 1 (e.g. max 15)
    ca_2 REAL DEFAULT 0,                  -- CA Score 2 (e.g. max 15)
    ca_3 REAL DEFAULT 0,                  -- CA Score 3 (e.g. max 10)
    exam REAL DEFAULT 0,                  -- Exam Score (e.g. max 60)
    total REAL GENERATED ALWAYS AS (ca_1 + ca_2 + ca_3 + exam) STORED,
    grade VARCHAR(2),                     -- Auto-calculated on save: "A", "B", "C", etc.
    comment TEXT,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(subject_id) REFERENCES subjects(id)
);

-- Configures grading scale boundaries per school
CREATE TABLE grading_scales (
    id VARCHAR(64) PRIMARY KEY,
    min_score REAL NOT NULL,              -- Minimum percentage for this grade (e.g., 85.0)
    max_score REAL NOT NULL,              -- Maximum percentage (e.g., 100.0)
    grade VARCHAR(2) NOT NULL,            -- "A+", "A", "B", etc.
    remark VARCHAR(32) NOT NULL,          -- "Excellent", "Very Good", etc.
    points INTEGER DEFAULT 0              -- Grade points for GPA calculations
);
```

---

## 2. Compilation Pipeline: `report-compiler.js`

The `report-compiler.js` service parses, validates, aggregates, and renders student academic profiles.

### Architectural Flow of Compilation

```mermaid
graph TD
    A["1. Query Configs & Student Records"] --> B["2. Aggregate Cumulative Averages"]
    B --> C["3. Calculate Student Class Positions"]
    C --> D["4. Inject Dynamic Comments & Signatures"]
    D --> E["5. Run Fee Shield Gates"]
    E --> F["6. Render Handlebars to HTML string"]
    F --> G["7. Pipe to Headless Chrome (Puppeteer)"]
    G --> H["8. Export Output PDF Buffer"]
    style A fill:#1e293b,stroke:#3b82f6,color:#fff
    style H fill:#0f172a,stroke:#10b981,color:#fff
```

### Key Logic Steps in Compilation

1. **Cumulative Aggregation**: The compiler queries all records for the student across all terms of the session to build side-by-side comparative datasets (useful for the `Sovereign Cumulative` template).
2. **Ranking & Positions**: Positions in class are calculated dynamically via a dense-ranking SQLite window function, grouping by `class_id` and summing the student's combined subject scores.
   ```sql
   SELECT student_id,
          SUM(total) AS aggregate_score,
          RANK() OVER (PARTITION BY class_id ORDER BY SUM(total) DESC) as position
   FROM academic_records
   WHERE term = ? AND academic_session = ?
   GROUP BY student_id;
   ```
3. **Dynamic Comment Injection**: The compiler evaluates student aggregates against the `grading_scales` database to pick appropriate rule-based templates if a teacher has not written a manual review.

---

## 3. PDF Generation via Headless Chrome

Nexus uses an embedded Puppeteer/headless Chromium instances configured for absolute reliability inside local, offline operating environments:

* **No External Assets**: To work offline, all CSS styles, custom fonts, and images (school logos) are converted into static, inline declarations or Base64 URI strings before injecting into the template.
* **Layout Isolation**: Each student's report is wrapped in an isolation container with explicit print breaks:
  ```css
  .report-page-container {
      page-break-after: always;
      break-inside: avoid;
  }
  ```
* **PDF Options**: The compiler spawns Chrome with specific parameters:
  ```javascript
  const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '10mm', right: '10mm', bottom: '10mm', left: '10mm' },
      preferCSSPageSize: true
  });
  ```

---

## 4. Custom Colors & Layout Reflow

Diamond-tier licensing allows schools to inject custom brand colors directly into report cards.

### Color Injection Architecture
1. In the Print Hub UI, admins configure primary, secondary, and accent colors.
2. These hex values are written to `school_term_config`.
3. During compilation, these variables are injected into the Handlebars context:
   ```javascript
   const context = {
       student: studentData,
       config: {
           primary_color: termConfig.primary_color || "#3b82f6",
           secondary_color: termConfig.secondary_color || "#1e293b",
           font_family: termConfig.report_font || "Outfit"
       }
   };
   ```
4. In the Handlebars template, a block of CSS custom properties governs the theme:
   ```html
   <style>
       :root {
           --primary-color: {{config.primary_color}};
           --secondary-color: {{config.secondary_color}};
           --font-family: '{{config.font_family}}', sans-serif;
       }
   </style>
   ```
   This architecture ensures the layout auto-adapts instantly to changes without template code manipulation.
