# Nexus School OS: Academic Grading and Results Guide

Welcome to the Nexus Academic Grading and Results Module! This guide will explain how to configure termly grading, design beautiful academic report sheets using our premium templates, and manage comments to deliver an exceptional results experience to your parents.

---

## Overview

In Nexus, grading and results computation is entirely automated. Instead of teachers manually averaging scores, computing positions, and hand-writing comments on hundreds of paper sheets, teachers enter grades into their portals or classroom devices, and Nexus instantly compiles elegant, print-ready, professional report cards.

---

## 1. The 8 Premium Report Card Templates

Nexus features **8 beautifully engineered report card layouts** matching different school aesthetics. You can switch between these instantly in the **Print Hub** with a single click — all student data will dynamically reflow to fit the chosen design.

| Template Name | Design Philosophy | Best For |
| :--- | :--- | :--- |
| **Azure Flex** | Sleek corporate blue, clean grid structure, compact layout. | Modern schools with a professional identity |
| **Sovereign Cumulative** | Elite dark navy themes, deep headers, displays multiple prior term averages side-by-side. | Academically rigorous schools tracking termly growth |
| **Emerald Grid** | Rich forest green accents, spacious tables, emphasized signature panels. | Traditional, prestigious institutions |
| **Classic Minimalist** | Clean black-and-white, zero border distractions, high legibility. | Schools focused on ink saving and crisp photocopies |
| **Crimson Bold** | Vibrant warm burgundy tones, bold subject cards, stylized performance gauges. | Active, sports-and-arts integrated academies |
| **Modernist Slate** | Glassmorphism-inspired borders, rounded cards, subtle gray gradients. | International-standard curricula and primary sections |
| **Royal Gold** | Deep royal purple and gold trim, ornate headers, prominent principal comments. | Premium, high-end private colleges |
| **Compact Summary** | Condensed single-page view, dense data density, perfect for quick interim term reports. | Mid-term progress sheets and performance summaries |

---

## 2. Dynamic Comments and Form Mentor Profiles

A great report card is personal. Nexus allows form teachers and principals to inject custom comments that make every parent feel seen and valued.

### A. Automatic Comment Generators
For large classrooms, admins can set up **Rule-Based Comments**. The system automatically selects a warm, descriptive comment based on the student's final average:
* **Over 90%**: *"An exemplary student who consistently demonstrates outstanding academic leadership."*
* **70% to 89%**: *"An excellent term's work. Shows strong understanding and a highly commendable work ethic."*
* **50% to 69%**: *"A good effort, but there is room for improvement. With more focused study, higher grades are within reach."*

### B. Form Mentor and Principal Sign-off Profiles
Every report sheet includes custom signature panels. Administrators can upload digital signatures and configure individual profiles:
* **Form Mentor (Class Teacher)**: Manages class registers, writes daily behavioral reviews.
* **Principal / Head of School**: Controls global school seals and final promotion status.

---

## 3. How to Generate Report Cards

1. Open the **Print Hub** on the desktop app.
2. Select your target **Session** and **Term** (e.g. *2025/2026 - First Term*).
3. Select the **Class** (e.g. *JSS 1 Gold*).
4. Select one of the **8 Premium Templates** from the dropdown.
5. Choose whether to show attendance, behavior metrics, or positions via the configuration toggles.
6. Click **Generate PDFs**. All report cards will be compiled instantly into a single print job.

---

## 4. Tier Availability

* **Silver Tier**: Core grading (continuous assessments + exams), automated grade scale calculations, access to the **Classic Minimalist** template.
* **Gold Tier**: Dynamic comments system, Form Mentor signatures, and access to 4 premium templates (**Azure Flex**, **Emerald Grid**, **Classic Minimalist**, **Compact Summary**).
* **Diamond Tier**: Full unlocks! All 8 premium templates, dynamic multi-term cumulative averages side-by-side (Sovereign style), custom HTML color injecting, and PDF batch exporting to Google Drive.
