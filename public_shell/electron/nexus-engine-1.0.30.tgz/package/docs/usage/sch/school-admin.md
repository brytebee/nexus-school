# 🗺️ Nexus School OS — School Administrator Usage Guide

Welcome to Nexus School OS! This guide is written for school administrators and owners to help you understand the simple step-by-step process of purchasing, activating, and running your school management system offline.

---

## The Journey: From Portal to Classroom

```mermaid
graph LR
    A["1. Configure & Quote"] --> B["2. Secure Checkout"]
    B --> C["3. Download App & License"]
    D["4. Activate Offline"] --> E["5. Run Daily! 🎉"]
    C --> D
    style A fill:#1e293b,stroke:#3b82f6,stroke-width:2px,color:#fff
    style B fill:#1e293b,stroke:#3b82f6,stroke-width:2px,color:#fff
    style C fill:#1e293b,stroke:#3b82f6,stroke-width:2px,color:#fff
    style D fill:#1e293b,stroke:#10b981,stroke-width:2px,color:#fff
    style E fill:#064e3b,stroke:#10b981,stroke-width:2px,color:#fff
```

### Quick Reference: 5-Step Process

| Step | Phase | Action | Location / Context |
| :--- | :--- | :--- | :--- |
| **1** | **Configure & Quote** | Select student count and terms; view total price. | Online Portal (`/portal/billing`) |
| **2** | **Secure Checkout** | Make payment using Bank Transfer, Card, or USSD. | Secure Paystack Checkout |
| **3** | **Get License & App** | Download your `license.nexus` and the desktop app. | Portal Downloads or Email Inbox |
| **4** | **Install & Activate** | Install the desktop app and drop `license.nexus` inside. | Local Computer (Offline) |
| **5** | **Run Daily** | Manage students, attendance, grades, and fees offline. | Local Classroom (No Internet) |

---

### Step 1: Choose Your Plan & Request a Quote
1. Log into your account on the **Nexus Portal**.
2. Go to the **Billing** section.
3. Enter your current **Student Count** and select the subscription tier that best fits your school:
   * **Silver**: Core school management (attendance, basic student records).
   * **Gold**: Includes advanced grading, SMS notifications, and finance features.
   * **Diamond**: Unlocks the full suite, priority support, and custom integrations.
4. Select the school terms you wish to license (e.g. *Term 1*, *Term 2*, and/or *Term 3*). 
5. Review the instant price calculation shown on the screen.

### Step 2: Pay Securely via Paystack
1. Click the **"Pay Now"** button. You will be securely redirected to the Paystack checkout page.
2. Choose your preferred payment method:
   * **Debit/Credit Card**: Enter your card details to pay instantly.
   * **Bank Transfer**: Paystack will show a temporary bank account number. Simply transfer the exact amount from your bank app.
   * **USSD / Mobile Money**: Follow the on-screen prompts for your phone.
3. *Note: Transaction processing fees are automatically added to the checkout total, so your school's bank statement matches the raw licensing price.*

### Step 3: Receive Your License File and Install the App
1. As soon as your payment is processed, you will see a success page on the portal.
2. Check your school's registered email inbox. You will find:
   * A payment receipt invoice.
   * A digital license file attached called `license.nexus`. Download this file to your computer.
3. Visit the **Downloads** section in the Nexus Portal and download the **Nexus School OS** desktop application (compatible with Windows and macOS).

### Step 4: First-Time Offline Activation
1. Double-click the installer you downloaded to install **Nexus School OS** on your admin computer.
2. Launch the application. On first start, it will display an **"Activation Required"** screen.
3. **No internet connection is needed for this step.** Drag and drop the `license.nexus` file from your downloads folder directly into the app window.
4. The application will instantly read the license details, show a success message, and activate.

### Step 5: Day-to-Day Operations (100% Offline)
* You are all set! You can now use Nexus School OS to register students, manage attendance, compute grades, print report cards, and track fees.
* All data is stored locally and securely on your own computer. You never have to worry about internet outages or server downtime.

---

## Frequently Asked Questions (FAQ)

#### Do I need internet access to run Nexus School OS?
Only for the initial purchase and download of the application and the license file. Once the app is installed and the `license.nexus` file is uploaded, the software runs 100% offline.

#### What happens if our student count grows beyond our licensed cap?
If your student enrollment increases, you can easily log into the online Nexus Portal, upgrade your cap, make a top-up payment, and download an updated `license.nexus` file to upload into the desktop app.

#### Who do I contact if I have trouble activating my license?
Please reach out to our support team at `support@nexusos.com.ng` or contact your school's onboarding coordinator.
