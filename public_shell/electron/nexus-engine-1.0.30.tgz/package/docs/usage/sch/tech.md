# 🛠️ Nexus School OS — Developer Technical Integration Guide

This document explains the technical architecture behind Nexus School OS pricing, checkout routing, offline cryptography-based licensing, and transaction splits.

---

## 🏗️ System Architecture Overview

```
[nexusos (Portal UI)] ──(Next.js Proxy)──> [nexus-api (Backend Service)]
                                                    │
                                           ┌────────┴────────┐
                                           ▼                 ▼
                                   [Paystack API]     [PostgreSQL DB]
```

The system comprises:
1. **Frontend App (`nexusos`)**: Next.js client portal. Orchestrates checkout forms and handles payment status polling.
2. **Backend API (`nexus-api`)**: Central API server. Computes quotes, interfaces with Paystack, issues signed licenses, and handles webhooks.
3. **Desktop App (Client)**: Local Electron/Rust native application. Operates offline and verifies licenses using embedded cryptographic public keys.

---

## 💳 Payment split and Subaccounts

To ensure self-managed financial operations, 100% of revenue from each sub-domain/product is routed directly into specialized Paystack subaccounts.

### 1. Configuration
Set the following environment variables in your deployment environment (`nexus-api`):
* `PAYSTACK_SUBACCOUNT_SCH`: Subaccount code for School OS payments (e.g. `ACCT_xxxxxxxxxx`).
* `PAYSTACK_SUBACCOUNT_MEDIC`: Subaccount code for Nexus Medic payments.
* `PAYSTACK_SUBACCOUNT_BILLS`: Subaccount code for Nexus Utility Bills.
* `PAYSTACK_SUBACCOUNT_FIN`: Subaccount code for Nexus Finance.

### 2. Transaction routing
When a transaction is initialized via `POST /api/billing/initiate`, the route dynamically resolves the product type and appends the subaccount parameter:

```typescript
// Lookup code
let subaccount = process.env.PAYSTACK_SUBACCOUNT_SCH; // or MEDIC, BILLS, FIN...

// Call Paystack
const tx = await paystackInitialize({
  email: body.email,
  amount: body.amount_kobo,
  reference,
  callback_url: `${process.env.NEXUSOS_PORTAL_URL}/billing/callback?ref=${reference}`,
  subaccount,
  bearer: subaccount ? 'subaccount' : undefined, // Subaccount receives 100% minus fees
  metadata: { ... }
});
```

---

## 🔐 Cryptographic Offline Licensing

Nexus apps require 100% offline functionality. To authenticate payments without phone-home checks, we use asymmetric Ed25519 cryptography.

### 1. Key Configuration
* **Private Key** (`NEXUS_LICENSE_SIGNING_KEY`): A 64-byte hex string (128 hex chars) containing the Ed25519 secret key. Configured only on the secure `nexus-api` environment.
* **Public Key**: Embedded inside the desktop application's source code for offline verification.

### 2. License Payload Format
Licenses are signed JSON payloads. The schema is defined as:

```typescript
export interface LicensePayload {
  school_id: string;
  product: 'sch' | 'medic' | 'bills' | 'fin';
  tier: 'silver' | 'gold' | 'diamond';
  student_cap: number;
  licensed_terms: string[]; // e.g. ["2025/2026-T1", "2025/2026-T2"]
  hardware_id?: string | null; // null = provisional (not yet bound to specific computer)
  issued_at: number;   // Unix timestamp (ms)
  valid_until: number; // Unix timestamp (ms)
}
```

### 3. Token Format
The generated license token is a base64url-encoded string following this layout:
```
base64url(JSON_payload) + "." + base64url(signature)
```

### 4. Verification Logic (Offline Client)
The client app performs the following checks:
1. Splits the token at the `.` separator.
2. Verifies the signature of the payload bytes against the embedded public key using `tweetnacl`.
3. Assures `Date.now() < valid_until` to check expiration.
4. If `hardware_id` is present, confirms it matches the machine's hashed local MAC address/hardware fingerprint.

---

## 🔄 Dual-Confirmation Payment Flow

To prevent payments from remaining in a `pending` state due to webhook delivery failures (very common during local development and serverless cold starts), we employ a **dual-confirmation strategy**:

```
[Paystack Checkout]
       │
       ├──────────────────────────────────────────┐
       ▼ (Webhook)                                ▼ (Redirect)
[POST /api/webhook/paystack]              [/portal/billing/callback]
       │                                          │
       │                                          ▼ (Polls status)
       │                                  [GET /api/billing/status]
       │                                          │
       │ (If still pending in DB)                 │ (Calls Paystack Verify API)
       └───────────────────> [fulfillPayment()] <─┘
                                   │
                      ┌────────────┴────────────┐
                      ▼                         ▼
              [Update DB Status]       [Issue & Email License]
```

### 1. Webhook Endpoint (`/api/webhook/paystack`)
* Paystack triggers this asynchronously.
* Validates the signature header (`x-paystack-signature`) using `verifyPaystackWebhook`.
* On `charge.success`, calls `fulfillPayment(reference, metadata)`.
* On `charge.failed`, calls `failPayment(reference)`.

### 2. Status Polling fallback (`/api/billing/status`)
* Client-side callback page polls this endpoint every 3 seconds.
* If the database payment record status is still `pending`, the backend calls `paystackVerify(ref)` to fetch the live transaction details.
* If Paystack reports `success` or `failed`, the backend triggers `fulfillPayment()` or `failPayment()` **synchronously** before returning the response. This ensures instant checkout fulfillment.
