# Nexus School OS — Boot Screen Flow

> **Audience:** Sovereign operators, engine maintainers, and on-site support staff.
> This document explains how the app decides which screen to show at launch,
> the correct first-run sequence a new school should experience, and the production
> bugs discovered and fixed during v1.0.1 QA that disrupted this flow.

---

## 1. Screen Routing Architecture

Electron's `main.js` decides which file to load into the BrowserWindow during
`createWindow()`. There is no client-side router at the lock/activation layer —
the decision is made in Node.js before any HTML is rendered.

### The Decision Tree (v1.x)

```
createWindow()
│
├─ [Early check] Does license.nexus exist in userData?
│    └── NO  → licenseStatus = { locked: true, reason: 'no_license' }
│
├─ [DEV_TEST_LOCK env] Override lock reason for UI testing
│
├─ licenseStatus.locked === true?
│    ├── reason: no_license        → lock.html#invalid    (Import License screen)
│    ├── reason: expired           → lock.html#expired
│    ├── reason: revoked           → lock.html#revoked
│    ├── reason: tampered          → lock.html#tampered   (Integrity Error screen)
│    ├── reason: hardware_mismatch → lock.html#tampered
│    └── reason: trial_end         → lock.html#trial_end
│
├─ DEV_AUTO_LOGIN === 'true'?
│    └── YES → dist/renderer.html  (skips auth — dev only, never in prod)
│
└─ ELSE (valid license, normal launch)
     ├─ Query: SELECT COUNT(*) FROM admin_users
     │    ├── count === 0  → dist/renderer.html?firstRun=1   (Admin Setup Wizard)
     │    ├── count  >  0  → lock.html                       (PIN login screen)
     │    └── DB error     → dist/renderer.html?firstRun=1   (treat as first run)
     │
     └─ [Phase 4, async] Full license verification runs after UI loads
          → Ed25519 signature check → hardware binding → calendar expiry → heartbeat
```

> **Note:** The early license check (step 1) only tests for file existence.
> The full cryptographic verification happens in **Phase 4**, after the window is
> shown, to avoid blocking the UI on startup. The lock screen / setup screen is
> therefore shown optimistically — Phase 4 can still transition to `lock.html#tampered`
> if verification fails after the window is displayed.

---

## 2. Expected First-Run Screen Sequence

This is the intended experience for a new school after receiving their `.nexus` file:

```
1. App launches (no license.nexus found)
         ↓
   lock.html#invalid  →  "No License Found"
   User clicks [Import License File] and selects their .nexus file

2. License imported → app relaunches (app:relaunch IPC)

3. Phase 4 runs:  Ed25519 signature verified ✅
                  hardware_id = null (provisional — not yet bound) ✅
                  → licenseStatus = { locked: false, provisional: true }

4. Boot router runs adminCount query
         ↓
   DB not yet initialised / admin_users empty → catch fires, treated as first-run
         ↓
   dist/renderer.html?firstRun=1  →  <AdminSetupScreen />

5. Admin fills in:
   - Step 1: Admin Name + PIN (min 4 digits, confirmed)
   - Step 2: Security Question + Answer (for PIN recovery)
   - [Create Admin Account]
         ↓
   IPC: app:load-lock  →  mainWindow.loadFile('lock.html')

6. lock.html (default)  →  PIN login screen
   Admin selects their name from dropdown, enters PIN

7. Authenticated  →  mainWindow.loadFile('dist/renderer.html')
   Full React dashboard. License binds hardware_id on first heartbeat sync.
```

---

## 3. Production Bugs Fixed in v1.0.1

Three separate bugs combined to prevent a school from ever reaching step 3 above.
Each is documented here so future developers understand why the code is written
the way it is and do not accidentally revert to the broken patterns.

---

### Bug A — Ed25519 key type `'spki'` with `format: 'raw'` (throws TypeError)

**Commit:** `01eb5c5`
**Location:** `main.js` — `verifyNexusToken()` function
**Symptom:** Every imported license showed **"License Integrity Error"** immediately.

**Broken code:**
```javascript
const keyObj = crypto.createPublicKey({ key: pubKey, format: 'raw', type: 'spki' });
```

`type: 'spki'` refers to a DER-encoded **Subject Public Key Info** structure, which
contains an algorithm identifier prefix before the raw key bytes. Passing a bare
32-byte buffer with this type makes Node.js throw a `TypeError` before any
signature check runs. The exception is caught by the outer `try/catch`, which sets
`reason: 'tampered'` → displayed as "License Integrity Error" on screen.

The key pair itself was always correct — `NEXUS_PUBLIC_KEY_HEX` in `main.js` is
the exact matching pair for the production `NEXUS_LICENSE_SIGNING_KEY`.

**First attempted fix (also incorrect):** changed `type: 'spki'` → `type: 'ed25519'`.

---

### Bug B — `type: 'ed25519'` with `format: 'raw'` is silently ignored

**Commit:** `395e4bb` *(superseded same session)*
**Symptom:** License still failed after Bug A fix. SHA verified — correct binary installed.

Per the Node.js documentation:
> *"`type` is required only if `format` is `'der'` and ignored otherwise."*

When `format: 'raw'`, the `type` field is **silently dropped**. Node.js receives
a 32-byte buffer with no algorithm context, produces an unusable key object, and
`crypto.verify()` returns `false` — so the signature check fails cleanly and
`reason: 'tampered'` is still set.

---

### Bug C — Correct fix: SPKI DER header wrapping

**Final commit:** `395e4bb` (same commit, second iteration, rebuilt)

Node.js crypto **requires** the algorithm context embedded in the key material.
The correct approach for a raw 32-byte Ed25519 public key is to prepend the
12-byte ASN.1 DER SPKI header and import as `format: 'der', type: 'spki'`:

```javascript
// Ed25519 SPKI DER prefix — ASN.1 encoding of:
//   SEQUENCE {
//     SEQUENCE { OID 1.3.101.112 (id-Ed25519) }
//     BIT STRING { [0 unused bits] [32-byte raw key] }
//   }
const SPKI_ED25519_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
const spkiDer = Buffer.concat([SPKI_ED25519_PREFIX, pubKey]);
const keyObj = crypto.createPublicKey({ key: spkiDer, format: 'der', type: 'spki' });
const valid = crypto.verify(null, payloadBytes, keyObj, sigBytes);
```

End-to-end tested: `tweetnacl.sign.detached` sign → `crypto.verify` = `true`.

> ⚠️ **If you ever refactor `verifyNexusToken`:** Do NOT use `format: 'raw'`
> for Ed25519 keys in Node.js crypto. Always use the SPKI DER wrapper above,
> or switch entirely to `tweetnacl.sign.detached.verify()` (same library used
> for signing in nexus-api).

---

### Bug D — First-run `catch` block defaulted to lock screen

**Commit:** `7264eb5`
**Location:** `main.js` — boot router, first-run detection block
**Symptom:** After license passed verification, app showed PIN login on first install
instead of the Admin Setup Wizard.

**Root cause:** The admin-count query runs during `createWindow()`, before Phase 4
initialises the SQLite database. On a fresh install:

```
database.getDb().prepare('SELECT COUNT(*) AS c FROM admin_users').get()
  → throws (table does not exist yet)
  → catch: console.warn only, bootFile stays 'lock.html'
  → User lands on PIN login with zero admins — a dead end
```

**Fix:** The catch block now defaults to the setup wizard:

```javascript
} catch (e) {
  // DB not initialised yet (fresh install) — always treat as first run.
  // Showing the PIN lock screen here would be a dead end (no admin to log in with).
  console.warn('[Boot] Admin count check failed (treating as first-run):', e.message);
  bootFile = 'dist/renderer.html';
  loadOptions = { query: { firstRun: '1' } };
}
```

Any DB failure at this stage definitionally means a fresh install.

---

## 4. Diagnosing Screen Routing Issues

When a school reports landing on an unexpected screen, use this checklist:

### Step 1 — Identify the screen

| Visible screen | Boot target | Probable cause |
|---|---|---|
| "No License Found" / import button | `lock.html#invalid` | `license.nexus` absent in userData |
| "License Integrity Error" | `lock.html#tampered` | Signature verification failed (see Bugs A/B/C) |
| "License Expired" | `lock.html#expired` | Calendar terms expired or `valid_until` passed |
| "License Revoked" | `lock.html#revoked` | License revoked in the portal DB |
| PIN numpad, no admins listed | `lock.html` (default) | First-run catch bug (Bug D) — update the binary |
| Admin setup wizard | `renderer.html?firstRun=1` | ✅ Correct first-run flow |
| React dashboard directly | `renderer.html` | DEV_AUTO_LOGIN active (dev only) |

### Step 2 — Read the console logs

The app logs every boot decision. On Linux, launch from terminal:
```bash
/opt/Nexus\ School\ OS/nexusschoolos
```

Key log lines to look for:
```
[License] No license file found — booting to activation screen.
[Boot] First-run detected — no admins exist. Loading admin setup screen.
[Boot] Admin count check failed (treating as first-run): <error>
[Boot] Defaulting to admin setup screen.
[License] System is LOCKED due to tampered. Loading lock.html#tampered
```

### Step 3 — Verify the build hash

```bash
sha256sum nexusschoolos_1.0.1_amd64.deb
# Compare against the hash in release notes or RELEASE_GOTCHAS.md
```

Builds before commit `395e4bb` → License Integrity Error on any valid license.
Builds before commit `7264eb5` → PIN screen dead-end on first install.

### Step 4 — Clear userData and reimport

If the app state is corrupted or the database is in a bad state:
```bash
# Linux
rm -rf ~/.config/"Nexus School OS"

# macOS
rm -rf ~/Library/"Application Support"/"Nexus School OS"

# Windows (Command Prompt)
rmdir /s /q "%APPDATA%\Nexus School OS"
```

Relaunch → `lock.html#invalid` → import license → correct flow from step 1.

---

## 5. License Token Reference

The `.nexus` file contains a single-line token:
```
base64url(JSON_payload) . base64url(Ed25519_signature)
```

Payload fields (sorted alphabetically — required for deterministic signing):
```json
{
  "hardware_id": null,
  "issued_at": 1720612800000,
  "licensed_terms": ["2025/2026-T1", "2025/2026-T2", "2025/2026-T3"],
  "product": "sch",
  "school_id": "sch_abc123",
  "student_cap": 500,
  "tier": "silver",
  "valid_until": 1751025600000
}
```

| Field | Notes |
|---|---|
| `hardware_id: null` | Provisional — not yet device-bound |
| `hardware_id: "abc…"` | Bound — mismatch = hardware_mismatch lock |
| `tier` | Must be lowercase: `silver`, `gold`, `diamond`, `standalone` |
| `licensed_terms` | Format: `"YYYY/YYYY-T1"` — must match calendar.ts ranges |

Signed with `nacl.sign.detached` (tweetnacl) using 64-byte private key.
Verified in the desktop app with Node.js `crypto.verify` using SPKI-wrapped
32-byte public key (see Bug C).

---

*Last updated: 2026-07-10 | Fixes: commits `395e4bb`, `7264eb5` | Sovereign Ops*
