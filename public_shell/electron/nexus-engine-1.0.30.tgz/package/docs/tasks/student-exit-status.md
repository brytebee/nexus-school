# Student Exit & Status Scenarios

This document specifies the technical and database changes required to handle student exit events (expulsion, withdrawal) and progress anomalies (repeating, demotions). It highlights the initial administrator inquiry and outlines the proceeding discussion and features.

---

## 1. Enquiry & Context
Administrators require a clear answer to: *"What happens to students in the following scenarios?"*
*   **Expulsion**: Removing the student from current-term rosters and tablet syncing without destroying their historical academic and financial records.
*   **Withdrawal**: Parent-initiated exit with read-only record retention.
*   **Repeat**: Retaining a student in their current class hierarchy level (e.g. JSS 1) during session rollover while their peers advance.
*   **Demotion**: Mid-term transition of a student back to a lower class hierarchy level.

Historically, deletion of a student profile resulted in loss of data integrity (past grades, attendance, payments), whereas leaving them active resulted in stale rosters synced to teacher devices.

---

## 2. Database Schema Upgrades
We will add an `enrollment_status` column to the `students` table:
```sql
ALTER TABLE students ADD COLUMN enrollment_status TEXT NOT NULL DEFAULT 'active' 
    CHECK(enrollment_status IN ('active', 'suspended', 'expelled', 'withdrawn', 'graduated'));
```

For compliance and audit trails, all existing tables (`student_records`, `student_attendance`, `fee_transactions`) will preserve references to the student's ID, even when their status changes.

---

## 3. Sync & Roster Filtering
*   **Companion Device Syncing**: The Express LAN sync server (defined in `server.js`) must filter the handshake student payloads. Non-active students (withdrawn, expelled, graduated) will not be sent to teachers' Android tablets during handshake pairing or attendance checks.
*   **Grade Submissions**: If a companion device attempts to sync scores for an inactive student (due to a stale local roster), the sync handler in `server.js` will reject the score event with a soft warning.

---

## 4. Academic Progress Transitions

### A. Rollover Retention (Repeaters)
When the academic session rolls over:
*   Active students are promoted to the next class defined in the class hierarchy.
*   Students flagged as **Repeaters** are retained in their current class configuration.
*   The database records the new session reference (e.g., `2025/2026`) for their new records, leaving their `2024/2025` history intact in `student_records`.

### B. Class Demotions
*   If a student is demoted mid-term, their class assignment is updated.
*   The admin console will prompt the registrar to archive their current-term scores or clear them to start grading afresh in the new class arm.

---

## 5. Roadmap & References
*   This feature is mapped to the V2 cycle (Phase 6 - Student Public Profile & Verified Records).
*   For database migration patterns, see V2 database schema changes in [`docs/tasks/version2_dev.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/docs/tasks/version2_dev.md).
*   For context on school status gates, see active plans in [`nexus_master_plan.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/nexus_master_plan.md).
