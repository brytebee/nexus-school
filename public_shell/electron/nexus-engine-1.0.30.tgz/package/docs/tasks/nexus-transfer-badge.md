# Cryptographic Offline Transfer Badge

This document specifies the design and cryptographic protocol for the "NexusOS Transfer Badge". It captures the administrator inquiry and the subsequent discussion regarding the 3-party verification workflow.

---

## 1. Enquiry & Context
Administrators asked: *"What if we introduce a 'NexusOS Transfer Badge', a QR code that contains student personal and academic records issued by their current school during exits, scanned by the receiving school... What do you think about involving the 3 parties? Sending some form of token to the school via email and/or whatsapp and a completing piece of the puzzle to the parent or student?"*

Manual data entry during student transfers is prone to error and forgery. The Transfer Badge addresses this by creating a secure, tamper-proof, offline-first digital transcript transfer protocol.

---

## 2. 3-Party Split-Token Protocol
To prevent transcript tampering and unauthorized scanning, verification key $K$ (AES-256) is split into two pieces ($K_A \oplus K_B = K$):

1.  **Issuing School**: Generates the badge, encrypts the payload with $K$, and saves $K_B$ on the parent-held badge.
2.  **Parent/Student**: Receives the physical/digital QR badge containing $K_B$ and the encrypted payload.
3.  **Receiving School**: Receives the matching key piece $K_A$ officially from the issuing school via automated Email or WhatsApp (Nexus Pulse).

Neither piece alone can decrypt the student transcript, ensuring zero-knowledge privacy and authentic verification.

---

## 3. Data Capacity & Compression
A standard QR code is limited to 2,953 binary bytes. To fit a student profile offline:
*   **Minimal Payload**: Includes student details (name, DOB, parent contact) and cumulative session grade averages.
*   **Compression**: Serialized via CBOR or MessagePack and compressed using Deflate/Gzip. Reduces payload size to under 800 bytes.

---

## 4. Cryptographic Signatures
*   Every badge is signed using the issuing school's Private Key (ECDSA).
*   The receiving school's Hub validates the signature integrity using the issuing school's Public Key (either verified online via the global Nexus registry or verified offline using trusted certificates).

---

## 5. Intake UI & Mobile App
*   **Admin Scan**: Receiving admin scans the badge via the Admin Mobile App or a connected camera.
*   **Decryption & Verification**: The Hub combines the scanned $K_B$ with the received $K_A$ to decrypt and verify the transcript.
*   **Customization**: The intake screen lets the admin customize the resuming Class & Arm and local Admission ID before clicking "Confirm Intake" to populate the database.

---

## 6. Roadmap & References
*   This module is part of the Gold and Diamond plan companion mobile app features.
*   For details on the Zero-Router LAN syncing hotspot setup and meta integration, see [`nexus_master_plan.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/nexus_master_plan.md).
*   For the sync log database structures and device revocation flows, see [`docs/tasks/version2_dev.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/docs/tasks/version2_dev.md).
