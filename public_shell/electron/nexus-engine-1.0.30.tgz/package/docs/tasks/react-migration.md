# ⚛️ React Migration Strategy
## Nexus School OS · Frontend Architecture Modernisation

> **The Problem:** A 2,506-line `index.html` with inline styles, global functions,
> and tangled feature logic has become the codebase's single biggest liability.
> Every new feature makes it harder to maintain every existing feature.

---

## Why React? (The Honest Case)

| Pain Today | React Solves It By |
|---|---|
| Fee table duplicated in index.html AND portal.html | One `<FeeTable />` component used in both |
| Adding a column to the student table requires editing 4 places | One `<StudentRow />` component |
| `pulse-ui.js` was 28 lines doing nothing — nobody noticed | Components are self-contained, testable units |
| CSS class names clash across 2,500 lines | CSS Modules scoped per component |
| CBT would add another 500+ lines to index.html | A separate `/cbt` React route, fully isolated |
| `showView()` is a global function hiding/showing divs | React Router handles navigation declaratively |
| No shared state — data re-fetched on every view change | React Context: one fetch, shared everywhere |

**What React does NOT change:**
- The Electron IPC layer (`main.js`, `preload.js` — unchanged)
- The `private_engine` backend — completely unchanged
- The SQLite schema — unchanged
- The license and security system — unchanged

The backend is solid. Only the frontend presentation layer changes.

---

## Cardinal Rule: No Big-Bang Rewrite

Rewriting everything from scratch is a 3-month pause in feature delivery.
The strategy is **strangler fig migration**: React components grow around
the existing HTML, view by view. The app ships new features throughout. Nothing breaks.

---

## Technology Stack

| Layer | Choice | Why |
|---|---|---|
| Framework | React 18 | Industry standard |
| Build tool | Vite 5 | Fastest dev server, excellent Electron integration |
| Language | TypeScript | Catches the class of bugs that broke pulse-ui.js |
| Routing | React Router v6 | Matches the current `showView()` mental model |
| Data fetching | TanStack Query | Caching + loading states for IPC calls |
| Styling | CSS Modules + existing CSS variables | Zero visual change, keeps current design |

---

## Phase 0 — Foundation (Week 1, no visible changes)

**Goal:** Get React, Vite, and Electron living together. Don't touch any existing feature.

- Add Vite to the project as the build tool
- Create `/src` folder next to the existing `/js` folder
- Vite outputs a built `renderer.html` that Electron can load
- The existing `index.html` stays completely functional in parallel
- Add a `.env` toggle:
  - `USE_REACT_UI=false` → loads `index.html` (current behaviour, instant rollback)
  - `USE_REACT_UI=true` → loads `renderer.html` (new React app)

### Project Structure After Phase 0
```
public_shell/electron/
  ├── index.html          ← OLD (untouched, still works)
  ├── renderer.html       ← NEW (built by Vite)
  ├── main.js             ← unchanged
  ├── preload.js          ← unchanged
  ├── src/                ← NEW React source
  │   ├── main.tsx
  │   ├── App.tsx
  │   ├── router.tsx
  │   ├── components/
  │   ├── views/
  │   ├── hooks/
  │   └── context/
  └── js/                 ← OLD JS modules (kept until migration complete)
```

---

## Phase 1 — Design System & Shared Components (Week 2)

Build the atoms everything else uses. No feature views yet.

### Components to Build First

**`<DataTable />`** — The most duplicated pattern in the codebase. Student
table, teacher table, attendance register, fee roster, results table — all
the same: header, rows, action buttons, pagination. One component serves all.

**`<Modal />`** — Record Payment, Financial Settings, Student Edit — all
modals. One component with `title`, `children`, `onClose`.

**`<StatusBadge />`** — The cleared/partial/unpaid pill. Used in fee roster
and WhatsApp bot message. One source of truth for colours.

**`<ViewHeader />`** — Top bar with title, subtitle, and action buttons.
Every view has one. Currently 8+ identical copies in index.html.

**`<NavSidebar />`** — Navigation with tier-based visibility. Currently
scattered across boot.js. As a component, it's one `if (tier >= 'Gold')`
check per nav item.

**`<LoadingState />` and `<EmptyState />`** — "No records found" and spinner.
Each view currently has its own copy.

### The IPC Hook Pattern

Every React component that needs Electron data uses a custom hook:
```
useIdentity()     → window.electronAPI.getIdentity()
useTermConfig()   → window.electronAPI.getTermConfig()
usePulseStatus()  → subscribes to window.electronAPI.onPulseStatus()
useLicense()      → provides tier everywhere via Context
```

These replace scattered `electronAPI.` calls across every JS module.
They also enable caching: `useIdentity()` fetches once on mount, shares
via Context — no more per-view re-fetch.

---

## Phase 2 — Migrate Views (Weeks 3–8)

One view per 2–3 days. Simpler, self-contained views go first.

### Migration Order

| Order | View | Why This Order |
|---|---|---|
| 1 | About | Static content. Zero IPC calls. 30-minute confidence builder. |
| 2 | Settings (Identity Forge) | One form, one save. Good hook exercise. |
| 3 | Guardian Shield | Display cards. Tests identity + pulse hooks. |
| 4 | Nexus Pulse | Tests pulse status listener and cloud bridge UI. |
| 5 | Attendance | Tests class/date filter + table pattern. |
| 6 | Financial Hub | Tests paginated data table + modal pattern. |
| 7 | Sync Hub | Tests QR component. |
| 8 | Print Hub | Tests complex filter strip + PDF generation. |
| 9 | Result Studio | Similar to Print Hub, more complex scope filters. |
| 10 | Teachers | CRUD table. Tests add/edit/delete modal pattern. |
| 11 | Students | Most complex. Largest table. Subject assignment logic. |
| 12 | Dashboard | Depends on data from all views. Build last. |

### The Migration Pattern (Per View)
1. Create `/src/views/FeesView.tsx`
2. Move HTML markup into JSX
3. Replace `document.getElementById` calls with `useState`
4. Replace `electronAPI.*` calls with the appropriate hook
5. Add route in `router.tsx`: `<Route path="/fees" element={<FeesView />} />`
6. Test thoroughly
7. Remove old `div#view-fees` block from `index.html`
8. After all views migrated, delete `index.html`

---

## Phase 3 — Portal Migration (Week 9)

`portal.html` becomes a separate Vite entry point, sharing the
design system components from Phase 1:

```
src/portal/
  ├── main.tsx
  ├── PortalApp.tsx
  └── views/
      ├── PortalLogin.tsx
      ├── PortalDashboard.tsx
      ├── PortalResults.tsx
      ├── PortalAttendance.tsx
      └── PortalFees.tsx
```

The `<DataTable />` built for the admin roster renders parent results
without any changes. Shared component library pays off immediately.

---

## Phase 4 — CBT as First-Class React App (Diamond)

CBT is built in React from day one — never added to `index.html`:

```
src/cbt/
  ├── ExamClient.tsx        ← student-facing exam interface
  ├── InvigilatorDash.tsx   ← admin live view
  └── QuestionBank.tsx      ← question management
```

The CBT student interface is also served by the Hub's Express server as a
static HTML page (Vite builds it as a separate output). Students open a
browser on their device — they get React. No native app install needed.

---

## What to Avoid

**Avoid Context overload.** Use Context only for truly global state: identity,
license tier, term config. Everything else stays local to the component or hook.

**Avoid Redux.** The app's data needs are simple. TanStack Query handles caching,
loading states, and re-fetching with far less ceremony.

**Avoid rewriting working backend logic.** Fee calculation, attendance aggregation,
PDF generation — none of this moves to React. It stays in `main.js` / `private_engine`.

**Avoid rebuilding the design language.** Import existing CSS variables
(`--gold`, `--accent`, `--bg-panel`) into the React app's global CSS. The
visual identity does not change.

---

## Recommended Starting Point

**Build the next Gold feature (fee structure) in React first**, rather than
migrating old views. The fee structure is complex enough to justify React's
component model (it has modals, forms, a data table, and bulk actions). Building
it in React from scratch proves Phase 0 and Phase 1 in production before the
larger migration begins.

This way:
- Gold ships the fee structure in ~3 weeks, built in React
- The rest of the app still runs on `index.html`
- Views are migrated one by one in parallel with other feature work
- No 3-month feature freeze

---

## Timeline (Realistic)

| Phase | Duration | Ships |
|---|---|---|
| Phase 0: Foundation | Week 1 | Nothing visible. Infrastructure in place. |
| Phase 1: Design System | Week 2 | Nothing visible. Shared components ready. |
| Phase 2: Views | Weeks 3–8 | Each migrated view slightly better than before. |
| Phase 3: Portal | Week 9 | Portal on React, shared with admin. |
| Phase 4: CBT | After Gold complete | Diamond flagship, React-native. |

---

*Nexus School OS — React Migration Strategy v1.0 · April 2026*
*Source: react_migration.md (session e8dafa3d)*
