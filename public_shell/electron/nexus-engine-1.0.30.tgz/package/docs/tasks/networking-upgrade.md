# 🔀 Unified Single-Port Routing (Zero-Router Topology)

> **Implementation Status** (last updated June 2026)
>
> | Item | Status |
> |---|---|
> | Single Port 3000 — all routes on one Express instance | ✅ Complete |
> | `/portal/*` routes | ✅ Complete |
> | `/cbt/*` routes | ✅ Complete |
> | Express Router extraction (`/api` prefix for `/handshake` + `/sync`) | 🔄 Pending — requires Android client update |
> | `/handshake` deprecation in favour of unified `/api/sync` | 📅 Future |
>
> Developer reference: see [25-networking-architecture.md](../guides/25-networking-architecture.md)

## Overview
This document specifies the consolidation of all local server modules from multiple disjoint ports (e.g., 3000, 3001, 3002, 3003) to a single port multiplexer running on **Port 3000** (or standard HTTP Port 80) utilizing Express sub-routers. 

This architectural upgrade resolves inbound firewall restrictions on client platforms, simplifies local Wi-Fi mobile hotspot deployments (zero-router setups), and unifies network discovery via a single Bonjour multicast address.

---

## 🏗️ Architectural Topology

### Ephemeral Port Bloat (V1)
In the initial implementation, each feature group operated its own independent listener:
* **Port 3000**: Electron app static UI server
* **Port 3001**: Grader Android Handshake & Sync Server (HTTP/UDP)
* **Port 3002**: Sovereign Parent Lookup Portal
* **Port 3003**: CBT Arena Client (Proposed)

### Unified Multiplexer (V2)
All endpoints are consolidated under a single Express listener on **Port 3000**:

```
                        ┌──────────────────────────────┐
                        │   Single Express Listener    │
                        │         (Port 3000)          │
                        └──────────────┬───────────────┘
                                       │
         ┌─────────────────────────────┼─────────────────────────────┐
         ▼                             ▼                             ▼
     `/api/*`                     `/portal/*`                     `/cbt/*`
 [Grader App Sync]            [Parent Portal UI]            [CBT Candidate UI]
 - /api/sync                  - /portal/api/request-otp     - /cbt/api/verify-token
                              - /portal/api/student-data    - /cbt/api/submit-exam
```

---

## 📡 Endpoint Specifications

### 1. Grader Mobile Sync (`/api/*`)
Handles teacher device registration, cryptographic pairing, name allocation, and grade synchronization in a single-endpoint transaction.
* `POST /api/sync`: Receives signed grade packets and device ID. If the device ID is not registered, the Desktop Hub raises an approval notification in the UI. Once approved, the public key is saved, and subsequent sync packets are processed and committed to the SQLite ledger. This eliminates the multi-step, stateful `/api/handshake` flow.

### 2. Sovereign Parent Portal (`/portal/*`)
Serves parent lookup pages and handles local OTP verification checks.
* `GET /portal`: Serves static `portal.html` parent portal index.
* `POST /portal/api/request-otp`: Issues 4-digit PINs, pushes to pending bot queue, or returns E2E bypass pins.
* `POST /portal/api/verify-otp`: Validates PINs, returns session access tokens.
* `GET /portal/api/student-data`: Fetches student reports, attendance grids, and ledger sheets.

### 3. CBT Arena (`/cbt/*`)
Serves exam clients and verification protocols.
* `GET /cbt`: Serves candidate client portal static views.
* `POST /cbt/api/verify-token`: Checks CBT ticket codes, launches active session windows.
* `POST /cbt/api/submit-exam`: Evaluates and tallies question sheet scores.

---

## 🔌 Zero-Router Setup (Virtual AP / Hotspot)
When a school operates offline without standard network router equipment:
1. The admin starts the Windows/macOS built-in **Mobile Hotspot**.
2. Laptop assigns itself a standard local gateway IP (e.g., `192.168.137.1`).
3. Teachers and parents connect to this Hotspot.
4. The system broadcasts the service `nexus.local` pointing to Port `3000`.
5. Clients query specific routes dynamically:
   * **Grader Handshake**: `http://nexus.local/api/handshake`
   * **Parent Lookup**: `http://nexus.local/portal`
   * **CBT Exams**: `http://nexus.local/cbt`
