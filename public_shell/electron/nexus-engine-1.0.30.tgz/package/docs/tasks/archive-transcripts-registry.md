# Historical Archive & Transcript Registry

This document specifies the design for the historical student registry and multi-term academic record reporting tools. It captures the administrator inquiry and details the proceeding features.

---

## 1. Enquiry & Context
Administrators asked: *"Is there an archive interface for quickly getting student records for the preparation and printing of Results, Transcripts, Statements, and Certificates?"*

While Result Studio currently handles active term report cards, it lacks the multi-session database aggregation required for transcripts and graduation credentials.

---

## 2. Archive Registry Roster
We will implement an **Archive & Registry Hub** tab on the desktop shell:
*   A comprehensive, searchable list showing all active, graduated, withdrawn, and expelled students.
*   Enabling admins to quickly pull up any current or historical student profile without altering current-term grade books.

---

## 3. Multi-Session Transcript Compiler
*   **Database Query**: Aggregates grades from `student_records` across multiple sessions (e.g. `2022/2023`, `2023/2024`, `2024/2025`) for a given student ID.
*   **Transcript Layout**: Compiles a multi-page PDF document detailing:
    *   Year-by-year subject averages.
    *   Cumulative GPA and final positions.
    *   Verified principal sign-offs and stamps.

---

## 4. Statements & Graduation Certificates
*   **Statement of Results**: A single-page official declaration summarizing final exit grades in core subjects, bypassing full transcripts for quick verification.
*   **Certificate Engine**: A template gallery using SVG/HTML layers to render graduation, transfer, or character certificates. The system automatically pulls signature PNGs and stamp assets from the school config.

---

## 5. Roadmap & References
*   This feature is mapped to Phase 6 (Student Public Profile & Verified Records) of the Gold/Diamond plans.
*   For the original database table setups (`student_records` and `school_term_config`), see [`docs/tasks/version2_dev.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/docs/tasks/version2_dev.md).
*   For context on positioning verified records and cloud profiles, see Gold plan strategy in [`nexus_master_plan.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/nexus_master_plan.md).
