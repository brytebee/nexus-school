# Nexus School OS — Version 2 Sprint 8 Specifications

> This document captures the detailed technical specifications for the features
> scoped in Sprint 8. It is the companion engineering reference to `version2_dev.md`.

---

## S8-1: Linux Packaging (AppImage + .deb)

### Background

The first client installation is on Ubuntu Linux. The Electron shell must be
packaged and distributed in a format that installs cleanly on any Linux distro
without manual dependency resolution.

### Strategy

Two targets via `electron-builder`:

| Target | Use Case |
|---|---|
| **AppImage** | Universal — self-contained executable, runs on any glibc-compatible distro (Ubuntu, Fedora, Arch, Debian, Mint, etc.) without installation |
| **.deb** | For the first client specifically (Ubuntu) — native package manager integration, `.desktop` launcher, `/usr/bin` symlink |

### `package.json` addition

```json
"linux": {
  "target": [
    { "target": "AppImage", "arch": ["x64"] },
    { "target": "deb",      "arch": ["x64"] }
  ],
  "icon": "assets/icon.png",
  "category": "Education",
  "maintainer": "Nexus Infrastructure Ltd <support@nexusos.com.ng>",
  "synopsis": "High-End School Management System"
},
"deb": {
  "depends": ["libglib2.0-0", "libnss3", "libatk1.0-0", "libatk-bridge2.0-0",
               "libgtk-3-0", "libgbm1", "libasound2"]
}
```

### `electron-builder` scripts to add

```json
"predist:linux": "npm run build && npm run test",
"dist:linux":    "electron-builder --linux",
"publish:linux": "electron-builder --linux --publish always"
```

### `asarUnpack` Note

`better-sqlite3` native `.node` bindings must remain in `asarUnpack` (already
done). On Linux, the AppImage launcher correctly resolves the unpacked path
via `process.resourcesPath`.

### Cross-compilation (from macOS)

Building a Linux target on macOS requires Docker:

```bash
docker run --rm -ti \
  -v ${PWD}:/project \
  -v ~/.cache/electron:/root/.cache/electron \
  electronuserland/builder:wine \
  /bin/bash -c "npm install && npm run dist:linux"
```

Or use a Linux CI runner (GitHub Actions matrix strategy — recommended for
release builds).

### Files to Modify

- `public_shell/electron/package.json` — add `linux` and `deb` targets + build scripts
- `public_shell/electron/assets/icon.png` — ensure a 512x512 PNG exists (for Linux)

---

## S8-2: Installment Loop Controls

**Full technical specification**: see `financial-hub/tech.md` § 10.

### Summary of changes

| Component | What changes |
|---|---|
| `database.js` | `ALTER TABLE installment_plans ADD COLUMN max_occurrences INTEGER DEFAULT 0` |
| `database.js` | New `installment_usage` table (migration) |
| `pulse-bot.js` | `buildInstallmentOptions(studentId, planId, term, session)` — filters milestones by usage count |
| `pulse-bot.js` | `recordInstallmentUsage(studentId, planId, milestone, term, session)` — called after successful payment |
| `main.js` | `installments:update-milestone` IPC — writes `max_occurrences` |
| `FinancialHub.tsx` Installment Plans tab | Add **Allowed Times** dropdown (0-7) per milestone row |

### Tier gate
Diamond only (installment plans are already Diamond-gated).

---

## S8-3: Payment Channel Toggles

**Full technical specification**: see `financial-hub/tech.md` § 11.

### Summary of changes

| Component | What changes |
|---|---|
| `database.js` | `ALTER TABLE fee_settings ADD COLUMN allow_manual_payments INTEGER DEFAULT 1` |
| `database.js` | `ALTER TABLE fee_settings ADD COLUMN allow_custom_amount INTEGER DEFAULT 1` |
| `pulse-bot.js` | Fee reply builder reads both flags from DB before constructing the options menu |
| `main.js` | `fees:update-payment-channels` IPC handler |
| `FinancialHub.tsx` Fee Settings | New **Payment Channels** card with two toggles |

### Tier gate
Gold+ (fee settings are already Gold-gated).

---

## S8-4: PDF/HTML Result Dispatch (WhatsApp + Email)

**Full technical specification**: see `financial-hub/tech.md` § 12.

### Summary of changes

| Component | What changes |
|---|---|
| `result-dispatcher.js` | **NEW module** — `compileToPdf(html)`, `dispatchWhatsApp(...)`, `dispatchEmail(...)` |
| `database.js` | New `pending_emails` table |
| `database.js` | `ALTER TABLE app_settings ADD COLUMN smtp_host TEXT` (+ port, user, pass, from) |
| `pulse-bot.js` | New `sendResultPdf(phone, buffer, name, school)` method |
| `main.js` | `results:dispatch` IPC handler |
| `main.js` | `settings:smtp:save` / `settings:smtp:test` IPC handlers |
| `ResultStudio.tsx` | **Send Results** button panel — scope picker (student / class / school) + channel checkboxes |
| `Settings.tsx` | New **Email Setup** section (SMTP credentials form) |
| Sync Hub worker | Email drain loop — processes `pending_emails` every 15s |

### PDF Compilation Note

Puppeteer is already bundled as a transitive dependency of `whatsapp-web.js`.
Use the bundled Chromium path for PDF rendering. Alternatively, use
`webContents.printToPDF()` on a hidden `BrowserWindow` (already used by the
print receipt flow in tech.md § 9.3) — this is the **preferred approach** to
avoid extra Chromium startup overhead.

### Email: SMTP credentials storage

`smtp_pass` is stored in `app_settings` AES-256 encrypted using the machine's
device fingerprint as the key. Implementation:
`crypto.createCipheriv('aes-256-gcm', key, iv)`.

### Tier gate
Gold+ for WhatsApp dispatch. Diamond for email + SMTP config.

---

## S8-5: E-Portal Parent Result Downloads

### Route: `/[slug]/parent`

New page in `nexusos/src/app/[slug]/parent/` (Next.js App Router).

#### Authentication
Parents log in with their registered **phone number + OTP** (SMS or WhatsApp OTP
sent from the school's bot number). JWT session stored in a cookie; valid 7 days.

The parent JWT payload:
```json
{
  "phone": "2348012345678",
  "schoolSlug": "green-valley-high",
  "linkedStudentIds": ["abc123", "def456"]
}
```

#### Result Download Endpoint

```
GET /api/[slug]/results/download
Query: studentId, term, academicSession
Auth: Bearer JWT (school-scoped)
Response: application/pdf (streamed)
```

The endpoint:
1. Verifies the JWT and confirms `studentId` is in `linkedStudentIds`.
2. Calls the school's Nexus instance via the portal API to pull the compiled
   result HTML (or cached PDF buffer if pre-generated).
3. Streams the PDF back with `Content-Disposition: attachment`.

#### Portal Content Publishing Flag

```sql
-- On the portal_content table (nexusos Postgres DB)
ALTER TABLE portal_content ADD COLUMN results_published_terms JSONB DEFAULT '[]';
-- e.g. ["Third Term 2025/2026", "Second Term 2025/2026"]
```

Admin flow (Nexus desktop → Portal Content view):
1. Admin clicks **Publish Results** for a term.
2. IPC → API call to nexusos → inserts term into `results_published_terms`.
3. `/[slug]/parent` checks this array and only shows download buttons for
   published terms.

### Files to Create / Modify (nexusos)

| File | Action |
|---|---|
| `src/app/[slug]/parent/page.tsx` | **NEW** — Parent dashboard (children list + results per published term) |
| `src/app/[slug]/parent/login/page.tsx` | **NEW** — Phone + OTP login flow |
| `src/app/api/[slug]/results/download/route.ts` | **NEW** — Authenticated PDF download endpoint |
| `src/app/api/[slug]/parent/auth/route.ts` | **NEW** — OTP issue + JWT mint |

---

## Cross-cutting: Tier Gates Summary

| Feature | Minimum Tier |
|---|---|
| Linux packaging | N/A (all tiers — build target) |
| Installment occurrence limits | Diamond |
| Payment channel toggles | Gold |
| WhatsApp PDF results dispatch | Gold |
| Email results dispatch | Diamond |
| SMTP configuration | Diamond |
| E-portal parent login + result download | Gold (via Portal Content) |
