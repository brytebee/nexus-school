# Official Letter & Letterhead Builder

This document specifies the design and implementation plans for a local Letter drafting and Letterhead layout configuration module. It captures the administrator inquiry and details the proceeding features.

---

## 1. Enquiry & Context
Administrators asked: *"Is it achievable/realistic to present schools with a letter draft interface and then format it properly with a chosen letter head design? Can they export letter headed designs for just printing without letter drafts?"*

Standard school operations frequently require official notices (suspensions, exits, awards) containing school identity branding. Designing these documents in external software often leads to visual inconsistency.

---

## 2. Front-End WYSIWYG Editor
We will build a local **Letter Builder Canvas** inside the desktop shell:
*   **Drafting Area**: A lightweight rich-text editor (using a contenteditable iframe or standard package) allowing admins to compose and edit documents.
*   **Dynamic Placeholders**: Merge variables automatically resolved before PDF compilation:
    *   `{{student_name}}`, `{{class}}`, `{{parent_name}}`, `{{current_date}}`, `{{principal_name}}`.

---

## 3. Letterhead Layouts & Styles
The layout builder compiles the document by combining the drafted body with school identity shards:

*   **Classic Layout**: Centered logo, school name in bold serif, motto below, and contact details separated by a double line.
*   **Modern Layout**: Split header (left-aligned logo, right-aligned contact details) matching the school's primary and secondary theme colors.
*   **Digital Stamp Mode**: Integrates the principal's signature PNG and the school stamp dynamically at the bottom.
*   **Custom Template Overlay**: Permits schools to upload a full-page JPG/PNG background representing pre-printed paper, rendering the drafted body precisely on top of it.

---

## 4. Blank Letterhead Export
*   Admins can click "Export Blank Letterhead".
*   The system renders only the configured header and footer styles, outputting a print-ready PDF containing no draft body. This allows the school to print physical blank paper sheets or use them in external processors.

---

## 5. Roadmap & References
*   This module is part of the school branding and document generation tools in the V2 rollout.
*   For the school branding configuration keys and logo/signature upload schemas, see [`nexus_master_plan.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/nexus_master_plan.md).
*   For PDF compilation and browser print security configs, see printing specs in [`docs/tasks/version2_dev.md`](file:///Users/MAC/Documents/Projects/nexus-school/private_engine/docs/tasks/version2_dev.md).
