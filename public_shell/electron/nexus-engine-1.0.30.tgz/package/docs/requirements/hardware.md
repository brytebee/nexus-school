# Nexus School OS: Hardware Requirements & Setup Guide

> This document helps you understand exactly what hardware a school needs before
> installation day. Share it with the school owner or IT coordinator in advance
> so there are no surprises on setup day.

---

## The Core Principle

**The Nexus Hub runs on the school's existing admin laptop.** In most cases,
no new hardware needs to be purchased. The laptop that the admin already uses
for typing letters and printing reports is powerful enough to run Nexus for
a school of up to 300 students.

Additional hardware is only needed when the school wants to run large-scale
CBT exams, serve more than 300 students simultaneously, or keep the Hub
running 24/7 when the admin laptop is off.

---

## 1. The Admin Hub Laptop (Required — Every School)

This is the central device. It runs the Nexus Desktop App and serves
all other devices on the network.

### Minimum Specification

| Component            | Minimum                                   | Recommended                       |
| -------------------- | ----------------------------------------- | --------------------------------- |
| **Processor**        | Intel Core i3 (8th Gen+) or equivalent    | Intel Core i5 (10th Gen+)         |
| **RAM**              | 4 GB                                      | 8 GB                              |
| **Storage**          | 64 GB free space (SSD strongly preferred) | 128 GB SSD                        |
| **Operating System** | Windows 10 (64-bit) or macOS 11+          | Windows 11 or macOS 13+           |
| **WiFi**             | 802.11n (2.4 GHz)                         | 802.11ac (dual-band, 2.4 + 5 GHz) |
| **Battery / Power**  | Must stay plugged in during exams         | UPS backup strongly advised       |

### Why SSD Matters

Nexus uses SQLite as its database. On a spinning hard drive (HDD), saving
attendance for 300 students can take 3–5 seconds. On an SSD, the same
operation takes under 100 milliseconds (less than the blink of an eye). If the school's laptop has an HDD,
upgrading to an SSD (₦18,000–₦35,000) is the single best performance investment.

---

## 2. Network Setup by School Size

### Size A — Small School (Up to 150 students, Up to 15 simultaneous devices)

**WiFi Requirement:** None (Laptop hotspot only)

**Setup Steps:**

1. On the admin laptop, enable the built-in WiFi hotspot:
   - **Windows:** Settings → Network & Internet → Mobile Hotspot → Turn On
   - **Mac:** System Settings → Sharing → Internet Sharing → Enable
2. Set a simple network name (SSID): e.g., `NexusHub-GraceAcademy`
3. Set a strong password (share only with staff and trusted devices)
4. Note the laptop's IP address on the hotspot (usually `192.168.137.1` on Windows)
5. Open the Nexus App — the Hub IP is displayed automatically on the Sync Hub screen
6. Teachers and student devices connect to `NexusHub-GraceAcademy` from their WiFi settings
7. They open a browser and go to the URL shown on the admin screen

**Maximum simultaneous connections (hotspot):** ~8–25 devices (depends on laptop WiFi driver)

**Cost of additional hardware:** ₦0

---

### Size B — Medium School (150–400 students, Up to 80 simultaneous devices)

**WiFi Requirement:** A basic consumer router

This size covers the majority of Nigerian private schools. The school likely
already has a router. If not, one purchase is required.

**Recommended Router:** TP-Link Archer A6 or Tenda AC6 (₦18,000–₦28,000)

**Setup Steps:**

1. Connect the router to power. Connect the admin laptop to the router via:
   - **Ethernet cable (preferred):** Fastest, most reliable connection for the Hub
   - **WiFi:** Acceptable if no cable is available
2. Note the laptop's IP address on the network:
   - Windows: Open Command Prompt → type `ipconfig` → look for "IPv4 Address" under the active adapter
   - Mac: System Preferences → Network → look for the IP next to the active connection
3. In the router admin panel, assign the hub laptop a **static (fixed) IP address**
   so it does not change when devices reconnect. This is important — if the IP
   changes, devices will lose the Hub URL.
   - Access the router admin panel at `192.168.0.1` or `192.168.1.1` in a browser
   - Look for "DHCP Reservation" or "Address Reservation" settings
   - Enter the laptop's MAC address and assign a fixed IP (e.g., `192.168.1.100`)
4. Teachers connect their Android phones to the router's WiFi
5. Student devices connect to the same WiFi for portal access
6. The Hub URL (shown in the Nexus app) stays constant from now on

**Cost of router (if not already owned):** ₦18,000–₦28,000 one-time

---

### Size C — Large School (400–1,000 students, Up to 200 simultaneous devices)

**WiFi Requirement:** A mid-range router with good range, or a mesh system

At this scale, a single router may not cover the entire building with
strong enough signal. Options:

| Option                | Hardware                               | Approximate Cost | Best For              |
| --------------------- | -------------------------------------- | ---------------- | --------------------- |
| Single strong router  | TP-Link Archer AX55 or Asus RT-AX58U   | ₦55,000–₦90,000  | Compact buildings     |
| Mesh system (2-node)  | TP-Link Deco M5 2-pack or Eero         | ₦75,000–₦120,000 | Multi-floor buildings |
| Router + access point | Mid router + TP-Link EAP225 ceiling AP | ₦70,000–₦110,000 | Long corridor schools |

**Additional Recommendation:** A UPS (Uninterruptible Power Supply) for the
hub laptop and router. Power cuts mid-exam or during attendance sync cause
data loss. A basic UPS (Eaton or Luminous, 650VA) costs ₦35,000–₦60,000
and provides 30–45 minutes of backup — enough to save and close gracefully.

**Setup Steps:** Same as Size B, but also:

1. Place the router or access points centrally
2. Test signal strength in the classrooms where CBT or attendance entry will happen
3. The Nexus app has a "Connection Test" button — use it from each classroom
   before the school's first digital exam

---

### Size D — Enterprise / Multi-Stream School (1,000–5,000 students)

**WiFi Requirement:** Enterprise-grade managed access points

At this scale, the school should have or be willing to invest in proper
network infrastructure. Nexus works with any network — we do not require
specific enterprise hardware. Work with the school's IT vendor to ensure:

- Adequate access point coverage per classroom
- A dedicated VLAN or subnet for the Nexus Hub (isolates student traffic)
- Wired ethernet from the Hub machine to the switch (mandatory at this scale)

**Dedicated Hub Device Recommendation:** At this scale, running Nexus on the
admin's everyday laptop introduces risk (laptop goes home, laptop is used for
other tasks, laptop battery dies). Recommend a dedicated always-on Hub machine:

| Option                                      | Specification                      | Approximate Cost  | Handles              |
| ------------------------------------------- | ---------------------------------- | ----------------- | -------------------- |
| **Mini-PC** (Beelink EQ12 or Intel NUC)     | Core i5/N100, 16GB RAM, 512GB NVMe | ₦180,000–₦320,000 | Up to 1,500 students |
| **Small workstation** (refurbished Dell/HP) | Core i7, 32GB RAM, 1TB SSD         | ₦350,000–₦550,000 | Up to 5,000 students |

This machine sits in the server room or admin office, runs 24/7, and is
accessible from any device on the school network. Staff use the Nexus app
on their own laptops — they simply connect to this Hub over the network.

---

## 3. Teacher Devices (Android Phones)

Teachers use the **Nexus Android App** to enter grades and take attendance.

### Requirements

| Component           | Minimum            | Notes                                         |
| ------------------- | ------------------ | --------------------------------------------- |
| **Android Version** | 8.0 (Oreo)         | 10+ strongly preferred                        |
| **RAM**             | 2 GB               | 3 GB+ recommended                             |
| **Storage**         | 500 MB free        | App + local grade cache                       |
| **WiFi**            | 802.11n            | Must be on same network as Hub                |
| **Screen**          | 5 inches+          | Smaller screens work but are less comfortable |
| **Biometric**       | Fingerprint sensor | Required for biometric lock feature           |

### Important Notes

- Teachers use their **personal phones**. Nexus does not require the school to
  purchase devices for teachers.
- The Nexus app's Eco-Guardian automatically slows down CPU-intensive operations
  when a teacher's phone is hot, protecting their device.
- If a teacher's phone has no fingerprint sensor, the biometric gate falls back
  to PIN entry.

---

## 4. Student / Parent Devices (For Portal & CBT)

No special hardware. Any device with a modern browser works.

### Tested Devices

- Android phones (Chrome browser) — ✅ Fully supported
- iPhones (Safari browser) — ✅ Fully supported
- Windows laptops (Chrome/Edge) — ✅ Fully supported
- iPad / Android tablets — ✅ Fully supported
- Basic school netbooks (Chromebook or low-end Windows) — ✅ Supported

### Minimum Browser Requirement

Chrome 80+, Safari 13+, Firefox 75+, or Edge 80+. Any phone or laptop
purchased after 2019 meets this requirement.

---

## 5. CBT-Specific Requirements

For Computer-Based Testing, the network load increases because all students
are submitting answers simultaneously. Additional guidance:

### Small CBT (Up to 30 students)

- **Network:** Laptop hotspot or basic router — sufficient
- **Device:** Students use personal phones or school tablets
- **Hub:** Admin laptop stays on and plugged in for the duration of the exam
- **No additional hardware needed**

### Medium CBT (30–100 students)

- **Network:** Mid-range router (Size B or C above)
- **Device:** Each student on their own device (phone, tablet, or computer lab PC)
- **UPS:** Strongly recommended to protect Hub from power interruption
- **Tip:** Run a dry-run exam 48 hours before the real exam to identify connectivity gaps

### Large CBT (100–500 students)

- **Network:** Enterprise access points covering each exam room
- **Hub:** Dedicated Mini-PC (see Size D above) — do not run a large exam on the admin's regular laptop
- **UPS:** Required for both the Hub and the network switch
- **IT Coordinator:** Should be on-site during the exam for rapid response

---

## 6. Internet Connectivity

Nexus is **offline-first**. The core system (grading, attendance, report cards,
CBT, parent portal) works with **zero internet** as long as devices are on the
same local WiFi.

Internet is only required for:

| Feature                          | When Internet is Needed           | Frequency         |
| -------------------------------- | --------------------------------- | ----------------- |
| Google Drive Backup              | After school hours, in background | Automatic, daily  |
| Always-On WhatsApp Bot (Diamond) | Continuous (Vercel cloud worker)  | Continuous        |
| Public Parent Portal (Diamond)   | Continuous (Vercel serves pages)  | Continuous        |
| Nexus App Update                 | Occasionally                      | Monthly/Quarterly |
| License Activation               | Once at setup                     | One-time          |

For the backup and cloud features, a basic mobile data connection on the hub
laptop is sufficient. Schools do not need a dedicated broadband line — a
₦4,000/month 10GB data SIM in a USB modem works fine.

---

## 7. Pre-Installation Checklist

Share this checklist with the school before your installation visit:

```
Hardware Checklist — Please verify before Nexus installation day:

[ ] Admin laptop is available and working
[ ] Admin laptop has at least 4GB RAM and 30GB free storage
[ ] Admin laptop battery works or power adapter is available
[ ] Admin laptop has WiFi capability
[ ] A WiFi router is available and working (Medium/Large schools)
    → Router brand and model: ____________________
[ ] Router admin password is available (to set static IP)
[ ] UPS is available for Hub laptop and router (recommended)
[ ] At least 2 teacher Android phones are available for testing
[ ] Android phones have WiFi enabled and can connect to the school router
[ ] Android phones have Chrome or Firefox browser installed
[ ] At least one student/parent device is available for portal testing
```

---

## 8. What Nexus Provides

Nexus supplies all software. No additional software licences are needed.

| Component                         | Who Provides                               | Cost           |
| --------------------------------- | ------------------------------------------ | -------------- |
| Nexus Desktop App                 | Nexus (included in subscription)           | ₦0             |
| Nexus Android App                 | Nexus (included in subscription)           | ₦0             |
| Hub web server (CBT, Portal)      | Included in Nexus app                      | ₦0             |
| SQLite database                   | Included in Nexus app                      | ₦0             |
| Google Drive Backup               | School's Google account                    | ₦0 (free tier) |
| WhatsApp Bot (Office-Hours)       | Included in Nexus app                      | ₦0             |
| WhatsApp Bot (Always-On, Diamond) | Vercel (free tier) + school's Meta account | ₦0–₦500/month  |

---

_Nexus School OS — Strategic Infrastructure Partner Edition_
_Hardware Requirements Guide v1.0 — April 2026_
