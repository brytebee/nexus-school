# Nexus School OS: Attendance Management Guide

Welcome to the Nexus Attendance Module! This guide will explain how to track, manage, and report student attendance using your Nexus School OS platform.

## Overview
Attendance in Nexus is designed to be effortless. Instead of manually calculating how many days a student was present at the end of the term, Nexus calculates it automatically and places it directly onto their report card.

## 1. How Attendance is Recorded
*(Note: Full mobile entry is rolling out to Gold and Diamond schools soon).*
Teachers will use the **Nexus Android App** in the classroom. With a single tap, a teacher can mark a student as "Absent" or "Late". If no action is taken, the student is assumed "Present". When the teacher's phone syncs with the Admin's laptop, the attendance records are automatically saved to the school's master database.

## 2. Displaying Attendance on Report Cards
When it is time to generate results, the Admin has full control over whether attendance is shown to parents.

**How to show attendance:**
1. Open the **Print Hub** on the desktop app.
2. Under the general settings panel, locate and check the **Show Attendance in Result** checkbox.
3. When you generate the report cards, the attendance data (e.g., "Days Present: 40 / 45") and an attendance column will appear on the student report sheet and broadsheet.

*If you uncheck this, all attendance information is completely hidden from the report card.*

## 3. Grading Attendance vs. Standalone Display
Some schools award marks for good attendance (e.g., Attendance is worth 10 marks out of the overall 100), while others only want to show attendance as a reference without it affecting grades. Nexus supports both options:

- **Standalone Column Display**: If you check **Show Attendance in Result** but leave **Include Attendance in Grade Computation** unchecked, the attendance score (e.g. 9/10) is rendered in a column on the report card, but the student's final average and subject grades are calculated purely from their test/exam scores (out of 100%).
- **Grade Computation**: If you check both **Show Attendance in Result** and **Include Attendance in Grade Computation**, the attendance score is added directly to the student's subject total (e.g. CA 1 + CA 2 + Exam + Attendance = 100%). You can configure the maximum attendance points using the **Att. Score Weight** input field.

## 4. Tier Availability
- **Silver Tier**: Can view and print attendance summaries on report cards if the data exists.
- **Gold Tier**: Unlocks the ability for teachers to log daily attendance via the mobile app.
- **Diamond Tier**: Unlocks advanced "Subject-Level" attendance tracking (Truancy detection).
