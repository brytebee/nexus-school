# Technical Architecture: Attendance Module

This document outlines the engineering architecture of the Nexus School OS Attendance Module, specifically how the backend handles attendance aggregation, report injection, and grading components.

## 1. Database Schema
Currently, attendance operates on a general "Form-Level" (daily presence) model.
- **Table**: `daily_attendance`
- **Fields**: `student_id`, `date`, `status`, `term`, `academic_session`.
- *(Future Phase 7)*: Diamond tier will introduce `subject_attendance` (`student_id`, `subject_id`, `date`) for granular truancy detection.

## 2. Desktop Hub & Report Compiler Integration
The attendance system is tightly integrated into the report generation pipeline via `report-compiler.js`. 

### The `buildContext` Injection
When report cards are compiled, the `buildContext` function receives `show_attendance`, `include_attendance_in_grades`, and `attendance_score_weight` from the SQLite `school_term_config`. 

If `attendance_score_weight > 0` and `show_attendance` is enabled, the compiler dynamically pushes a new component into the grading breakdown:
```javascript
  if (attWeight > 0 && termConfig?.show_attendance !== 0) {
    scoreComponents.push({ key: "Attendance", label: "Att.", max: attWeight });
  }
```

Wait, if `include_attendance_in_grades` is disabled (`0`), the `totalMaxScore` excludes the attendance weight, keeping the base cumulative grade out of the remaining assessment sum (typically 100):
```javascript
  const includeAttendanceInGrades = termConfig?.include_attendance_in_grades !== 0;
  const totalMaxScore = scoreComponents.reduce((s, c) => {
    if (c.key === "Attendance" && !includeAttendanceInGrades) return s;
    return s + (Number(c.max) || 0);
  }, 0);
```

### Student Score Recalculation
During the student mapping phase, `report-compiler.js` calculates a proportional score based on the raw days attended using `attendanceLib.computeAttendanceScore(days_attended, total_days, attWeight)`.

If `include_attendance_in_grades` is enabled, this score is added to the student's final score for each subject:
```javascript
  if (includeInGrades) {
    sub.score = Number(sub.score) + attScore;
  }
```
If it is disabled, the score is not added to the total, but is still injected into the student's subject breakdown map (`breakdowns["Attendance"] = attScore`) so that it renders in the attendance column.

## 3. Print Hub UI (`printhub.js`)
The UI is gated using `window.currentLicenseTier`. If the tier is `Silver`, the attendance configuration DOM elements (`#ph-attendance-wrapper`) are explicitly set to `display: none`.

To maintain visual parity with the backend compiler, the `_phRefreshTotal()` function listens to the `ph-attendance-weight` input and dynamically updates the UI's Total component score tracker.

## 4. Template Engine (Handlebars)
The compiler passes a `showAttendance` boolean and the raw `student.attendance` object to the templates. All 8 premium templates include conditional blocks `{{#if showAttendance}}` to gracefully handle layout reflows when the attendance stat block is injected into the DOM (e.g., in the Azure Flex layout or the Sovereign Cumulative row).
