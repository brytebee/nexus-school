# Nexus School OS: Truancy Detection & Subject-Level Attendance

Welcome to the **Diamond-Tier Attendance Module**. This document explains how your school can leverage our dual-layer attendance system to detect truancy, ensure student engagement, and communicate transparently with parents via a structured, dialogue-based intervention workflow.

## 1. What is Truancy Detection?

Traditional "Form Teacher Roll Call" only answers one question: *"Is the student physically inside the school gates today?"*

While this is important for general safety, it doesn't solve the problem of **Internal Truancy**—where a student arrives at school but skips specific classes, hides in the library, or avoids particular subjects. 

Nexus solves this by running a **Dual-Layer System simultaneously**:
1. **Daily Roll Call:** The Form Teacher marks the student as present in the morning.
2. **Subject Roll Call:** Each subject teacher marks whether the student attended their specific lesson.

By comparing these two records, the Nexus **Truancy Radar** automatically flags students who were marked "Present" for the day, but "Absent" for specific classes.

---

## 2. Setting Up the Attendance Panel

Navigate to the dedicated **Attendance** tab in the sidebar of your Nexus Desktop Hub (similar to Nexus Pulse). You will see three sections:

### Section A: Attendance Settings
- **Enable Daily Roll Call:** Keep this ON for standard morning registration (available for Gold+ plans).
- **Enable Subject Roll Call:** Turn this ON to activate Diamond-tier granular tracking.

*Note: Both can be ON simultaneously to give the fullest attendance picture.*

### Section B: Truancy Config (Diamond Only)
This is where you define your school's **Intervention Ladder** — a step-by-step escalation workflow agreed upon (e.g., via PTA dialogues) for how the school handles truancy:

| Step | Triggered After | Action | Channel |
|------|-----------------|--------|---------|
| 1 | 1st flag | Notify Form Teacher | In-App |
| 2 | 3rd flag | Notify Principal | In-App |
| 3 | 5th flag | Alert Parent | WhatsApp |

All thresholds are fully configurable by the Super Admin. If your school's PTA agrees on a different policy, you adjust the numbers here.

### Section C: Truancy Radar
A live dashboard showing every flagged student, their current escalation step, and the date of their last flag. Admins can manually **Dismiss** a flag for a student after the issue has been resolved (e.g., parental note received).

---

## 3. How Teachers Use It (Nexus Mobile App)

Your teachers see only what is relevant to their role — no training overhead.

- **Form Teachers** open the Nexus App and see the standard morning **Daily Roll Call** for their assigned class.
- **Subject Teachers** see the **Subject Roll Call** for the specific class they are currently teaching (e.g., *JSS3 Mathematics*).
- A teacher who is both a Form Teacher and a Subject Teacher will see both modules.

Data syncs automatically to the Desktop Hub when the device reconnects to the school's Wi-Fi.

---

## 4. Report Cards & Parent Communication

### Premium Report Cards
At the end of each term, the Nexus Report Compiler automatically generates attendance data for the PDF:
- A new **Att.** column appears next to each subject's score (e.g., *Maths 78 | Att. 92%*).
- The total daily attendance remains at the bottom summary (e.g., *Total Days Attended: 50/55*).

### Nexus Pulse (WhatsApp Bot)
Parents can message your school's **Nexus Pulse WhatsApp Bot** to request their child's attendance record at any time.
- The bot will return both the general daily attendance and the per-subject percentages for Diamond schools.
- For schools on Silver/Gold, parents receive general daily attendance only.
