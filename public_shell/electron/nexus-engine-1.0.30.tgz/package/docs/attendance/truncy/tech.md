# Technical Specification: Truancy Detection & Dual-Layer Attendance

This document details the architectural implementation for the Nexus School OS dual-layer attendance system (Daily Roll Call + Granular Subject Roll Call). 

## 1. Database Architecture

The attendance system utilizes two distinct SQLite tables to capture the dual-layer data.

### 1.1 `daily_attendance` (Standard)
Tracks the binary "Form Teacher" presence.
- `student_id` (INTEGER)
- `date` (TEXT - YYYY-MM-DD)
- `status` (TEXT - 'present', 'absent', 'late')

### 1.2 `subject_attendance` (Diamond Tier)
Tracks the granular "Subject Teacher" engagement.
- `student_id` (INTEGER)
- `subject_name` (TEXT)
- `date` (TEXT - YYYY-MM-DD)
- `status` (TEXT - 'present', 'absent', 'late')
- `marked_by` (TEXT)

**System Settings Flags:**
The feature is gated by boolean toggles in the `system_settings` key-value table:
- `enable_daily_attendance` (boolean string)
- `enable_subject_attendance` (boolean string)

---

## 2. Desktop IPC & Backend Sync

### 2.1 Sync Protocol (Android to Desktop)
The Kotlin Android app sends a `sync_logs` payload via local Wi-Fi to the Desktop Node.js Express server. 
The payload structure has been expanded to distinguish between general roll calls and subject-specific roll calls. The backend parser routes entries with a valid `subject_name` to the `subject_attendance` table, while null `subject_name` entries go to `daily_attendance`.

### 2.2 Truancy Radar (Electron IPC)
The IPC handler `get-truancy-report` performs an SQL aggregation. It cross-references `daily_attendance` against `subject_attendance` for a given date.
**Logic:** `IF daily_attendance.status == 'present' AND subject_attendance.status == 'absent' THEN flag = true`.

---

## 3. Plan-Aware Integration (Nexus Pulse)

Nexus Pulse (the local WhatsApp Bot) is **Plan-Aware**. 
When a parent queries attendance via the webhook:
1. The `pulse-handler.js` queries `system_settings` to verify the active `NEXUS_TIER` (Silver, Gold, Diamond).
2. **If Silver/Gold:** It queries `daily_attendance` and returns: *"Student was present today."*
   - If the user explicitly asks for subject breakdown, it replies: *"While Nexus offers granular subject-level attendance tracking, this feature is not included in the school's current plan."*
3. **If Diamond:** It queries both tables. It calculates the percentage (e.g., `(total_present / total_classes) * 100`) from `subject_attendance` and sends a detailed breakdown per subject, alongside the daily status.

---

## 4. Report Card Compiler Engine

The PDF generation engine (`report-compiler.js`) injects attendance data dynamically.

1. **Subject Breakdown Injection:** 
   - When generating the subject score table, the compiler executes a `GROUP BY subject_name` query on `subject_attendance` for the active term.
   - It calculates the percentage and appends it to a newly instantiated **Attendance** column on the PDF template.
2. **Footer Injection:**
   - Independent of the subject breakdown, the compiler queries `daily_attendance` to inject the global term summary (e.g., *Total Days Attended: 50/55*) into the bottom endorsements section.
   
Both columns/summaries render simultaneously on the Diamond tier to provide maximum context.
