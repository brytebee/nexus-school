# Technical Architecture: Financial Hub and Fee Shield

This document outlines the engineering architecture of the Nexus School OS Financial Hub, ledger structure, and the Fee Shield execution gate.

---

## 1. Database Schema

The financial system uses a robust triple-entry ledger design inside SQLite to track billings, payments, and adjustments.

```sql
-- Tracks invoices issued to students based on Applied Fee Schedules
CREATE TABLE student_invoices (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    fee_schedule_id VARCHAR(64) NOT NULL,
    term VARCHAR(16) NOT NULL,
    academic_session VARCHAR(16) NOT NULL,
    amount_billed REAL NOT NULL,          -- Base billed amount (e.g. 50000.0)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(64) NOT NULL,      -- Username of the admin who billed
    FOREIGN KEY(student_id) REFERENCES students(id)
);

-- Tracks adjustments applied to standard bills (Scholarships, waivers, levies)
CREATE TABLE fee_adjustments (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    invoice_id VARCHAR(64),
    type VARCHAR(16) NOT NULL,            -- "WAIVER", "ADDITIONAL_CHARGE"
    amount REAL NOT NULL,                 -- Discount (negative) or charge (positive)
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(64) NOT NULL,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(invoice_id) REFERENCES student_invoices(id)
);

-- Tracks payments received from parents
CREATE TABLE payments (
    id VARCHAR(64) PRIMARY KEY,
    student_id VARCHAR(64) NOT NULL,
    amount_paid REAL NOT NULL,            -- Amount received (e.g. 20000.0)
    payment_method VARCHAR(32) NOT NULL,  -- "BANK_TRANSFER", "CASH", "CARD"
    transaction_ref VARCHAR(128),         -- External banking transaction ID
    term VARCHAR(16) NOT NULL,
    academic_session VARCHAR(16) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by VARCHAR(64) NOT NULL,     -- Admin who entered the payment (Audit Log)
    FOREIGN KEY(student_id) REFERENCES students(id)
);
```

---

## 2. The Fee Shield Compilation Gate

During results compilation, `report-compiler.js` runs a financial query to evaluate the student's debt ratio before rendering the report.

### Arithmetic Logic for Debt Ratios
1. **Total Billed**: Sum of standard invoices + positive adjustments.
2. **Total Deductions**: Sum of negative adjustments (waivers/scholarships).
3. **Total Paid**: Sum of all payments.
4. **Real Balance**: `(Total Billed - Total Deductions) - Total Paid`.

### The Code-Level Compilation Gate

Inside `report-compiler.js`, the gate processes this balance:

```javascript
async function evaluateFeeShield(studentId, term, session, config) {
  // If licensing is not Diamond, Fee Shield is bypassed
  if (global.licenseTier !== 'Diamond') {
    return { status: 'CLEARED', balance: 0 };
  }

  const financialSummary = await db.get(`
    SELECT 
      (COALESCE((SELECT SUM(amount_billed) FROM student_invoices WHERE student_id = ? AND term = ? AND academic_session = ?), 0) +
       COALESCE((SELECT SUM(amount) FROM fee_adjustments WHERE student_id = ? AND type = 'ADDITIONAL_CHARGE'), 0)) AS total_billed,
      ABS(COALESCE((SELECT SUM(amount) FROM fee_adjustments WHERE student_id = ? AND type = 'WAIVER'), 0)) AS total_waiver,
      COALESCE((SELECT SUM(amount_paid) FROM payments WHERE student_id = ? AND term = ? AND academic_session = ?), 0) AS total_paid
  `, [studentId, term, session, studentId, studentId, studentId, term, session]);

  const netBilled = financialSummary.total_billed - financialSummary.total_waiver;
  const outstandingBalance = netBilled - financialSummary.total_paid;

  if (outstandingBalance <= config.fee_shield_tolerance_limit) {
    return { status: 'CLEARED', balance: outstandingBalance };
  }

  // Trigger Action Gating depending on term settings
  if (config.fee_shield_mode === 'HARD_LOCK') {
    return { status: 'LOCKED', balance: outstandingBalance };
  } else {
    return { status: 'WATERMARKED', balance: outstandingBalance };
  }
}
```

### Flow Outcome:
* If the status is **`LOCKED`**, the compiler throws a custom exception, which routes the builder to compile the fallback debt warning sheet.
* If the status is **`WATERMARKED`**, the compiler injects a boolean `watermark: true` to the Handlebars compilation context. The CSS layer then overlays a skewed base64 background SVG text:
  ```css
  .watermarked-report::before {
      content: "OUTSTANDING FEES - UNRELEASED REPORT";
      position: absolute;
      transform: rotate(-45deg);
      opacity: 0.12;
      font-size: 4rem;
      /* ... positioning layouts ... */
  }
  ```

---

## 3. Tier Capabilities Comparison

| Architectural Attribute | Gold Capability | Diamond Capability |
| :--- | :--- | :--- |
| **Active DB Ledger** | Writes to `student_invoices` and `payments` tables. | Fully locks database, tracking actions via `recorded_by` indices. |
| **Simultaneous Sync** | Locked to single-device write access. | Multi-admin SQLite WAL mode enabled, permitting concurrent desktop/tablet writes. |
| **Fee Shield Enforcer** | Bypassed. Reports print without financial validation checks. | Active. Bypasses only if explicit exemption flag exists in `student_exemption` table. |
| **Exam QR Gate** | Bypassed. | Generates cryptographic QR string: `encrypt(studentId + ":" + balance)`. |

---

## 4. Live DB Schema (Active Version)

While V1 used `student_invoices` and `payments` tables, the production release leverages a simplified and unified ledger model:

* **`student_fees`**: Tracks aggregated student status per term.
  * Columns: `student_id`, `academic_session`, `term`, `total_billed`, `total_paid`, `status` (`'unpaid' | 'partial' | 'cleared'`), `next_due_date`, `updated_at`.
* **`fee_transactions`**: The payment ledger (Diamond audit-enabled single source of truth).
  * Columns: `id`, `student_id`, `academic_session`, `term`, `amount`, `payment_method` (`'cash' | 'transfer' | 'card'`), `reference_number`, `note`, `recorded_by`, `created_at`.
* **`fee_structures`**: Class category fee templates.
  * Columns: `id`, `class_name`, `item_name`, `amount`, `academic_session`, `term`, `created_at`.
* **`fee_adjustments`**: Custom discounts or waiver entries.
  * Columns: `id`, `student_id`, `academic_session`, `term`, `amount`, `reason`, `recorded_by`, `created_at`.
* **`fee_payment_sessions`**: Temporary WhatsApp bot checkout session tracker.
  * Columns: `id`, `parent_phone`, `student_ids`, `total_amount`, `payment_type`, `partial_percent`, `paystack_ref`, `paystack_access_code`, `status`, `created_at`.

---

## 5. Performance Engineering: 100k-Record Scale

To support schools with large historical transaction registries (exceeding 100,000 records), the following optimizations are applied:

### Compound SQL Indexes
Two static indexes are created in `database.js` during server initialization:
```sql
-- Speeds up pagination and alphabetical class roster sorting
CREATE INDEX IF NOT EXISTS idx_students_class_name 
    ON students (class_name, name);

-- Accelerates status filtering (All/Unpaid/Partial/Cleared) queries
CREATE INDEX IF NOT EXISTS idx_student_fees_session_term_status 
    ON student_fees (academic_session, term, status);
```

### Direct Server-Side Filtering
The `fees:get-roster` IPC handler performs filter execution directly in SQLite. Rather than using subquery wrappers, a clean `COALESCE` check maps non-billed students to `'unpaid'` to preserve accurate counting and pagination:
```sql
SELECT COUNT(*) as total
FROM students s
LEFT JOIN student_fees f
  ON  f.student_id       = s.id
  AND f.academic_session = ?
  AND f.term             = ?
WHERE (s.name LIKE ? OR s.id LIKE ?)
  AND (? = 'all' OR COALESCE(f.status, 'unpaid') = ?)
```

---

## 6. Admin Control: Destruction and Danger Zone

Destructive wipes are restricted via the `fees:clear-data` IPC channel.

### IPC Handler Contract
* **Request Payload**: `{ scope: 'term' | 'session' | 'all', academic_session, term }`
* **Response Payload**: `{ ok: true, counts: { fees, transactions, adjustments, structures } }` or `{ ok: false, error: string }`

### Security Controls
1. **Active Session Requirement**: The handler asserts `currentAdminSession` exists. If not, it rejects with a `401 Unauthorized` equivalent error payload.
2. **Double-Confirmation Flow**: Wipes require two interactive checks:
   * Verification of admin credentials/PIN (verified against `auth:verify-pin` IPC handler).
   * Word matches validation requiring the admin to type `"DELETE"` in a sweetalert modal.
3. **Audit Log Registration**: Successful wipes write to the `audit_logs` table:
   * Action: `'CLEAR_FINANCIAL_DATA'`
   * Target: `'student_fees'`
   * Details: Records the scope, target term/session, and the count of deleted entries across tables.

---

## 7. App Session List Unification

To prevent hardcoded mismatched values, all session dropdown selectors must import and use the standard generator utility:
* **Import**: `import { generateSessionsList } from '../lib/sessions';`
* **Range**: Generates terms from current year - 2 up to current year + 3 (e.g. `2023/2024` through `2028/2029`).
* **Usage**: Extends to `PrintHub.tsx`, `FinancialHub.tsx`, `Dashboard.tsx`, and `Classes.tsx`.

---

## 8. Pull-Based Online Transaction Verification

For schools without static public IPs or tunnel bridges to handle Paystack Webhooks, payment states reconcile via background pull polling.

### Workflow Sequence
1. **Link Dispatch**: When a checkout is requested on WhatsApp, the bot initializes a transaction, registers a `pending` status session in `fee_payment_sessions`, and sends the checkout URL to the parent's phone.
2. **Redirect Configuration**: The checkout link forces a `callback_url` pointing to the public confirmation route `https://nexusos.com.ng/payment-complete`.
3. **Local SCAN (15s)**: Every 15 seconds, the main Electron process queries for pending sessions that are active within a 24-hour window.
4. **Paystack Direct Check**: The poller calls Paystack's official transaction verification endpoint.
5. **Ledger Update**: 
   * If verified **Success**, database ledger transactions are split across linked siblings, and `student_fees` and `fee_payment_sessions` records update to `'settled'`.
   * If verified **Failed**, or if the session exceeds 2 hours without payment, status is set to `'failed'`.
6. **Confirmation Dispatch**: The verification worker directly calls the local `pulse-bot` to trigger the confirmation invoice or failure receipt to the parent on WhatsApp, ensuring immediate confirmation.

---

## 9. Refunds, PDF Receipts, and Local Print (Diamond)

### 9.1 Refund Pipeline

Refunds are only supported for online Paystack payments (i.e., transactions that have a `paystack_tx_id` on their `fee_payment_sessions` row).

#### Schema Additions

```sql
-- fee_payment_sessions gets a new column (auto-migrated on first launch)
ALTER TABLE fee_payment_sessions ADD COLUMN paystack_tx_id INTEGER;

-- Tracks every refund event for auditing
CREATE TABLE IF NOT EXISTS fee_refunds (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id   TEXT NOT NULL,
  tx_ref       TEXT NOT NULL,       -- matches fee_transactions.reference_number
  paystack_ref TEXT,                -- Paystack's own refund reference
  amount       REAL NOT NULL,
  reason       TEXT,
  initiated_by TEXT,
  status       TEXT DEFAULT 'pending',   -- 'pending' | 'success' | 'failed'
  created_at   TEXT DEFAULT (datetime('now'))
);
```

#### Paystack API Call

`POST https://api.paystack.co/refund` with body `{ transaction: <paystack_tx_id>, amount: <kobo> }`.
Implemented in `paystack-service.js → initiateRefund(transactionIdOrRef, amountKobo?, reason)`.

#### IPC Handler: `fees:refund`

| Parameter | Type   | Description                        |
|-----------|--------|------------------------------------|
| studentId | string | Target student ID                  |
| txRef     | string | `reference_number` from `fee_transactions` |
| amount    | number | Naira amount to refund             |
| reason    | string | Mandatory reason (audit trail)     |

**Guard checks (all rejections return `{ ok: false, error }`)**:
1. `licenseStatus.tier !== 'Diamond'`
2. `!currentAdminSession`
3. Transaction not found for the given student/ref pair
4. Requested amount exceeds `tx.amount - sum(refunded)`
5. No `paystack_tx_id` — manual payments cannot be auto-refunded via API

**On success**:
1. Calls `paystackService.initiateRefund()` → `paystackRefundRef`
2. Inside `db.transaction()`:
   - Inserts a **negative** `fee_transactions` row (reversal entry)
   - Inserts into `fee_refunds` with `status = 'success'`
   - Recomputes `student_fees.total_paid` and `status`
3. Writes to `audit_logs` (`action = 'REFUND_TRANSACTION'`)
4. Sends WhatsApp refund notification to parent via `pulseBot.sendRawMessage()`

---

### 9.2 Branded PDF Receipts

#### Module: `receipt-generator.js`

`generateReceiptPdf(data: ReceiptData): Promise<Buffer>`

Generates an in-memory A4 PDF using **pdfkit** (pure Node.js, no Chromium). Returns a `Buffer`.

| Field           | Type     | Description                               |
|-----------------|----------|-------------------------------------------|
| schoolName      | string   | From `app_settings.school_name`           |
| schoolAddress   | string   | From `app_settings`                       |
| schoolPhone     | string   | From `app_settings`                       |
| schoolLogoB64   | string?  | Base-64 encoded school logo (optional)    |
| studentName     | string   | Student full name                         |
| studentClass    | string   | e.g. `"JSS 2B"`                           |
| academicSession | string   | e.g. `"2025/2026"`                        |
| term            | string   | e.g. `"Third Term"`                       |
| reference       | string   | Paystack ref used as receipt number       |
| paymentDate     | string   | Formatted payment date                    |
| paymentMethod   | string   | e.g. `"Paystack Online"`                  |
| amountPaid      | number   | Total Naira paid                          |
| allocations     | array    | `{ name, amount, balance }[]`             |

**Visual structure**: top accent bar → school header (logo or text fallback) → dark title banner → Bill-To / Transaction-Details columns → allocation table (alternating rows) → Total Paid block → footer notice.

#### IPC Handler: `fees:send-receipt-pdf`

Triggered from the **Receipt** button in the roster action column. Sends a PDF as a WhatsApp document.

```
Request: { studentId, txRef }
Response: { ok: true } | { ok: false, error: string }
```

#### WhatsApp Delivery: `pulseBot.sendReceiptPdf(phone, filename, pdfBuffer, caption)`

Wraps the Buffer in `new MessageMedia('application/pdf', ...)` and sends it via `client.sendMessage()`.

---

### 9.3 Local On-Site Print

#### IPC Handler: `fees:print-receipt`

```
Request: { txRef, studentId, format? }
Response: { ok: true } | { ok: false, error: string }
```

**Mechanism**:
1. Creates a hidden `BrowserWindow` (`show: false`)
2. Loads `receipt-print.html`
3. On `did-finish-load`, sends receipt data to the renderer via `win.webContents.send('receipt-data', data)`
4. Calls `win.webContents.print({ silent: false, printBackground: true })`
5. Destroys the window on `did-finish-print`

#### Template: `receipt-print.html`

Self-contained print-optimised HTML. Listens for the `receipt-data` IPC message, then populates and triggers `window.print()`. CSS uses `@media print` to control page size:
- **A4** (`format: 'a4'`) — standard portrait layout
- **Thermal** (`format: 'thermal'`) — 80mm-width teller printer layout

---

### 9.4 Roster Table: 4-Button Action Column (Diamond)

The `Actions` column in the fee roster table renders four pill buttons in a 2×2 grid:

| Button  | Colour | Condition                                   | Action                                |
|---------|--------|---------------------------------------------|---------------------------------------|
| +Pay    | Cyan   | Always shown                                | Opens manual payment modal            |
| Ledger  | Slate  | Always shown                                | Opens transaction ledger slide-over   |
| Receipt | Green  | Disabled if no settled `fee_payment_session`| Calls `fees:send-receipt-pdf`         |
| Refund  | Amber  | Disabled if no `paystack_tx_id` on session  | Opens refund confirmation modal       |

The **Refund modal** requires:
- Full vs partial amount selection (slider or text input)
- Mandatory reason field
- Confirmation step before calling `fees:refund` IPC

The **Ledger slide-over** now includes a 🖨️ Print Receipt button per transaction row.

---

### 9.5 Horizontal Scroll on Roster Table

The roster table wrapper (`div.table-container`) has `overflow-x: auto` applied and the inner `<table>` has `min-width: 700px`. This ensures readability on narrow windows without breaking the layout on full screens.

---

## 10. Installment Loop Controls

### Problem

The standard part-payment flow allows a parent to pay any defined installment percentage repeatedly, as long as a balance exists. This is intentional for some schools (rolling deferred payments) but undesirable for others who want a strict two-phase collection (50% by Week 3, 50% by Week 8).

### Schema Addition

```sql
-- Each milestone in an installment plan gets a max_occurrences column
ALTER TABLE installment_plans ADD COLUMN max_occurrences INTEGER DEFAULT 0;
-- 0 = unlimited. 1–7 = hard limit.

-- Tracks how many times each parent has exercised a specific installment milestone per student per term
CREATE TABLE IF NOT EXISTS installment_usage (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id       TEXT NOT NULL,
    plan_id          TEXT NOT NULL,          -- FK to installment_plans.id
    milestone_label  TEXT NOT NULL,          -- e.g. "First Instalment"
    term             TEXT NOT NULL,
    academic_session TEXT NOT NULL,
    used_count       INTEGER DEFAULT 0,
    last_used_at     TEXT DEFAULT (datetime('now')),
    UNIQUE(student_id, plan_id, milestone_label, term, academic_session)
);
```

### Bot Enforcement Logic (pulse-bot.js)

When a parent selects an installment option:

1. Query `installment_usage` for `(student_id, plan_id, milestone_label, term, session)`.
2. If `used_count >= max_occurrences AND max_occurrences > 0`:
   - Remove the milestone option from the reply menu.
   - If all milestones are exhausted: present full balance option only.
3. On successful payment, `INSERT OR REPLACE` into `installment_usage` incrementing `used_count` by 1.

---

## 11. Payment Channel Toggles

### Schema Additions

```sql
-- Added to fee_settings (already exists) via migration:
ALTER TABLE fee_settings ADD COLUMN allow_manual_payments INTEGER DEFAULT 1;
-- 1 = manual bank transfer & cash bot option shown. 0 = hidden.

ALTER TABLE fee_settings ADD COLUMN allow_custom_amount   INTEGER DEFAULT 1;
-- 1 = parent can type any arbitrary amount. 0 = restricted to defined options only.
```

### IPC Handler: `fees:update-payment-channels`

```
Request: { allowManual: boolean, allowCustomAmount: boolean }
Response: { ok: true } | { ok: false, error: string }
```

Updates `fee_settings` row. Changes take effect on the next parent WhatsApp interaction — no bot restart required (the bot reads settings on each request, not at startup).

### Bot Menu Filtering (pulse-bot.js)

In the fee payment reply builder:
```javascript
const settings = db.getFeeSettings();
const options = [];

if (settings.allow_manual_payments) {
  options.push('Reply 2 to Transfer manually / Pay Cash');
}
if (settings.allow_custom_amount) {
  options.push('Reply 9 to Pay a Custom Amount');
}
// Always present:
options.push('Reply 1 to Pay Online via Paystack 💳');
options.push('Reply 0 to return to main menu');
```

---

## 12. Result Dispatch Pipeline (WhatsApp PDF & Email)

### Architecture Overview

```
Result Studio UI
  → IPC: results:dispatch
    → Electron Main (main.js)
      → report-compiler.js → compileResultHtml(student)
        → Pupeteer/printToPDF → PDF Buffer in memory
          ├── WhatsApp path: pulseBot.sendResultPdf(parentPhone, pdfBuffer, studentName)
          └── Email path:    emailQueue.enqueue(parentEmail, pdfBuffer, studentName)
                              → if online: SMTP send immediately
                              → if offline: INSERT INTO pending_emails
                                            → Sync Hub poller drains on reconnect
```

### Step 1 — PDF Compilation

`report-compiler.js` already generates fully styled HTML for each student's report card. The dispatcher uses `puppeteer` (bundled with `whatsapp-web.js`) to convert that HTML to an A4 PDF:

```javascript
// In result-dispatcher.js (new module)
const browser = await puppeteer.launch({ headless: true });
const page = await browser.newPage();
await page.setContent(html, { waitUntil: 'networkidle0' });
const pdfBuffer = await page.pdf({
  format: 'A4',
  printBackground: true,
  margin: { top: '15mm', bottom: '15mm', left: '12mm', right: '12mm' }
});
await browser.close();
return pdfBuffer;
```

> **Alternative**: `BrowserWindow.webContents.printToPDF()` (Electron native) — avoids spawning a second Chromium process if puppeteer introduces startup latency at scale.

### Step 2 — WhatsApp Delivery

```javascript
// pulseBot.sendResultPdf(phone, pdfBuffer, studentName, schoolName)
const media = new MessageMedia(
  'application/pdf',
  pdfBuffer.toString('base64'),
  `${studentName}_Report_Card.pdf`
);
const caption = `🎓 Results are out!\n\nDear Parent, kindly find attached the ${term} report card for *${studentName}* — ${className}.\n\n_${schoolName} · Powered by Nexus Pulse_`;
await client.sendMessage(`${phone}@c.us`, media, { caption });
```

Dispatch is batched with a **2-second delay between sends** to avoid WhatsApp rate-limiting.

### Step 3 — Email Delivery

#### Schema: `pending_emails`

```sql
CREATE TABLE IF NOT EXISTS pending_emails (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    to_email     TEXT NOT NULL,
    subject      TEXT NOT NULL,
    body_html    TEXT NOT NULL,
    attachment_b64 TEXT,                   -- Base-64 PDF
    attachment_name TEXT,                  -- e.g. "Ada_Obi_Report_Card.pdf"
    status       TEXT DEFAULT 'pending',   -- 'pending' | 'sent' | 'failed'
    attempts     INTEGER DEFAULT 0,
    created_at   TEXT DEFAULT (datetime('now')),
    sent_at      TEXT
);
```

#### SMTP Configuration

Stored in `app_settings`:
```sql
ALTER TABLE app_settings ADD COLUMN smtp_host    TEXT;
ALTER TABLE app_settings ADD COLUMN smtp_port    INTEGER DEFAULT 587;
ALTER TABLE app_settings ADD COLUMN smtp_user    TEXT;
ALTER TABLE app_settings ADD COLUMN smtp_pass    TEXT;   -- AES-256 encrypted at rest
ALTER TABLE app_settings ADD COLUMN smtp_from    TEXT;   -- e.g. "results@greenvalleyhigh.edu.ng"
```

Configurable in **Settings → Notifications → Email Setup**.

#### Email Worker

Runs inside the Sync Hub worker (already polling every 15 seconds). On each tick:
1. Query `SELECT * FROM pending_emails WHERE status = 'pending' AND attempts < 3`.
2. For each queued email, attempt SMTP send via **nodemailer**.
3. On success: `UPDATE pending_emails SET status = 'sent', sent_at = datetime('now')`.
4. On failure: `UPDATE pending_emails SET attempts = attempts + 1, status = CASE WHEN attempts >= 2 THEN 'failed' ELSE 'pending' END`.

### Step 4 — IPC Handler: `results:dispatch`

```
Request: {
  scope: 'student' | 'class' | 'school',
  studentId?: string,        // if scope = 'student'
  className?: string,        // if scope = 'class'
  term: string,
  academicSession: string,
  channels: ('whatsapp' | 'email')[]
}
Response: {
  ok: true,
  dispatched: number,
  skipped: number,           // no phone / no email on file
  queued: number             // offline email queue count
} | { ok: false, error: string }
```

### Step 5 — Parent Portal Downloads

Published results are also accessible from the school's E-Portal. When a result term is marked published (`portal_content.results_published = true`):

- The Next.js `/[slug]/parent` route exposes `GET /api/[slug]/results/download?studentId=&term=&session=` (JWT-authenticated with parent phone login).
- The endpoint calls `report-compiler.js` server-side to generate the PDF on demand.
- The parent sees a **"Download Report Card"** button per child per published term.

### Files Affected

| File | Change |
|---|---|
| `private_engine/src/result-dispatcher.js` | **NEW** — PDF compilation, WhatsApp send, email enqueue |
| `private_engine/src/database.js` | Schema: `pending_emails`, `installment_usage`, `fee_settings` column additions, `app_settings` SMTP columns |
| `public_shell/electron/main.js` | IPC: `results:dispatch`, `fees:update-payment-channels`, `fees:send-result-pdf` |
| `public_shell/electron/pulse-bot.js` | `sendResultPdf()`, installment filter, channel filter |
| `public_shell/electron/src/views/ResultStudio.tsx` | "Send Results" action button panel |
| `nexusos/src/app/[slug]/parent/` | Parent portal result download route (Next.js) |


