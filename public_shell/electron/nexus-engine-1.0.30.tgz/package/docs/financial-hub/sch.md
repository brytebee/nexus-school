# Nexus School OS: Financial Hub Guide

Welcome to the Nexus Financial Hub! This guide will explain how to set up termly fee schedules, invoice parents in bulk, record single or multi-admin payments, and leverage the automated **Fee Shield** to accelerate fee collections.

---

## Overview

The Financial Hub in Nexus is designed to solve a school's most critical challenge: **securing tuition payments and eliminating manual debtor tracking**. By combining an offline transaction ledger with an automated results blocker, Nexus helps schools recover millions of Naira in outstanding fees in their first term.

---

## 1. Bulk Invoicing and Fee Schedules

Instead of manually typing an invoice for every single student, Nexus uses **Fee Structures** to bill entire classrooms simultaneously.

### How to set up and apply bulk billing:
1. Navigate to the **Financial Hub** and click **Fee Schedules**.
2. Create a new fee schedule for each class category (e.g. *Tuition + Dev Levy + PTA* for JSS students = ₦50,000; *Tuition + Lab Fee + PTA* for SSS students = ₦60,000).
3. Select the class category and click **Apply Invoice Schedule**.
4. **What happens next**: Nexus will instantly generate customized ledger invoices for *every student* enrolled in those classes.

### Adjustments and Scholarships:
If a student has a scholarship or discount (e.g. staff child waiver or sibling discount):
* Open the student's billing record.
* Click **Add Adjustment**.
* Enter the discount amount and reason (e.g. *Staff Child: 50% Tuition Waiver = ₦25,000*).
* Nexus adjusts their outstanding balance instantly while preserving the general class schedule data.

---

## 2. Managing Payments and Ledgers

Nexus tracks every payment to keep your accounts accurate and audited.

### A. Recording Payments:
* When a parent pays via cash, bank transfer, or card, go to their profile in the **Financial Hub**.
* Click **Record Payment**.
* Enter the amount, payment method (e.g., Bank Transfer), transaction reference (e.g., bank receipt code), and date.
* The system instantly updates the student's ledger and generates a printable payment receipt.

### B. Multi-Admin Audits:
For larger school admin teams, Nexus tracks **which administrator recorded which payment**. Every single receipt is stamped with the recording admin's initials and username, creating an unalterable audit trail for the school owner to review.

---

## 3. The "Fee Shield" (Debtor Results Lock)

The **Fee Shield** is the ultimate tool for accelerating fee collection. When parents know their child's academic reports will be locked until outstanding balances are paid, they pay on time.

### How the Fee Shield operates:
When you generate report cards in the **Print Hub**, Nexus checks each student's real-time financial ledger against the **Fee Shield threshold** set by the school owner.

Depending on your settings, report cards for students with outstanding balances are:
1. **Watermarked**: The report card is compiled, but a highly visible **"OUTSTANDING BALANCE - OFFICIALLY UNRELEASED"** watermark is stamped diagonally across every page.
2. **Hard Locked**: The compiler refuses to compile the report card altogether. In its place, it generates a single sheet stating: **"Results Locked: Please contact the bursary to clear outstanding fees (Balance: ₦25,000)."**

> [!TIP]
> **Commercial ROI**: Automated Fee Shield alerts combined with early invoice distribution have been shown to recover up to **₦3.6M to ₦4.2M** in previously uncollectable outstanding fees in a single term for a standard 300-student school.

---

## 5. Online Fee Payments via Paystack (Nexus Pulse)

When **Nexus Pulse** (the school WhatsApp bot) is running and a Paystack-verified bank account is set as active, parents can pay outstanding fees directly from WhatsApp — no cash, no bank queues.

### How it works:
1. Parent messages the school's WhatsApp number (the bot handle).
2. Bot identifies the parent, retrieves their children's outstanding balances.
3. Parent selects *"Pay Online via Paystack"*.
4. Bot sends a unique, secure Paystack checkout link.
5. Parent completes payment on Paystack (card or bank transfer).
6. Nexus receives confirmation automatically, updates all child ledgers, and sends a **WhatsApp payment receipt** to the parent.

### Enabling Paystack:
- Go to **Financial Hub → Fee Settings → Bank Accounts**.
- Add your school bank account and click **Verify & Connect** to create a Paystack subaccount.
- Click **Set as Active** on the verified account.

### Installment & Part-Payment Plans:
Schools can configure milestone payment plans (e.g. 50% First Installment, 50% Balance). Parents will see these as numbered reply options when they choose to pay online. Installment plans are configured in **Fee Settings → Installment Plans**.

> [!TIP]
> **Commercial benefit**: Parents who would otherwise avoid paying due to logistics now pay instantly, any time of day, without leaving home. Schools report collecting outstanding fees in the same week invoices are issued.

---

## 4. Tier Availability

* **Silver Tier**: Basic payment tracking (manually logs whether a student has "Paid" or "Unpaid" in a single column).
* **Gold Tier**: Class fee structures, bulk billing schedule applicator, individual scholarship adjustments/waivers, printable payment receipts, **Paystack online parent payments via Nexus Pulse** (including parent email update prompts).
* **Diamond Tier**: Full unlocks! Multi-admin Simultaneous Ledgers, audit logs tracking admin signatures, the **Fee Shield** (automatic watermarking and results locking), Exam Clearance QR Codes, and **Installment/Part-Payment Plans**.

---

## 5. WhatsApp Checkout: Parent Email and Fallbacks

Because Paystack requires a valid email address to process card and bank transfer checkout requests, Nexus Pulse manages parent email collection automatically.

### A. The Parent Validation Flow
When a parent requests a secure checkout link on WhatsApp:
1. **Email on Record**: If the student's directory profile already has an email address, the bot presents it:
   > *"Registered Email: parent@domain.com. Reply 1 to use this, 2 to skip, or type a new email address to update it."*
2. **Missing Email**: If there is no email on file, the bot alerts them:
   > *"Currently: None registered. Type your email directly to save it, or reply 2 to skip."*
3. **Database Auto-Cleaning**: If the parent types a new email address, the bot automatically saves it back into the student's profile inside the school directory. This keeps the registry clean and up-to-date.

### B. Configuring the Fallback Email
If parents skip email input (reply `2`), they can proceed immediately using the school's **Fallback Email**:
* Go to **Financial Hub → ⚙️ Settings**.
* Scroll to the **WhatsApp Checkout — Fallback Email** card.
* Enter a valid address (e.g. `bursary@yourschool.edu.ng` or `payments@yourschool.com`).
* Click **Save Settings**.
* **Why it is important**: If set, Paystack sends transaction receipts directly to the school's billing address when parents skip inputting their own, keeping settlement logs consolidated.

---

## 6. The Danger Zone: Data Clearing Wipes

To help school owners clear transaction testing data or prepare ledgers for a new academic year, an administrative Danger Zone is available:
1. Navigate to **Financial Hub → ⚙️ Settings** and scroll to the bottom.
2. Under **Danger Zone**, choose your scope:
   * **Current Term**: Deletes fees, payments, and adjustments for the selected term.
   * **Entire Session**: Deletes records across all terms for the current session.
   * **Everything**: Performs a clean database wipe of all fees, ledger entries, and custom fee structures.
3. Click **Clear Financial Data**.
4. Authenticate by selecting an Admin profile and entering the security PIN.
5. Confirm deletion by typing `DELETE` exactly when prompted. This operation is **permanent and cannot be undone**. All actions are logged under the Audit Trail.

---

## 7. Installment Plan Occurrence Limits

By default, when a school defines an installment plan (e.g. *50% First Instalment*), a parent can technically pay 50% of whatever outstanding balance they have each time they contact the bot. Over several sessions, this means a parent could defer indefinitely, perpetually paying "half" of a shrinking balance.

**Occurrence limits** solve this. Each installment milestone can be restricted to fire between **1 and 7 times per term, per student**.

### How to configure it:
1. Go to **Financial Hub → Fee Settings → Installment Plans**.
2. Create or edit a plan milestone.
3. Set the **Allowed Times** dropdown (1 → 7) for each milestone.
   - *Example:* "50% First Instalment — Allowed Times: **1**" means a parent can only use this option once. After one payment, the bot will no longer offer it as a choice.
4. Save the plan.

> [!TIP]
> Setting a two-milestone plan to 1 occurrence each gives you a clean "First Half / Second Half" structure: the parent pays exactly 50% once, then the remaining balance once. This mirrors the most common school installment policy in Nigeria.

---

## 8. Payment Channel Toggles

Nexus gives you full control over which payment methods parents can use when they contact the bot.

### A. Paystack-Only Mode

If your school wants **all fee payments to flow exclusively through Paystack** (no manual transfers, no cash through the bot):

1. Go to **Financial Hub → Fee Settings → Payment Channels**.
2. Toggle **Allow Manual Bank Transfer / Cash via Bot** to **OFF**.

When this is disabled, the bot no longer presents the bank transfer option. Parents see only the Paystack checkout link, keeping all payments fully auditable and digitally tracked.

### B. Disabling Custom Amount Payments

By default, parents can reply with any custom naira amount to pay an arbitrary portion of their balance (e.g. "Pay ₦7,500"). If you want to enforce structure — requiring parents to pay either the full balance or a defined installment amount:

1. Go to **Financial Hub → Fee Settings → Payment Channels**.
2. Toggle **Allow Custom Amount Payments** to **OFF**.

When disabled, the bot only presents:
- Full balance payment
- Defined installment milestones (if configured)

> [!NOTE]
> Custom amount payments that bypass your installment plan can create reconciliation complexity at term end. Disabling this is recommended for schools with strict financial controls.

---

## 9. Sending Results via WhatsApp and Email

At the end of each term, Nexus can dispatch student report cards directly to parents — both as a **styled PDF attachment** via WhatsApp and as an **email with attached PDF**.

> [!IMPORTANT]
> **Requirements**: Gold or Diamond tier · Nexus Pulse bot running and authenticated · Results compiled in Result Studio.

### 9.1 WhatsApp PDF Dispatch

1. In **Result Studio**, after compiling results for a class, click **📤 Send Results via WhatsApp**.
2. Nexus generates a fully branded A4 PDF report card for each student using your school's letterhead and stamp.
3. The PDF is sent as an attachment directly to each student's parent WhatsApp number (pulled from the student directory).
4. Parents receive a message like:
   ```
   🎓 Results are out!
   
   Dear Mrs. Obi, kindly find attached the Third Term
   report card for Ada Obi — JSS 2B.
   
   Green Valley High · Powered by Nexus Pulse
   ```

> [!TIP]
> You can dispatch results for an individual student, an entire class, or the whole school in one action. Nexus processes them in batches to avoid WhatsApp rate limits.

### 9.2 Email Dispatch

For parents who cannot receive WhatsApp attachments (or for schools that prefer a formal channel):

1. In **Result Studio**, click **📧 Send Results via Email**.
2. Nexus composes a branded email with the PDF report card attached for each student whose parent has an email address on file.
3. Emails are queued and sent as soon as the app has an internet connection.
   - If the school's PC is offline at the time of dispatch, the emails are stored in the **pending email queue** and automatically sent the next time Nexus detects a connection.

### 9.3 Parent Portal Download

Parents on a school that uses the **E-Portal** (your school's Nexus-hosted web page) can log in and download report cards directly from the portal whenever results are published:

1. In **Portal Content**, toggle **Publish Results to Parent Portal** for the completed term.
2. Parents visit your school's portal URL, log in with their phone number, and access results from the **My Children → Reports** section.

---

