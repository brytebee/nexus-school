# Nexus School OS: Sovereign Portal Guide

Welcome to the Sovereign Portal Module! This guide will explain how to set up your local school Wi-Fi broadcaster, print parent access credentials, and give parents instant, cost-free digital access to results and fee records.

---

## The Vision: "Institutional Sovereignty"

Most modern school management systems store your student records on a server overseas. If the internet goes down in Nigeria, or the hosting company suffers an outage, your school's daily operations grind to a halt.

**Nexus operates differently.** 
Your school's data belongs to you. It resides entirely on your local Nexus laptop inside your building. The **Sovereign Portal** allows parents to connect directly to your laptop over local school Wi-Fi to view their children's grades, fee status, and attendance — **100% offline, with absolute data privacy and zero internet cost**.

---

## 1. Setting Up the Local Wi-Fi Broadcaster

To allow parents to view portal data, you must turn on the Nexus Broadcaster.

### Quick Setup Steps:
1. Connect your Nexus laptop to your school's local Wi-Fi router (no internet is needed on this router; it only acts as a wireless bridge).
2. Open the Nexus desktop application and go to the **Sovereign Portal** panel.
3. Turn on the **Broadcaster Service**.
4. The screen will display:
   * **Broadcasting Port**: `3002`
   * **School Local IP Address**: (e.g. `http://192.168.1.105:3002`)
   * An auto-generated **Broadcaster QR Code**.

---

## 2. Printing Parent Access Cards

Parents can access the portal by scanning their customized **Access QR Cards** or entering their private login credentials.

### How to print and distribute access cards:
1. In the **Sovereign Portal** panel, click **Print Access Cards**.
2. Select the target classrooms and click **Export PDF**.
3. Cut and laminate the printed cards to distribute to parents.
4. Each card contains:
   * **Student Name & Admission Number**
   * **The Broadcaster Web Link** (and QR Code)
   * **A private 6-digit Portal Access PIN** (unique to each parent)

---

## 3. How a Parent Connects (The Parent Experience)

When a parent visits the school (e.g. on Open Day, during Parent-Teacher Association meetings, or at pick-up time):

1. The parent connects their smartphone or tablet to the **School Wi-Fi network**.
2. They open their phone camera and scan the **Access QR Code** on their card.
3. Their phone browser instantly opens the **Nexus Parent Portal** (broadcasting directly from the laptop at reception).
4. The parent enters their child's **Access PIN**.
5. **The Dashboard is Live**: They instantly see a beautiful glassmorphic layout displaying their child's:
   * Academic grades, termly averages, and positions.
   * Total days attended and attendance metrics.
   * Outstanding invoices, payments made, and net balance due.

> [!NOTE]
> **Zero Data Cost**: Because the phone is communicating directly with your reception laptop via the Wi-Fi router, **neither the school nor the parent consumes any internet data**! It is fast, instant, and completely free.

---

## 4. Tier Availability

* **Silver Tier**: Local broadcasting disabled. Report cards must be physically printed and handed to parents.
* **Gold Tier**: Full Local Wi-Fi Broadcaster (Express on Port `3002`), printed access QR cards, and local smartphone lookup.
* **Diamond Tier**: Full unlocks! Includes **Always-On Cloud Portal** sync (auto-uploads an encrypted database clone to Google Drive so parents can view records from home, anywhere in the country, via `https://[school].nexusschoolos.app` hosted on Vercel).
