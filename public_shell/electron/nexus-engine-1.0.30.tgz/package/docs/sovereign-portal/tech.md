# Technical Architecture: Local Sovereign Broadcaster

This document outlines the system architecture of the local Parent Portal network broadcaster running inside the Nexus School OS desktop application.

---

## 1. Local Network Architecture

The local portal runs as a dedicated HTTP Express server instance nested inside the Electron main process, sharing access to the master SQLite database in multi-read mode.

```
┌────────────────────────────────────────────────────────┐
│               Electron Desktop Application             │
│                                                        │
│   ┌──────────────────┐          ┌──────────────────┐   │
│   │ Main UI Renderer │          │  SQLite Database │   │
│   └──────────────────┘          └────────┬─────────┘   │
│                                          │             │
│   ┌──────────────────┐                   │             │
│   │  Express Server  │◄──────────────────┘             │
│   │   (Port 3002)    │                                 │
│   └────────┬─────────┘                                 │
└────────────┼───────────────────────────────────────────┘
             │ (Local LAN Broadcast)
             ▼
    ┌──────────────────┐
    │   Local Router   │
    └────────┬─────────┘
             ├──────────────────────────┐
             ▼                          ▼
    ┌──────────────────┐       ┌──────────────────┐
    │ Parent SmartPhone│       │ Parent Tablet    │
    └──────────────────┘       └──────────────────┘
```

---

## 2. Express Server Setup & Routes

The broadcaster listener is initialized in `broadcaster-service.js` under the main process scope. It binds to all available network interfaces (`0.0.0.0`) on port `3002`.

### Initialization
```javascript
const express = require('express');
const app = express();
const PORT = 3002;

app.set('view engine', 'hbs');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Binds server listener
let serverInstance;
function startBroadcaster() {
  serverInstance = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Sovereign Portal broadcasting on port ${PORT}`);
  });
}
```

### Route Definitions
The server exposes localized, secure server-side rendered routes:

```
GET  /login                   → Renders glassmorphic PIN login screen.
POST /login                   → Authenticates parent credentials and sets local browser cookie.
GET  /dashboard               → Authenticated dashboard querying SQLite student snapshot.
GET  /results/:term/:session  → Fetches academic records, aggregates positions, returns report context.
GET  /invoice                 → Fetches current term's billing invoice and payment ledger.
```

---

## 3. Session Authentication & Private PIN Verification

Access to routes is protected by a lightweight cookie-based session token signed using a dynamic localized secret.

### Student Access Schema
```sql
CREATE TABLE parent_portal_credentials (
    student_id VARCHAR(64) PRIMARY KEY,
    portal_pin VARCHAR(6) NOT NULL,       -- Encrypted 6-digit access code
    last_login TIMESTAMP,
    device_fingerprint VARCHAR(128),      -- Binds session to specific smartphone
    FOREIGN KEY(student_id) REFERENCES students(id)
);
```

### Authentication Logic
```javascript
app.post('/login', async (req, res) => {
  const { admission_number, pin } = req.body;
  
  // 1. Resolve student ID from admission number
  const student = await db.get('SELECT id FROM students WHERE admission_no = ?', [admission_number]);
  if (!student) {
    return res.status(401).render('login', { error: 'Invalid Admission Number' });
  }

  // 2. Verify 6-digit PIN
  const creds = await db.get('SELECT portal_pin FROM parent_portal_credentials WHERE student_id = ?', [student.id]);
  const isMatch = await bcrypt.compare(pin, creds.portal_pin);
  if (!isMatch) {
    return res.status(401).render('login', { error: 'Incorrect PIN' });
  }

  // 3. Issue Session Token
  const token = jwt.sign({ student_id: student.id }, global.localJwtSecret, { expiresIn: '6h' });
  res.cookie('nexus_parent_session', token, { httpOnly: true, maxAge: 21600000 });
  res.redirect('/dashboard');
});
```

---

## 4. Off-LAN Fail-safes & Offline Warning Mechanisms

Since the broadcaster is local-network bound (LAN-only in the standard Gold Tier), network edge-cases must be handled gracefully:

### A. Dynamic Host Resolution
The Broadcaster dashboard dynamically monitors interface changes to prevent stale IP references:
```javascript
const os = require('os');
function getLocalIpAddress() {
  const interfaces = os.networkInterfaces();
  for (const devName in interfaces) {
    const iface = interfaces[devName];
    for (let i = 0; i < iface.length; i++) {
      const alias = iface[i];
      if (alias.family === 'IPv4' && !alias.internal) {
        return alias.address;
      }
    }
  }
  return '127.0.0.1';
}
```

### B. Offline Bot Warnings
If the parent attempts to verify login or request an OTP password reset while the school's WhatsApp bot module is offline, the interface displays an offline warning helper:
* **The check**: The local Express server probes the Electron main process via a state query: `ipcRenderer.sendSync('get-bot-state')`.
* **The fallback**: If the state is `OFFLINE`, the UI intercepts OTP requests and changes the helper alert:
  ```html
  <div class="alert alert-warning">
    <strong>⚠️ WhatsApp Bot Offline</strong>: Automatic PIN retrieval is currently unavailable. 
    Please request your credentials directly from the School Reception desks.
  </div>
  ```
