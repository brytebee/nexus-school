# Nexus Pulse: Office Hours Bot (Gold Tier)

Welcome to Nexus Pulse! This guide explains how to use the local WhatsApp bot to automate parent communication during school hours.

## Overview
Nexus Pulse acts as a 24/7 (during school hours) receptionist for your school. Parents can message the school's WhatsApp number to get instant, private updates on their child's results and attendance without calling the school office.

## 1. Setting Up the Bot
The Office Hours bot runs directly on your school's main laptop.
1. Open the **Nexus Pulse** tab in the desktop app.
2. Click **Start Bot**.
3. A QR code will appear. Open WhatsApp on your school's official phone, go to **Linked Devices**, and scan the code.
4. Once "Ready", the bot is active!

## 2. How Parents Interact
Parents simply send a message to your school's number.
- The bot greets them and presents a simple menu:
  - **1. Results**
  - **2. Attendance**
  - **3. Fees**
- Parents reply with **1, 2, or 3** to navigate.
- The bot automatically identifies the parent based on the phone number registered in the Student Directory.

## 3. Important: The "Office Hours" Limitation
Since this bot runs on your local laptop:
- **Laptop Must Be On**: The bot only works when the Nexus desktop app is running and the laptop is connected to the internet.
- **Connection**: If the laptop is closed or loses internet, the bot will stop responding until it is back online.

*Tip: For 24/7 availability even when the school is closed, consider upgrading to the **Diamond Plan**.*

## 4. Tier Availability
- **Gold Tier**: Full access to the Office Hours bot.
- **Diamond Tier**: Includes the "Always-On" Cloud Bridge (24/7 service).

---

## 5. Pay Online: The Parent Email Verification Step

When paying school fees online via the WhatsApp bot, parents must confirm their email address before the system can generate a Paystack checkout link. Paystack uses this email to send parents their transaction receipts.

### How the Email Step Works:
1. **Choose Pay Online**: The parent replies `1` (Pay Online) and chooses their payment amount or plan.
2. **Email Confirmation Prompt**: 
   * **If the parent has an email on file**: The bot displays it (e.g. *parent@email.com*) and asks them to reply `1` to confirm, or **type a new email** if they need to update it.
   * **If no email is on file**: The bot asks them to **type their email** to register it.
3. **Skipping (The Fallback Email)**: If a parent does not want to type their email or wants to skip, they can reply `2`. The system will automatically use the school's fallback billing email to complete the payment setup.
4. **Checkout Link**: Once confirmed, the bot sends the checkout link. Clicking it opens a secure page where they can pay via bank transfer or card.

