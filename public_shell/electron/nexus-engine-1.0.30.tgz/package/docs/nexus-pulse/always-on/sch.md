# Nexus Pulse: Always-On Cloud Bridge (Diamond Tier)

The Always-On Cloud Bridge is a premium Diamond feature that ensures your school is reachable 24/7, even when your office is closed and the school laptop is turned off.

## Overview
While the standard bot requires your laptop to be on, the **Always-On** bot uses a secure "Bridge" to answer parents via the cloud. This means parents can check results at 9 PM on a Saturday or during holidays without any staff intervention.

## 1. How It Works
1. **The Bridge**: Your school laptop periodically sends a "Snapshot" (named `pulse_cache.enc`) to a secure, private folder in your school's **Google Drive**.
2. **The Cloud Bot**: A Nexus cloud service listens for messages on your school's official WhatsApp number.
3. **Data Fetching**: When a parent asks for a result, the cloud bot securely reads the encrypted snapshot from your Google Drive and replies instantly.

## 2. Privacy & Security (The Pulse Key)
Your student data is never visible to us or Google. 
- **Encryption**: Every snapshot sent to Google Drive is locked with a **Pulse Security Key** that only your school owns.


## 3. Setup Requirements
To activate Always-On, your school needs:
1. **Diamond Tier License**.
2. **Google Drive Account**: A standard Google account for the school.
3. **Meta Developer Account**: To link the official WhatsApp Business API (Professional grade).

## 4. Benefits
- **24/7 Service**: Parents get answers instantly at any time of day.
- **PDF Delivery**: Capability to automatically send full Result PDFs directly to a parent's WhatsApp (coming soon).
- **Professionalism**: Elevates your school to a modern, digital-first institution.
