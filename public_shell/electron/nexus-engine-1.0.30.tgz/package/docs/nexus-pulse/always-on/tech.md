# Technical Architecture: Always-On Cloud Bridge

This document details the stateless cloud bridge architecture that enables 24/7 responsiveness for Diamond-tier schools.

## 1. Architecture: The Drive Bridge
The system uses an asynchronous data-shuttling model to maintain the "Offline-First" philosophy while providing cloud-scale availability.
- **Data Source**: Local SQLite DB on the School Hub.
- **Transport**: `pulse-exporter.js` service pushes encrypted `pulse_cache.enc` to Google Drive via OAuth2.
- **Consumer**: Stateless Vercel Cloud Worker.
- **Messaging**: Meta WhatsApp Cloud API (Graph API).

## 2. Security: AES-256 GCM Encryption
Data privacy is maintained through client-side encryption before upload:
- **Key**: A 32-byte AES key generated locally on the Hub.
- **Process**: The Exporter encrypts the JSON payload using the key.
- **Cloud Decryption**: The Vercel worker receives the decryption key via a secure Environment Variable (provided by the admin during setup). This ensures the data is opaque to Google and the transport layer.

## 3. Stateless Response Logic
The Cloud Worker does not have a database. Instead:
1. Receives a WhatsApp Webhook from Meta.
2. Identifies the sender's phone number.
3. Authenticates with Google Drive using the school's `refresh_token`.
4. Downloads and decrypts `pulse_cache.json`.
5. Performs a local lookup in the JSON object to generate the response.
6. Sends the reply via the Meta Graph API.

## 4. Meta Cloud API Integration
Unlike the local bot which uses Puppeteer to automate the web client, Always-On uses the official **Meta Cloud API**:
- **Webhooks**: Handles `messages` events.
- **Media**: Securely serves PDF attachments by generating temporary Drive download links and passing them to Meta's media endpoint.
- **Scaling**: Capable of handling hundreds of concurrent parent queries without local hardware bottlenecks.

## 5. Common Setup Gotchas
- **403 Forbidden**: Ensure the **Google Drive API** is enabled in the Google Cloud Console for your project.
- **Redirect URI Mismatch**: The OAuth2 Redirect URI must be exactly `http://localhost:3005/google-callback`.
- **Scopes**: The app requires the `https://www.googleapis.com/auth/drive.file` scope.

**For a step-by-step IT setup guide, see [deployment-guide.md](./deployment-guide.md).**
