# Obtaining the GOOGLE_REFRESH_TOKEN

The `GOOGLE_REFRESH_TOKEN` is a critical environment variable required for the **Always-On Cloud Bridge** (Nexus Pulse Cloud Worker). Because the Cloud Worker operates statelessly in Vercel, it uses this token to retrieve the encrypted `pulse_cache.enc` from the school's Google Drive on every request.

## How It Works (Account Linking)

1. **Nexus Desktop Hub UI:** The School Administrator goes to the Nexus Pulse settings and initiates the Google Account connection.
2. **OAuth 2.0 Flow:** The Desktop Hub redirects the administrator to Google to grant Drive permissions.
3. **Token Issuance:** Google returns an authorization code to the Hub's local callback server, which is then exchanged for an OAuth tokens payload.
4. **Local Storage:** The `refresh_token` and other credentials are saved locally in the `nexus.sqlite` database.

> [!IMPORTANT]
> Google only issues a `refresh_token` the **first time** a user grants consent. If you re-authenticate and do not see a refresh token, you must revoke the application's access in your Google Account Security settings and link the account again.

## How to Extract the Token

Once the account is successfully linked on the Desktop Hub, the token is automatically exposed in the **Nexus Pulse > Cloud Bridge UI** when the system is successfully configured. You can safely copy it directly from the UI.

Alternatively, developers can extract the token manually via the SQLite database:

### Using the SQLite CLI

Run the following command against the `nexus.sqlite` database:

```bash
sqlite3 nexus.sqlite "SELECT value FROM app_settings WHERE key = 'google_tokens';"
```

Look for the `refresh_token` property in the resulting JSON output:

```json
{
  "access_token": "ya29.a0AfB_byC...",
  "refresh_token": "1//0gA-bCDeF...", // <-- Copy this value
  "scope": "https://www.googleapis.com/auth/drive.file",
  "token_type": "Bearer",
  "expiry_date": 1698765432100
}
```

### Using Node.js

You can programmatically extract it via `better-sqlite3`:

```javascript
const Database = require('better-sqlite3');
const db = new Database('nexus.sqlite', { readonly: true });

const row = db.prepare("SELECT value FROM app_settings WHERE key = 'google_tokens'").get();

if (row && row.value) {
    const tokens = JSON.parse(row.value);
    console.log("GOOGLE_REFRESH_TOKEN:", tokens.refresh_token);
}
```
