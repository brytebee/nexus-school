# 🚀 Always-On Cloud Bridge: Deployment Guide

This guide is for School IT Administrators. Follow these steps to activate your 24/7 WhatsApp Assistant. You will need access to your school's official **Google Account** and a **Meta (Facebook) Developer Account**.

---

## 🛑 Before You Begin
Make sure you have:
1. Your **Pulse Security Key** (Found in the Nexus Desktop App under the Pulse tab).
2. A credit/debit card (for Meta's identity verification — **WhatsApp messages from parents are free**, but Meta requires a card for verification).

---

## Step 1: Create Your WhatsApp App (Meta)
Nexus uses the official Meta Cloud API to ensure your school's number doesn't get banned.

1. Go to the [Meta for Developers Portal](https://developers.facebook.com/).
2. Log in with a Facebook account and click **Create App**.
3. Select **Other** -> **Next** -> **Business** -> **Next**.
4. Give your app a name (e.g., `[School Name] Assistant`).
5. Once in the dashboard, scroll down to **WhatsApp** and click **Set up**.
6. On the left menu, go to **WhatsApp** -> **API Setup**.
7. **Note down these values**:
   - `Phone Number ID`
   - `WhatsApp Business Account ID`

---

## Step 2: Configure Google Cloud (Data Source)
This allows the bot to securely read the academic snapshots from your Google Drive.

1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project named `Nexus Pulse`.
3. Go to **APIs & Services** -> **Enabled APIs & Services**.
4. Click **+ ENABLE APIS AND SERVICES** and search for **Google Drive API**. Click **Enable**.
5. Go to **OAuth Consent Screen**:
   - Choose **External** and fill in your school's email.
   - Add the scope: `.../auth/drive.file`.
6. Go to **Credentials**:
   - Click **Create Credentials** -> **OAuth Client ID**.
   - Select **Web Application**.
   - **Authorized Redirect URIs**: Add `http://localhost:3005/google-callback`.
7. **Note down these values**:
   - `Client ID`
   - `Client Secret`

---

## Step 3: Deploy the Cloud Worker (Vercel)
The "Brain" that answers parents lives here.

1. We will provide you with a **Deploy to Vercel** button or a code folder.
2. Log in to [Vercel](https://vercel.com/) (Free account).
3. During deployment, you will be asked for **Environment Variables**. Enter the values you noted down earlier:
   - `PULSE_SECURITY_KEY`: (Your 32-character key from the Nexus app)
   - `GOOGLE_CLIENT_ID`: (From Step 2)
   - `GOOGLE_CLIENT_SECRET`: (From Step 2)
   - `META_ACCESS_TOKEN`: (Your Permanent Token from Meta)
   - `VERIFY_TOKEN`: (A secret word you choose, e.g., `nexus_shield`)

---

## Step 4: Final Link (The Webhook)
1. In your Meta Developer Portal, go to **WhatsApp** -> **Configuration**.
2. Click **Edit** next to Webhooks.
3. **Callback URL**: Paste your Vercel deployment URL (e.g., `https://my-school-bot.vercel.app/api/webhook`).
4. **Verify Token**: Paste the secret word you chose in Step 3.
5. Under **Webhook Fields**, click **Manage** and subscribe to `messages`.

---

## ✅ You are live!
Your bot is now listening. When a parent sends a message, the cloud worker will:
1. Reach into your Google Drive.
2. Decrypt your snapshot using your unique security key.
3. Reply instantly with the student's data.

**Need Help?** Contact our Strategic Infrastructure team for a guided onboarding session.
