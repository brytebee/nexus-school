# Nexus School OS — Production Release Process

> **Owner:** Nexus Infrastructure Ltd.
> **Maintainer:** @brytebee
> **Last updated:** 2026-06-29

---

## 1. Architecture Overview — 3 Projects, 4 Repos

```
┌─────────────────────────────────────────────────────────────────┐
│  PROJECT 1: Private Engine                                       │
│  Repo: brytebee/nexus-private-engine                            │
│  Path: /private_engine/                                         │
│  Role: Core business logic, database schema, server, reports    │
│  Output: nexus-engine-X.Y.Z.tgz  (produced via npm pack)       │
└──────────────────────────────┬──────────────────────────────────┘
                               │  consumed as
                               ▼  file:nexus-engine-X.Y.Z.tgz
┌─────────────────────────────────────────────────────────────────┐
│  PROJECT 2: Public Shell                                         │
│  Repo: brytebee/nexus-school                                    │
│  Path: /public_shell/                                           │
│  ├── electron/   Electron desktop app (Windows + macOS)         │
│  └── android/    Kotlin mobile app (teacher devices)            │
└──────────────────────────────┬──────────────────────────────────┘
                               │  electron-builder publishes to
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│  PROJECT 3: Release Artifacts                                    │
│  Repo: brytebee/nexus-school-releases                           │
│  Role: Hosts GitHub Releases with DMG, EXE, APK binaries        │
│  Auto-updated by: npm run publish:mac / publish:win             │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Versioning Scheme

All four version surfaces must be **bumped together** on every release.

| Surface | File | Key | Current |
|---|---|---|---|
| Engine package | `private_engine/package.json` | `"version"` | `1.0.22` |
| Engine tarball | `public_shell/electron/nexus-engine-X.Y.Z.tgz` | filename | `1.0.22` |
| Desktop app | `public_shell/electron/package.json` | `"version"` | `1.0.1` |
| Android app | `public_shell/android/build.gradle.kts` | `versionName` / `versionCode` | `1.0` / `1` |

> The engine version and the desktop app version are **independent**. The engine can be
> patched frequently (e.g. 1.0.16 → 1.0.22) without bumping the app version. Only bump
> the desktop/Android version when user-facing changes ship.

### Semantic Versioning for App Version

- `PATCH` (1.0.x) — bug fixes, internal refactors, engine upgrades with no new features
- `MINOR` (1.x.0) — new user-facing features within existing plans
- `MAJOR` (x.0.0) — breaking changes, major new modules, plan restructure

---

## 3. Release Workflow — Step by Step

### Phase 1: Engine Release (when engine changes)

> Work in `/private_engine/`

```bash
# 1. Make and commit your engine changes
git add -A && git commit -m "feat(engine): ..."
git push origin main

# 2. Bump engine version in private_engine/package.json
#    e.g. "version": "1.0.22" → "1.0.23"

# 3. Pack the engine as a tarball
npm pack
# → produces: nexus-engine-1.0.23.tgz

# 4. Copy the new tarball into the electron shell
cp nexus-engine-1.0.23.tgz ../public_shell/electron/

# 5. Update the dependency reference in public_shell/electron/package.json
#    "@nexus/engine": "file:nexus-engine-1.0.23.tgz"

# 6. Reinstall dependencies to lock the new tarball
cd ../public_shell/electron
npm install

# 7. Delete the previous tarball (keep only the current one)
rm nexus-engine-1.0.22.tgz
```

### Phase 2: Desktop App Release

> Work in `/public_shell/electron/`

```bash
# 1. Bump version in package.json "version" field
#    e.g. "1.0.1" → "1.0.2"

# 2. Build the React UI
npm run build

# 3. Run unit tests — all must pass before proceeding
npm run test

# 4. (Optional) Run E2E tests
npm run test:e2e

# 5. Commit everything
git add -A
git commit -m "chore(packaging): release vX.Y.Z

- <summary of changes>"

git push origin main
```

### Phase 3: Build & Publish Installers

#### macOS (on this Mac)

```bash
# Output lands in: public_shell/electron/release/
# Produces DMG for arm64 (Apple Silicon) and x64 (Intel)
npm run dist:mac

# To auto-publish directly to GitHub Releases:
npm run publish:mac
```

#### Windows (must be done on a Windows PC or CI)

```bash
# On the Windows machine, rebuild native dependencies first
rmdir /s /q node_modules
npm install
npx electron-rebuild -f -w better-sqlite3

# Package the NSIS installer
npm run dist:win

# Or auto-publish:
npm run publish:win
```

> CAUTION: Never build the Windows installer on a Mac.
> better-sqlite3 contains native C++ that must be compiled on the target OS.

#### Android APK

```bash
# From public_shell/android/
./gradlew assembleRelease

# Output: app/build/outputs/apk/release/app-release.apk
```

> Keystore: public_shell/android/nexus-release.jks (keep this backed up securely)
> Signing credentials go into local.properties (never committed to git):
>
>   RELEASE_STORE_FILE=nexus-release.jks
>   RELEASE_STORE_PASSWORD=<password>
>   RELEASE_KEY_ALIAS=<alias>
>   RELEASE_KEY_PASSWORD=<alias-password>
>
> Then wire into build.gradle.kts under signingConfigs { release { ... } }

### Phase 4: Verify the Release

1. Go to https://github.com/brytebee/nexus-school-releases/releases
2. Confirm the new tag (e.g. v1.0.1) is present with all artifacts
3. Install the DMG on a clean Mac — confirm app opens, guide files load, DB initialises
4. Install the NSIS EXE on Windows — confirm desktop shortcut and launch work
5. Install APK on a teacher device — confirm handshake and attendance work

---

## 4. Per-Release Checklist

### `brytebee/nexus-private-engine`
- [ ] Engine version bumped in `package.json`
- [ ] All DB schema changes use `IF NOT EXISTS` / `ADD COLUMN IF NOT EXISTS`
- [ ] New tarball packed and copied to `public_shell/electron/`
- [ ] Old tarball deleted from electron directory
- [ ] Committed and pushed

### `brytebee/nexus-school` (public shell)
- [ ] `package.json` `"@nexus/engine"` points to the new tarball filename
- [ ] `npm install` run after tarball update
- [ ] App version bumped in `public_shell/electron/package.json`
- [ ] Android `versionCode` incremented and `versionName` updated in `build.gradle.kts`
- [ ] `npm run build` produces `dist/renderer.html` without errors
- [ ] `npm run test` passes all unit tests
- [ ] Committed and pushed

### `brytebee/nexus-school-releases`
- [ ] GitHub Release auto-created by `electron-builder --publish always`
- [ ] DMG (arm64 + x64) attached
- [ ] EXE (NSIS installer, x64) attached
- [ ] APK attached manually (drag-drop to the GitHub Release page)
- [ ] Release notes written

---

## 5. Key Configuration Reference

### electron-builder publish config (`public_shell/electron/package.json`)

```json
"directories": { "output": "release" },
"publish": [{
  "provider": "github",
  "owner": "brytebee",
  "repo": "nexus-school-releases",
  "private": false,
  "releaseType": "release"
}]
```

Installer artifacts land in `public_shell/electron/release/`.
`dist/` holds only the compiled React UI — these are separate directories.

### Files excluded from the ASAR installer package

```
.env, .env.local, release/**, nexus-engine-*.tgz,
*.sqlite, *.sqlite-shm, *.sqlite-wal, *.sqlite.seed_backup,
tests/**, playwright.config.js, tsconfig*.json, vite.config.ts,
verify-*.js, patch_*.js, run_init.js, errors.txt, Sample_*.csv
```

### Guide file resolution in production (`main.js`)

Guide .md files live in `private_engine/docs/guides/` and bundle inside the engine tarball.
In production, main.js resolves them via the bundled @nexus/engine:

```js
// Dev: reads from private_engine/docs/guides/
// Production fallback: reads from node_modules/@nexus/engine/docs/guides/
const engineDir = path.dirname(require.resolve('@nexus/engine'));
const engineGuidePath = path.join(engineDir, '..', 'docs', 'guides', filename);
```

---

## 6. Environment Variables

| Variable | Purpose | Where set |
|---|---|---|
| `GH_TOKEN` | GitHub PAT — required for `electron-builder --publish` | `.env` (never committed) |
| `USE_REACT_UI` | Set `true` to boot the Vite/React UI instead of `index.html` | `.env` |

---

## 7. Release History

| App Version | Engine Version | Date | Notes |
|---|---|---|---|
| 1.0.0 | 1.0.3 | 2026-06-15 | Initial production release |
| 1.0.1 | 1.0.22 | 2026-06-29 | Packaging pipeline cleanup; fix GitHub owner; fix guide IPC production fallback; fix verify scripts; remove stale tarballs |
