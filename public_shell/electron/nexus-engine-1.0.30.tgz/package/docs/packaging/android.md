# Nexus School OS — Android Packaging Guide

This guide covers how to package the Nexus School OS Android app (used by teachers for The Marriage sync, grading, and attendance).

## Prerequisites
- Ensure you have **Android Studio** installed.
- Ensure the Android SDK and command-line tools are configured in your system environment variables.
- You need a Java Development Kit (JDK 17 is currently recommended for modern Android builds).

## Building the APK (Standard Process)

Depending on the framework used for the Android app (React Native, Expo, Flutter, or native Java/Kotlin), the build command differs.

### If using React Native (CLI)
1. Open a terminal in your Android project directory.
2. Run the assembly command:
   ```bash
   cd android
   ./gradlew assembleRelease
   ```
3. The APK will be located at: `android/app/build/outputs/apk/release/app-release.apk`

### If using Expo
1. Run the local build command for an APK:
   ```bash
   npx expo build:android -t apk
   ```
   *Or using EAS (Expo Application Services):*
   ```bash
   eas build -p android --profile production
   ```

### If using Flutter
1. Open a terminal in the Flutter project directory.
2. Run:
   ```bash
   flutter build apk --release
   ```
3. The APK will be located at: `build/app/outputs/flutter-apk/app-release.apk`

## Distributing to Schools

You **do not** need to put this app on the Google Play Store immediately.
For offline-first distribution:
1. Copy the `app-release.apk` to the Hub Admin Laptop.
2. The admin can transfer the APK to teacher phones via Bluetooth, USB cable, or local WiFi file sharing (e.g., Xender).
3. **Instruct Teachers:** They will need to enable "Install from Unknown Sources" in their Android Settings to install the APK directly.

## Security Considerations
- **Keystore:** When you generate a release build, you sign it with a Keystore file. Keep your `nexus-release-key.keystore` file extremely safe. If you lose it, you cannot issue updates to the app in the future without forcing teachers to uninstall and reinstall from scratch.
