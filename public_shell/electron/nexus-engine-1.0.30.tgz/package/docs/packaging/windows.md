# Nexus School OS — Windows Packaging Guide

This guide covers how to package the Nexus School OS Electron app for Windows. This is the most critical platform, as 95%+ of Nigerian schools use Windows laptops for administration.

## Prerequisites
- You can build Windows apps on a Mac, but it requires `wine` installed. It is highly recommended to build the Windows version **on a Windows PC** to avoid cross-compilation issues, especially with native dependencies like `better-sqlite3`.
- App icon: Ensure you have an `assets/icon.ico` file (Windows requires `.ico`, not `.icns`).

## Rebuilding Native Dependencies (Crucial for SQLite)
Nexus uses `better-sqlite3`, which contains native C++ code. If you copy your project from a Mac to a Windows PC, you MUST rebuild it for Windows:

```bash
# Inside public_shell/electron (on the Windows PC)
rm -rf node_modules
npm install
npx electron-rebuild -f -w better-sqlite3
```

## Creating a Professional Installer (.exe)

We use `electron-builder` to create an NSIS installer. This gives the school a standard "Next -> Next -> Finish" installation experience.

1. Install `electron-builder`:
   ```bash
   npm install --save-dev electron-builder
   ```
2. Add this configuration to your `package.json`:
   ```json
   "build": {
     "appId": "com.nexus.schoolos",
     "productName": "Nexus School OS",
     "win": {
       "target": "nsis",
       "icon": "assets/icon.ico"
     },
     "nsis": {
       "oneClick": false,
       "perMachine": true,
       "allowToChangeInstallationDirectory": true,
       "createDesktopShortcut": true
     }
   },
   "scripts": {
     "build:win": "electron-builder --win"
   }
   ```
3. Run the build:
   ```bash
   npm run build:win
   ```
4. **Result:** You will get a `Nexus School OS Setup 1.0.0.exe` in your `dist/` folder. This is the file you put on a flash drive to install at the school.

## Handling Windows Defender
Because the `.exe` is not signed with an expensive Extended Validation (EV) certificate, Windows Defender SmartScreen will flag it with a blue "Windows protected your PC" warning.
- **Instruct the school:** Click **"More info"** -> **"Run anyway"**. This only happens the first time it is run.
