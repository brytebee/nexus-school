# Nexus School OS — Linux Packaging Guide

This guide covers how to package the Nexus School OS Electron app for Linux distributions (Ubuntu, Debian, Fedora, etc.). While rare in Nigerian administrative offices, some tech-forward schools may use Ubuntu.

## Prerequisites
- You can build Linux apps on a Mac or Windows machine using `electron-builder`.
- App icon: Ensure you have an `assets/icon.png` (Linux prefers standard PNGs, usually 512x512).

## Creating Linux Distributions (.AppImage and .deb)

`electron-builder` can easily generate multiple Linux formats. The most portable format is `.AppImage`, which runs on almost any Linux distribution without installation.

1. Install `electron-builder` if you haven't already:
   ```bash
   npm install --save-dev electron-builder
   ```
2. Add this configuration to your `package.json`:
   ```json
   "build": {
     "appId": "com.nexus.schoolos",
     "productName": "Nexus School OS",
     "linux": {
       "target": [
         "AppImage",
         "deb"
       ],
       "icon": "assets/icon.png",
       "category": "Education"
     }
   },
   "scripts": {
     "build:linux": "electron-builder --linux"
   }
   ```
3. Run the build:
   ```bash
   npm run build:linux
   ```
4. **Results:** Look in your `dist/` folder for:
   - `Nexus School OS-1.0.0.AppImage` (Double-click to run anywhere)
   - `nexus-school-os_1.0.0_amd64.deb` (For installation on Ubuntu/Debian)

## Running the AppImage
When you give an `.AppImage` to a school, they must make it executable before it will run:
1. Right-click the file -> Properties -> Permissions -> Check "Allow executing file as program".
2. Alternatively, via terminal: `chmod +x "Nexus School OS-1.0.0.AppImage"`
3. Double-click to launch.
