# Nexus School OS — macOS Packaging Guide

This guide covers how to package the Nexus School OS Electron app for macOS (Apple Silicon and Intel).

## Prerequisites
- You must build macOS apps on a Mac.
- Ensure all dependencies are installed: `npm install` inside `/public_shell/electron`.
- App icon: Ensure you have an `assets/icon.icns` file.

## Method 1: The Quick Pack (Existing Script)
Your project already has a basic packager script. This creates a `.app` executable but does not create a distributable `.dmg` installer.

1. Open a terminal in `/public_shell/electron`.
2. Run the command:
   ```bash
   npm run pack
   ```
3. This creates two folders in the `dist/` directory:
   - `NexusSchoolOS-darwin-arm64/` (for M1/M2/M3 Macs)
   - `NexusSchoolOS-darwin-x64/` (for Intel Macs)
4. Inside, you will find `NexusSchoolOS.app`. You can compress this to a `.zip` to share with schools using Macs.

## Method 2: Professional Installer (electron-builder)
For a professional `.dmg` installer (recommended for school distribution).

1. Install `electron-builder`:
   ```bash
   npm install --save-dev electron-builder
   ```
2. Add this configuration to your `package.json`:
   ```json
   "build": {
     "appId": "com.nexus.schoolos",
     "productName": "Nexus School OS",
     "mac": {
       "target": "dmg",
       "icon": "assets/icon.icns",
       "hardenedRuntime": true
     }
   },
   "scripts": {
     "build:mac": "electron-builder --mac"
   }
   ```
3. Run the build:
   ```bash
   npm run build:mac
   ```
4. The output will be a professional `Nexus School OS-1.0.0.dmg` installer in the `dist/` folder.

## Important Note on macOS Security (Gatekeeper)
If you do not pay for an Apple Developer Account ($99/yr) to "sign and notarize" the app, macOS will warn users that the app is from an "Unidentified Developer".
- **Workaround for schools:** Tell the admin to **Right-Click** the app and select **Open** the very first time they run it, rather than double-clicking. This bypasses the security block.
