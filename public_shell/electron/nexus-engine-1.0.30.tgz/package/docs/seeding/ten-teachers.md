# 📡 Nexus 10-Teacher Demo Seeding Guide

This guide documents the usage, structure, and execution of the **10-Teacher Demo Seeder** for the Nexus School OS V2 sync and grading engine. Use this seeder to quickly populate the local sovereign database with a complex, secondary school relational dataset featuring distinct teachers, multiple subjects, separate student registers, and no pre-existing grades—making it optimal for testing real-time mobile sync.

---

## 📋 Seed Dataset Overview

The seed script creates the following relational entities:

### 1. 👥 Teachers & Subject Allocations
10 distinct teachers allocated to teach specific combinations of subjects across different grade levels:

| Teacher ID | Teacher Name | Contact Number | Assigned Class & Subject Allocations |
| :--- | :--- | :--- | :--- |
| **T-001** | Mr. Adebayo | `08011111111` | JSS1A Mathematics, JSS2A Mathematics, JSS3A Mathematics, SS1A Mathematics |
| **T-002** | Mrs. Chima | `08022222222` | JSS1A English, JSS2A English, JSS3A English, SS1A English, SS2A English |
| **T-003** | Dr. Ibrahim | `08033333333` | SS1A Physics, SS2A Physics |
| **T-004** | Ms. Oyenusi | `08044444444` | SS1A Chemistry, SS2A Chemistry |
| **T-005** | Mr. Okafor | `08055555555` | SS1A Biology, SS2A Biology |
| **T-006** | Mrs. Balogun | `08066666666` | SS1A Government, SS2A Government |
| **T-007** | Mr. Nwachukwu| `08077777777` | SS1A Economics, SS2A Economics |
| **T-008** | Ms. Effiong | `08088888888` | SS1A Literature in English, SS2A Literature in English |
| **T-009** | Engr. Musa | `08099999999` | SS1A Further Mathematics, SS2A Further Mathematics |
| **T-010** | Mrs. Kolawole | `08010101010` | JSS3A Civic Education, SS2A Civic Education |

### 2. 🎒 Classes & Students (6 per class)
A total of **30 students** divided equally into **5 classes** (6 students per class), fully enrolled in all subjects available at their class level:

*   **`JSS1A`** (Mathematics, English Language)
    *   `S-J1-01` — Abel John
    *   `S-J1-02` — Beatrice Audu
    *   `S-J1-03` — Charles Obi
    *   `S-J1-04` — Deborah Danjuma
    *   `S-J1-05` — Emmanuel Femi
    *   `S-J1-06` — Faith Okon
*   **`JSS2A`** (Mathematics, English Language)
    *   `S-J2-01` — Gabriel Ade
    *   `S-J2-02` — Helen Bassey
    *   `S-J2-03` — Isaac Cole
    *   `S-J2-04` — Joy David
    *   `S-J2-05` — Kingsley Ezenwa
    *   `S-J2-06` — Linda George
*   **`JSS3A`** (Mathematics, English Language, Civic Education)
    *   `S-J3-01` — Matthew Haruna
    *   `S-J3-02` — Naomi Idowu
    *   `S-J3-03` — Okey Jude
    *   `S-J3-04` — Patricia Kola
    *   `S-J3-05` — Richard Lawal
    *   `S-J3-06` — Sarah Moses
*   **`SS1A`** (Math, English, Physics, Chemistry, Biology, Government, Economics, Literature, Further Maths)
    *   `S-S1-01` — Timothy Ndu
    *   `S-S1-02` — Ursula Ojo
    *   `S-S1-03` — Victor Peter
    *   `S-S1-04` — Winifred Quadri
    *   `S-S1-05` — Xavier Rufus
    *   `S-S1-06` — Yvonne Sani
*   **`SS2A`** (English, Physics, Chemistry, Biology, Government, Economics, Literature, Further Maths, Civic Education)
    *   `S-S2-01` — Zachariah Thomas
    *   `S-S2-02` — Abigail Uche
    *   `S-S2-03` — Benjamin Victor
    *   `S-S2-04` — Charity Williams
    *   `S-S2-05` — Daniel Yusuf
    *   `S-S2-06` — Elizabeth Zack

### 3. 🧹 Clean Slate Enforced
To guarantee a flawless test run, the following tables are wiped during seeding:
*   `student_records` — All previously recorded grades/scores are purged.
*   `sync_logs` — All historical device synchronization transactions are removed.

---

## 🚀 Execution Instructions

Because the database uses the native C++ compilation module `better-sqlite3`, it is safest to execute the seeding script inside Electron's Node runtime. Run the command matching your current workspace:

### Method A: Execute via Electron CLI (Recommended)
This runs the seeder using Electron's native environment to guarantee native binary compatibility:

1. Navigate to the `public_shell/electron` directory:
   ```bash
   cd public_shell/electron
   ```
2. Execute the seeder script located in the `private_engine` folder:
   ```bash
   ./node_modules/.bin/electron ../../private_engine/src/scripts/seed_ten_teachers.js
   ```

### Method B: Execute via standard Node (Alternative)
*Note: This will only succeed if your system's global Node version matches the ABI of the installed `better-sqlite3` native module.*

1. Navigate to the `private_engine` directory:
   ```bash
   cd private_engine
   ```
2. Run using standard Node:
   ```bash
   node src/scripts/seed_ten_teachers.js
   ```

---

## 🔍 Seeding Verification

To verify the database has seeded correctly:
1. Open the Electron app (`npm start` inside `public_shell/electron`).
2. Go to **Teachers** or **Sync Hub** tab.
3. Observe the newly added 10 teacher profiles, 5 classes, and 30 student rosters.
4. Perform mobile QR scan and pairing (The Marriage) using one of the teacher accounts to begin grade syncing.
