# Technical Architecture: Licensing and OTA Delivery

This document outlines the security architecture, license verification mechanisms, and Over-The-Air (OTA) download systems powering the Nexus School OS ecosystem.

---

## 1. Cryptographic License Verification System

Nexus uses a high-security, asymmetric cryptographic signature validation architecture to support offline activation without phone-home requirements.

### License Issuance (Server-Side)
When a school purchase completes on the portal backend (`nexus-api`), the server compiles a JSON descriptor detailing the school's contract:
```json
{
  "school_id": "sch_982b1c",
  "school_name": "Grace Academy",
  "licensed_tier": "Diamond",
  "student_cap": 300,
  "term": "Third Term",
  "academic_session": "2025/2026",
  "expires_at": "2026-08-31T23:59:59Z"
}
```
This payload is signed using an **asymmetric Ed25519 private key** owned exclusively by the operator backend. The resulting file (`license.nexus`) is generated as:
`Base64(JSON_Payload) + "." + Base64(Signature)`

### Local Client Validation (`license-validator.js`)
The desktop client contains a hardcoded public key embedded in its secure build environment. When a license is loaded:

```javascript
const fs = require('fs');
const crypto = require('crypto');

function validateLicense(filePath) {
  const licenseContent = fs.readFileSync(filePath, 'utf8');
  const [payloadB64, signatureB64] = licenseContent.split('.');

  const payload = Buffer.from(payloadB64, 'base64');
  const signature = Buffer.from(signatureB64, 'base64');

  // Hardcoded public key corresponding to operator private key
  const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----`;

  const isVerified = crypto.verify(
    null,
    payload,
    { key: PUBLIC_KEY, format: 'pem', type: 'spki' },
    signature
  );

  if (!isVerified) {
    throw new Error("Invalid license signature: Validation failed.");
  }

  const data = JSON.parse(payload.toString());
  
  // Verify date constraints offline
  if (new Date(data.expires_at) < new Date()) {
    throw new Error("License has expired.");
  }

  return data; // Active metadata containing student cap and active tier
}
```

---

## 2. OTA Update and Binary Distribution Architecture

To minimize server costs and ensure blazing-fast downloads globally, binary installers are served via **Cloudflare R2 Object Storage** using signed, time-limited URLs.

```
┌──────────────┐          ┌──────────────┐          ┌──────────────┐
│ Parent/Admin │          │  NextJS App  │          │ Cloudflare   │
│   Browser    │          │  (nexusos)   │          │  R2 Storage  │
└──────┬───────┘          └──────┬───────┘          └──────┬───────┘
       │                         │                         │
       │  1. Request /download   │                         │
       ├────────────────────────►│                         │
       │                         │  2. Sign download URL   │
       │                         ├────────────────────────┐│
       │                         │  with 15 min expiry    ││
       │                         │◄───────────────────────┘│
       │  3. Redirect to signed  │                         │
       │     R2 URL              │                         │
       │◄────────────────────────┤                         │
       │                         │                         │
       │  4. GET /nexus-win.exe  │                         │
       ├─────────────────────────┼────────────────────────►│
       │  5. Return binary file  │                         │
       │◄────────────────────────┼─────────────────────────┤
```

### Path Structuring in Cloudflare R2
Binary assets are organized systematically by product, operating system, and semantic version:
* Windows: `r2://nexus-releases/sch/desktop/win/nexusos-setup-[version].exe`
* macOS: `r2://nexus-releases/sch/desktop/mac/nexusos-[version].dmg`

### Signed URL Generation on Vercel Edge Server (`nexusos`)
Using the AWS S3 SDK mapped to Cloudflare R2's private credentials:
```typescript
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const r2 = new S3Client({
  region: "auto",
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

export async function generateDownloadUrl(product: string, os: string, version: string) {
  const key = `${product}/desktop/${os}/nexusos-setup-${version}.${os === 'win' ? 'exe' : 'dmg'}`;
  
  const command = new GetObjectCommand({
    Bucket: "nexus-releases",
    Key: key
  });

  // URL expires in 15 minutes (900 seconds) to prevent hotlinking
  return await getSignedUrl(r2, command, { expiresIn: 900 });
}
```
This architecture secures the files from unauthorized downloads, while offloading high-bandwidth network delivery from the operator's primary API servers.
