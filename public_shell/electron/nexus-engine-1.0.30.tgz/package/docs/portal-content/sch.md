# Nexus School OS: Portal Content and Licensing Guide

Welcome to the Licensing and Self-Serve Portal! This guide explains how to activate your desktop application, upgrade your school capabilities, manage student caps, and install the latest system updates.

---

## 1. How Self-Serve License Activation Works

When you purchase a subscription tier (Silver, Gold, or Diamond) on the Nexus online portal, our licensing engine automatically issues a secure, customized cryptographic license file named `license.nexus`.

### Steps to activate your offline software:
1. Log into your dashboard at `nexusos.com.ng`.
2. Go to the **Billing & Downloads** section and download your active `license.nexus` file.
3. Open the **Nexus School OS** desktop application on your computer.
4. **No internet connection is needed**: Drag and drop the `license.nexus` file directly into the application window, or click **Upload License** and select the file from your downloads folder.
5. The application instantly validates the key, displays your school name, active term, and tier privileges, and unlocks the system.

---

## 2. Upgrading Capabilities and Student Caps

Every subscription is bounded by a **Student Cap** (e.g. up to 300 students) and active **Term Licenses** (e.g. *2025/2026 - Third Term*). As your school grows, you can easily adapt your license.

### A. Exceeding Your Student Cap:
If you attempt to register a new student while at your cap (e.g., trying to add student #301 on a 300-student cap), the system will display a friendly notification: **"Student Cap Reached - Upgrade License to Add More Profiles."**
* **The fix**: Simply log into the online billing portal, increase your cap, make a quick top-up payment, and download an updated `license.nexus` file. Re-upload this file to your offline desktop app to instantly unlock the higher cap.

### B. Activating a New Term:
At the start of a new academic term:
* Log into the portal and select the upcoming term.
* Checkout securely via Paystack.
* Download and upload your new `license.nexus` file to authorize database operations for the new term.

---

## 3. How Software Updates and Releases Work

Our engineering team continuously improves Nexus School OS, adding templates, features, and security patches.

* **Update Alerts**: When a new release is available, you will receive a notification via your registered email or the WhatsApp notification network.
* **Downloading Binaries**: Visit the **Downloads** panel on the online portal. You will see links for the latest stable installer packages:
  * **Windows Installer** (`.exe`)
  * **macOS Disk Image** (`.dmg`)
* **Installing Updates**: Simply download the new installer and run it on your computer. **Your local database and student records are completely safe!** The installer replaces only the core application files, while leaving your student data entirely untouched inside your secure local database.
