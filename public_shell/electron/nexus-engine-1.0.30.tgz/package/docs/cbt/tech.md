# Technical Architecture: Offline CBT Engine

This document details the database structures, candidate state machines, and real-time cheating detection services powering the offline computer-based testing engine.

---

## 1. Database Schema

The CBT engine operates inside SQLite, utilizing a localized set of tables to store question banks, candidate tokens, and active examination sessions.

```sql
-- Represents a collection of questions for a specific subject/class
CREATE TABLE cbt_question_banks (
    id VARCHAR(64) PRIMARY KEY,
    subject_id VARCHAR(64) NOT NULL,
    class_id VARCHAR(64) NOT NULL,
    title VARCHAR(128) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(subject_id) REFERENCES subjects(id)
);

-- Individual multiple-choice questions
CREATE TABLE cbt_questions (
    id VARCHAR(64) PRIMARY KEY,
    bank_id VARCHAR(64) NOT NULL,
    question_text TEXT NOT NULL,
    image_attachment TEXT,                 -- Path or base64 of inline image
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT,
    option_d TEXT,
    correct_option CHAR(1) NOT NULL,       -- "A", "B", "C", or "D"
    marks REAL DEFAULT 1.0,
    FOREIGN KEY(bank_id) REFERENCES cbt_question_banks(id) ON DELETE CASCADE
);

-- Scheduled exam profiles
CREATE TABLE cbt_exams (
    id VARCHAR(64) PRIMARY KEY,
    bank_id VARCHAR(64) NOT NULL,
    title VARCHAR(128) NOT NULL,
    duration_minutes INTEGER NOT NULL,
    scheduled_start TIMESTAMP NOT NULL,
    status VARCHAR(16) DEFAULT 'DRAFT',     -- "DRAFT", "ACTIVE", "COMPLETED"
    shuffle_questions BOOLEAN DEFAULT TRUE,
    FOREIGN KEY(bank_id) REFERENCES cbt_question_banks(id)
);

-- Unique single-use active session slips for students
CREATE TABLE cbt_candidate_tokens (
    token VARCHAR(6) PRIMARY KEY,         -- Unique 6-digit access code (e.g. 783921)
    exam_id VARCHAR(64) NOT NULL,
    student_id VARCHAR(64) NOT NULL,
    status VARCHAR(16) DEFAULT 'UNUSED',   -- "UNUSED", "WRITING", "SUBMITTED", "LOCKED"
    started_at TIMESTAMP,
    submitted_at TIMESTAMP,
    final_score REAL,
    tab_switch_count INTEGER DEFAULT 0,
    FOREIGN KEY(exam_id) REFERENCES cbt_exams(id) ON DELETE CASCADE,
    FOREIGN KEY(student_id) REFERENCES students(id)
);
```

---

## 2. Exam Packaging and Question Shuffling

To protect examination integrity and allow fast offline delivery, Nexus compiles active exam configurations into compressed JSON packages.

### Shuffling Logic (Anti-Cheat Mechanism)
When a student logs in using an active token, the API generates a randomized question set unique to their token session:
```javascript
function compileExamPackage(exam, questions) {
  // Deep clone questions
  let shuffledList = [...questions];
  
  if (exam.shuffle_questions) {
    // Fisher-Yates shuffle algorithm
    for (let i = shuffledList.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffledList[i], shuffledList[j]] = [shuffledList[j], shuffledList[i]];
    }
  }

  // Strip correct answers from candidate package to prevent inspector-based cheating
  return shuffledList.map(q => ({
    id: q.id,
    question_text: q.question_text,
    image_attachment: q.image_attachment,
    options: {
      A: q.option_a,
      B: q.option_b,
      C: q.option_c,
      D: q.option_d
    }
  }));
}
```

---

## 3. Real-time Browser-Ping and Cheat Detection (Invigilation Radar)

The **Invigilation Radar** is built on a high-frequency polling/heartbeat loop between the student's browser and the local Express broadcaster.

### Browser Event Listener
On the student's exam interface, a background thread monitors focus states and dispatches cheating metrics:
```javascript
let focusLossCount = 0;

window.addEventListener('blur', () => {
  focusLossCount++;
  sendCheatingAlert('TAB_SWITCH');
});

// Periodic heartbeat (every 5 seconds)
setInterval(() => {
  fetch('/api/cbt/heartbeat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      token: examToken,
      tab_switches: focusLossCount
    })
  }).then(res => res.json())
    .then(data => {
      if (data.status === 'LOCKED') {
        lockExamScreen();
      }
    });
}, 5000);
```

### Server Invigilation Router
The Express server receives these heartbeats and writes state flags directly to memory caches, rendering them to the Admin Invigilator Panel:

```javascript
app.post('/api/cbt/heartbeat', async (req, res) => {
  const { token, tab_switches } = req.body;

  // 1. Fetch current token state
  const candidate = await db.get('SELECT status, tab_switch_count FROM cbt_candidate_tokens WHERE token = ?', [token]);
  
  if (!candidate) {
    return res.status(404).json({ error: 'Token not found' });
  }

  if (candidate.status === 'LOCKED') {
    return res.json({ status: 'LOCKED' });
  }

  // 2. Update cheating alerts if focus losses increase
  if (tab_switches > candidate.tab_switch_count) {
    await db.run('UPDATE cbt_candidate_tokens SET tab_switch_count = ? WHERE token = ?', [tab_switches, token]);
    // Broadcast trigger directly to Electron Admin UI via IPC
    global.mainWindow.webContents.send('invigilator-cheat-alert', {
      token,
      type: 'TAB_SWITCH',
      current_count: tab_switches
    });
  }

  res.json({ status: 'OK' });
});
```
This architecture ensures that admins have sub-second visibility into cheating incidents, network dropouts, or active submissions from a single screen, operating completely without an internet connection.
