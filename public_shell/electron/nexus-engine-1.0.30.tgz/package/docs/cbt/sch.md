# Nexus School OS: Computer-Based Testing (CBT) Guide

Welcome to the Computer-Based Testing (CBT) Module! This guide will explain how to set up your Question Studio, deploy local exams over your school's Wi-Fi network, invigilate candidate progress in real time, and generate secondary revenue by hosting external candidate mock testing.

---

## 1. Creating Exams in the "Question Studio"

Preparing exam questions inside Nexus is simple and intuitive. Teachers use the **Question Studio** to input questions, configure options, and prepare answer keys.

### How to use Question Studio:
1. Navigate to the **CBT Panel** and select **Question Studio**.
2. Click **Create Question Bank** and select your subject and class (e.g. *Mathematics - JSS 3*).
3. Choose your input method:
   * **Direct Entry**: Type questions directly into the system, upload optional diagrams or illustrations, and mark the correct answer.
   * **Spreadsheet Import**: Download the Nexus Excel template, populate your questions, options, and keys, and click **Import XLS** to load hundreds of questions in seconds.
4. Set marks per question and click **Save & Publish**.

---

## 2. Setting Up a LAN-Bound Exam Center

You do **not** need to pay cyber cafés or buy expensive internet subscriptions to run computer-based exams. Nexus runs the entire exam center **100% offline using your local network**.

### Step-by-Step Exam Deployment:
1. **Schedule the Exam**: In the **CBT Engine**, select your Question Bank, choose the target class, set the duration (e.g. *60 minutes*), and define the question shuffling pattern (to prevent cheating).
2. **Launch Broadcaster**: Ensure your desktop reception laptop is connected to your computer lab's router (no internet is needed on this router).
3. **Print Tokens**: Generate and print candidate slips. Each student receives a unique **6-digit Exam Access Token**.
4. **Candidates Log In**: Students sit at lab PCs or open tablets/phones, connect to the school network, open their browsers to `http://[hub-ip]/cbt`, enter their **Token**, and click **Start Exam**.

---

## 3. Invigilating Exams and Malpractice Detection

Nexus includes a live **Invigilator Radar** that gives you total control over the exam room from a single desktop screen.

### Live Invigilator Dashboard:
* See real-time metrics: *"42 submitted · 18 writing · 0 flagged"*
* **Tab-Switch Cheating Protection**: If a student attempts to open a different browser tab to search for answers, the Nexus client immediately detects the loss of window focus. The invigilator's screen will flash red: **"ALERT: Student Chukwudi Okonkwo switched windows!"**
* **Instant Lockout**: The invigilator can click **Lock Candidate** to freeze any student's screen instantly for misconduct.
* **Auto-Submit**: When the timer expires, Nexus automatically saves and submits the candidate's answers, preventing anyone from writing past the limit.
* **Instant Grading**: The moment the exam is submitted, Nexus grades the script, records the score, and imports it directly into the student's CA or exam records.

---

## 4. CBT-as-a-Service (Monetizing Idle Assets)

Many private schools have computer labs that sit idle for most of the school term. Nexus Diamond Tier allows you to convert this lab into a **revenue generator** by hosting external exams:

* **National Mock Exams**: Charge neighboring public/private schools a per-candidate fee to host mock JAMB, WAEC, or NECO computer-based practice sessions.
* **Entrance Examinations**: Host local entrance examinations for prospective families. Candidates pay a registration fee, sit the exam in your center, and receive instant admissions scores.

> [!TIP]
> **Secondary Revenue Potential**: By charging neighboring candidates ₦1,500 per seat to run mock exams, a school with a 40-seat computer lab can generate up to **₦240,000 in a single Saturday** of mock testing sessions, turning a cost-center lab into a highly profitable asset.

---

## 5. Tier Availability

* **Silver Tier**: CBT Module disabled.
* **Gold Tier**: Access to the local Question Studio to prepare and print paper-based exams.
* **Diamond Tier**: Full unlocks! Full offline LAN CBT Engine, 6-digit Candidate Token authorization, Live Invigilator Radar with tab-switch cheating detection, Auto-Grading, direct grading injection, and CBT-as-a-Service portal.
