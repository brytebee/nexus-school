# Nexus Scholar — AI Feature Guide

## Overview

Nexus Scholar's AI Synthesis feature allows the system to read answers directly from your school's own uploaded documents (handbooks, fee schedules, admission policies, etc.) and compose a clear, conversational response for staff and parents — without needing the internet for the knowledge itself.

To power the AI answering, Nexus Scholar uses **Google Gemini**, a free AI service provided by Google. Each school must obtain their own free API key from Google. This takes less than 5 minutes and costs nothing.

---

## What is a Gemini API Key?

Think of it as a **password that gives your school access to Google's AI brain**. When you ask Nexus Scholar a question, it:

1. Searches your uploaded documents for the most relevant paragraphs (this works 100% offline, no key needed)
2. Sends those paragraphs + your question to Google's AI
3. Google's AI writes a clean, human-friendly answer
4. The answer appears on your screen

Without a key, step 2 and 3 are skipped — you still get the raw matching paragraphs, but no synthesized answer.

---

## Step-by-Step: Getting Your Free Gemini API Key

### Step 1 — Sign in to Google AI Studio

1. Open your browser and go to: **[https://aistudio.google.com](https://aistudio.google.com)**
2. Click **"Sign in"** in the top-right corner
3. Sign in with any **Google / Gmail account** (a school Gmail account is recommended)

> ⚠️ If you do not have a Gmail account, create one free at [https://accounts.google.com](https://accounts.google.com)

---

### Step 2 — Create an API Key

1. Once signed in, look at the left sidebar and click **"Get API Key"**
2. Click the blue button **"Create API key"**
3. A dialog box will appear — click **"Create API key in new project"**
4. Google will generate a key. It will look like this:

   ```
   AIzaSyD3X7kM...
   ```

5. Click the **copy icon** next to the key to copy it to your clipboard

> ✅ This key is **free**. Google provides a generous free usage quota suitable for a school's daily needs.

---

### Step 3 — Enter the Key in Nexus School OS

1. Open **Nexus School OS**
2. Click **Settings** in the left sidebar (⚙️ icon)
3. Scroll down to the section labelled **"Google Gemini API Key"**
4. Paste the key you copied from Google into the input field
5. Click **"Save Settings"**

> 🔒 Your key is stored **only on this computer**, inside the school's secure local database. It is never shared with anyone, including Nexus Software.

---

### Step 4 — Test the AI

1. Click **Nexus Scholar** (🧠) in the left sidebar
2. If you have not yet uploaded any documents, drag and drop a school PDF (e.g. student handbook, fee schedule) into the **Document Ingestion** panel
3. Once indexed, type a question into the **Query Intelligence** panel — for example:
   - *"What is the school fee for SS2 students?"*
   - *"What is the policy on late arrivals?"*
4. Press **Enter** or click **Search Knowledge Base**
5. A blue **✨ AI Synthesis** box will appear at the top with a clear, grounded answer

---

## Free Tier Limits (Google's Allowances)

| Limit | Amount |
|-------|--------|
| Requests per day | 1,500 |
| Requests per minute | 15 |
| Tokens per minute | 1,000,000 |

For a typical school, this is more than sufficient. A "request" is one question asked in Nexus Scholar.

> 💡 If you exceed the free limit on a very busy day, Scholar automatically falls back to showing the raw matching paragraphs from your documents. No data is lost and no error is shown to staff.

---

## Frequently Asked Questions

**Q: Does my API key expire?**  
No. A free Gemini API key does not expire as long as you keep your Google account active.

**Q: Will Google charge me?**  
No — unless you manually upgrade to a paid plan inside Google AI Studio. The free tier is fully sufficient for school use.

**Q: Can I use the same key for multiple computers in the school?**  
Yes. You can copy the same key and paste it into Nexus Scholar on every computer in your school network.

**Q: Is my school data sent to Google?**  
Only the **relevant text from your uploaded documents** (the matching paragraph) and your **question** are sent. No student names, fees, attendance records, or personal data are ever included in an AI request.

**Q: What if I don't want to use AI at all?**  
Simply leave the API Key field blank. Nexus Scholar will still search your documents and show you the most relevant paragraphs — just without the AI-written summary.

---

## Supported Document Types

| Format | Extension | Notes |
|--------|-----------|-------|
| PDF | `.pdf` | Recommended for handbooks, fee schedules |
| Word Document | `.docx` | Recommended for policies, circulars |
| Plain Text | `.txt` | Useful for quick knowledge entries |

> 📌 Indexed documents are stored **locally on your computer**. They are not uploaded to any server.

---

*Last updated: May 2026 — Nexus School OS v2.3 Diamond*
