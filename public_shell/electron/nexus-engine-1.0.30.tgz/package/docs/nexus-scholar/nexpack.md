# NexPack — Premium Content System

## Overview

The NexPack system allows Nexus School OS to seamlessly import bulk premium question banks (such as JAMB, WAEC, or NECO past papers) securely. These premium packs are distributed as encrypted `.nexpack` files.

Once installed, NexPack banks are treated specially by the system:
- **Locked Interface**: To prevent content leaking, the Question Bank library will only display a 5-question preview.
- **Export Disabled**: The 'Export to CSV' and 'Print' functions are fully blocked for premium banks.
- **Full Exam Access**: Despite the UI restrictions, the Nexus CBT engine has full access to the premium bank and can construct exams, shuffle questions, and grade students normally.

---

## 1. How to Install a Premium Pack

1. Open **Nexus School OS** and navigate to the **CBT Arena** (💎).
2. Click the **Settings (⚙️)** icon in the top right of the CBT header.
3. In the sliding panel, locate the **"Install Premium Pack (.nexpack)"** section.
4. Click **Select File** and browse to the `.nexpack` file you received.
5. The system will decrypt, verify, and import the questions. You will see a progress bar indicating the import status.
6. Once complete, your new premium bank will appear in the **Question Banks** list with a 🔒 (Lock) badge.

---

## 2. Managing Annual Updates

Exams like WAEC and JAMB release new questions annually. Installing an update pack works exactly the same way as the initial install.

The Nexus engine uses **Smart Upsert Technology**:
- It mathematically identifies questions you already have.
- It safely ignores duplicates.
- It seamlessly appends only the new questions to your existing premium bank.
- Your existing live exams remain unbroken.

---

## 3. Creating Your Own Content (Administrators & Creators)

If you are a content creator looking to generate `.nexpack` files, the absolute easiest and free workflow leverages Google AI Studio.

### Step A: Free Question Extraction
1. Go to [aistudio.google.com](https://aistudio.google.com) (free, using Gemini 1.5 Pro).
2. Upload your past-paper document (PDF/DOCX).
3. Use the following prompt to extract questions:
   > "Extract all MCQ questions from the attached past-question document and return them as a JSON array following this schema:
   > `[{ "question_text": "...", "option_a": "...", "option_b": "...", "option_c": "...", "option_d": "...", "correct_option": "A", "marks": 1, "difficulty": "medium" }]`"
4. Save the JSON output to a file (e.g., `WAEC_Econ_2010.json`).

### Step B: The NexPack CLI Builder
To package your JSON files into a secure `.nexpack`:
1. Place all your extracted JSON files into a single folder.
2. Open your terminal at the root of the Nexus project.
3. Run the CLI builder tool:
   ```bash
   node nexpack-builder.js "WAEC Economics" path/to/json/folder
   ```
4. The tool will automatically encrypt the data and generate `WAEC_Economics.nexpack` ready for distribution.

---

*Last updated: May 2026 — Nexus School OS v2.3 Diamond*
