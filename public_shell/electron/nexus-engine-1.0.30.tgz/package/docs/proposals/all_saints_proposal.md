# NEXUS SCHOOL OS — Product Proposal

_Prepared exclusively for All Saints International School_
_Nexus School OS — June 2026_
_Confidential_

---

## A Message to the Leadership of All Saints International School

Thank you for the time you gave us during our visit. This proposal has been prepared specifically for All Saints International School, and it outlines two clear paths to bringing Nexus School OS into your institution — one designed for schools that want to move immediately, and one designed for schools that want to start at their own pace and scale up.

Both options solve the same core problems your school faces today. The difference is in how much of the platform you access and when.

---

## What Is Costing Your School Right Now

Every term your school operates without a proper system, it absorbs preventable losses that compound silently.

| Problem                                        | Annual Cost to Your School         |
| ---------------------------------------------- | ---------------------------------- |
| Grade disputes & result manipulation           | ₦600,000 – ₦1,000,000 per incident |
| Manual admin processing (60-120 hrs/term)      | ₦450,000 – ₦900,000 / year         |
| Cloud subscription fees (foreign servers)      | ₦240,000 – ₦960,000 / year         |
| Printing waste — drafts, reprints, corrections | ₦360,000 – ₦750,000 / year         |
| **TOTAL PREVENTABLE ANNUAL LOSS**              | **₦1,650,000 – ₦3,610,000 / year** |

---

## Your Two Options

Nexus School OS gives All Saints International School two clear entry points. You choose what fits your school today.

| Feature                                     | Standalone Pack (₦45,500 Once) | Full Subscription Plans (Silver / Gold / Diamond)                       |
| ------------------------------------------- | ------------------------------ | ----------------------------------------------------------------------- |
| **DATABASE & SECURITY**                     |                                |                                                                         |
| Student Records Management                  | YES                            | YES                                                                     |
| Class Structure Configuration               | YES                            | YES                                                                     |
| Teacher Directory / Allocation              | -                              | YES                                                                     |
| Offline-First — No Internet Required        | YES                            | YES                                                                     |
| SQLCipher AES-256 Encryption                | YES                            | YES                                                                     |
| Dynamic Lock Screen & Sudo PIN Protection   | YES                            | YES                                                                     |
| **RESULT GENERATION (REPORT CARDS)**        |                                |                                                                         |
| High-Speed Batch Generation (500 in 4s)     | YES                            | YES                                                                     |
| Custom School Branding, Logo & Signature    | YES                            | YES                                                                     |
| Passport Photo Report Cards (`class_photo`) | YES                            | YES                                                                     |
| Premium Multi-Page Report Card Layouts      | YES                            | YES                                                                     |
| **MOBILE SYNC & TERMINALS**                 |                                |                                                                         |
| Android Companion App                       | YES (Admin Extension mode)     | YES (Role-Based Staff mode)                                             |
| Device Pairing Limit                        | **Max 2 Devices**              | **Unlimited Devices**                                                   |
| Local LAN Wi-Fi Sync (Zero Internet)        | YES                            | YES                                                                     |
| Grade Entry & Sync via mobile               | YES (Full School Admin view)   | YES (Class / Subject restricted per teacher)                            |
| Device-Attributed Audit Logs                | YES                            | YES                                                                     |
| **ADVANCED MODULES**                        |                                |                                                                         |
| Attendance Tracking & Registers             | -                              | Gold & Diamond (🥇/💎)                                                  |
| Financial Hub & Ledger System               | -                              | Gold & Diamond (🥇/💎)                                                  |
| WhatsApp Fee Automation (Nexus Pulse)       | -                              | Gold & Diamond (🥇/💎)                                                  |
| Sovereign Parent Portal                     | -                              | Gold & Diamond (🥇/💎)                                                  |
| CBT Exam Automation (CBT Arena)             | -                              | Diamond only (💎)                                                       |
| AI-Powered Comments (Nexus Scholar)         | -                              | Diamond only (💎)                                                       |
| **SUPPORT & UPDATES**                       |                                |                                                                         |
| Direct Founder WhatsApp Support             | YES                            | YES                                                                     |
| Security & Maintenance Updates              | YES                            | YES                                                                     |
| Sovereign Support Shield (S3)               | -                              | YES                                                                     |
| **PRICING**                                 |                                |                                                                         |
| One-time / Setup Cost                       | ₦45,500 — once, forever        | ₦100,000 – ₦250,000 IDT (₦45,500 deducted if upgrading from Standalone) |
| Recurring Cost                              | **None**                       | ₦250 – ₦750 per student / per term                                      |

---

## Our Recommendation for All Saints International School

We recommend beginning with the **Standalone Pack at ₦45,500**. Alternatively, if you would want the job to be less stressful on the admin who would be in charge of the system and allow you to connect all your teachers to handle their individual classes begin with the **Silver plan at ₦100,000** (we have a running 20% discount that has 2 slots left if you're coming onboard before August 2026).

It gives your school immediate access to core student management, premium result card compilations (including student passport photos, signatures, and custom logos), and local Wi-Fi sync for up to 2 Admin devices with zero recurring subscription fees.

When you are ready to expand—unlocking the teacher directory, unlimited companion devices, daily attendance registers, financial ledgers, or the Sovereign Parent Portal—your **₦45,500 is deducted in full** from the Setup/IDT fee of whichever subscription plan you choose to upgrade to.

_You do not lose a single Naira. The Standalone Pack is your bridge, not your destination._

---

## FOUNDER COHORT OFFER — FIRST 10 SCHOOLS ONLY

The Standalone Pack is available to All Saints International School at **₦45,500** — a promotional discount off our standard ₦100,000 pricing — exclusively as part of our Founder Cohort of the first 10 schools. This offer closes permanently when the 10th school signs.

---

## See Nexus School OS in Action

We have produced a complete video library showing every feature of Nexus School OS — from first setup to generating your school's result sheets. Watch the full playlist here:

**[Watch the Nexus School OS Video Guides](https://youtube.com/playlist?list=PLek9Ug3kYHno)**

---

## Next Step

To proceed with the Standalone Pack for All Saints International School, simply reach out directly on WhatsApp or call the number below. We will handle setup at a time convenient for your school.

| Contact Person                                           | Contact Info                                                                                                                                                                |
| -------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Bright Atsighi**<br>Founder, Nexus Infrastructure Ltd. | **WhatsApp/Call**: +234 706 632 4306<br>**Web**: [sch.nexusos.com.ng](https://nexusos.com.ng)<br>**LinkedIn**: [linkedin.com/in/brytebee](https://linkedin.com/in/brytebee) |

---

_We look forward to serving All Saints International School._
