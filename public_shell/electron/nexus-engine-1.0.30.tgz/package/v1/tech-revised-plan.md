# 🚀 Nexus School OS — V1 Technical Execution Plan (The "MVP Gold" Release)

*Prepared by: Nexus Lead Engineering, QA, UI/UX & Growth Team*

## Strategic Objective
To deliver the core value proposition of Nexus—secure offline grading, rapid sync, and beautiful automated report cards—in the shortest timeframe possible. We are ruthless about Scope Creep. If it does not help a teacher enter a grade or a principal print a report card, it is pushed to V2.

## 🏗️ Phase 1: The Data Foundation (Backend)
**Target:** 2 Days
* **The Goal:** Replace the fragile in-memory array with a robust, relational `better-sqlite3` local database on the Electron host.
* **Key Tasks:**
  1. Initialize `nexus.sqlite`.
  2. Map out `students`, `teachers`, `teacher_allocations` (to handle JSS1 Math, JSS2 Physics, etc.), and `sync_logs`.
  3. Upgrade the `csv-parser` to properly seed these relational tables, maintaining data integrity.

## 📡 Phase 2: The Neural Network (Sync & Comms)
**Target:** 2 Days
* **The Goal:** Seamless, subject-aware data transfer between Laptop and Android.
* **Key Tasks:**
  1. Re-write the `/handshake` endpoint so a scanned Android device receives ONLY the students and subjects strictly assigned to that `Teacher_ID`.
  2. Implement the `SyncEvent` queue receiver on Electron so incoming grades securely map to the exact `[Student] + [Subject] + [Term]` slot.

## 📱 Phase 3: The Teacher's Workflow (Android UI/UX)
**Target:** 3 Days
* **The Goal:** A beautifully simple, subject-tabbed Android grading interface.
* **Key Tasks:**
  1. Migrate Android Room DB to support `subject` tracking per student.
  2. Build the Jetpack Compose `Focus Mode` grading cards.
  3. Ensure every grade entered immediately writes to the offline `sync_queue` Room table before being broadcasted.

## 🖨️ Phase 4: The Principal's Grand Finale (Reporting & PDF)
**Target:** 2 Days
* **The Goal:** The ultimate "Wow" factor. One-click, branded PDF generation.
* **Key Tasks:**
  1. Build the Headless PDF Generator using Electron's `webContents.printToPDF()`.
  2. Inject the dynamic `identity.json` (School Logo, Primary Color, Principal Signature) into the HTML template before snapshotting.
  3. Add the "Grading Philosophy Toggle" (Ranking vs. British Systems).

## 🔒 Phase 5: The Vault (Security & Licensing)
**Target:** 1 Day
* **The Goal:** Protect the hardware, lock the data, and secure the revenue.
* **Key Tasks:**
  1. Wire the Android Biometric Prompt to cold-starts.
  2. Implement the hardware-bound License Token validator (`Ed25519`) in Electron to enforce the Silver/Gold/Diamond tiers.

---

## 🚦 Execution Workflow (The Prompt System)
To maintain velocity, I have generated **10 sequential prompts** located in `./prompts/1.md` through `10.md`. 
As the Lead Engineer, you will feed these prompts back to the AI consecutively. Each prompt is designed to *verify* the previous work (QA), *implement* the next vertical slice (Engineering), and ensure it fits the *aesthetic* (UI/UX).
