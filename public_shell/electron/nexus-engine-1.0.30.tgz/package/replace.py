import os
import re

d = "/Users/MAC/Documents/Projects/nexus-school/private_engine/assets/templates"

tpls = {
    'prestige': {'tp': '#0a192f', 'ts': '#14532d'},
    'azure':    {'tp': '#1a2d5a', 'ts': '#4a7fd4'},
    'royal':    {'tp': '#0d1f4e', 'ts': '#b8960c'},
    'monarch':  {'tp': '#1b3a4b', 'ts': '#4ecdc4'},
    'sovereign':{'tp': '#0d1f4e', 'ts': '#b8960c'},
    'sterling': {'tp': '#0d1f4e', 'ts': '#b8960c'},
    'apex':     {'tp': '#2d1060', 'ts': '#b8960c'}
}

for name, colors in tpls.items():
    fp = os.path.join(d, f"{name}.hbs")
    if not os.path.exists(fp): continue
    
    with open(fp, 'r') as f:
        content = f.read()
        
    def repl(string, hexstr, varname):
        return re.sub(hexstr, f"{{{{{varname}}}}}", string, flags=re.IGNORECASE)

    content = repl(content, colors['tp'], 'tp')
    content = repl(content, colors['ts'], 'ts')

    # Specifics
    if name in ['royal', 'sovereign', 'sterling', 'apex']:
        content = repl(content, '#f5d020', 'ts')
        content = repl(content, '#c8980c', 'ts')
        content = repl(content, '#7a5c00', 'ts')
        content = repl(content, '#280e55', 'tp')
        content = repl(content, '#3d1a6e', 'tp')
    if name == 'azure':
        content = repl(content, '#eff6ff', 'transparent')
        content = repl(content, '#0f172a', 'tp')
        content = repl(content, '#1e293b', 'tp')
        content = repl(content, '#3b82f6', 'ts')
        content = repl(content, '#38bdf8', 'ts')

    with open(fp, 'w') as f:
        f.write(content)
    print(f"Updated {name}")
