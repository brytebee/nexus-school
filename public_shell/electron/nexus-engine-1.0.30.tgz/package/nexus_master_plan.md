# 🏫 Nexus School OS — Master Product & Engineering Plan

# (Strategic Infrastructure Partner Edition)

> **Vision:** Nigeria's first premium, sovereign, offline-first school OS. We don't just sell software — we deliver Institutional Sovereignty.

> **Positioning:** We are not a vendor. We are a **Strategic Infrastructure Partner.**

---

## 📂 Engineering Execution Documents

> This master plan sets product strategy, business model, and tier definitions.
> All active engineering execution is tracked in the documents below.

| Document | Purpose |
| --- | --- |
| [`docs/tasks/react-migration.md`](docs/tasks/react-migration.md) | **#1 Priority** — Full frontend architecture migration from 2,500-line `index.html` to React + Vite. Strangler-fig approach, phase-by-phase. |
| [`docs/tasks/version2_dev.md`](docs/tasks/version2_dev.md) | V2 feature tracker — live feature audit, coming soon items, missing features, test suite plan, RBAC, Technician Console, and recommended build order. |
| [`docs/tasks/student-exit-status.md`](docs/tasks/student-exit-status.md) | Student exit status specifications (expulsion, repeat, withdrawal, demotion) and roster sync filtering. |
| [`docs/tasks/letterhead-builder.md`](docs/tasks/letterhead-builder.md) | Official letter builder and custom letterhead customization canvas. |
| [`docs/tasks/archive-transcripts-registry.md`](docs/tasks/archive-transcripts-registry.md) | Student transcripts archive, statement of results, and official certificates layout generation. |
| [`docs/tasks/nexus-transfer-badge.md`](docs/tasks/nexus-transfer-badge.md) | Cryptographic offline QR Transfer Badge and 3-Party Split-Token Protocol design spec. |

> **Read these two documents before writing any new code.**

---

## 🎯 The Product in One Sentence

Nexus lets school admins manage classes and branding on a laptop, lets teachers grade offline from their phones, syncs securely over local Wi-Fi ("The Marriage"), and backs up quietly to the school's Google Drive whenever connectivity exists — all without a single byte of student data leaving their compound.

---

## 🧭 Executive Context

| Dimension               | Decision                                                                 |
| ----------------------- | ------------------------------------------------------------------------ |
| **Mobile Stack**        | Kotlin (Native Android — Jetpack Compose)                                |
| **Desktop Stack**       | Electron.js + Node.js/Express + SQLite                                   |
| **Sync Protocol**       | Zero-Config LAN (Standard) / Cloud Relay (Pro) / Hub Hotspot (Emergency) |
| **Primary Market**      | Nigerian private/private-aided schools                                   |
| **Positioning**         | Strategic Infrastructure Partner                                         |
| **Networking**          | LAN-focused: Connect via Local IP/Hotspot (No Internet needed)           |
| **Security Philosophy** | Hardware-bound, biometric-locked, cryptographically signed               |
| **Dev Tool**            | Google Antigravity IDE                                                   |
| **Repos**               | `nexus-private-engine` (Brain) + `nexus-school` (Shell)                  |

---

## 💰 Business Model: The "Sovereign Shield" Framework

> **Core Insight:** Schools don't resist recurring fees. They resist fees they cannot justify. Frame every cost as a _mandate_, not a _subscription_.

### Fee 1: IDT — Institutional Digital Transformation (One-Time Setup)

- **What it covers:** Hardware audit, staff training, biometric device pairing, data migration, and school identity configuration.
- **Why it's high:** It is **labor-intensive**. Once paid, the school has "skin in the game" and treats the system as their own infrastructure.
- **Psychological trigger:** _"This is your school's digital transformation, not a software purchase."_

### Fee 2: Sovereign Support Shield (Termly, Per-Student)

- **What it covers:** Local-to-Cloud security bridge, 24/7 security patches, regulatory compliance (WAEC/JAMB/NECO format updates), and priority on-site support.
- **Why it's termly:** It matches the school's **cash flow** (collected with tuition fees).
- **Objection handler:** _"Buying software once is like buying a car but never changing the oil. Within a year, external exam formats change, security threats evolve, and your 'ownership' becomes a liability."_

### Revenue Safety Net Logic

- Fee Management module remains **active during payment grace periods**.
- This proves you are a partner in their financial recovery, not a "slumlord" vendor who cuts access on day 1 of a late payment.

### Pricing Variables

```js
const IDT_FEE = "Negotiable face-to-face"; // Founder school strategy
const PRICE_SILVER = 250; // ₦ per student, per term (Result Pro)
const PRICE_GOLD = 500; // ₦ per student, per term (Connected Campus)
const PRICE_DIAMOND = 750; // ₦ per student, per term (Elite Intelligence)
```

---

## 🏆 The Three Tiers

### 🥈 Silver — Result Pro

**Primary Justification:** Eliminates manual grading errors and late nights.
**Psychological Trigger:** **RELIEF** — _"No more manual calculations at midnight."_

| Module                                            | Status     |
| ------------------------------------------------- | ---------- |
| Grading & Result Entry (Desktop + Android)        | ✅ Live    |
| 8 Premium Report Card Templates                   | ✅ Live    |
| Result Color Customization                        | ✅ Live    |
| Dynamic Endorsements (Teacher/Principal Comments) | 🚧 Phase 2 |
| Teacher & Principal Signature/Stamp Management    | 🚧 Phase 2 |
| Subject Consistency (Android ↔ Desktop)           | 🚧 Phase 3 |
| Print Hub 2-Column Layout (Templates Sizable)     | ✅ Done    |
| **Staff Directory & Profiles (Basic)**            | 🚧 Phase 2 |

---

### 🥇 Gold — Connected Campus

**Primary Justification:** Enhances parent engagement and digital presence.
**Psychological Trigger:** **ENGAGEMENT** — _"Your school is always in their pocket."_

| Module                                         | Status     |
| ---------------------------------------------- | ---------- |
| Parental Access & Student Portal (Local Wi-Fi) | 🔮 Phase 6 |
| Google Drive Backup (Local-to-Cloud Bridge)    | 🔮 Phase 5 |
| Assignments Module                             | 🔮 Phase 6 |
| Quiz Software                                  | 🔮 Phase 6 |
| Class Attendance                               | 🔮 Phase 5 |
| **WhatsApp Bot "Nexus Pulse"**                 | 🔮 Phase 5 |
| **Student Public Profile (Verified Record)**   | 🔮 Phase 6 |

---

### 💎 Diamond — Elite Intelligence

**Primary Justification:** Financial dominance and academic excellence.
**Psychological Trigger:** **PRESTIGE & GROWTH** — _"The best school in the region uses this."_

| Module                                       | Status     |
| -------------------------------------------- | ---------- |
| **Fee Management & Payment Tracking**        | 🚧 Phase 5 |
| **Financial Ledger & Fee Shield**            | 🚧 Phase 5 |
| **Local CBT & CBT-as-a-Service**             | 🔮 Phase 7 |
| Analytics Dashboard (WAEC/JAMB/NECO prep)    | 🔮 Phase 7 |
| "At-Risk" Student Flagging (Grade Drop ≥20%) | 🔮 Phase 7 |
| Mobile Admin App ("Command Center")          | 🔮 Phase 7 |
| Voice-to-Grade                               | 🔮 Future  |
| Multi-Campus Sync                            | 🔮 Future  |
| **CBT-as-a-Service (External Candidates)**   | 🔮 Phase 7 |
| **Skill Mastery Tracking (IEP Adaptation)**  | 🔮 Phase 7 |
| **Student Pulse (Welfare/Bullying Monitor)** | 🔮 Phase 8 |
| **System Auth & Lock Screen (Multi-Admin)**  | 🔮 Phase 9 |

---

## 🥇 Gold Plan Strategy: The "Connected Campus"

> **Goal:** Activate Gold as a revenue-generating, parent-facing tier that pays for itself in the first term.

### 🧩 Strategic Implementation (The Phased Rollout)

1. **GOLD PHASE A — Foundation (Attendance & Auth)**
   - **Daily Attendance (Android Tap):** Teachers mark attendance in class; syncs to Hub. Summary auto-injects into report cards.
   - **Local Network Broadcaster:** The Hub hosts a local server (Port 3001) for parent results/attendance lookup via Wi-Fi.

2. **GOLD PHASE B — The Revenue Engine (Nexus Pulse)**
   - **"Office-Hours" Bot:** Local WhatsApp bot runs on the Desktop Hub. 100% free; requires laptop to be on. (✅ Done)
   - **"Always-On" Cloud Bridge:** Diamond-tier background sync to Google Drive with AES-256 encryption. (✅ Done & Hardened)
   - **Lightweight Fee Entry:** Allows Gold schools to enter student balances so the bot can mention them to parents.

3. **GOLD PHASE C — The Parent Portal**
   - **Local Read-Only Portal:** Parents connect to the school's local Wi-Fi and view their child's latest results, attendance, and fee status.
   - **Parent QR Access:** Admin prints a QR per student; one scan opens the child's portal instantly.

4. **GOLD PHASE D — Prestige & Marketing**
   - **Assignment Hub:** Teachers assign; parents/students see tasks on the portal.
   - **Verified Public Profiles:** School-curated academic highlights hosted on the Nexus cloud for parents to share (marketing flywheel).

---

## 💎 Diamond Plan: Always-On Cloud Bridge

> **The "Senior Engineer" Architecture:** We separate the **Sovereign Hub** from the **Always-On Cloud**.

### 🔌 Separation of Concerns
In the Always-On manual test, the **WhatsApp Business API** does not touch the local school laptop. This is by design:
1. **The Desktop Hub (Local):** Acts as a secure data source. It encrypts the DB into `pulse_cache.enc` and pushes it to the school's Google Drive. It is **stateless** and does not need to handle incoming WhatsApp webhooks.
2. **The Cloud Worker (Vercel):** This is where the **Meta WhatsApp Cloud API** resides. It receives parent messages, reads the `pulse_cache.enc` from the school's Drive, decrypts it using the **Pulse Security Key**, and replies 24/7.

#### 🛠 Cloud Worker Build Specification
- **Runtime**: Node.js 20 (Serverless).
- **Core Dependencies**: `googleapis` (Drive Access), `crypto` (AES-256 decryption), `axios` (Meta Graph API calls).
- **State**: 100% Stateless. Tokens are refreshed on-the-fly using the `refresh_token` stored in the encrypted snapshot or environment variables.
- **Security**: AES-256-GCM decryption happens in memory. No student data is ever written to the cloud worker's disk.
- **Verification**: Implements X-Hub-Signature validation to ensure requests only come from Meta.

**Why this matters:**
- **Zero Liability:** We don't store student data; it stays in the school's Drive.
- **Resilience:** If the school laptop is off, the cloud worker can still answer because it has the latest encrypted snapshot.
- **Cost Efficiency:** No expensive 24/7 server hosting for the school.

---

---

## 🔒 Security Architecture — "The Vault"

### Zero-Knowledge Protocol

- **Market Message:** _We cannot see your financial records or exam questions. The school owns the keys. We provide the vault._
- All grade data encrypted at rest (SQLCipher / better-sqlite3 encrypted).
- Master records never touch a public cloud server without school consent.

### The "Marriage" Handshake

1. Electron generates QR: `{ sid, ip, port, handshake_key, config }`
2. Kotlin scans, generates device UUID + public key
3. Admin approves device via **Teacher Name Dropdown** (no manual Device ID entry)
4. All grade packets are digitally signed by device private key
5. Electron rejects packets from any non-whitelisted device

### Payment Lock — "Date-Proof" License

1. Developer-signed license token: `{ expiry, tier, school_id, student_count }`
2. Signed with developer's Ed25519 private key
3. Electron validates on boot using embedded public key
4. **Date-Drift Detection:** Clock rollback → immediate lock
5. **Hardware Binding:** Tied to laptop motherboard serial
6. `DEV_MODE=true` and `DEV_MOCK_TIER` in `.env` bypasses ALL checks during development and ensure you can test all features for each tier.

> ⚠️ **Non-Negotiable:** `DEV_MODE=true` and `DEV_MOCK_TIER` must always be present in the developer's local `.env` file to prevent self-lockout during active development and testing.

---

## 🌿 Engineering Management: Branching Strategy

> **Rule:** Never demo from an unstable branch. Never develop on `main`.

| Branch         | Purpose                                                 | Who can merge to `main`?          |
| -------------- | ------------------------------------------------------- | --------------------------------- |
| `main`         | **STABLE — Demo Ready.** Launch this for school owners. | Only after full smoke test.       |
| `nexus-shield` | Active development: License/Payment/Tier enforcement.   | After `DEV_MODE` bypass verified. |
| `ui-relief`    | Print Hub 2-col layout, Stamp, Android fixes.           | After local visual QA.            |
| `feature/*`    | Any other isolated feature work.                        | After review + smoke test.        |

### "Demo Ready" Checklist (before promoting to `main`):

- [ ] App launches without errors.
- [ ] Demo data: 15 students, 3 tracks, multi-session grades visible.
- [ ] At least one report card generates successfully.
- [ ] `DEV_MODE=true` confirmed in `.env`.

---

## 📐 Technical Achievements (Current State)

| Component                                           | Status |
| --------------------------------------------------- | ------ |
| Electron local server + IP detection + QR           | ✅     |
| Android QR scanner & "Marriage" handshake           | ✅     |
| Android biometric lock & thermal monitor            | ✅     |
| Identity Forge (Settings, Logos, Colors)            | ✅     |
| CSV ingestion & mapping                             | ✅     |
| 8 Premium PDF Report Card Templates                 | ✅     |
| Self-Healing DB Auto-Repair (15 students, 3 tracks) | ✅     |
| SQLite Dependency Injection (Windows/Mac parity)    | ✅     |
| Robust Temp-File PDF Rendering (Windows)            | ✅     |
| Teacher Allocation & Subject-Filtered Grading       | ✅     |

---

## 🚦 Build Priority — V2 Order

> **V2 Philosophy:** Guard what works. Modernise the foundation. Then build.
> Full execution detail in [`docs/tasks/version2_dev.md`](docs/tasks/version2_dev.md).

### ✅ COMPLETE — V1 Core (All phases shipped)

| Phase | What Shipped |
| --- | --- |
| Phase 2 | Print Hub 2-col layout, Template sizable preview, Dynamic comments, Form mentor, Seal engine, Logo in Settings, Revocation UX, Result Color |
| Phase 3 | School Logo on Android, Focus Mode fix, Premium Student Cards, Subject Tab fix, Ping Hub, Electron JS Refactor (9 modules) |
| Phase 4 | License Token (Ed25519), Token Validator, DEV_MODE Bypass, Feature Masking, Expiry Screen, Date-Drift Detector, Hardware Binding, Revenue Safety Net |
| Phase 5–6 | Attendance (Gold), Nexus Pulse (Gold), Financial Hub (Gold), Sovereign Portal (Gold), Portal Content (Gold), Nexus Scholar (Diamond), CBT Arena (Diamond) |

---

### 🔐 NOW — Test Suite (Guard Rails Before Migration)

Extract all business logic into pure `src/lib/` modules and write Vitest tests.
Every working feature guarded before any React migration begins.

**See:** [`docs/tasks/version2_dev.md § Test Suite`](docs/tasks/version2_dev.md)

### ⚛️ PHASE R — React Migration (Foundation for All V2 Features)

Full details in the dedicated migration document.

**See:** [`docs/tasks/react-migration.md`](docs/tasks/react-migration.md)

Summary: Strangler-fig migration via `.env` toggle. Phase 0 (Vite scaffold) →
Phase 1 (Design System) → Phase 2 (Views) → Phase 3 (Portal) → Phase 4 (CBT).

### 👥 PHASE R+1 — User Roles (RBAC)

Multi-admin support: Principal, Bursar, Form Teacher, Result Clerk, IT Admin.
Built in React (NavSidebar component). **See:** `version2_dev.md § User Roles`

### 🔧 PHASE R+1 — Technician Console

Scoped license-generation portal for field technicians. Signing secret stays
on server. Full audit log. **See:** `version2_dev.md § Technician Console`

### 🌐 PHASE 6 — Missing Gold Features (Promised to Customers)

Verified Student Public Profiles, Digital Assignment Hub, Parent Portal admin view.

### 💎 PHASE 7 — Diamond Coming Soon Features

Live Quiz Arena, Analytics Dashboard (At-Risk flagging, WAEC/JAMB prep),
Skill Mastery Tracking (IEP standard), Mobile Admin Command Center,
Biometric Staff Attendance, Exam Hall Clearance QR, Fee Pulse (on-demand WhatsApp).


#### 🔍 Feature Deep-Dive: Granular Subject-Level Attendance (Truancy Detection)
*To be built as a Diamond-exclusive enterprise feature.*
Unlike standard K-12 "Form Teacher Roll Call" which only answers *"Is the student on the premises?"*, Subject-Level Attendance tracks granular curriculum engagement. It shifts the responsibility from Form Teachers to Subject Teachers, answering the critical question: *"Is the student actually engaging with the curriculum?"* (identifying if a student is physically in the school building but skipping specific classes).

**Architectural Strategy (Hybrid Mode):**
We support this without alienating traditional schools via a Super Admin "Attendance Tracking Mode" toggle:
- **Mode A (Standard - Silver/Gold):** Form Teacher Roll Call. Binary daily presence stored in `daily_attendance`.
- **Mode B (Granular - Diamond):** Subject Teacher Roll Call. Introduces a `subject_attendance(student_id, subject_id, date, status)` schema. The Report Compiler aggregates attendance *per subject* instead of globally, injecting individual attendance metrics into each subject's score breakdown on the report card (e.g., `Math: 80%, Att: 14/15`).

### 🌐 PHASE 8 — Community & Welfare

Student Pulse, Parent Q&A Bot, Multi-Campus.

### 🚀 PHASE 9 — Zero-Touch Onboarding & Automated Distribution (Future)

Fully automated system for scaling without direct contact. Schools can download the Desktop OS and Android apps from a public landing page, select their tier, make an online payment, and instantly receive a cryptographically signed `license.nexus` file mapped to their hardware fingerprint—enabling seamless, self-serve onboarding.

---

## 🛠 Custom Features / On-Demand Features (Strategic Upsells)

> **Philosophy:** High-touch features that solve specific "Pain Points" for school owners and justify premium service contracts.

### 1. Biometric Staff Attendance (The Punctuality Shield)
- **Concept:** Automated sign-in/sign-out for all staff members.
- **Hardware:** External USB/Type-C Fingerprint Scanners connected to a PC or Tablet.
- **Workflow:** Staff members scan their fingerprint on arrival and departure. The system records a timestamped entry in the `staff_attendance` table.
- **Reporting:** Monthly "Staff Punctuality Report" for the Principal, showing late arrivals and total hours worked.

### 2. Dynamic Fee Reminders (The Financial Pulse)
- **Concept:** Instant, on-demand WhatsApp/SMS reminders for outstanding balances.
- **Workflow:** School owners or admins can trigger a "Fee Pulse" at any time. The system identifies all students with a balance > 0 and sends a personalized reminder via Nexus Pulse.
- **Psychological Trigger:** Allows owners to drive revenue recovery during poor cash-flow periods without waiting for automated term-end reminders.

### 3. Exam Hall Clearance QR (The Gatekeeper)
- **Concept:** Digital "Examination Pass" generated only for students who have cleared their fees.
- **Workflow:** On exam day, staff scan a student's ID card. If the student is a debtor, the portal shows a "RED: PAYMENT REQUIRED" screen. If cleared, it shows "GREEN: PROCEED TO HALL".

---

## 🔮 Coming Soon (Version 2 Roadmap)

> **Philosophy:** Features that require deeper infrastructure, significant historical data, or high user maturity. Deferred to Version 2 to ensure Day-1 stability of core operations.

### 🥇 Gold Expansion
- **Digital Assignment Hub:** Teachers create tasks on the desktop, and parents/students view and submit them via the portal. (Deferred because it requires high Day-1 teacher adoption to be useful).
- **Verified Student Public Profiles:** Public, shareable URLs hosting curated academic achievements for word-of-mouth marketing. (Deferred as it requires cloud infrastructure and public DNS routing).

### 💎 Diamond Enterprise Features
- **Advanced Analytics Dashboard:** Elite metrics including At-Risk student flagging (grade drop ≥20%), subject heatmaps, and WAEC/JAMB readiness. (Deferred until schools accumulate 2-3 terms of data).
- **Nexus Notes Marketplace:** A digital storefront for teachers to sell curated study materials. (Deferred due to complex payment gateway requirements).
- **Skill Mastery Tracking:** International IEP-standard academic progress tracking beyond simple CA/Exam scores.
- **Student Pulse:** A welfare and bullying monitoring module to track non-academic student well-being.
- **Mobile Admin Command Center:** A dedicated mobile app for the principal to control the Hub remotely.

### 🚀 Future Infrastructure (Phase 9/10)
- **System Auth & Lock Screen (The Vault):** Multi-admin authentication and idle-timeout locks on the Desktop Hub to create an audit trail for who recorded specific fee or attendance entries.
- **Multi-Campus Sync:** Cloud synchronization to manage multiple school branches from a single unified dashboard.
- **Voice-to-Grade:** Audio-based dictation for rapid score entry on the Android app.
- **Zero-Touch Onboarding:** An automated landing page where schools pay, download the software, and receive their cryptographically signed hardware license instantly.

---

## 🎬 Demo Script — "5 Minutes to Close"

1. Open Electron. Set school name + colors in front of the principal.
2. Load demo data — 15 students, 3 tracks visible.
3. Navigate to Print Hub. Show the **2-column template preview** — _"See your school's branding right here."_
4. Hand the Android phone to a teacher. They enter 5 grades.
5. Point at the laptop — grades appear live (The Pulse).
6. Generate one report card. Show the premium template with logo + stamp.
7. Lock the phone. Show fingerprint required to re-enter.
8. Say: _"Sir, your data never left this room. That's the Nexus Sovereign Shield."_

---

_Built with Google Antigravity IDE — Nigeria's first premium offline School OS._
_Strategic Infrastructure Partner Edition — v2.0_
