# NEXUS SCHOOL OS — Landing Page Blueprint

> **Vibe:** "The Apple of Education Software"
> **Emotions:** Elite, Bulletproof, Effortless, Trustworthy
> **Target Audience:** Premium Nigerian Private School Owners & Tech-forward Principals

---

## 🎨 1. Design & Aesthetic Guide

**Color Palette:**
* **Background (Void):** `#05081A` (Deepest Navy, almost black. Gives a premium, intense tech feel.)
* **Primary Accent (Nexus Indigo):** `#1A237E` (Used for primary buttons and soft glowing backgrounds.)
* **Secondary Accent (Electric Green):** `#00E676` (Used for "Eco-Guardian" highlights, checkmarks, and success states.)
* **Text (Primary):** `#FFFFFF` (Crisp white for high-contrast readability.)
* **Text (Muted):** `#8C9EFF` (Soft, icy blue for subtitles and secondary text.)

**Typography:**
* **Headings:** `Inter` or `SF Pro Display`, Extra Bold (800 weight), tight letter spacing (`-0.03em`).
* **Body:** `Inter`, Regular (400 weight), relaxed line height (`1.6`).
* *Pro tip: Make your H1 massive. Let the words breathe.*

**UI Magic / Micro-interactions:**
1. **Glassmorphism:** Use blurred `.backdrop-filter` cards `rgba(255,255,255, 0.03)` with `1px` subtle white borders.
2. **Glows:** The main CTA buttons should have a soft `#1A237E` drop-shadow glow.

---

## 🏗️ 2. The Page Structure & Copy

### Section 1: The Hero (Above the Fold)
* **Goal:** Instant authority. Hook them with the ultimate benefit.
* **Layout:** Split screen. Left side = Copy. Right side = **The Simulator App (`nexus-app-simulator.html`)**.

**[Eyebrow / Subtitle]**
THE GOLD STANDARD IN NIGERIAN EDUCATION

**[H1 / Headline]**
**Bank-Grade Security.** 
**Zero Internet Required.**

**[Body]**
Nexus School OS is the offline-first nervous system for premium private schools. End "Grade Expo." Eliminate your printing budget. Process 500 report cards in exactly 4 seconds — without ever connecting to the internet.

**[Primary CTA Button]**
`Request Your Private Demo` *(Links to a Calendly or contact form)*
*(Add a subtle "Hardware limits apply. Book early" below the button to create elite scarcity).*

---

### Section 2: The Core Pains (The "Why")
* **Goal:** Agitate the things that keep them awake at night.
* **Layout:** A 3-column grid of elegant Glassmorphic cards.

**[Section Header]**
**Nigerian Schools Run on Trust. Don't Lose It To An Excel Sheet.**

* **Card 1: Icon 🛑**
  * **Title:** The End of Grade Manipulation
  * **Body:** Every grade entered is timestamped, locked to a specific teacher's biometric fingerprint, and secured in an encrypted local vault. The truth is never negotiable.

* **Card 2: Icon 💸**
  * **Title:** Sancity From Data Costs
  * **Body:** Why pay exorbitant monthly cloud fees? Nexus uses localized "Marriage" tech. Teachers sync results directly to the Principal's laptop using free local Wi-Fi. 

* **Card 3: Icon 🖨️**
  * **Title:** Zero Manual Computation
  * **Body:** Your teachers enter the raw scores. Nexus calculates positions, handles ties instantly, and generates print-ready PDF-A4 report cards for the entire school in 4 seconds.

---

### Section 3: The "How It Works" (Visual Proof)
* **Goal:** Prove it's as easy as claimed.
* **Layout:** Alternating left/right image + text blocks.

**Step 1: The Marriage (Show screenshot of QR Code scanning)**
**Pair Teachers Instantly.** 
Admin uploads the student roster. Teachers point their phone at the Admin laptop. The system pairs their hardware, downloads their specific class, and locks the data behind their personal fingerprint.

**Step 2: Focus Mode Grading (Point an arrow to the interactive simulator here if needed)**
**Grade From Anywhere.**
Our proprietary "Focus Mode" lets teachers grade offline on their bus ride, during prep, or at home. 

**Step 3: The One-Click Report (Show the generated PDF report card)**
**Perfection in 4 Seconds.**
Upload termly logos and the Principal's digital signature once. Click 'Generate' and watch a folder of beautiful, branded, pristine report cards appear on your desktop.

---

### Section 4: The Tech Flex (For the Nerds / Justification of Price)
* **Goal:** Sound so advanced they feel embarrassed paying for anything less.
* **Layout:** Darker background section, technical bullet points.

**[Section Header]**
**Military-Grade Infrastructure, Built for the Principal's Desk.**

* **🛡️ Eco-Guardian Protocol:** Our app monitors device temperature in real-time. It breathes green when safe, and pauses sync if a teacher's phone overheats. We protect their hardware.
* **🔐 The Vault:** Protected by `androidx.biometric` and SQLCipher. Data at rest is encrypted so deeply that even if a phone is stolen, the data is useless.
* **📡 Burst Sync Technology:** No more "loading..." spinners. 1,000 grades sync across a room in less than 350 milliseconds over a private local area network.

---

### Section 5: Pricing Plans (Transparent & Scalable)
* **Goal:** Remove the "how much?" anxiety and make the pricing feel completely fair.
* **Layout:** 3-column card grid on a slightly lighter dark background. Highlight the **Gold** card (most popular) by making it slightly taller with a glowing Nexus Indigo border.
* **Design note:** Each card uses glassmorphism. The "Most Popular" Gold card has a `box-shadow: 0 0 40px rgba(26,35,126,0.6)` glow and a `transform: scale(1.05)` to lift it above the others.

**[Section Header]**
**A Partnership That Grows With You.**
*Pay per student, per term — just like a school should.*

---

**Plan: Silver**
> *For smaller schools finding their footing.*
* 🏫 Schools under 200 students
* **₦300/student/term**
* *(e.g. 150 students = ₦45,000/term)*
* ✅ Full offline grading suite
* ✅ PDF report card generation
* ✅ Biometric teacher security
* ✅ One-time Setup: ₦75,000

**[Button]** `Book a Demo`

---

**Plan: Gold ⭐ *(Most Popular)***
> *For established schools ready to scale.*
* 🏫 200–500 students
* **₦300/student/term**
* *(e.g. 400 students = ₦120,000/term)*
* ✅ Everything in Silver
* ✅ Priority on-site technical support
* ✅ Eco-Guardian thermal monitoring
* ✅ One-time Setup: ₦100,000

**[Button — Highlighted/Glowing]** `Book a Demo`

---

**Plan: Diamond**
> *For multi-campus schools and group schools.*
* 🏫 500+ students / multiple branches
* **Custom pricing per quote**
* ✅ Everything in Gold
* ✅ Multi-campus sync (chain Electron hubs)
* ✅ Dedicated account manager
* ✅ Custom API integrations available
* ✅ One-time Setup: Starting at ₦150,000

**[Button]** `Request a Quote`

---

**[Footnote under all 3 cards]**
*All plans are payable termly, at the start of school fees collection. Prices are per student enrolled — as your school grows, you stay on the same per-student rate.*

**[Trust Badge]**
👑 **Founder Cohort — First 10 schools only:** Setup fee waived entirely. Lock in your rate before public launch.

---

### Section 6: The Final CTA (Closing the Deal)
* **Goal:** The ultimate push to contact.
* **Layout:** Centered, massive text, glowing button.

**[H2 / Headline]**
**Stop Renting Out Your School's Most Valuable Asset.**
*Take ownership of your data today.*

**[Primary CTA Button]**
`Schedule Your Integration Demo`

**[Footer Note]**
*Nexus is currently accepting only 10 charter schools for the upcoming academic term to ensure white-glove onboarding. Secure your position.*

---

## 🚀 3. How to build this in Brytebee
1. Create a new Next.js / React page (or standard HTML if you prefer).
2. Set the global background to `#05081A`.
3. Put the hero copy on the left.
4. On the right side of the hero, embed the simulator using:
   ```html
   <div style="transform: scale(0.85); transform-origin: top center;">
       <iframe src="/assets/nexus-app-simulator.html" width="400" height="850" style="border:none; background:transparent;" scrolling="no"></iframe>
   </div>
   ```
5. Build the glassmorphic cards using CSS:
   ```css
   .glass-card {
       background: rgba(255, 255, 255, 0.03);
       backdrop-filter: blur(10px);
       border: 1px solid rgba(255, 255, 255, 0.05);
       border-radius: 24px;
       padding: 40px;
   }
   ```
