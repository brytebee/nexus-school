How should I prompt the upgrade of this page to give an elegant, proofessional and premium. look responsive across devices. Readable and yet maintain a silicon valley, world class structure and feel.

Great question. Here's how I'd structure the ideal prompt to get a world-class result in one shot:

---

## 🎯 The Ideal Prompt Template

```
You are a world-class Silicon Valley UI/UX engineer and visual designer.
Upgrade the Nexus School OS landing page (app/nexus-school-os/page.tsx)
to be elegant, premium, and production-ready.

**Core Design Philosophy:**
- Reference: Linear.app, Vercel.com, Stripe.com, Notion.so
- Typography system: Inter variable font, tight tracking on headings (-0.03em),
  relaxed line-height on body (1.7)
- Palette: Keep existing (#05081A, #1A237E, #00E676, #8C9EFF, #FFFFFF)

**Specific Upgrades Required:**
1. TYPOGRAPHY — Create a clear 5-level hierarchy: H1 (hero, 80-96px),
   H2 (section, 48-56px), H3 (card, 28px), body (16-18px), label (11-12px,
   tracked). No two section headings should feel the same weight or size.

2. SPACING — Generous section padding (py-40 on desktop, py-24 on mobile).
   Cards should breathe — minimum 40px internal padding. No crowded elements.

3. RESPONSIVE — Truly mobile-first. No horizontal scroll at 320px.
   Hero stacks gracefully: copy on top, phone simulator below.
   All font sizes scale with clamp() or responsive Tailwind breakpoints.

4. ANIMATIONS — Subtle fade-in-up on section entry (use Tailwind animate or
   CSS @keyframes). Pricing Gold card should pulse softly on hover.
   CTA button should have a slow breathing glow animation.

5. PRICING SECTION — The Gold card should feel like an iPhone box.
   Premium. Surrounded by soft indigo light. Lift it with a deeper shadow
   and give it a visually separate background.

6. FOOTER — Expand it: add a brief product tagline, links (Privacy, Terms,
   WhatsApp), and the founder's name/handle.

**Constraints:**
- No new npm packages unless you can use a CDN
- Keep Tailwind CSS only — no inline style except where Tailwind can't do it
- The page must score 90+ on Lighthouse mobile
- All images must use Next.js <Image> with fill + sizes props
```

---

## 💡 Power Tips for Better Results

| Tip                                                      | Why it works                                             |
| -------------------------------------------------------- | -------------------------------------------------------- |
| **Name reference sites** (Linear, Stripe)                | Grounds the AI on a specific aesthetic vocabulary        |
| **Specify pixel values** for type scales                 | Prevents vague "make it bigger" output                   |
| **Call out constraints explicitly**                      | Prevents the AI from installing Framer Motion, GSAP etc. |
| **Ask for one section at a time** if the result is messy | Smaller scope = more precise execution                   |
| **Include "score 90+ Lighthouse"**                       | Forces the AI to think about performance automatically   |

---

## 🔁 Follow-up Prompt (after first pass)

```
Now do a critical review of what you just built. Look at it as if you
were a design critic at a YC Demo Day. What 3 things would embarrass
you in front of investors? Fix them now.
```

That self-critique loop is where most AI-assisted design jumps from "good" to "genuinely impressive." Want me to go ahead and execute any version of this upgrade now?

## More

Metadata & Design Iteration Plan
Objective 1: World-Class Silicon Valley Design Prompt
Rather than instantly changing your code, I will provide a prompt artifact you can feed into an image generator (like Midjourney or DALL-E) or another AI to conceptualize a Silicon Valley Demo Day overhaul for /lab/ai and /lab/ecommerce. You can use this prompt later to iterate on your visual direction!

Objective 2: Dynamic Next.js Metadata
Currently, the <title> tag is hardcoded in app/layout.tsx as "Bright Atsighi | Senior Full Stack Engineer". We need it to be dynamic based on the page (e.g., "Intelligence Hub | Bright Atsighi", "Admin - Intelligence", etc.).

User Review Required
Some of our pages (like /lab/ai/page.tsx) are marked strictly with "use client". In Next.js App Router, you cannot export metadata from a Client Component. Therefore, for these pages, I will create small parallel layout.tsx files precisely to inject the metadata.
